import java.io.ByteArrayOutputStream

plugins {
	java
	id("org.springframework.boot") version "3.3.0-SNAPSHOT"
	id("io.spring.dependency-management") version "1.1.4"
	id("au.com.dius.pact") version "4.6.5"
}

group = "com.nsl.paas.kafkastream.consumer"
version = "0.0.1-SNAPSHOT"

java {
	sourceCompatibility = JavaVersion.VERSION_17
}

repositories {
	mavenLocal()
	mavenCentral()
	maven { url = uri("https://repo.spring.io/milestone") }
	maven { url = uri("https://repo.spring.io/snapshot") }
}

dependencies {
	implementation("org.springframework.boot:spring-boot-starter")
	testImplementation("org.springframework.boot:spring-boot-starter-test") {
		exclude(group = "org.junit.vintage", module = "junit-vintage-engine")
	}
	implementation("org.springframework.boot:spring-boot-starter-web")
	testImplementation("au.com.dius.pact.consumer:junit5:4.6.5")
}
tasks {
	test {
		useJUnitPlatform()
	}

	bootRun {
		standardInput = System.`in`
	}

	register("copyPacts", Copy::class) {
		description = "Copies the generated Pact json file to the provider resources directory"
		from("build/pacts/")
		into("../provider/src/test/resources/pacts/")
	}
}
val getGitHash: () -> String = {
	val stdout = ByteArrayOutputStream()
	exec {
		commandLine("git", "rev-parse", "--short", "HEAD")
		standardOutput = stdout
	}
	stdout.toString().trim()
}

val getGitBranch: () -> String = {
	val stdout = ByteArrayOutputStream()
	exec {
		commandLine("git", "rev-parse", "--abbrev-ref", "HEAD")
		standardOutput = stdout
	}
	stdout.toString().trim()
}

pact {
	publish {
		pactDirectory = "consumer/build/pacts"
		pactBrokerUrl = "http://localhost:9292/"
		pactBrokerUsername = "pact_workshop"
		pactBrokerPassword = "pact_workshop"
		consumerBranch = getGitBranch()
		consumerVersion = getGitHash()
	}
}
