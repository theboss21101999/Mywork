package com.nsl.paas.kafkastream.consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
