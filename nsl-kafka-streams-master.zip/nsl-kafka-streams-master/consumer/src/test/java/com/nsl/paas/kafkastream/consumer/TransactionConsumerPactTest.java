package com.nsl.paas.kafkastream.consumer;

import au.com.dius.pact.consumer.MockServer;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.consumer.junit5.PactTestFor;
import au.com.dius.pact.core.model.PactSpecVersion;
import au.com.dius.pact.core.model.RequestResponsePact;
import au.com.dius.pact.core.model.annotations.Pact;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import au.com.dius.pact.consumer.junit5.PactConsumerTestExt;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.client.RestTemplate;

import static au.com.dius.pact.consumer.dsl.LambdaDsl.newJsonBody;
import static org.junit.jupiter.api.Assertions.assertEquals;
@ExtendWith(PactConsumerTestExt.class)
public class TransactionConsumerPactTest {
    private final String BASE_URL = "/api";
    @Pact(consumer = "ConsumerApplication", provider = "StreamApplication")
    RequestResponsePact getFailedGsiCount(PactDslWithProvider builder){
        String url = BASE_URL + "/gsi/failed/count/"+"gsiTest";
        return builder.given("Gsi Failed Count Test")
                .uponReceiving("get gsi with name gsiTest")
                .method("GET")
                .path(url)
                .willRespondWith()
                .status(200)
                .body(newJsonBody(object -> {
                    object.stringType("message", "Success");
                    object.integerType("result", 2);
                    object.integerType("status", 200);
                }).build())
                .toPact();
    }
    @Pact(consumer = "ConsumerApplication", provider = "StreamApplication")
    RequestResponsePact getCompletedGsiCount(PactDslWithProvider builder){
        String url = BASE_URL + "/gsi/completed/count/"+"gsiTest";
        return builder.given("Gsi completed Count Test")
                .uponReceiving("get gsi with name gsiTest")
                .method("GET")
                .path(url)
                .willRespondWith()
                .status(200)
                .body(newJsonBody(object -> {
                    object.stringType("message", "Success");
                    object.integerType("result", 2);
                    object.integerType("status", 200);
                }).build())
                .toPact();
    }
    @Pact(consumer = "ConsumerApplication", provider = "StreamApplication")
    RequestResponsePact getGsiDuration(PactDslWithProvider builder){
        String url = BASE_URL + "/duration/" + "gsiTest" + "/" + 1548557309991L + "/" + "testTenant";
        return builder.given("Gsi Duration")
                .uponReceiving("get gsi with name gsiTest")
                .method("GET")
                .path(url)
                .willRespondWith()
                .status(200)
                .body(newJsonBody(object -> {
                    object.stringType("message", "Success");
                    object.stringType("result", "{\n" +
                            "            \"gsiName\": \"gsiTest\",\n" +
                            "            \"transactionId\": 1548557309991,\n" +
                            "            \"tenantId\": \"testTenant\",\n" +
                            "            \"startTime\": \"2024-02-16T19:41:40.269\",\n" +
                            "            \"endTime\": \"2024-02-19T13:36:33.574\",\n" +
                            "            \"duration\": 237293.305,\n" +
                            "            \"transactionStatus\": \"TRIGGERED\",\n" +
                            "            \"currentCuName\": \"Input1_SpecialCharacterInCurrencySolution 2024021614024026737\",\n" +
                            "            \"emailId\": \"usercco1@nslhub.com\",\n" +
                            "            \"lastUpdated\": 1708329993574\n" +
                            "        }");
                    object.integerType("status", 200);
                }).build())
                .toPact();
    }
    @Pact(consumer = "ConsumerApplication", provider = "StreamApplication")
    RequestResponsePact getCompletedGsiCountList(PactDslWithProvider builder){
        String url = BASE_URL + "/_facets";
        return builder.given("Gsi completion Count list Test")
                .uponReceiving("get gsi with names and counts")
                .method("GET")
                .path(url)
                .willRespondWith()
                .status(200)
                .body(newJsonBody(object -> {
                    object.stringType("message", "Success");
                    object.stringType("result", "{\n" +
                            "    \"gsiTest1\": 3,\n" +
                            "    \"gsiTest2\": 4,\n" +
                            "    \"gsiTest3\": 200\n" +
                            "}");
                    object.integerType("status", 200);
                }).build())
                .toPact();
    }

    @Test
    @PactTestFor(pactMethod = "getFailedGsiCount", pactVersion = PactSpecVersion.V3)
    void getGsiFailedCount_whenGsiWithNameGsiTestExists(MockServer mockServer) {
        APIResponse expected = new APIResponse("Success",2,200);
        RestTemplate restTemplate = new RestTemplateBuilder()
                .rootUri(mockServer.getUrl())
                .build();
        APIResponse actual = new TransactionService(restTemplate).getFailedGsiCount("gsiTest");
        assertEquals(expected, actual);
    }
    @Test
    @PactTestFor(pactMethod = "getCompletedGsiCount", pactVersion = PactSpecVersion.V3)
    void getGsiCompletedCount_whenGsiWithNameGsiTestExists(MockServer mockServer) {
        APIResponse expected = new APIResponse("Success",2,200);
        RestTemplate restTemplate = new RestTemplateBuilder()
                .rootUri(mockServer.getUrl())
                .build();
        APIResponse actual = new TransactionService(restTemplate).getCompletedGsiCount("gsiTest");
        assertEquals(expected, actual);
    }
    @Test
    @PactTestFor(pactMethod = "getGsiDuration", pactVersion = PactSpecVersion.V3)
    void getGsiDuration_whenGsiExists(MockServer mockServer) {
        APIResponse expected = new APIResponse("Success","{\n" +
                "            \"gsiName\": \"gsiTest\",\n" +
                "            \"transactionId\": 1548557309991,\n" +
                "            \"tenantId\": \"testTenant\",\n" +
                "            \"startTime\": \"2024-02-16T19:41:40.269\",\n" +
                "            \"endTime\": \"2024-02-19T13:36:33.574\",\n" +
                "            \"duration\": 237293.305,\n" +
                "            \"transactionStatus\": \"TRIGGERED\",\n" +
                "            \"currentCuName\": \"Input1_SpecialCharacterInCurrencySolution 2024021614024026737\",\n" +
                "            \"emailId\": \"usercco1@nslhub.com\",\n" +
                "            \"lastUpdated\": 1708329993574\n" +
                "        }",200);
        RestTemplate restTemplate = new RestTemplateBuilder()
                .rootUri(mockServer.getUrl())
                .build();
        APIResponse actual = new TransactionService(restTemplate).getGsiDuration("gsiTest",1548557309991L,"testTenant");
        assertEquals(expected, actual);
    }
    @Test
    @PactTestFor(pactMethod = "getCompletedGsiCountList", pactVersion = PactSpecVersion.V3)
    void getCompletedGsiCountList_whenGsiExists(MockServer mockServer) {
        APIResponse expected = new APIResponse("Success","{\n" +
                "    \"gsiTest1\": 3,\n" +
                "    \"gsiTest2\": 4,\n" +
                "    \"gsiTest3\": 200\n" +
                "}",200);
        RestTemplate restTemplate = new RestTemplateBuilder()
                .rootUri(mockServer.getUrl())
                .build();
        APIResponse actual = new TransactionService(restTemplate).getCompletedGsiCountList();
        assertEquals(expected, actual);
    }

}
