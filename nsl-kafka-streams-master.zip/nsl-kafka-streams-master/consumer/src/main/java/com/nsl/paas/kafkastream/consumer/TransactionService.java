package com.nsl.paas.kafkastream.consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
public class TransactionService {
    private final String BASE_URL = "/api";
    private final RestTemplate restTemplate;
    @Autowired
    public TransactionService(RestTemplate restTemplate){this.restTemplate=restTemplate;}

    public APIResponse getCompletedGsiCount(String gsiName) {
        String url = BASE_URL + "/gsi/completed/count/" + gsiName;
        ResponseEntity<APIResponse> response = restTemplate.exchange(url, HttpMethod.GET, null, APIResponse.class);
        return response.getBody();
    }

    public APIResponse getFailedGsiCount(String gsiName) {
        String url = BASE_URL + "/gsi/failed/count/" + gsiName;
        ResponseEntity<APIResponse> response = restTemplate.exchange(url, HttpMethod.GET, null, APIResponse.class);
        return response.getBody();
    }

    public APIResponse getGsiDuration(String gsiName, long transactionId, String tenantId) {
        String url = BASE_URL + "/duration/" + gsiName + "/" + transactionId + "/" + tenantId;
        ResponseEntity<APIResponse> response = restTemplate.exchange(url, HttpMethod.GET, null, APIResponse.class);
        return response.getBody();
    }

    public APIResponse getCompletedGsiCountList() {
        String url = BASE_URL + "/_facets";
        ResponseEntity<APIResponse> response = restTemplate.exchange(url, HttpMethod.GET, null,APIResponse.class);
        return response.getBody();
    }

}
