package com.nsl.paas.kafkastream.consumer;

public record APIResponse(String message,
                          Object result,
                          Integer status) {

}