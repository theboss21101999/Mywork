# NSL-Streams

Welcome to NSL-Streams, a powerful project leveraging Kafka Streams to analyze transaction trends and transaction data with ease. This project empowers you to gain valuable insights into your data streams, enabling efficient and real-time monitoring of transactional activities.

## Overview

NSL-Streams harnesses the capabilities of Kafka Streams, a powerful stream processing library, to provide a robust platform for analyzing trends in transaction data. Whether you're dealing with financial transactions, e-commerce data, or any other transactional data source, NSL-Streams simplifies the process of extracting meaningful insights.

## Key Features

- **Real-time Analysis:** Leverage Kafka Streams to process and analyze transaction data in real-time, ensuring you stay up-to-date with the latest trends and patterns.

- **Scalability:** NSL-Streams is designed to scale effortlessly, allowing you to handle growing amounts of transactional data without compromising performance.

- **Flexible Configuration:** Adapt NSL-Streams to your specific use case with a flexible and easy-to-configure setup. Customize parameters, filters, and analytics to suit your unique requirements.

- **Insightful Visualizations:** Transform raw transaction data into clear and insightful visualizations. NSL-Streams includes tools for generating charts, graphs, and dashboards to facilitate a comprehensive understanding of your data.

## Getting Started

Follow these simple steps to get started with NSL-Streams:

1. **Clone the Repository:**
   ```bash
   git clone http://10.220.112.253/fractal/nsl-kafka-streams.git
   cd nsl-streams
   ```
   It will have two repos  kafka-streams and consumer application. consumer application is used for contract consumer testing and streamer application is used as provider in the contract testing.

2. **Pact Broker SetUp in Local:**
   In the nsl-streams/ you will find the docker-compose.yaml file we need to bring it up.

   ```bash
   cd nsl-streams/
   docker-compose -f docker-compose.yaml up
   ```
   This will start the pact broker at http://localhost:9292 as mentioned in the docker-compose.yaml file.

   ![Screenshot](pactBrockerUp.png)

3. **Build and Run Consumer Contract:**
   Go to consumer application then run the testcases or build the consumer application 
   ```bash
   run Test --> nsl-streams/consumer/src/test/java/com/nsl/paas/kafkastreams/consumer/TransactionConsumerPactTest.
   or
   cd nsl-streams/
   ./gradlew clean build
   ```
   This will create the pact contract .json files in the build/pacts folder\
   Now use this command to send the pact contract jsons to the broker running at localhost:9292

   ```bash
   cd nsl-streams/
   ./gradlew consumer:test --tests '*PactTest*' pactPublish
   ```
   ![Screenshot](consumerRun.png)
   Now check the pact broker , you will find that your consumer pact is sent to the broker and waiting for the provider verification.

   ![Screenshot](consumerpact.png) 

4. **Build and Run NSL-Streams:**
   ```bash
   cd nsl-streams/kafka-streams
   ./gradlew clean build
   ```
   Here the tests in kafka-streams/src/test/java/com/nsl/paas/kafkastream/PactProvider will try to verify the consumer contract jsons in the broker\
   To run specifically provider contract test we can use the following command\
   ```bash
   cd nsl-streams/
   ./gradlew -DpactPublishResults=true kafka-streams:test --tests *Pact*Test
   ```
   The above command will throw the verification results in pact broker as well as the console.

   ![Screenshot](providerpact.png)

   Pact broker Provider Contract verification is as Shown below fig, where 1 min ago it got verified.

   ![Screenshot](providerpactverify.png)

   Now to start the application run this java file: src/java/com.nsl.paas.kafkastream/StreamsApplication.java

5. **Actuators url for NSL-Streams:**
Helps to find the controller endpoints present in the project
   ```bash
   http://localhost:9999/actuator/mappings

   ```
6. **Swagger url for NSL-Streams:**
Api documentation using swagger.
   ```bash
   http://localhost:8089/swagger-ui.html
   ```
7. **redoc url for NSL-Streams:**
   Api documentation using redoc.
   ```bash
   http://localhost:8089/redoc
   ```
8. **pact broker url for NSL-Streams:**
   Pact broker for contract tests
   ```bash
   http://localhost:9292/
   ```
9. **jobrunr url for NSL-Streams:**
   jobrunr dashboard for scheduler
   ```bash
   http://localhost:8000/
   ```