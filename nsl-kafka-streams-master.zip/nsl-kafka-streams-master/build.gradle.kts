subprojects {
	apply(plugin = "java")

	repositories {
		mavenCentral()
	}

	// Other common configurations for subprojects can go here
}
