import java.io.ByteArrayOutputStream

plugins {
	java
	id("org.springframework.boot") version "3.2.1-SNAPSHOT"
	id("io.spring.dependency-management") version "1.1.4"
}

group = "com.nsl.paas.kafkastream"
version = "0.0.1-SNAPSHOT"

java {
	sourceCompatibility = JavaVersion.VERSION_17
}

configurations {
	all {
		exclude(group = "commons-logging", module = "commons-logging")
	}
}

repositories {
	mavenLocal()
	mavenCentral()
	maven { url = uri("https://repo.spring.io/milestone") }
	maven { url = uri("https://repo.spring.io/snapshot") }
	maven { url = uri("https://packages.confluent.io/maven/") }
}

dependencies {
	implementation("org.springframework.boot:spring-boot-starter")
	// https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-starter-web
	implementation("org.springframework.boot:spring-boot-starter-web")
	// https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-starter-actuator
	implementation("org.springframework.boot:spring-boot-starter-actuator:3.2.1")
	implementation("org.apache.kafka:kafka-streams")
	implementation("org.apache.httpcomponents:httpcore:4.4.1")
	implementation("org.apache.httpcomponents:httpclient:4.5")
	testImplementation("org.testcontainers:junit-jupiter")
	// https://mvnrepository.com/artifact/org.apache.kafka/kafka-streams-test-utils
	testImplementation("org.apache.kafka:kafka-streams-test-utils")
	// https://mvnrepository.com/artifact/org.springframework.kafka/spring-kafka
	implementation("org.springframework.kafka:spring-kafka")
	testImplementation("org.springframework.boot:spring-boot-starter-test") {
		exclude(group = "org.junit.vintage", module = "junit-vintage-engine")
	}
	// https://mvnrepository.com/artifact/org.springframework.kafka/spring-kafka-test
	testImplementation("org.springframework.kafka:spring-kafka-test:1.0.0.RELEASE")
// https://mvnrepository.com/artifact/org.testcontainers/kafka
	testImplementation("org.testcontainers:kafka:1.6.0")
	// https://mvnrepository.com/artifact/com.google.code.gson/gson
	implementation("com.google.code.gson:gson:2.10.1")
	// https://mvnrepository.com/artifact/org.codehaus.jackson/jackson-core-asl
	implementation("org.codehaus.jackson:jackson-core-asl:1.9.13")
// https://mvnrepository.com/artifact/org.codehaus.jackson/jackson-mapper-asl
	implementation("org.codehaus.jackson:jackson-mapper-asl:1.9.13")
	// https://mvnrepository.com/artifact/org.springframework.boot/spring-boot-starter-thymeleaf
	implementation("org.springframework.boot:spring-boot-starter-thymeleaf")
	implementation("nz.net.ultraq.thymeleaf:thymeleaf-layout-dialect")
	implementation("org.springdoc:springdoc-openapi-starter-webmvc-ui:2.2.0")
// https://mvnrepository.com/artifact/com.google.guava/guava
	implementation("com.google.guava:guava:33.0.0-jre")
	// https://mvnrepository.com/artifact/org.webjars.npm/redoc
	// https://mvnrepository.com/artifact/org.jobrunr/jobrunr-spring-boot-3-starter
	implementation("org.jobrunr:jobrunr-spring-boot-3-starter:6.3.4")
	// https://mvnrepository.com/artifact/org.apache.avro/avro
	implementation("org.apache.avro:avro:1.11.3")
// https://mvnrepository.com/artifact/io.confluent/kafka-avro-serializer
	implementation("io.confluent:kafka-avro-serializer:7.6.0")
	// https://mvnrepository.com/artifact/io.confluent/kafka-streams-avro-serde
	implementation("io.confluent:kafka-streams-avro-serde:7.6.0")
	// https://mvnrepository.com/artifact/tech.allegro.schema.json2avro/converter
	implementation("tech.allegro.schema.json2avro:converter:0.2.15")
	// Memgraph Dependency
	implementation ("org.neo4j.driver:neo4j-java-driver:5.11.0")
	// Spring Security
	implementation ("org.springframework.boot:spring-boot-starter-security")
	// https://mvnrepository.com/artifact/com.bakdata.generic-avro-reflect/generic-avro-reflect
	implementation ("com.bakdata.generic-avro-reflect:generic-avro-reflect:1.0.6")
// https://mvnrepository.com/artifact/com.fasterxml.jackson.datatype/jackson-datatype-jsr310
	implementation ("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.17.1")




	testImplementation("au.com.dius.pact.provider:junit5:4.6.5")
	compileOnly("org.projectlombok:lombok")
	annotationProcessor("org.projectlombok:lombok")
	testCompileOnly("org.projectlombok:lombok")
	testAnnotationProcessor("org.projectlombok:lombok")
	compileOnly("org.projectlombok:lombok")
	annotationProcessor("org.projectlombok:lombok")
	testCompileOnly("org.projectlombok:lombok")
	testAnnotationProcessor("org.projectlombok:lombok")
}
val getGitHash = { ->
	val stdout = ByteArrayOutputStream()
	exec {
		commandLine("git", "rev-parse", "--short", "HEAD")
		standardOutput = stdout
	}
	stdout.toString().trim()
}
val getGitBranch = { ->
	val stdout = ByteArrayOutputStream()
	exec {
		commandLine("git", "rev-parse", "--abbrev-ref", "HEAD")
		standardOutput = stdout
	}
	stdout.toString().trim()
}

tasks.withType<Test> {
	useJUnitPlatform()
	systemProperty("pact.provider.branch", getGitBranch())
	if (System.getProperty("pactPublishResults") == "true") {
		systemProperty("pact.provider.version", getGitHash())
		systemProperty("pact.verifier.publishResults", "true")
	}
}
