package com.nsl.paas.kafkastream.controller;

import com.nsl.paas.kafkastream.dto.NodeDto;
import com.nsl.paas.kafkastream.dto.PathDto;
import com.nsl.paas.kafkastream.service.MemgraphService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@ExtendWith(MockitoExtension.class)
public class GraphViewControllerTest {

    private MockMvc mockMvc;

    @Mock
    private MemgraphService memgraphService;

    @InjectMocks
    private GraphViewController graphViewController;

    @BeforeEach
    public void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(graphViewController)
                .setViewResolvers(viewResolver())
                .build();
    }

    private ViewResolver viewResolver() {
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/WEB-INF/views/");
        viewResolver.setSuffix(".jsp");
        return viewResolver;
    }

    @Test
    public void testGetDependencyGraphByEntityId() throws Exception {
        Long entityId = 1L;
        List<PathDto> result = Collections.emptyList();
        when(memgraphService.getDependencyGraphByBetId(entityId, "GeneralEntity")).thenReturn(result);

        mockMvc.perform(get("/ui/graph/entity/{entityId}", entityId))
                .andExpect(status().isOk())
                .andExpect(view().name("ComponentGraph"))
                .andExpect(model().attribute("graphData", result));
    }

    @Test
    public void testGetDependencyGraphByChangeUnitId() throws Exception {
        Long cuId = 1L;
        List<PathDto> result = Collections.emptyList();
        when(memgraphService.getDependencyGraphByBetId(cuId, "ChangeUnit")).thenReturn(result);

        mockMvc.perform(get("/ui/graph/cu/{cuId}", cuId))
                .andExpect(status().isOk())
                .andExpect(view().name("ComponentGraph"))
                .andExpect(model().attribute("graphData", result));
    }

    @Test
    public void testGetDependencyGraphByGsiId() throws Exception {
        Long gsiId = 1L;
        List<PathDto> result = Collections.emptyList();
        when(memgraphService.getDependencyGraphByBetId(gsiId, "GSI")).thenReturn(result);

        mockMvc.perform(get("/ui/graph/gsi/{gsiId}", gsiId))
                .andExpect(status().isOk())
                .andExpect(view().name("ComponentGraph"))
                .andExpect(model().attribute("graphData", result));
    }

    @Test
    public void testGetParentNodesForCuId() throws Exception {
        Long cuId = 1L;
        NodeDto rootNode = new NodeDto("label", cuId, "root");
        List<NodeDto> result = Collections.singletonList(rootNode);
        when(memgraphService.getListOfNodes(cuId, "getParentNodesForCuId")).thenReturn(result); //getParentNodesForCuId

        mockMvc.perform(get("/ui/parent/nodes/cu/{cuId}", cuId))
                .andExpect(status().isOk())
                .andExpect(view().name("GraphNodeView"))
                .andExpect(model().attribute("graphData", result))
                .andExpect(model().attribute("root", rootNode));
    }

    @Test
    public void testGetChildNodesForCuId() throws Exception {
        Long cuId = 1L;
        NodeDto rootNode = new NodeDto("label", cuId, "root");
        List<NodeDto> result = Collections.singletonList(rootNode);
        when(memgraphService.getListOfNodes(cuId, "getChildNodesForCuId")).thenReturn(result);

        mockMvc.perform(get("/ui/child/nodes/cu/{cuId}", cuId))
                .andExpect(status().isOk())
                .andExpect(view().name("GraphNodeView"))
                .andExpect(model().attribute("graphData", result))
                .andExpect(model().attribute("root", rootNode));
    }

    @Test
    public void testGetCuNodesForGsiId() throws Exception {
        Long gsiId = 1L;
        NodeDto rootNode = new NodeDto("label", gsiId, "root");
        List<NodeDto> result = Collections.singletonList(rootNode);
        when(memgraphService.getListOfNodes(gsiId, "getCuNodesForGsiId")).thenReturn(result);

        mockMvc.perform(get("/ui/child/nodes/gsi/{gsiId}/cu", gsiId))
                .andExpect(status().isOk())
                .andExpect(view().name("GraphNodeView"))
                .andExpect(model().attribute("graphData", result))
                .andExpect(model().attribute("root", rootNode));
    }

    @Test
    public void testGetGeNodesForGsiId() throws Exception {
        Long gsiId = 1L;
        NodeDto rootNode = new NodeDto("label", gsiId, "root");
        List<NodeDto> result = Collections.singletonList(rootNode);
        when(memgraphService.getListOfNodes(gsiId, "getGeNodesForGsiId")).thenReturn(result);

        mockMvc.perform(get("/ui/child/nodes/gsi/{gsiId}/ge", gsiId))
                .andExpect(status().isOk())
                .andExpect(view().name("GraphNodeView"))
                .andExpect(model().attribute("graphData", result))
                .andExpect(model().attribute("root", rootNode));
    }

    @Test
    public void testGetGsiNodesForGeId() throws Exception {
        Long geId = 1L;
        NodeDto rootNode = new NodeDto("label", geId, "root");
        List<NodeDto> result = Collections.singletonList(rootNode);
        when(memgraphService.getListOfNodes(geId, "getGsiNodesForGeId")).thenReturn(result);

        mockMvc.perform(get("/ui/parent/nodes/ge/{geId}/gsi", geId))
                .andExpect(status().isOk())
                .andExpect(view().name("GraphNodeView"))
                .andExpect(model().attribute("graphData", result))
                .andExpect(model().attribute("root", rootNode));
    }

    @Test
    public void testGetCuNodesForGeId() throws Exception {
        Long geId = 1L;
        NodeDto rootNode = new NodeDto("label", geId, "root");
        NodeDto rootNode2 = new NodeDto("label", geId, "root");

        List<NodeDto> result = Arrays.asList(rootNode, rootNode2);
        when(memgraphService.getListOfNodes(geId, "getCuNodesForGeId")).thenReturn(result);

        mockMvc.perform(get("/ui/parent/nodes/ge/{geId}/cu", geId))
                .andExpect(status().isOk())
                .andExpect(view().name("GraphNodeView"))
                .andExpect(model().attribute("graphData", result))
                .andExpect(model().attribute("root", rootNode));
    }

    @Test
    public void testGetChildNodesForGeId() throws Exception {
        Long geId = 1L;
        NodeDto rootNode = null;
        List<NodeDto> result = Collections.emptyList();
        when(memgraphService.getListOfNodes(geId, "getChildNodesForGeId")).thenReturn(result);

        mockMvc.perform(get("/ui/child/nodes/ge/{geId}/attribute", geId))
                .andExpect(status().isOk())
                .andExpect(view().name("GraphNodeView"))
                .andExpect(model().attribute("graphData", result))
                .andExpect(model().attribute("root", rootNode));
    }
}
