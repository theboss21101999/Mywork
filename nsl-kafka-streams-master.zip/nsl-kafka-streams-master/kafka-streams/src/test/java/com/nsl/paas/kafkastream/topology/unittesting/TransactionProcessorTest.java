//package com.nsl.paas.kafkastream.topology.unittesting;
//
//import com.nsl.paas.kafkastream.dto.GsiFinalTransactionKeyDto;
//import com.nsl.paas.kafkastream.dto.GsiFinalTransactionValueDto;
//import com.nsl.paas.kafkastream.serdes.JsonDeserializer;
//import com.nsl.paas.kafkastream.topology.TransactionProcessor;
//import org.apache.kafka.common.serialization.StringSerializer;
//import org.apache.kafka.streams.Topology;
//import org.apache.kafka.streams.StreamsBuilder;
//import org.apache.kafka.streams.TopologyTestDriver;
//import org.apache.kafka.streams.TestOutputTopic;
//import org.apache.kafka.streams.TestInputTopic;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.annotation.DirtiesContext;
//
//import java.util.Properties;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
//@SpringBootTest
//@DirtiesContext
//class TransactionProcessorTest {
//
//    @Autowired
//    private TransactionProcessor transactionProcessor;
//
//    @BeforeEach
//    public void setUp() {
//
//    }
//
//    @Test
//    void gsiCompletionAnalysisTest(){
//        StreamsBuilder streamsBuilder = new StreamsBuilder();
//        transactionProcessor.txnTransDataAnalysis(streamsBuilder);
//        Topology topology = streamsBuilder.build();
//        try (TopologyTestDriver topologyTestDriver = new TopologyTestDriver(topology, new Properties())) {
//
//            TestInputTopic<String, String> inputTopic = topologyTestDriver
//                .createInputTopic("TxnTransRequest", new StringSerializer(), new StringSerializer());
//
//            TestOutputTopic<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> outputTopic = topologyTestDriver
//                .createOutputTopic("gsiTableDataStream",new JsonDeserializer<>(GsiFinalTransactionKeyDto.class),new JsonDeserializer<>(GsiFinalTransactionValueDto.class));
//
//            inputTopic.pipeInput("key", "{\"data\":{\"transactionDto\":{\"executionState\":[{\"containerCuId\":825770750105,\"referenceContainerCuId\":825770750105,\"currentContextualId\":\"GS825770750105\",\"isParallelCuContainer\":false,\"txnDataSaveMode\":\"DEFAULT\"}],\"hasSubtransactionalEntity\":false,\"contextCacheMap\":{},\"containerCuDisplayName\":\"Test GSI 12345\",\"transactionId\":\"633673673444\",\"triggerCuId\":872962544743,\"containerCuId\":825770750105,\"containerCuName\":\"Test GSI\",\"transactionStatus\":\"TRIGGERED\",\"triggerCuName\":\"Test CU\",\"dateTime\":1707908163148,\"assignedUserId\":\"1943859452520\",\"assignedStatus\":\"ASSIGNED\",\"startTime\":1707908163142,\"executionStatus\":\"COMPLETED\",\"isUpdateAssigneeApplicable\":false,\"id\":633673673444,\"ownerId\":1943859452520,\"createdAt\":1707908163142,\"createdBy\":1943859452520,\"updatedAt\":1707908163172,\"updatedBy\":1943859452520,\"orgUnitId\":664834828061}},\"userContext\":{\"tenantId\":\"ritik\",\"userId\":1943859452520,\"emailId\":\"binod@gmail.com\",\"orgUnitId\":664834828061},\"logEventTime\":1707908163173,\"methodName\":\"save\"}");
//            inputTopic.pipeInput("key2", "{\"data\":{\"txnDataDto\":{\"txnData\":{\"txnCULayer\":[{\"type\":\"physical\",\"txnSlotItems\":[{\"isMultiValue\":false,\"item\":{\"TYPE\":\"TxnGeneralEntity\",\"DATA\":{\"name\":\"test ent\",\"generalEntityID\":209991411478,\"transEntityRecords\":[{\"txnNslAttribute\":[{\"name\":\"Qty\",\"nslAttributeID\":2057662021669,\"values\":[\"1\"],\"displayName\":\"Qty\"}],\"txnRecordId\":1731042338089}],\"isLastBatch\":false,\"isMasterData\":true,\"isBulkImport\":false}},\"arrivalTime\":1707908163153}],\"id\":578174494784}],\"gsiId\":825770750105,\"gsiMasterId\":825770750105,\"referenceChangeUnitMasterId\":1368422140663,\"referenceChangeUnitId\":1368422140663,\"triggerCuIndex\":1,\"triggerState\":\"COMPLETED\",\"triggerEndTime\":1707908163226,\"triggeredTime\":1707908163225,\"triggerStartTime\":1707908163153,\"createdBy\":\"1943859452520\",\"updatedBy\":\"1943859452520\",\"updatedAt\":1707908163226,\"createdAt\":1707908163153,\"transactionId\":\"633673673444\",\"cuContextualId\":\"GS825770750105.CU872962544743_1368422140663\"},\"traceableMap\":{\"PHYSICAL\":[{\"id\":209991411478,\"name\":\"test ent\",\"masterId\":209991411478,\"attributeDtos\":[{\"id\":2057662021669,\"name\":\"Qty\",\"isTraceable\":false}]}]}}},\"userContext\":{\"tenantId\":\"ritik\",\"userId\":1943859452520,\"emailId\":\"binod@gmail.com\",\"orgUnitId\":664834828061},\"logEventTime\":1707908163232,\"methodName\":\"saveData\"}");
//            inputTopic.pipeInput("key3","{\"data\":{\"transactionDto\":{\"executionState\":[],\"masterTransactionIdRecords\":{},\"hasSubtransactionalEntity\":false,\"contextCacheMap\":{},\"containerCuDisplayName\":\"Test GSI 12345\",\"transactionId\":\"633673673444\",\"triggerCuId\":872962544743,\"containerCuId\":825770750105,\"containerCuName\":\"Test GSI\",\"transactionStatus\":\"COMPLETED\",\"triggerCuName\":\"Test CU\",\"dateTime\":1707908163148,\"assignedUserId\":\"1943859452520\",\"assignedStatus\":\"ASSIGNED\",\"startTime\":1707908163142,\"executionStatus\":\"COMPLETED\",\"endTime\":1707908163233,\"isUpdateAssigneeApplicable\":false,\"id\":633673673444,\"ownerId\":1943859452520,\"createdAt\":1707908163142,\"createdBy\":1943859452520,\"updatedAt\":1707908163234,\"updatedBy\":1943859452520,\"orgUnitId\":664834828061}},\"userContext\":{\"tenantId\":\"ritik\",\"userId\":1943859452520,\"emailId\":\"binod@gmail.com\",\"orgUnitId\":664834828061},\"logEventTime\":1707908163234,\"methodName\":\"save\"}");
//            inputTopic.pipeInput("key4","{\"data\":{\"transactionDto\":{\"executionState\":[],\"masterTransactionIdRecords\":{},\"hasSubtransactionalEntity\":false,\"contextCacheMap\":{},\"containerCuDisplayName\":\"Test GSI 12345\",\"transactionId\":\"633673673444\",\"triggerCuId\":872962544743,\"containerCuId\":825770750105,\"containerCuName\":\"Test GSI\",\"transactionStatus\":\"COMPLETED\",\"triggerCuName\":\"Test CU\",\"dateTime\":1707908163148,\"assignedUserId\":\"1943859452520\",\"assignedStatus\":\"ASSIGNED\",\"startTime\":1707908163142,\"executionStatus\":\"COMPLETED\",\"endTime\":1707908163233,\"isUpdateAssigneeApplicable\":false,\"id\":633673673444,\"ownerId\":1943859452520,\"createdAt\":1707908163142,\"createdBy\":1943859452520,\"updatedAt\":1707908163234,\"updatedBy\":1943859452520,\"orgUnitId\":664834828061}},\"userContext\":{\"tenantId\":\"ritik\",\"userId\":1943859452520,\"emailId\":\"binod@gmail.com\",\"orgUnitId\":664834828061},\"logEventTime\":1707908163234,\"methodName\":\"save\"}");
//            assertNotNull(outputTopic.readKeyValuesToList());
//        }
//
//    }
//}
