package com.nsl.paas.kafkastream.controller;

import com.nsl.paas.kafkastream.dto.APIResponse;
import com.nsl.paas.kafkastream.dto.CuTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.CuTransactionValueDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionValueDto;
import com.nsl.paas.kafkastream.dto.UserKeyDto;
import com.nsl.paas.kafkastream.enums.KafkaStoreExceptionType;
import com.nsl.paas.kafkastream.exceptions.InvalidRequestException;
import com.nsl.paas.kafkastream.exceptions.KafkaStoreAccessException;
import com.nsl.paas.kafkastream.exceptions.NotFoundException;
import com.nsl.paas.kafkastream.model.*;
import com.nsl.paas.kafkastream.service.GsiActivityService;
import com.nsl.paas.kafkastream.service.TenantActivityService;
import com.nsl.paas.kafkastream.service.UserActivityService;
import java.util.HashSet;
import java.util.Set;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.nsl.paas.kafkastream.constants.AppConstants.SUCCESS_MSG;
import static com.nsl.paas.kafkastream.constants.AppConstants.TRANSACTION_CONTROLLER;
import static com.nsl.paas.kafkastream.enums.KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

public class TransactionControllerTest {

    @Mock
    private StreamsBuilderFactoryBean factoryBean;

    @Mock
    private KafkaStreams kafkaStreams;

    @Mock
    private ReadOnlyKeyValueStore<String, Long> counts;

    @Mock
    private ReadOnlyKeyValueStore<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> gsiDuration;

    @Mock
    private ReadOnlyKeyValueStore<CuTransactionKeyDto, CuTransactionValueDto> cuTable;

    @Mock
    private GsiActivityService gsiActivityService;

    @Mock
    private UserActivityService userActivityService;

    @Mock
    private TenantActivityService tenantActivityService;

    @InjectMocks
    private TransactionController transactionController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGsiCompletedCount() {
        when(gsiActivityService.getCompletedGsiCountByGsiName("gsi1")).thenReturn(10L);

        ResponseEntity<APIResponse> result = transactionController.gsiCompletedCount("gsi1");
        long count = (long) result.getBody().result();
        assertEquals(10L, count);
    }

    @Test
    public void testGsiCompletedCount_NotFoundException() {
        String gsiName = "gsiUnknown";
        when(gsiActivityService.getCompletedGsiCountByGsiName(gsiName)).thenThrow(
            new NotFoundException("GSI not found"));

        ResponseEntity<APIResponse> response = transactionController.gsiCompletedCount(gsiName);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("GSI not found", response.getBody().message());
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getBody().status());
    }

    @Test
    public void testGsiCompletedCount_KafkaStoreAccessException() {
        String gsiName = "gsiError";
        KafkaStoreAccessException exception = new KafkaStoreAccessException(
            "Kafka store access error", INVALID_STATE_STORE_EXCEPTION);
        when(gsiActivityService.getCompletedGsiCountByGsiName(gsiName)).thenThrow(exception);

        ResponseEntity<APIResponse> response = transactionController.gsiCompletedCount(gsiName);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing gsiCompletedCount request: Kafka store access error",
            response.getBody().message());
        assertEquals(INVALID_STATE_STORE_EXCEPTION, response.getBody().result());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGsiCompletedCount_Exception() {
        String gsiName = "gsiError";
        when(gsiActivityService.getCompletedGsiCountByGsiName(gsiName)).thenThrow(
            new RuntimeException("Unexpected error"));

        ResponseEntity<APIResponse> response = transactionController.gsiCompletedCount(gsiName);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing gsiCompletedCount request: Unexpected error",
            response.getBody().message());
        assertNull(
            response.getBody().result()); // Assuming the result is null for generic exceptions
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGsiFailedCount() {
        when(gsiActivityService.getFailedGsiCountByGsiName("gsi2")).thenReturn(5L);

        ResponseEntity<APIResponse> result = transactionController.gsiFailedCount("gsi2");
        long count = (long) result.getBody().result();
        assertEquals(5L, count);
    }

    @Test
    public void testGsiFailedCount_NotFoundException() {
        String gsiName = "gsiUnknown";
        when(gsiActivityService.getFailedGsiCountByGsiName(gsiName)).thenThrow(
            new NotFoundException("GSI not found"));

        ResponseEntity<APIResponse> response = transactionController.gsiFailedCount(gsiName);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("GSI not found", response.getBody().message());
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getBody().status());
    }

    @Test
    public void testGsiFailedCount_KafkaStoreAccessException() {
        String gsiName = "gsiError";
        KafkaStoreAccessException exception = new KafkaStoreAccessException(
            "Kafka store access error", INVALID_STATE_STORE_EXCEPTION);
        when(gsiActivityService.getFailedGsiCountByGsiName(gsiName)).thenThrow(exception);

        ResponseEntity<APIResponse> response = transactionController.gsiFailedCount(gsiName);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing gsiFailedCount request: Kafka store access error",
            response.getBody().message());
        assertEquals(INVALID_STATE_STORE_EXCEPTION, response.getBody().result());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGsiFailedCount_Exception() {
        String gsiName = "gsiError";
        when(gsiActivityService.getFailedGsiCountByGsiName(gsiName)).thenThrow(
            new RuntimeException("Unexpected error"));

        ResponseEntity<APIResponse> response = transactionController.gsiFailedCount(gsiName);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing gsiFailedCount request: Unexpected error",
            response.getBody().message());
        assertNull(
            response.getBody().result()); // Assuming the result is null for generic exceptions
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }


    @Test
    public void testGsiDuration() {
        GsiFinalTransactionValueDto expectedValueDto = new GsiFinalTransactionValueDto("value1",
            34564345L, "wert", LocalDateTime.of(2015,
            Month.JULY, 29, 19, 30, 40), LocalDateTime.of(2015,
            Month.JULY, 29, 19, 30, 40), 70, "completed", "dvbvcx", "eefffg", 3456543454L);
        when(gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId("gsi", 123L,
            "tenant1")).thenReturn(expectedValueDto);

        ResponseEntity<APIResponse> result = transactionController.getGsiDuration("gsi", 123,
            "tenant1");

        assertEquals(expectedValueDto, result.getBody().result());
    }

    @Test
    public void testGetGsiDuration_Exception() {
        String gsiName = "gsiName";
        long transactionId = 123L;
        String tenantId = "tenant1";
        when(gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId(gsiName, transactionId,
            tenantId))
            .thenThrow(new RuntimeException("Unexpected error"));

        ResponseEntity<APIResponse> response = transactionController.getGsiDuration(gsiName,
            transactionId, tenantId);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing getGsiDuration request: Unexpected error",
            response.getBody().message());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetGsiDuration_KafkaStoreAccessException() {
        String gsiName = "gsiName";
        long transactionId = 123L;
        String tenantId = "tenant1";
        KafkaStoreAccessException exception = new KafkaStoreAccessException(
            "Kafka store access error", INVALID_STATE_STORE_EXCEPTION);
        when(gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId(gsiName, transactionId,
            tenantId))
            .thenThrow(exception);

        ResponseEntity<APIResponse> response = transactionController.getGsiDuration(gsiName,
            transactionId, tenantId);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing getGsiDuration request: Kafka store access error",
            response.getBody().message());
        assertEquals(INVALID_STATE_STORE_EXCEPTION, response.getBody().result());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetGsiDuration_NotFoundException() {
        String gsiName = "gsiName";
        long transactionId = 123L;
        String tenantId = "tenant1";
        when(gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId(gsiName, transactionId,
            tenantId))
            .thenThrow(new NotFoundException("Duration data not found"));

        ResponseEntity<APIResponse> response = transactionController.getGsiDuration(gsiName,
            transactionId, tenantId);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Duration data not found", response.getBody().message());
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getBody().status());
    }

    @Test
    public void testFacets() {
        Map<String, Long> expected = new HashMap<>();
        expected.put("key1", 10L);
        expected.put("key2", 20L);
        when(gsiActivityService.getCompletedGsiCountMap()).thenReturn(expected);

        ResponseEntity<APIResponse> result = transactionController.facets();

        assertEquals(expected, result.getBody().result());
    }

    @Test
    public void testFacets_KafkaStoreAccessException() {
        when(gsiActivityService.getCompletedGsiCountMap())
            .thenThrow(new KafkaStoreAccessException("Kafka store access error",
                INVALID_STATE_STORE_EXCEPTION));

        ResponseEntity<APIResponse> response = transactionController.facets();

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing facets request: Kafka store access error",
            response.getBody().message());
        assertEquals(INVALID_STATE_STORE_EXCEPTION, response.getBody().result());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testFacets_Exception() {
        when(gsiActivityService.getCompletedGsiCountMap())
            .thenThrow(new RuntimeException("Unexpected error"));

        ResponseEntity<APIResponse> response = transactionController.facets();

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing facets request: Unexpected error",
            response.getBody().message());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testCuTable() {
        Map<CuTransactionKeyDto, CuTransactionValueDto> expected = new HashMap<>();
        expected.put(new CuTransactionKeyDto(123L,123L,"test"), new CuTransactionValueDto(123L,"test",768L,new CuDetails("test","human",true,"adapter","mqtt"),"7tr",LocalDateTime.of(2015,
            Month.JULY, 29, 19, 30, 40),LocalDateTime.of(2015,
            Month.JULY, 29, 19, 30, 40),LocalDateTime.of(2015,
            Month.JULY, 29, 19, 30, 40),123,"asdf","qwsdfv",234L));
        expected.put(new CuTransactionKeyDto(124L,123L,"test"), new CuTransactionValueDto(123L,"test",768L,new CuDetails("test","machine",true,"adapter","mqtt"),"7tr",LocalDateTime.of(2015,
            Month.JULY, 29, 19, 30, 40),LocalDateTime.of(2015,
            Month.JULY, 29, 19, 30, 40),LocalDateTime.of(2015,
            Month.JULY, 29, 19, 30, 40),123,"asdf","qwsdfv",234L));
        when(gsiActivityService.getCuExecutionActivityMap()).thenReturn(expected);

        ResponseEntity<APIResponse> result = transactionController.cuTable();

        assertEquals(expected, result.getBody().result());
    }

    @Test
    public void testCuTable_KafkaStoreAccessException() {
        when(gsiActivityService.getCuExecutionActivityMap())
            .thenThrow(new KafkaStoreAccessException("Kafka store access error",
                INVALID_STATE_STORE_EXCEPTION));

        ResponseEntity<APIResponse> response = transactionController.cuTable();

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing cuTable request: Kafka store access error",
            response.getBody().message());
        assertEquals(INVALID_STATE_STORE_EXCEPTION, response.getBody().result());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testCuTable_GeneralException() {
        when(gsiActivityService.getCuExecutionActivityMap()).thenThrow(
            new RuntimeException("Unexpected error"));

        ResponseEntity<APIResponse> response = transactionController.cuTable();

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing cuTable request: Unexpected error",
            response.getBody().message());
        assertNull(response.getBody()
            .result()); // Assuming the general exception does not set a specific error type in the result
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGsiTable() {
        Map<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> expected = new HashMap<>();
        expected.put(new GsiFinalTransactionKeyDto("gsiKey1", 123L, "tenant1"),
            new GsiFinalTransactionValueDto("value1", 34564345L, "wert", LocalDateTime.of(2015,
                Month.JULY, 29, 19, 30, 40), LocalDateTime.of(2015,
                Month.JULY, 29, 19, 30, 40), 70, "completed", "dvbvcx", "eefffg", 3456543454L));
        expected.put(new GsiFinalTransactionKeyDto("gsiKey2", 456L, "tenant2"),
            new GsiFinalTransactionValueDto("value1", 34564345L, "wert", LocalDateTime.of(2015,
                Month.JULY, 29, 19, 30, 40), LocalDateTime.of(2015,
                Month.JULY, 29, 19, 30, 40), 70, "completed", "dvbvcx", "eefffg", 3456543454L));
        when(gsiActivityService.getGsiExecutionActivityMap()).thenReturn(expected);

        ResponseEntity<APIResponse> result = transactionController.gsiTable();

        assertEquals(expected, result.getBody().result());
    }

    @Test
    public void testGsiTable_KafkaStoreAccessException() {
        when(gsiActivityService.getGsiExecutionActivityMap())
            .thenThrow(new KafkaStoreAccessException("Kafka store access error",
                INVALID_STATE_STORE_EXCEPTION));

        ResponseEntity<APIResponse> response = transactionController.gsiTable();

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing gsiTable request: Kafka store access error",
            response.getBody().message());
        assertEquals(INVALID_STATE_STORE_EXCEPTION, response.getBody().result());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGsiTable_GenericException() {
        when(gsiActivityService.getGsiExecutionActivityMap())
            .thenThrow(new RuntimeException("Unexpected error"));

        ResponseEntity<APIResponse> response = transactionController.gsiTable();

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing gsiTable request: Unexpected error",
            response.getBody().message());
        assertNull(response.getBody()
            .result()); // Assuming that in a generic exception case, result would be null
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetUsersActivityDetailsByTimeWindow() {

        int page = 1;
        int pageSize = 10;
        String sortBy = "totalTransactions";
        String sortOrder = "desc";
        int windowSizeInHours = 1;

        Map<UserKeyDto, UserActivityInfo> expected = new HashMap<>();
        Map<String, ContainerCuInfo> containerCuName = new HashMap<>();
        ContainerCuInfo containerCuInfo1 = new ContainerCuInfo();
        containerCuInfo1.setContainerCuName("abc");
        containerCuInfo1.setTotalTransactions(1L);
        ContainerCuInfo containerCuInfo2 = new ContainerCuInfo();
        containerCuInfo2.setContainerCuName("edc");
        containerCuInfo2.setTotalTransactions(1L);

        containerCuName.put("abc", containerCuInfo1);
        containerCuName.put("edc", containerCuInfo2);

        Set<String> tenants = new HashSet<>();
        tenants.add("Test Tenant");
        UserActivityInfo userActivityInfo = UserActivityInfo.Builder()
            .withEmailId("xyz@gmail.com")
            .withUserId(12132L)
            .withTenantIds(tenants)
            .withAvgDuration(12L)
            .withTotalTransactions(2L)
            .withTotalCompletedTransactions(2L)
            .withTotalFailedTransactions(0L)
            .withTotalIncompleteTransactions(0L)
            .withContainerCuNames(containerCuName)
            .build();

        expected.put(new UserKeyDto(123L, "xyz@gmail.com"), userActivityInfo);

        when(userActivityService.getUserActivityInfoByTimeWindow(page, pageSize, sortBy, sortOrder,
            windowSizeInHours))
            .thenReturn(expected);

        ResponseEntity<APIResponse> result = transactionController.getUsersActivityDetailsByTimeWindow(
            page, pageSize, sortBy,
            sortOrder, windowSizeInHours);

        assertEquals(expected, result.getBody().result());
    }

    @Test
    public void testGetUsersActivityDetailsByTimeWindow_InvalidRequestException() {
        int invalidWindowSizeInHours = 0; // Assuming 0 is an invalid window size for demonstration

        ResponseEntity<APIResponse> response = transactionController.getUsersActivityDetailsByTimeWindow(
            1, 10, "totalTransactions", "desc", invalidWindowSizeInHours);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().message().contains("Invalid window size specified"));
        assertNull(response.getBody().result());
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getBody().status());
    }

    @Test
    public void testGetUsersActivityDetailsByTimeWindow_KafkaStoreAccessException() {
        when(userActivityService.getUserActivityInfoByTimeWindow(1, 10, "totalTransactions", "desc",
            1))
            .thenThrow(new KafkaStoreAccessException("Kafka store access error",
                INVALID_STATE_STORE_EXCEPTION));

        ResponseEntity<APIResponse> response = transactionController.getUsersActivityDetailsByTimeWindow(
            1, 10, "totalTransactions", "desc", 1);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(
            "Error processing getUsersActivityDetailsByTimeWindow request: Kafka store access error",
            response.getBody().message());
        assertEquals(INVALID_STATE_STORE_EXCEPTION, response.getBody().result());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetUsersActivityDetailsByTimeWindow_GenericException() {
        when(userActivityService.getUserActivityInfoByTimeWindow(1, 10, "totalTransactions", "desc",
            1))
            .thenThrow(new RuntimeException("Unexpected error"));

        ResponseEntity<APIResponse> response = transactionController.getUsersActivityDetailsByTimeWindow(
            1, 10, "totalTransactions", "desc", 1);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(
            "Error processing getUsersActivityDetailsByTimeWindow request: Unexpected error",
            response.getBody().message());
        assertNull(response.getBody()
            .result()); // Assuming that in a generic exception case, result would be null
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetTenantsActivityDetailsByTimeWindow() {

        int page = 1;
        int pageSize = 10;
        String sortBy = "totalTransactions";
        String sortOrder = "desc";
        int windowSizeInHours = 1;

        Map<String, TenantActivityInfo> expected = new HashMap<>();
        Map<String, ContainerCuInfo> containerCuName = new HashMap<>();
        ContainerCuInfo containerCuInfo1 = new ContainerCuInfo();
        containerCuInfo1.setContainerCuName("abc");
        containerCuInfo1.setTotalTransactions(1L);
        ContainerCuInfo containerCuInfo2 = new ContainerCuInfo();
        containerCuInfo2.setContainerCuName("edc");
        containerCuInfo2.setTotalTransactions(1L);

        containerCuName.put("abc", containerCuInfo1);
        containerCuName.put("edc", containerCuInfo2);
        TenantActivityInfo tenantActivityInfo = TenantActivityInfo.builder()
            .withTenantId("Test Tenant")
            .withAvgDuration(12L)
            .withTotalTransactions(2L)
            .withTotalCompletedTransactions(2L)
            .withTotalFailedTransactions(0L)
            .withTotalIncompleteTransactions(0L)
            .withContainerCuNames(containerCuName)
            .build();

        expected.put("abc", tenantActivityInfo);

        when(tenantActivityService.getTenantActivityInfoByTimeWindow(page, pageSize, sortBy,
            sortOrder, windowSizeInHours))
            .thenReturn(expected);

        ResponseEntity<APIResponse> result = transactionController.getTenantsActivityDetailsByTimeWindow(
            page, pageSize, sortBy,
            sortOrder, windowSizeInHours);

        assertEquals(expected, result.getBody().result());
    }

    @Test
    public void testGetTenantsActivityDetailsByTimeWindow_InvalidRequestException() {
        int invalidWindowSizeInHours = 0; // Assuming 0 is an invalid window size for demonstration purposes

        ResponseEntity<APIResponse> response = transactionController.getTenantsActivityDetailsByTimeWindow(
            1, 10, "totalTransactions", "desc", invalidWindowSizeInHours);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().message().contains("Invalid window size specified"));
        assertNull(response.getBody().result());
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getBody().status());
    }

    @Test
    public void testGetTenantsActivityDetailsByTimeWindow_KafkaStoreAccessException() {
        when(tenantActivityService.getTenantActivityInfoByTimeWindow(1, 10, "totalTransactions",
            "desc", 1))
            .thenThrow(new KafkaStoreAccessException("Kafka store access error",
                INVALID_STATE_STORE_EXCEPTION));

        ResponseEntity<APIResponse> response = transactionController.getTenantsActivityDetailsByTimeWindow(
            1, 10, "totalTransactions", "desc", 1);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(
            "Error processing getTenantsActivityDetailsByTimeWindow request: Kafka store access error",
            response.getBody().message());
        assertEquals(INVALID_STATE_STORE_EXCEPTION, response.getBody().result());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetTenantsActivityDetailsByTimeWindow_GenericException() {
        when(tenantActivityService.getTenantActivityInfoByTimeWindow(1, 10, "totalTransactions",
            "desc", 1))
            .thenThrow(new RuntimeException("Unexpected error"));

        ResponseEntity<APIResponse> response = transactionController.getTenantsActivityDetailsByTimeWindow(
            1, 10, "totalTransactions", "desc", 1);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(
            "Error processing getTenantsActivityDetailsByTimeWindow request: Unexpected error",
            response.getBody().message());
        assertNull(response.getBody()
            .result()); // Assuming that in a generic exception case, the result would be null
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetActiveUserCount() {

        int windowSizeInHours = 1;
        when(userActivityService.getActiveUserCountByTimeWindow(windowSizeInHours)).thenReturn(3L);
        ResponseEntity<APIResponse> result = transactionController.getActiveUserCount(
            windowSizeInHours);
        assertEquals(3L, result.getBody().result());
    }

    @Test
    public void testGetActiveUserCount_InvalidRequestException() {
        // Given an invalid window size, assuming 0 is not allowed
        int invalidWindowSizeInHours = 0;

        // When
        ResponseEntity<APIResponse> response = transactionController.getActiveUserCount(
            invalidWindowSizeInHours);

        // Then
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().message().contains("Invalid window size specified"));
        assertNull(response.getBody().result());
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getBody().status());
    }

    @Test
    public void testGetActiveUserCount_KafkaStoreAccessException() {
        // Given a valid window size
        int windowSizeInHours = 1;
        // Setup the service to throw a KafkaStoreAccessException when called
        when(userActivityService.getActiveUserCountByTimeWindow(windowSizeInHours))
            .thenThrow(new KafkaStoreAccessException("Kafka store access error",
                INVALID_STATE_STORE_EXCEPTION));

        // When
        ResponseEntity<APIResponse> response = transactionController.getActiveUserCount(
            windowSizeInHours);

        // Then
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing getActiveUserCount request: Kafka store access error",
            response.getBody().message());
        assertEquals(INVALID_STATE_STORE_EXCEPTION, response.getBody().result());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetActiveUserCount_GenericException() {
        // Given a valid window size
        int windowSizeInHours = 1;
        // Setup the service to throw a generic exception when called
        when(userActivityService.getActiveUserCountByTimeWindow(windowSizeInHours))
            .thenThrow(new RuntimeException("Unexpected error"));

        // When
        ResponseEntity<APIResponse> response = transactionController.getActiveUserCount(
            windowSizeInHours);

        // Then
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing getActiveUserCount request: Unexpected error",
            response.getBody().message());
        assertNull(response.getBody()
            .result()); // Assuming that in a generic exception case, the result would be null
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetActiveTenantCount() {

        int windowSizeInHours = 1;
        when(tenantActivityService.getActiveTenantCountByTimeWindow(windowSizeInHours)).thenReturn(
            3L);
        ResponseEntity<APIResponse> result = transactionController.getActiveTenantCount(
            windowSizeInHours);
        assertEquals(3L, result.getBody().result());
    }

    @Test
    public void testGetActiveTenantCount_InvalidRequestException() {
        // Given an invalid window size, assuming 0 is not allowed
        int invalidWindowSizeInHours = 0;

        // When
        ResponseEntity<APIResponse> response = transactionController.getActiveTenantCount(
            invalidWindowSizeInHours);

        // Then
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().message().contains("Invalid window size specified"));
        assertNull(response.getBody().result());
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getBody().status());
    }

    @Test
    public void testGetActiveTenantCount_KafkaStoreAccessException() {
        // Given a valid window size
        int windowSizeInHours = 1;
        // Setup the service to throw a KafkaStoreAccessException when called
        when(tenantActivityService.getActiveTenantCountByTimeWindow(windowSizeInHours))
            .thenThrow(new KafkaStoreAccessException("Kafka store access error",
                INVALID_STATE_STORE_EXCEPTION));

        // When
        ResponseEntity<APIResponse> response = transactionController.getActiveTenantCount(
            windowSizeInHours);

        // Then
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing getActiveTenantCount request: Kafka store access error",
            response.getBody().message());
        assertEquals(INVALID_STATE_STORE_EXCEPTION, response.getBody().result());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetActiveTenantCount_GenericException() {
        // Given a valid window size
        int windowSizeInHours = 1;
        // Setup the service to throw a generic exception when called
        when(tenantActivityService.getActiveTenantCountByTimeWindow(windowSizeInHours))
            .thenThrow(new RuntimeException("Unexpected error"));

        // When
        ResponseEntity<APIResponse> response = transactionController.getActiveTenantCount(
            windowSizeInHours);

        // Then
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Error processing getActiveTenantCount request: Unexpected error",
            response.getBody().message());
        assertNull(response.getBody()
            .result()); // Assuming that in a generic exception case, the result would be null
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
    }

    @Test
    public void testGetUserActivityDetailsByTimeWindowSuccess() {
        long userId = 1L;
        String emailId = "user@example.com";
        int windowSizeInHours = 1;

        UserActivityInfo mockActivityInfo = UserActivityInfo.Builder().build();
        when(
            userActivityService.getActivityByUserIdAndTimeWindow(userId, emailId, windowSizeInHours,
                TRANSACTION_CONTROLLER))
            .thenReturn(mockActivityInfo);

        ResponseEntity<APIResponse> response = transactionController.getUserActivityDetailsByTimeWindow(
            userId, emailId, windowSizeInHours);

        assertEquals(HttpStatus.OK.value(), response.getBody().status());
        assertEquals(SUCCESS_MSG, response.getBody().message());
        assertNotNull(response.getBody().result());
        assertTrue(response.getBody().result() instanceof Map);
    }

    @Test
    public void testGetUserActivityDetailsByTimeWindowInvalidRequest() {
        long userId = 1L;
        String emailId = "user@example.com";
        int invalidWindowSizeInHours = -1;

        when(userActivityService.getActivityByUserIdAndTimeWindow(anyLong(), anyString(), anyInt(),
            anyString()))
            .thenThrow(new InvalidRequestException("Invalid window size"));

        ResponseEntity<APIResponse> response = transactionController.getUserActivityDetailsByTimeWindow(
            userId, emailId, invalidWindowSizeInHours);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getBody().status());
        assertEquals("Invalid window size specified. Valid values are 1, 3, 6, 12, 24.",
            response.getBody().message());
        assertNull(response.getBody().result());
    }

    @Test
    public void testGetUserActivityDetailsByTimeWindowNotFound() {
        long userId = 1L;
        String emailId = "nonexistent@example.com";
        int windowSizeInHours = 1;

        when(
            userActivityService.getActivityByUserIdAndTimeWindow(userId, emailId, windowSizeInHours,
                TRANSACTION_CONTROLLER))
            .thenThrow(new NotFoundException("User activity not found"));

        ResponseEntity<APIResponse> response = transactionController.getUserActivityDetailsByTimeWindow(
            userId, emailId, windowSizeInHours);

        assertEquals(HttpStatus.NOT_FOUND.value(), response.getBody().status());
        assertEquals("User activity not found", response.getBody().message());
        assertNull(response.getBody().result());
    }

    @Test
    public void testGetUserActivityDetailsByTimeWindowKafkaStoreAccessException() {
        long userId = 1L;
        String emailId = "user@example.com";
        int windowSizeInHours = 1;

        when(
            userActivityService.getActivityByUserIdAndTimeWindow(userId, emailId, windowSizeInHours,
                TRANSACTION_CONTROLLER))
            .thenThrow(new KafkaStoreAccessException("Kafka store access error",
                KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION));

        ResponseEntity<APIResponse> response = transactionController.getUserActivityDetailsByTimeWindow(
            userId, emailId, windowSizeInHours);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
        assertEquals(
            "Error processing getUserActivityDetailsByTimeWindow request: Kafka store access error",
            response.getBody().message());
        assertEquals(KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION,
            response.getBody().result());
    }

    @Test
    public void testGetUserActivityDetailsByTimeWindowGenericException() {
        long userId = 1L;
        String emailId = "user@example.com";
        int windowSizeInHours = 1;

        when(
            userActivityService.getActivityByUserIdAndTimeWindow(userId, emailId, windowSizeInHours,
                TRANSACTION_CONTROLLER))
            .thenThrow(new RuntimeException("Unexpected error"));

        ResponseEntity<APIResponse> response = transactionController.getUserActivityDetailsByTimeWindow(
            userId, emailId, windowSizeInHours);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
        assertEquals(
            "Error processing getUserActivityDetailsByTimeWindow request: Unexpected error",
            response.getBody().message());
        assertNull(response.getBody().result());
    }

    @Test
    public void testGetTenantActivityDetailsByTimeWindowSuccess() {
        String tenantId = "tenant123";
        int windowSizeInHours = 1;

        TenantActivityInfo mockActivityInfo = TenantActivityInfo.builder().build();
        when(tenantActivityService.getActivityByTenantIdAndTimeWindow(tenantId, windowSizeInHours,
            TRANSACTION_CONTROLLER))
            .thenReturn(mockActivityInfo);

        ResponseEntity<APIResponse> response = transactionController.getTenantActivityDetailsByTimeWindow(
            tenantId, windowSizeInHours);

        assertEquals(HttpStatus.OK.value(), response.getBody().status());
        assertEquals(SUCCESS_MSG, response.getBody().message());
        assertNotNull(response.getBody().result());
        assertTrue(response.getBody().result() instanceof Map);
    }

    @Test
    public void testGetTenantActivityDetailsByTimeWindowInvalidRequest() {
        String tenantId = "tenant123";
        int invalidWindowSizeInHours = -1;

        doThrow(new InvalidRequestException("Invalid window size"))
            .when(tenantActivityService)
            .getActivityByTenantIdAndTimeWindow(anyString(), anyInt(), anyString());

        ResponseEntity<APIResponse> response = transactionController.getTenantActivityDetailsByTimeWindow(
            tenantId, invalidWindowSizeInHours);

        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getBody().status());
        assertEquals("Invalid window size specified. Valid values are 1, 3, 6, 12, 24.",
            response.getBody().message());
        assertNull(response.getBody().result());
    }

    @Test
    public void testGetTenantActivityDetailsByTimeWindowNotFound() {
        String tenantId = "nonexistentTenant";
        int windowSizeInHours = 1;

        doThrow(new NotFoundException("Tenant activity not found"))
            .when(tenantActivityService)
            .getActivityByTenantIdAndTimeWindow(anyString(), anyInt(), anyString());

        ResponseEntity<APIResponse> response = transactionController.getTenantActivityDetailsByTimeWindow(
            tenantId, windowSizeInHours);

        assertEquals(HttpStatus.NOT_FOUND.value(), response.getBody().status());
        assertEquals("Tenant activity not found", response.getBody().message());
        assertNull(response.getBody().result());
    }

    @Test
    public void testGetTenantActivityDetailsByTimeWindowKafkaStoreAccessException() {
        String tenantId = "tenant123";
        int windowSizeInHours = 1;

        doThrow(new KafkaStoreAccessException("Kafka store access error",
            KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION))
            .when(tenantActivityService)
            .getActivityByTenantIdAndTimeWindow(anyString(), anyInt(), anyString());

        ResponseEntity<APIResponse> response = transactionController.getTenantActivityDetailsByTimeWindow(
            tenantId, windowSizeInHours);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
        assertEquals(
            "Error processing getTenantActivityDetailsByTimeWindow request: Kafka store access error",
            response.getBody().message());
        assertEquals(KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION,
            response.getBody().result());
    }

    @Test
    public void testGetTenantActivityDetailsByTimeWindowGenericException() {
        String tenantId = "tenant123";
        int windowSizeInHours = 1;

        doThrow(new RuntimeException("Unexpected error"))
            .when(tenantActivityService)
            .getActivityByTenantIdAndTimeWindow(anyString(), anyInt(), anyString());

        ResponseEntity<APIResponse> response = transactionController.getTenantActivityDetailsByTimeWindow(
            tenantId, windowSizeInHours);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
        assertEquals(
            "Error processing getTenantActivityDetailsByTimeWindow request: Unexpected error",
            response.getBody().message());
        assertNull(response.getBody().result());
    }

    @Test
    public void test_getGsiTrendsAnalysis() {

        ConcurrentHashMap<Long, GsiTrendsValueInfo> mockActivityInfo = new ConcurrentHashMap<>();
        when(
                gsiActivityService.getGsiTrendsMap()).thenReturn(mockActivityInfo);

        ResponseEntity<APIResponse> response = transactionController.getGsiTrendsAnalysis();
        assertEquals(HttpStatus.OK.value(), response.getBody().status());
        assertEquals(SUCCESS_MSG, response.getBody().message());
        assertNotNull(response.getBody().result());
        assertTrue(response.getBody().result() instanceof Map);
    }
    @Test
    public void test_getGsiTrendsAnalysisException() {

        doThrow(new RuntimeException("Unexpected error"))
                .when(gsiActivityService)
                .getGsiTrendsMap();

        ResponseEntity<APIResponse> response = transactionController.getGsiTrendsAnalysis();

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
        assertEquals(
                "Error processing getGsiTrendsAnalysis request: Unexpected error",
                response.getBody().message());
        assertNull(response.getBody().result());
    }
    @Test
    public void test_getGsiTrendsAnalysisExceptionKafkaStoreAccessException() {


        doThrow(new KafkaStoreAccessException("Kafka store access error",
                KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION))
                .when(gsiActivityService)
                .getGsiTrendsMap();

        ResponseEntity<APIResponse> response = transactionController.getGsiTrendsAnalysis();
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
        assertEquals(
                "Error processing getGsiTrendsAnalysis request: Kafka store access error",
                response.getBody().message());
        assertEquals(KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION,
                response.getBody().result());
    }
    @Test
    public void test_gsiTrendsAnalysisByName() {
        String gsiName="test";
        ConcurrentHashMap<Long, GsiTrendsValueInfo> mockActivityInfo = new ConcurrentHashMap<>();
        when(
                gsiActivityService.getGsiTrendsMapByName(gsiName)).thenReturn(mockActivityInfo);

        ResponseEntity<APIResponse> response = transactionController.gsiTrendsAnalysisByName(gsiName);
        assertEquals(HttpStatus.OK.value(), response.getBody().status());
        assertEquals(SUCCESS_MSG, response.getBody().message());
        assertNotNull(response.getBody().result());
        assertTrue(response.getBody().result() instanceof Map);
    }
    @Test
    public void test_gsiTrendsAnalysisByNameException() {
        String gsiName="test";

        doThrow(new RuntimeException("Unexpected error"))
                .when(gsiActivityService)
                .getGsiTrendsMapByName(gsiName);

        ResponseEntity<APIResponse> response = transactionController.gsiTrendsAnalysisByName(gsiName);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
        assertEquals(
                "Error processing gsiTrendsAnalysisByName request: Unexpected error",
                response.getBody().message());
        assertNull(response.getBody().result());
    }
    @Test
    public void test_gsiTrendsAnalysisByNameKafkaStoreAccessException() {

        String gsiName="test";
        doThrow(new KafkaStoreAccessException("Kafka store access error",
                KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION))
                .when(gsiActivityService)
                .getGsiTrendsMapByName(gsiName);

        ResponseEntity<APIResponse> response = transactionController.gsiTrendsAnalysisByName(gsiName);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
        assertEquals(
                "Error processing gsiTrendsAnalysisByName request: Kafka store access error",
                response.getBody().message());
        assertEquals(KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION,
                response.getBody().result());
    }
    @Test
    public void test_allReservedCuTypes() {
        Map<String, Set<String>> mockActivityInfo = new HashMap<>();
        when(
                gsiActivityService.getReservedCuTypes()).thenReturn(mockActivityInfo);

        ResponseEntity<APIResponse> response = transactionController.allReservedCuTypes();
        assertEquals(HttpStatus.OK.value(), response.getBody().status());
        assertEquals(SUCCESS_MSG, response.getBody().message());
        assertNotNull(response.getBody().result());
        assertTrue(response.getBody().result() instanceof Map);
    }
    @Test
    public void test_allReservedCuTypesException() {

        doThrow(new RuntimeException("Unexpected error"))
                .when(gsiActivityService)
                .getReservedCuTypes();

        ResponseEntity<APIResponse> response = transactionController.allReservedCuTypes();

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
        assertEquals(
                "Error processing allReservedCuTypes request: Unexpected error",
                response.getBody().message());
        assertNull(response.getBody().result());
    }
    @Test
    public void test_allReservedCuTypesKafkaStoreAccessException() {

        doThrow(new KafkaStoreAccessException("Kafka store access error",
                KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION))
                .when(gsiActivityService)
                .getReservedCuTypes();

        ResponseEntity<APIResponse> response = transactionController.allReservedCuTypes();
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getBody().status());
        assertEquals(
                "Error processing allReservedCuTypes request: Kafka store access error",
                response.getBody().message());
        assertEquals(KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION,
                response.getBody().result());
    }

}