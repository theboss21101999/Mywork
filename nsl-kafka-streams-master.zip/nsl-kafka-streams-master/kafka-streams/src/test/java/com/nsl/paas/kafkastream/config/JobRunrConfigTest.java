package com.nsl.paas.kafkastream.config;

import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.storage.StorageProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class JobRunrConfigTest {

    @Mock
    private JobMapper jobMapper;

    @InjectMocks
    private JobRunrConfig jobRunrConfig;

    @BeforeEach
    public void setUp() {
        // Initialize mocks before each test
    }

    @Test
    public void storageProviderBeanShouldBeConfiguredCorrectly() {
        // Act
        StorageProvider storageProvider = jobRunrConfig.storageProvider(jobMapper);

        // Assert
        assertNotNull(storageProvider, "StorageProvider bean should not be null");
        // Additional assertions can be added here if needed
    }
}
