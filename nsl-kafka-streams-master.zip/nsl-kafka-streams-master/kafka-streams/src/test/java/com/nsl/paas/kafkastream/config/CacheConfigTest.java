package com.nsl.paas.kafkastream.config;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.nsl.paas.kafkastream.model.CuDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

public class CacheConfigTest {

    @Mock
    private CacheBuilder<Long, String> mockCacheBuilder;

    @InjectMocks
    private CacheConfig cacheConfig;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void guavaCacheShouldBeConfiguredCorrectly() {
        // Mock Cache instance
        Cache<Long, String> mockCache = CacheBuilder.newBuilder()
            .maximumSize(100)
            .expireAfterWrite(10, TimeUnit.MINUTES)
            .build();

        // Mock CacheBuilder behavior
        when(mockCacheBuilder.maximumSize(100)).thenReturn(mockCacheBuilder);
        when(mockCacheBuilder.expireAfterWrite(10, TimeUnit.MINUTES)).thenReturn(mockCacheBuilder);
        when(mockCacheBuilder.build()).thenReturn(mockCache);

        // Call the method under test
        Cache<Long, CuDetails> cache = cacheConfig.guavaCache();

        // Verify the configuration
        assertNotNull(cache);
    }

    @Test
    public void restTemplateShouldBeConfigured() {
        // Call the method under test
        RestTemplate restTemplate = cacheConfig.restTemplate();

        // Verify that the RestTemplate bean is created
        assertNotNull(restTemplate);
    }

    @Test
    public void guavaCacheAndRestTemplateShouldBeInjected() {
        // Call the method under test
        assertNotNull(cacheConfig.guavaCache());
        assertNotNull(cacheConfig.restTemplate());
    }
}