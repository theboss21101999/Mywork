package com.nsl.paas.kafkastream.serviceImpl;

public class TenantActivityServiceImplTest {
}
