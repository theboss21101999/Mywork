package com.nsl.paas.kafkastream.controller;

import com.fasterxml.jackson.core.JsonProcessingException;

import com.nsl.paas.kafkastream.dto.CuTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.CuTransactionValueDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionValueDto;
import com.nsl.paas.kafkastream.dto.UserKeyDto;
import com.nsl.paas.kafkastream.model.ContainerCuInfo;
import com.nsl.paas.kafkastream.model.GsiTrendsValueInfo;
import com.nsl.paas.kafkastream.model.TenantActivityInfo;
import com.nsl.paas.kafkastream.model.UserActivityInfo;
import com.nsl.paas.kafkastream.service.GsiActivityService;

import com.nsl.paas.kafkastream.service.TenantActivityService;
import com.nsl.paas.kafkastream.service.UserActivityService;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.ui.Model;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.nsl.paas.kafkastream.constants.AppConstants.GSI_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.TRANSACTION_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.TENANT_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_START_TIME;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_END_TIME;
import static com.nsl.paas.kafkastream.constants.AppConstants.TRIGGERED_TIME;
import static com.nsl.paas.kafkastream.constants.AppConstants.DURATION;
import static com.nsl.paas.kafkastream.constants.AppConstants.TRIGGER_STATE;
import static com.nsl.paas.kafkastream.constants.AppConstants.EMAIL_ID;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class TransactionDisplayControllerTest {

    @Mock
    private StreamsBuilderFactoryBean factoryBean;

    @Mock
    private KafkaStreams kafkaStreams;

    @Mock
    private ReadOnlyKeyValueStore<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> gsiTable;

    @Mock
    private ReadOnlyKeyValueStore<CuTransactionKeyDto, CuTransactionValueDto> cuTable;

    @Mock
    private GsiActivityService gsiActivityService;

    @Mock
    private UserActivityService userActivityService;

    @Mock
    private TenantActivityService tenantActivityService;

    @InjectMocks
    private TransactionDisplayController transactionDisplayController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testDisplayGsiExecutionTable() {

        List<Map<String, String>> gsiExecutionDataList = new ArrayList<>();
        Map<String, String> rowData1 = new HashMap<>();
        rowData1.put(GSI_NAME, "gsiKey1");
        rowData1.put(TRANSACTION_ID, "123");
        rowData1.put(TENANT_ID, "tenant1");

        gsiExecutionDataList.add(rowData1);

        when(gsiActivityService.getGsiExecutionActivityMapAsList()).thenReturn(gsiExecutionDataList);

        Model model = mock(Model.class);

        String result = transactionDisplayController.displayGsiExecutionTable(model);

        assertEquals("gsiExecutionTemplate", result);

        verify(model).addAttribute("gsiExecutionDataList", gsiExecutionDataList);
    }

    @Test
    public void testDisplayCuTable() throws JsonProcessingException {

        List<Map<String, String>> cuDataList = new ArrayList<>();
        Map<String, String> rowData1 = new HashMap<>();
        rowData1.put(TRANSACTION_ID, "123");
        rowData1.put(CU_NAME, "test");
        rowData1.put(CU_ID, "456");
        rowData1.put(TENANT_ID, "tenant1");
        rowData1.put(CU_START_TIME, LocalDateTime.of(2023, 2, 10, 10, 30).toString());
        rowData1.put(TRIGGERED_TIME, LocalDateTime.of(2023, 2, 10, 10, 35).toString());
        rowData1.put(CU_END_TIME, LocalDateTime.of(2023, 2, 10, 10, 40).toString());
        rowData1.put(DURATION, "300 secs");
        rowData1.put(TRIGGER_STATE, "triggered");
        rowData1.put(EMAIL_ID, "test@example.com");

        cuDataList.add(rowData1);

        Map<String, String> rowData2 = new HashMap<>();
        rowData2.put(TRANSACTION_ID, "124");
        rowData2.put(CU_NAME, "anotherTest");
        rowData2.put(CU_ID, "457");
        rowData2.put(TENANT_ID, "tenant2");
        rowData2.put(CU_START_TIME, LocalDateTime.of(2023, 2, 10, 11, 30).toString());
        rowData2.put(TRIGGERED_TIME, LocalDateTime.of(2023, 2, 10, 11, 35).toString());
        rowData2.put(CU_END_TIME, LocalDateTime.of(2023, 2, 10, 11, 40).toString());
        rowData2.put(DURATION, "300 secs");
        rowData2.put(TRIGGER_STATE, "triggered");
        rowData2.put(EMAIL_ID, "anotherTest@example.com");

        cuDataList.add(rowData2);

        when(gsiActivityService.getCuExecutionActivityMapAsList()).thenReturn(cuDataList);

        Model model = mock(Model.class);

        String result = transactionDisplayController.displayCuTable(model);

        assertEquals("cuDetailsTable", result);

        verify(model).addAttribute("cuDataList", cuDataList);
    }

    @Test
    public void testGsiAnalytics() {
        // Create sample data for success and failure counts
        Map<String, Long> successCounts = new HashMap<>();
        successCounts.put("key1", 10L);

        Map<String, Long> failureCounts = new HashMap<>();
        failureCounts.put("key2", 5L);

        when(gsiActivityService.getGsiAnalyticsMapAsList()).thenReturn(
                Arrays.asList(successCounts, failureCounts));

        Model model = mock(Model.class);

        String result = transactionDisplayController.gsiAnalytics(model);

        assertEquals("gsiCountTreeMap", result);

        verify(model).addAttribute("gsiSuccessCountList", successCounts);
        verify(model).addAttribute("gsiFailureCountList", failureCounts);
    }

    @Test
    public void redoc(){
        String result= transactionDisplayController.redoc();
        assertEquals("redoc",result);
    }
    @Test
    public void testUserActivityAnalytics(){

        int windowSizeInHours = 1;
        List<UserActivityInfo> userActivityList = new ArrayList<>();
        Map<String, ContainerCuInfo> containerCuName = new HashMap<>();
        ContainerCuInfo containerCuInfo1 = new ContainerCuInfo();
        containerCuInfo1.setContainerCuName("abc");
        containerCuInfo1.setTotalTransactions(1L);
        ContainerCuInfo containerCuInfo2 = new ContainerCuInfo();
        containerCuInfo2.setContainerCuName("edc");
        containerCuInfo2.setTotalTransactions(1L);

        containerCuName.put("abc", containerCuInfo1);
        containerCuName.put("edc", containerCuInfo2);
        Set<String> tenants = new HashSet<>();
        tenants.add("Test Tenant");
        UserActivityInfo rowData1 = UserActivityInfo.Builder()
                .withEmailId("xyz@gmail.com")
                .withUserId(12132L)
                .withTenantIds(tenants)
                .withAvgDuration(12L)
                .withTotalTransactions(2L)
                .withTotalCompletedTransactions(2L)
                .withTotalFailedTransactions(0L)
                .withTotalIncompleteTransactions(0L)
                .withContainerCuNames(containerCuName)
                .build();

        userActivityList.add(rowData1);

        when(userActivityService.getUserActivityListByTimeWindow(windowSizeInHours)).thenReturn(userActivityList);

        Model model = mock(Model.class);

        String result = transactionDisplayController.userActivityAnalytics(windowSizeInHours,model);

        assertEquals("userActivityTable",result);

        verify(model).addAttribute("userActivityList",userActivityList);
    }
    @Test
    public void testUserActivityAnalytics_Error() {
        int windowSizeInHours = 0;  // Invalid window size
        Model model = mock(Model.class);

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            transactionDisplayController.userActivityAnalytics(windowSizeInHours, model);
        });

        assertEquals("Invalid window size specified. Valid values are 1, 3, 6, 12, 24.", thrown.getMessage());
    }

    @Test
    public void testTenantActivityAnalytics(){

        int windowSizeInHours = 1;
        List<TenantActivityInfo> tenantActivityList = new ArrayList<>();

        LinkedHashMap<String, Long> containerCuNames = new LinkedHashMap<>();
        Map<String, ContainerCuInfo> containerCuName = new HashMap<>();
        ContainerCuInfo containerCuInfo1 = new ContainerCuInfo();
        containerCuInfo1.setContainerCuName("abc");
        containerCuInfo1.setTotalTransactions(1L);
        ContainerCuInfo containerCuInfo2 = new ContainerCuInfo();
        containerCuInfo2.setContainerCuName("edc");
        containerCuInfo2.setTotalTransactions(1L);

        containerCuName.put("abc", containerCuInfo1);
        containerCuName.put("edc", containerCuInfo2);

        Set<UserKeyDto> users = new HashSet<>();
        UserKeyDto userKeyDto = new UserKeyDto(123L,"xyz@gmail.com");
        users.add(userKeyDto);

        TenantActivityInfo rowData1 = TenantActivityInfo.builder()
                .withTenantId("Test Tenant")
                .withTotalTransactions(2L)
                .withTotalCompletedTransactions(2L)
                .withTotalFailedTransactions(0L)
                .withTotalIncompleteTransactions(0L)
                .withAvgDuration(12L)
                .withContainerCuNames(containerCuName)
                .withUsers(users)
                .build();

        tenantActivityList.add(rowData1);

        when(tenantActivityService.getTenantActivityListByTimeWindow(windowSizeInHours)).thenReturn(tenantActivityList);

        Model model = mock(Model.class);

        String result = transactionDisplayController.tenantActivityAnalytics(windowSizeInHours,model);

        assertEquals("tenantActivityTable",result);

        verify(model).addAttribute("tenantActivityList",tenantActivityList);
    }
    @Test
    public void testuserActivity(){

        int windowSizeInHours = 1;
        long userId = 1213;
        String emailId = "xyz@gmail.com";
        Map<String, ContainerCuInfo> containerCuName = new HashMap<>();
        ContainerCuInfo containerCuInfo1 = new ContainerCuInfo();
        containerCuInfo1.setContainerCuName("abc");
        containerCuInfo1.setTotalTransactions(1L);
        containerCuInfo1.setTotalCompletedTransactions(1l);
        Set<Long> transactionIds = new HashSet<>();
        transactionIds.add(1L);
        transactionIds.add(2L);
        containerCuInfo1.setTransactionIds(transactionIds);
        containerCuInfo1.setTotalDuration(1L);
        containerCuInfo1.setLastAddedDuration(1L);
        containerCuInfo1.setTotalFailedTransactions(1L);
        containerCuInfo1.setTotalIncompleteTransactions(1L);

        ContainerCuInfo containerCuInfo2 = new ContainerCuInfo();
        containerCuInfo2.setContainerCuName("edc");
        containerCuInfo2.setTotalTransactions(1L);
        containerCuInfo2.setTotalCompletedTransactions(1L);
        containerCuInfo2.setTransactionIds(transactionIds);
        containerCuInfo2.setTotalDuration(1L);
        containerCuInfo2.setLastAddedDuration(1L);
        containerCuInfo2.setTotalFailedTransactions(1L);
        containerCuInfo2.setTotalIncompleteTransactions(1L);
        containerCuName.put("abc", containerCuInfo1);
        containerCuName.put("edc", containerCuInfo2);
        Set<String> tenants = new HashSet<>();
        tenants.add("Test Tenant");
        UserActivityInfo userActivityInfo = UserActivityInfo.Builder()
                .withEmailId("xyz@gmail.com")
                .withUserId(1213L)
                .withTenantIds(tenants)
                .withAvgDuration(12L)
                .withTotalTransactions(2L)
                .withTotalCompletedTransactions(2L)
                .withTotalFailedTransactions(0L)
                .withTotalIncompleteTransactions(0L)
                .withContainerCuNames(containerCuName)
                .build();

        Map<String, ContainerCuInfo> containerCuName1 = new HashMap<>();
        containerCuName1.put("abc",containerCuInfo1);
        containerCuName1.put("edc",containerCuInfo2);


        when(userActivityService.getActivityByUserIdAndTimeWindow(userId, emailId, windowSizeInHours,"DISPLAY_CONTROLLER")).
                thenReturn(userActivityInfo);

        Model model = mock(Model.class);

        String result = transactionDisplayController.userActivity(userId,emailId,windowSizeInHours,model);

        assertEquals("userActivity",result);
        verify(model).addAttribute("userActivityInfoObj",userActivityInfo);
        verify(model).addAttribute("userId",userId);
        verify(model).addAttribute("emailId",emailId);

    }
    @Test
    public void testTenantActivity(){

        int windowSizeInHours = 1;
        String tenantId = "Test Tenant";

        Map<String, ContainerCuInfo> containerCuName = new HashMap<>();
        ContainerCuInfo containerCuInfo1 = new ContainerCuInfo();
        containerCuInfo1.setContainerCuName("abc");
        containerCuInfo1.setTotalTransactions(1L);
        ContainerCuInfo containerCuInfo2 = new ContainerCuInfo();
        containerCuInfo2.setContainerCuName("edc");
        containerCuInfo2.setTotalTransactions(1L);

        containerCuName.put("abc", containerCuInfo1);
        containerCuName.put("edc", containerCuInfo2);

        TenantActivityInfo tenantActivityInfo = TenantActivityInfo.builder()
                .withTenantId("Test Tenant")
                .withTotalTransactions(2L)
                .withTotalCompletedTransactions(2L)
                .withTotalFailedTransactions(0L)
                .withTotalIncompleteTransactions(0L)
                .withAvgDuration(12L)
                .withContainerCuNames(containerCuName)
                .build();

        List<Map<String, Long>> containerCuNames = new ArrayList<>();
        Map<String, Long> containerCuName1 = new HashMap<>();
        containerCuName1.put("abc",1L);
        containerCuNames.add(containerCuName1);
        Map<String, Long> containerCuName2 = new HashMap<>();
        containerCuName2.put("edc",1L);
        containerCuNames.add(containerCuName2);

        when(tenantActivityService.getActivityByTenantIdAndTimeWindow(tenantId, windowSizeInHours,"DISPLAY_CONTROLLER")).
                thenReturn(tenantActivityInfo);

        Model model = mock(Model.class);

        String result = transactionDisplayController.tenantActivity(tenantId,windowSizeInHours,model);

        assertEquals("tenantActivity",result);
        verify(model).addAttribute("tenantActivityInfo",tenantActivityInfo);
        verify(model).addAttribute("tenantId",tenantId);
        verify(model).addAttribute("users",tenantActivityInfo.getUsers());

    }
    @Test
    public void test_displayGsiTrends() {
        // Create sample data for success and failure counts
        ConcurrentHashMap<Long, GsiTrendsValueInfo> response=new ConcurrentHashMap<>();
        when(gsiActivityService.getGsiTrendsMap()).thenReturn(
                response);

        Model model = mock(Model.class);

        String result = transactionDisplayController.displayGsiTrends(model);

        assertEquals("gsiTrendsTable", result);

        verify(model).addAttribute("gsiTrendsMap", response);

    }
    @Test
    public void test_displayForGsiTrendsByName() {
        String gsiName="test";
        // Create sample data for success and failure counts
        ConcurrentHashMap<Long, GsiTrendsValueInfo> response=new ConcurrentHashMap<>();
        when(gsiActivityService.getGsiTrendsMapByName(gsiName)).thenReturn(
                response);

        Model model = mock(Model.class);

        String result = transactionDisplayController.displayForGsiTrendsByName(model,gsiName);

        assertEquals("gsiTrends", result);


    }



}