package com.nsl.paas.kafkastream.config;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.lang.reflect.Field;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class KafkaAvroConfigTest {

    @InjectMocks
    private KafkaAvroConfig kafkaAvroConfig;

    private static final String TEST_BOOTSTRAP_ADDRESS = "localhost:9092";
    private static final String TEST_SCHEMA_REGISTRY_URL = "http://localhost:8081";

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        setPrivateField(kafkaAvroConfig, "bootstrapAddress", TEST_BOOTSTRAP_ADDRESS);
        setPrivateField(kafkaAvroConfig, "schemaRegistryUrl", TEST_SCHEMA_REGISTRY_URL);
    }

    private void setPrivateField(Object target, String fieldName, String value) throws NoSuchFieldException, IllegalAccessException {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    public void kafkaTemplateBeanShouldBeConfiguredCorrectly() {
        // Act
        KafkaTemplate<Object, Object> kafkaTemplate = kafkaAvroConfig.kafkaTemplate();

        // Assert
        assertNotNull(kafkaTemplate, "KafkaTemplate bean should not be null");
    }

    @Test
    public void producerFactoryBeanShouldBeConfiguredCorrectly() {
        // Act
        ProducerFactory<Object, Object> producerFactory = kafkaAvroConfig.producerFactory();

        // Assert
        assertNotNull(producerFactory, "ProducerFactory bean should not be null");
        assertEquals(DefaultKafkaProducerFactory.class, producerFactory.getClass(), "ProducerFactory should be an instance of DefaultKafkaProducerFactory");

        Map<String, Object> configProps = ((DefaultKafkaProducerFactory<Object, Object>) producerFactory).getConfigurationProperties();
        assertEquals(TEST_BOOTSTRAP_ADDRESS, configProps.get(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG), "Bootstrap servers should match");
        assertEquals(KafkaAvroSerializer.class.getName(), configProps.get(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG), "Key serializer should match");
        assertEquals(KafkaAvroSerializer.class.getName(), configProps.get(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG), "Value serializer should match");
        assertEquals(TEST_SCHEMA_REGISTRY_URL, configProps.get("schema.registry.url"), "Schema registry URL should match");
    }
}
