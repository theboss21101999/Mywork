package com.nsl.paas.kafkastream.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.ClassPathResource;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.templateresolver.FileTemplateResolver;

import java.io.File;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class LocalDevConfigTest {

    @Mock
    private TemplateEngine templateEngine;

    @InjectMocks
    private LocalDevConfig localDevConfig;

    @BeforeEach
    public void setUp() throws Exception {
        // The constructor of LocalDevConfig will be automatically called with the injected TemplateEngine mock
    }

    @Test
    public void testLocalDevConfig() throws Exception {
        // Capture the FileTemplateResolver that was set in the TemplateEngine
        ArgumentCaptor<FileTemplateResolver> captor = ArgumentCaptor.forClass(FileTemplateResolver.class);
        verify(templateEngine).setTemplateResolver(captor.capture());

        FileTemplateResolver fileTemplateResolver = captor.getValue();
        assertNotNull(fileTemplateResolver, "FileTemplateResolver should not be null");

        File sourceRoot = new ClassPathResource("application.properties").getFile().getParentFile();
        while (sourceRoot.listFiles((dir, name) -> name.equals("gradlew")).length != 1) {
            sourceRoot = sourceRoot.getParentFile();
        }

        assertEquals(sourceRoot.getPath() + "/src/main/resources/templates/", fileTemplateResolver.getPrefix(), "Prefix should match the source root path");
        assertEquals(".html", fileTemplateResolver.getSuffix(), "Suffix should be .html");
        assertFalse(fileTemplateResolver.isCacheable(), "Cacheable should be false");
        assertEquals("UTF-8", fileTemplateResolver.getCharacterEncoding(), "Character encoding should be UTF-8");
        assertEquals(true, fileTemplateResolver.getCheckExistence(), "Check existence should be true");
    }
}
