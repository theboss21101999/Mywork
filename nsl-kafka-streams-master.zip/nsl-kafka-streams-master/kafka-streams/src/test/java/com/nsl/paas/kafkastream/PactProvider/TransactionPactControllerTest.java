package com.nsl.paas.kafkastream.PactProvider;

import au.com.dius.pact.provider.junit5.HttpTestTarget;
import au.com.dius.pact.provider.junit5.PactVerificationContext;
import au.com.dius.pact.provider.junit5.PactVerificationInvocationContextProvider;
import au.com.dius.pact.provider.junitsupport.Consumer;
import au.com.dius.pact.provider.junitsupport.Provider;
import au.com.dius.pact.provider.junitsupport.State;
import au.com.dius.pact.provider.junitsupport.loader.PactBroker;
import au.com.dius.pact.provider.junitsupport.loader.PactBrokerAuth;
import au.com.dius.pact.provider.junitsupport.loader.SelectorBuilder;
import com.nsl.paas.kafkastream.controller.TransactionController;
import com.nsl.paas.kafkastream.dto.APIResponse;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestTemplate;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.mockito.Mockito.when;

@Provider("StreamApplication")
@PactBroker(
        host = "localhost",
        port = "9292",
        authentication = @PactBrokerAuth(username = "pact_workshop", password = "pact_workshop")
)
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@DirtiesContext
public class TransactionPactControllerTest {
    @MockBean
    private TransactionController transactionController;
    @BeforeEach
    void before(PactVerificationContext context) {
        context.setTarget(new HttpTestTarget("localhost", port));
    }
    @LocalServerPort
    private int port;
    @TestTemplate
    @ExtendWith(PactVerificationInvocationContextProvider.class)
    void pactVerificationTestTemplate(PactVerificationContext context) {
        context.verifyInteraction();
    }
    @State("Gsi Failed Count Test")
    void getFailedGsiCountState() {
        APIResponse apiResponse=new APIResponse("Success",2, HttpStatus.OK.value());
        when(transactionController.gsiFailedCount("gsiTest")).thenReturn(new ResponseEntity<>(apiResponse, HttpStatus.OK));

    }
    @State("Gsi completed Count Test")
    void getCompletedGsiCountState() {
        APIResponse apiResponse=new APIResponse("Success",2, HttpStatus.OK.value());
        when(transactionController.gsiCompletedCount("gsiTest")).thenReturn(new ResponseEntity<>(apiResponse, HttpStatus.OK));
    }
    @State("Gsi Duration")
    void getGsiDurationState() {
        APIResponse apiResponse=new APIResponse("Success","{\n" +
                "    \"gsiName\": \"gsiTest\",\n" +
                "    \"transactionId\": 1548557309991,\n" +
                "    \"tenantId\": \"testTenant\",\n" +
                "    \"startTime\": \"2024-02-16T19:41:40.269\",\n" +
                "    \"endTime\": \"2024-02-19T13:36:33.574\",\n" +
                "    \"duration\": 237293.305,\n" +
                "    \"transactionStatus\": \"TRIGGERED\",\n" +
                "    \"currentCuName\": \"Input1_SpecialCharacterInCurrencySolution 2024021614024026737\",\n" +
                "    \"emailId\": \"usercco1@nslhub.com\",\n" +
                "    \"lastUpdated\": 1708329993574\n" +
                "}", HttpStatus.OK.value());
        when(transactionController.getGsiDuration("gsiTest",1548557309991L,"testTenant")).thenReturn(new ResponseEntity<>(apiResponse, HttpStatus.OK));
    }
    @State("Gsi completion Count list Test")
    void getCompletedGsiCountListState(){
        APIResponse apiResponse=new APIResponse("Success","{\n" +
                "    \"gsiTest1\": 3,\n" +
                "    \"gsiTest2\": 4,\n" +
                "    \"gsiTest3\": 200\n" +
                "}",HttpStatus.OK.value());
        when(transactionController.facets()).thenReturn(new ResponseEntity<>(apiResponse, HttpStatus.OK));


    }





}
