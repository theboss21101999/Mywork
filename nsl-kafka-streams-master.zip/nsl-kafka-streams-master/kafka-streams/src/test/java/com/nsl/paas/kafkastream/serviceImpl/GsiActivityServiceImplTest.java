package com.nsl.paas.kafkastream.serviceImpl;

import com.nsl.paas.kafkastream.dto.*;
import com.nsl.paas.kafkastream.enums.KafkaStoreExceptionType;
import com.nsl.paas.kafkastream.exceptions.KafkaStoreAccessException;
import com.nsl.paas.kafkastream.exceptions.NotFoundException;

import com.nsl.paas.kafkastream.model.CuDetails;
import com.nsl.paas.kafkastream.model.GsiTrendsValueInfo;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.errors.TimeoutException;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StoreQueryParameters;
import org.apache.kafka.streams.errors.InvalidStateStoreException;
import org.apache.kafka.streams.state.KeyValueIterator;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class GsiActivityServiceImplTest {

    @Mock
    private StreamsBuilderFactoryBean factoryBean;

    @Mock
    private KafkaStreams kafkaStreams;

    @Mock
    private ReadOnlyKeyValueStore<String, Long> testKTable;
    @Mock
    ReadOnlyKeyValueStore<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> gsiDurationStore;
    @Mock
    ReadOnlyKeyValueStore<CuTransactionKeyDto, CuTransactionValueDto> cuTable;

    @Mock
    ReadOnlyKeyValueStore<GsiTrendsKey, GsiTrendsValueInfo> gsiCuTable;

    @InjectMocks
    private GsiActivityServiceImpl gsiActivityService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        when(factoryBean.getKafkaStreams()).thenReturn(kafkaStreams);
    }
    @Test
    public void testGetCompletedGsiCountByGsiName(){

        String gsiName = "testGSI";
        Long expectedCount = 5L;
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(testKTable);
        when(testKTable.get(gsiName)).thenReturn(expectedCount);

        Long actualCount = gsiActivityService.getCompletedGsiCountByGsiName(gsiName);
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testGetCompletedGsiCountByGsiName_NotFoundException() {
        String unknownGsiName = "unknownGSI";
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(testKTable);
        when(testKTable.get(unknownGsiName)).thenReturn(null); // Simulate gsiName not found

        Exception exception = assertThrows(NotFoundException.class, () ->
                gsiActivityService.getCompletedGsiCountByGsiName(unknownGsiName));

        assertTrue(exception.getMessage().contains("not found in the kTable for completed transactions"));
    }

    @Test
    public void testGetCompletedGsiCountByGsiName_InvalidStateStoreException() {
        String gsiName = "testGSI";
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new InvalidStateStoreException("State store is not available"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () ->
                gsiActivityService.getCompletedGsiCountByGsiName(gsiName));

        assertTrue(exception.getMessage().contains("InvalidStateStoreException occurred while retrieving"));
    }

    @Test
    public void testGetCompletedGsiCountByGsiName_SerializationException() {
        String gsiName = "testGSI";
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new SerializationException("Error during serialization"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () ->
                gsiActivityService.getCompletedGsiCountByGsiName(gsiName));

        assertTrue(exception.getMessage().contains("SerializationException occurred while retrieving"));
    }

    @Test
    public void testGetCompletedGsiCountByGsiName_TimeoutException() {
        String gsiName = "testGSI";
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new TimeoutException("Timeout occurred"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () ->
                gsiActivityService.getCompletedGsiCountByGsiName(gsiName));

        assertTrue(exception.getMessage().contains("TimeoutException occurred while retrieving"));
    }

    @Test
    public void testGetCompletedGsiCountByGsiName_UnexpectedException() {
        String gsiName = "testGSI";
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new RuntimeException("Unexpected error"));

        Exception exception = assertThrows(RuntimeException.class, () ->
                gsiActivityService.getCompletedGsiCountByGsiName(gsiName));

        assertTrue(exception.getMessage().contains("Exception occurred while retrieving"));
    }

    @Test
    public void testGetFailedGsiCountByGsiName(){

        String gsiName = "testGSI";
        Long expectedCount = 5L;
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(testKTable);
        when(testKTable.get(gsiName)).thenReturn(expectedCount);

        Long actualCount = gsiActivityService.getFailedGsiCountByGsiName(gsiName);
        assertEquals(expectedCount, actualCount);
    }

    @Test
    public void testGetFailedGsiCountByGsiName_NotFoundException() {
        String gsiName = "nonExistentGSI";
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(testKTable);
        when(testKTable.get(gsiName)).thenReturn(null);

        Exception exception = assertThrows(NotFoundException.class, () ->
                gsiActivityService.getFailedGsiCountByGsiName(gsiName));

        String expectedMessage = "GSI name 'nonExistentGSI' not found in the kTable for failed transactions";
        assertEquals(expectedMessage, exception.getMessage());
    }

    @Test
    public void testGetFailedGsiCountByGsiName_InvalidStateStoreException() {
        String gsiName = "testGSI";
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new InvalidStateStoreException("State store is not valid"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () ->
                gsiActivityService.getFailedGsiCountByGsiName(gsiName));

        String expectedMessage = "InvalidStateStoreException occurred while retrieving the failure count for GSI Name: testGSI";
        assertEquals(expectedMessage, exception.getMessage());
    }

    @Test
    public void testGetFailedGsiCountByGsiName_SerializationException() {
        String gsiName = "testGSI";
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new SerializationException("Error during serialization"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () ->
                gsiActivityService.getFailedGsiCountByGsiName(gsiName));

        String expectedMessage = "SerializationException occurred while retrieving the failure count for GSI Name: testGSI";
        assertEquals(expectedMessage, exception.getMessage());
    }

    @Test
    public void testGetFailedGsiCountByGsiName_TimeoutException() {
        String gsiName = "testGSI";
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new TimeoutException("Operation timed out"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () ->
                gsiActivityService.getFailedGsiCountByGsiName(gsiName));

        String expectedMessage = "TimeoutException occurred while retrieving the failure count for GSI Name: testGSI";
        assertEquals(expectedMessage, exception.getMessage());
    }

    @Test
    public void testGetFailedGsiCountByGsiName_UnexpectedException() {
        String gsiName = "testGSI";
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new RuntimeException("Unexpected error"));

        Exception exception = assertThrows(RuntimeException.class, () ->
                gsiActivityService.getFailedGsiCountByGsiName(gsiName));

        String expectedMessage = "Exception occurred while retrieving the failure count for GSI Name: testGSI";
        assertEquals(expectedMessage, exception.getMessage());
    }


    @Test
    public void testGetGsiDurationByTxnIdAndNameAndTenantId(){

         String gsiName = "testGSI";
         long transactionId = 123L;
         String tenantId = "testTenant";
         when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(gsiDurationStore);

        GsiFinalTransactionKeyDto key = new GsiFinalTransactionKeyDto(gsiName, transactionId, tenantId);
        GsiFinalTransactionValueDto expectedValue = new GsiFinalTransactionValueDto(gsiName,transactionId,tenantId,
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),2L,
                "COMPLETED","testCu","xyz@gmail.com",12L);

        when(gsiDurationStore.get(key)).thenReturn(expectedValue);

        GsiFinalTransactionValueDto actualValue = gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId(gsiName,
                transactionId, tenantId);
        assertEquals(expectedValue, actualValue);
        verify(gsiDurationStore).get(key);
    }

    @Test
    void testGetGsiDurationByTxnIdAndNameAndTenantId_NotFoundException() {
        String gsiName = "testGSI";
        long transactionId = 123L;
        String tenantId = "testTenant";

        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(gsiDurationStore);
        when(gsiDurationStore.get(any(GsiFinalTransactionKeyDto.class))).thenReturn(null);

        assertThrows(NotFoundException.class, () ->
                gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId(gsiName, transactionId, tenantId));
    }

    @Test
    void testGetGsiDurationByTxnIdAndNameAndTenantId_InvalidStateStoreException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new InvalidStateStoreException("Store not available"));

        assertThrows(KafkaStoreAccessException.class, () ->
                gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId("testGSI", 123L, "testTenant"));
    }

    @Test
    void testGetGsiDurationByTxnIdAndNameAndTenantId_SerializationException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new SerializationException("Serialization failed"));

        assertThrows(KafkaStoreAccessException.class, () ->
                gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId("testGSI", 123L, "testTenant"));
    }

    @Test
    void testGetGsiDurationByTxnIdAndNameAndTenantId_TimeoutException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new TimeoutException("Timeout occurred"));

        assertThrows(KafkaStoreAccessException.class, () ->
                gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId("testGSI", 123L, "testTenant"));
    }

    @Test
    void testGetGsiDurationByTxnIdAndNameAndTenantId_GeneralException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new RuntimeException("Unexpected error"));

        assertThrows(RuntimeException.class, () ->
                gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId("testGSI", 123L, "testTenant"));
    }

    @Test
    public void testGetCompletedGsiCountMap(){

        KeyValueIterator<String, Long> iterator = mock(KeyValueIterator.class);
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(testKTable);
        when(iterator.hasNext()).thenReturn(true, true, false);
        when(iterator.next()).thenReturn(new KeyValue<>("GSI1", 10L), new KeyValue<>("GSI2", 20L));
        when(testKTable.all()).thenReturn(iterator);

        Map<String, Long> actualMap = gsiActivityService.getCompletedGsiCountMap();

        // Expected result
        Map<String, Long> expectedMap = new HashMap<>();
        expectedMap.put("GSI1", 10L);
        expectedMap.put("GSI2", 20L);

        assertEquals(expectedMap, actualMap);
        verify(testKTable).all();
        verify(iterator, atLeastOnce()).hasNext();
        verify(iterator, times(2)).next();
    }

    @Test
    public void testGetCompletedGsiCountMap_InvalidStateStoreException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new InvalidStateStoreException("State store is not valid"));

        assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getCompletedGsiCountMap();
        });

        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCompletedGsiCountMap_SerializationException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new SerializationException("Error serializing key/value"));

        assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getCompletedGsiCountMap();
        });

        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCompletedGsiCountMap_TimeoutException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new TimeoutException("Timeout accessing store"));

        assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getCompletedGsiCountMap();
        });

        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCompletedGsiCountMap_GenericException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new RuntimeException("Generic error"));

        assertThrows(RuntimeException.class, () -> {
            gsiActivityService.getCompletedGsiCountMap();
        });

        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCuExecutionActivityMap(){

        KeyValueIterator<CuTransactionKeyDto, CuTransactionValueDto> iterator = mock(KeyValueIterator.class);
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(cuTable);
        when(cuTable.all()).thenReturn(iterator);

        when(iterator.hasNext()).thenReturn(true, true, false);
        CuTransactionKeyDto key1 = new CuTransactionKeyDto(12345L,6789L,"testTenant1");
        CuTransactionValueDto value1 = new CuTransactionValueDto(12345L,"testCu1",6789L,new CuDetails("test","HUMAN",true,"adapter","mqtt"),
                "testTenant1",LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),14L,
                "COMPLETED","xyz@gmail1.com",1234567L);
        CuTransactionKeyDto key2 = new CuTransactionKeyDto(123465L,6569L,"testTenant2");
        CuTransactionValueDto value2 = new CuTransactionValueDto(123465L,"testCu",6569L,new CuDetails("test","MACHINE",true,"adapter","mqtt"),
                "testTenant",LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),14L,
                "FAILED","xyz@gmail2.com",1234578L);

        when(iterator.next()).thenReturn(new KeyValue<>(key1, value1), new KeyValue<>(key2, value2));

        Map<CuTransactionKeyDto, CuTransactionValueDto> resultMap = gsiActivityService.getCuExecutionActivityMap();

        assertEquals(2, resultMap.size());
        assertTrue(resultMap.containsKey(key1));
        assertTrue(resultMap.containsKey(key2));
        assertEquals(value1, resultMap.get(key1));
        assertEquals(value2, resultMap.get(key2));

        // Verify interactions
        verify(cuTable).all();
        verify(iterator, atLeastOnce()).hasNext();
        verify(iterator, times(2)).next();
    }

    @Test
    public void testGetCuExecutionActivityMap_InvalidStateStoreException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new InvalidStateStoreException("State store is not valid"));

        assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getCuExecutionActivityMap();
        });

        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCuExecutionActivityMap_SerializationException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new SerializationException("Error serializing key/value"));

        assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getCuExecutionActivityMap();
        });

        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCuExecutionActivityMap_TimeoutException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new TimeoutException("Timeout accessing store"));

        assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getCuExecutionActivityMap();
        });

        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCuExecutionActivityMap_GenericException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new RuntimeException("Generic error"));

        assertThrows(RuntimeException.class, () -> {
            gsiActivityService.getCuExecutionActivityMap();
        });

        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetGsiExecutionActivityMap(){

        KeyValueIterator<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> iterator = mock(KeyValueIterator.class);
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(gsiDurationStore);
        when(gsiDurationStore.all()).thenReturn(iterator);

        when(iterator.hasNext()).thenReturn(true, true, false);
        GsiFinalTransactionKeyDto key1 = new GsiFinalTransactionKeyDto("testGSI1", 123L, "testTenant1");
        GsiFinalTransactionValueDto value1 = new GsiFinalTransactionValueDto("testGSI1",123L,"testTenant1",
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),2L,
                "COMPLETED","testCu","xyz@gmail.com",12L);
        GsiFinalTransactionKeyDto key2 = new GsiFinalTransactionKeyDto("testGSI2", 456L, "testTenant2");
        GsiFinalTransactionValueDto value2 = new GsiFinalTransactionValueDto("testGSI2",456L,"testTenant2",
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),2L,
                "FAILED","testCu","xyz@gmail.com",12L);

        when(iterator.next()).thenReturn(new KeyValue<>(key1, value1), new KeyValue<>(key2, value2));

        Map<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> resultMap = gsiActivityService.getGsiExecutionActivityMap();

        // Assertions
        assertEquals(2, resultMap.size());
        assertTrue(resultMap.containsKey(key1));
        assertTrue(resultMap.containsKey(key2));
        assertEquals(value1, resultMap.get(key1));
        assertEquals(value2, resultMap.get(key2));

        // Verify interactions
        verify(gsiDurationStore).all();
        verify(iterator, atLeastOnce()).hasNext();
        verify(iterator, times(2)).next();
    }

    @Test
    public void testGetGsiExecutionActivityMapWithInvalidStateStoreException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new InvalidStateStoreException("State store is not valid"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiExecutionActivityMap();
        });

        assertTrue(exception instanceof KafkaStoreAccessException);
        assertEquals("InvalidStateStoreException occurred while retrieving GSI execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof InvalidStateStoreException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetGsiExecutionActivityMapWithSerializationException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new SerializationException("Error serializing key/value"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiExecutionActivityMap();
        });

        assertTrue(exception instanceof KafkaStoreAccessException);
        assertEquals("SerializationException occurred while retrieving GSI execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof SerializationException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetGsiExecutionActivityMapWithTimeoutException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new TimeoutException("Timeout occurred"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiExecutionActivityMap();
        });

        assertTrue(exception instanceof KafkaStoreAccessException);
        assertEquals("TimeoutException occurred while retrieving GSI execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof TimeoutException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetGsiExecutionActivityMapWithGenericException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new RuntimeException("Generic error"));

        Exception exception = assertThrows(RuntimeException.class, () -> {
            gsiActivityService.getGsiExecutionActivityMap();
        });

        assertEquals("Exception occurred while retrieving GSI execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof RuntimeException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetGsiExecutionActivityMapAsList(){

        KeyValueIterator<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> iterator = mock(KeyValueIterator.class);
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(gsiDurationStore);
        when(gsiDurationStore.all()).thenReturn(iterator);

        when(iterator.hasNext()).thenReturn(true, false);
        GsiFinalTransactionKeyDto key = new GsiFinalTransactionKeyDto("testGSI1", 123L, "testTenant1");
        GsiFinalTransactionValueDto value = new GsiFinalTransactionValueDto("testGSI1",123L,"testTenant1",
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),2L,
                "COMPLETED","testCu","xyz@gmail.com",12L);

        when(iterator.next()).thenReturn(new KeyValue<>(key, value));
        List<Map<String, String>> result = gsiActivityService.getGsiExecutionActivityMapAsList();
        // Verify the result
        assertNotNull(result);
        assertEquals(1, result.size());

        Map<String, String> firstMap = result.get(0);
        assertEquals("2.0 secs", firstMap.get("duration"));
        // Verify interactions
        verify(iterator, atLeastOnce()).hasNext();
        verify(iterator, times(1)).next();
    }

    @Test
    public void testGetGsiExecutionActivityMapAsListWithInvalidStateStoreException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new InvalidStateStoreException("State store is not valid"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiExecutionActivityMapAsList();
        });

        assertTrue(exception instanceof KafkaStoreAccessException);
        assertEquals("InvalidStateStoreException occurred while retrieving GSI execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof InvalidStateStoreException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetGsiExecutionActivityMapAsListWithSerializationException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new SerializationException("Error serializing key/value"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiExecutionActivityMapAsList();
        });

        assertTrue(exception instanceof KafkaStoreAccessException);
        assertEquals("SerializationException occurred while retrieving GSI execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof SerializationException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetGsiExecutionActivityMapAsListWithTimeoutException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new TimeoutException("Timeout occurred"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiExecutionActivityMapAsList();
        });

        assertTrue(exception instanceof KafkaStoreAccessException);
        assertEquals("TimeoutException occurred while retrieving GSI execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof TimeoutException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetGsiExecutionActivityMapAsListWithGenericException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new RuntimeException("Generic error"));

        Exception exception = assertThrows(RuntimeException.class, () -> {
            gsiActivityService.getGsiExecutionActivityMapAsList();
        });

        assertEquals("Exception occurred while retrieving GSI execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof RuntimeException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCuExecutionActivityMapAsList(){
        KeyValueIterator<CuTransactionKeyDto, CuTransactionValueDto> iterator = mock(KeyValueIterator.class);
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(cuTable);
        when(cuTable.all()).thenReturn(iterator);

        when(iterator.hasNext()).thenReturn(true, false);
        CuTransactionKeyDto key = new CuTransactionKeyDto(12345L,6789L,"testTenant1");
        CuTransactionValueDto value = new CuTransactionValueDto(12345L,"testCu1",6789L,new CuDetails("test","HUMAN",true,"adapter","mqtt"),
                "testTenant1",LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),
                LocalDateTime.of(2015, Month.JULY, 29, 19, 30, 40),14L,
                "COMPLETED","xyz@gmail1.com",1234567L);

        when(iterator.next()).thenReturn(new KeyValue<>(key, value));
        List<Map<String, String>> result = gsiActivityService.getCuExecutionActivityMapAsList();
        // Verify the result
        assertNotNull(result);
        assertEquals(1, result.size());

        Map<String, String> firstMap = result.get(0);
        assertEquals("14.0 secs", firstMap.get("duration"));
        // Verify interactions
        verify(iterator, atLeastOnce()).hasNext();
        verify(iterator, times(1)).next();
    }

    @Test
    public void testGetCuExecutionActivityMapAsListWithInvalidStateStoreException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new InvalidStateStoreException("State store is not valid"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getCuExecutionActivityMapAsList();
        });

        assertTrue(exception instanceof KafkaStoreAccessException);
        assertEquals("InvalidStateStoreException occurred while retrieving CU execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof InvalidStateStoreException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCuExecutionActivityMapAsListWithSerializationException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new SerializationException("Error serializing key/value"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getCuExecutionActivityMapAsList();
        });

        assertTrue(exception instanceof KafkaStoreAccessException);
        assertEquals("SerializationException occurred while retrieving CU execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof SerializationException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCuExecutionActivityMapAsListWithTimeoutException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new TimeoutException("Timeout occurred"));

        Exception exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getCuExecutionActivityMapAsList();
        });

        assertTrue(exception instanceof KafkaStoreAccessException);
        assertEquals("TimeoutException occurred while retrieving CU execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof TimeoutException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetCuExecutionActivityMapAsListWithGenericException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenThrow(new RuntimeException("Generic error"));

        Exception exception = assertThrows(RuntimeException.class, () -> {
            gsiActivityService.getCuExecutionActivityMapAsList();
        });

        assertEquals("Exception occurred while retrieving CU execution activity map", exception.getMessage());
        assertTrue(exception.getCause() instanceof RuntimeException);
        verify(kafkaStreams).store(any(StoreQueryParameters.class));
    }

    @Test
    public void testGetGsiAnalyticsMapAsList(){

        KeyValueIterator<String, Long> iterator = mock(KeyValueIterator.class);
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(testKTable);

        KeyValueIterator<String, Long> successIterator = mock(KeyValueIterator.class);
        KeyValueIterator<String, Long> failureIterator = mock(KeyValueIterator.class);

        when(testKTable.all()).thenReturn(successIterator);
        when(successIterator.hasNext()).thenReturn(true, true, false);
        when(successIterator.next()).thenReturn(new KeyValue<>("SuccessKey1", 1L), new KeyValue<>("FailureKey1", 2L));

        List<Map<String, Long>> result = gsiActivityService.getGsiAnalyticsMapAsList();

        //assertNotNull(result, "Result should not be null");
        assertEquals(2, result.size(), "Result list should contain two maps");

        Map<String, Long> successMap = result.get(0);
        assertNotNull(successMap);
        assertEquals(Long.valueOf(1), successMap.get("SuccessKey1"));
        assertEquals(Long.valueOf(2), successMap.get("FailureKey1"));
    }

    @Test
    public void testGetGsiAnalyticsMapAsListWithInvalidStateStoreException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new InvalidStateStoreException("Invalid state store"));

        KafkaStoreAccessException exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiAnalyticsMapAsList();
        });

        assertEquals("InvalidStateStoreException occurred while retrieving counts from KTable.", exception.getMessage());
        assertEquals(KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION, exception.getExceptionType());
    }

    @Test
    public void testGetGsiAnalyticsMapAsListWithSerializationException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new SerializationException("Error during serialization"));

        KafkaStoreAccessException exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiAnalyticsMapAsList();
        });

        assertEquals("SerializationException occurred while retrieving counts from KTable.", exception.getMessage());
        assertEquals(KafkaStoreExceptionType.SERIALIZATION_EXCEPTION, exception.getExceptionType());
    }

    @Test
    public void testGetGsiAnalyticsMapAsListWithTimeoutException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new TimeoutException("Timeout accessing store"));

        KafkaStoreAccessException exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiAnalyticsMapAsList();
        });

        assertEquals("TimeoutException occurred while retrieving counts from KTable.", exception.getMessage());
        assertEquals(KafkaStoreExceptionType.TIMEOUT_EXCEPTION, exception.getExceptionType());
    }

    @Test
    public void testGetGsiAnalyticsMapAsListWithGenericException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new RuntimeException("Unexpected error"));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            gsiActivityService.getGsiAnalyticsMapAsList();
        });

        assertEquals("Exception occurred while retrieving counts from KTable.", exception.getMessage());
    }

    @Test
    public void testProcessGsiTableData(){

        KeyValueIterator<GsiTrendsKey, GsiTrendsValueInfo> iterator = mock(KeyValueIterator.class);
        when(kafkaStreams.store(any(StoreQueryParameters.class))).thenReturn(gsiCuTable);
        when(gsiCuTable.all()).thenReturn(iterator);

        GsiTrendsKey key = new GsiTrendsKey("testTenant",123L,1245L);
        GsiTrendsValueInfo value = new GsiTrendsValueInfo();
        value.setContainerId(1234L);
        value.setTotalTransactionCount(1L);
        when(iterator.hasNext()).thenReturn(true, false);
        when(iterator.next()).thenReturn(new KeyValue<>(key, value));

        GsiTrendsValueInfo expectedResult = new GsiTrendsValueInfo();
        expectedResult.setGsiId(1234L);
        expectedResult.setContainerName("testGsi");
        expectedResult.setTotalTransactionCount(1L);
        expectedResult.setTotalSuccessCount(1L);
        expectedResult.setAverageTime(0.01D);
        expectedResult.setMaximumTime(0.01D);
        expectedResult.setMinimumTime(0.01D);

        ConcurrentHashMap<Long, GsiTrendsValueInfo> result = gsiActivityService.getGsiTrendsMap();

        // Validate the results
        assertFalse(result.isEmpty(), "Resulting map should not be empty");

        GsiTrendsValueInfo gsiTrendsValueInfo = result.get(1234L);
        assertEquals(gsiTrendsValueInfo.getTotalTransactionCount(), expectedResult.getTotalTransactionCount());
    }

    @Test
    public void testProcessGsiTableDataWithInvalidStateStoreException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new InvalidStateStoreException("Invalid state store"));

        KafkaStoreAccessException exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiTrendsMap();
        });

        assertEquals("InvalidStateStoreException occurred while retrieving info from KTable.", exception.getMessage());
        assertEquals(KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION, exception.getExceptionType());
    }

    @Test
    public void testProcessGsiTableDataWithSerializationException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new SerializationException("Error during serialization"));

        KafkaStoreAccessException exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiTrendsMap();
        });

        assertEquals("SerializationException occurred while retrieving info from KTable.", exception.getMessage());
        assertEquals(KafkaStoreExceptionType.SERIALIZATION_EXCEPTION, exception.getExceptionType());
    }

    @Test
    public void testProcessGsiTableDataWithTimeoutException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new TimeoutException("Timeout accessing store"));

        KafkaStoreAccessException exception = assertThrows(KafkaStoreAccessException.class, () -> {
            gsiActivityService.getGsiTrendsMap();
        });

        assertEquals("TimeoutException occurred while retrieving info from KTable.", exception.getMessage());
        assertEquals(KafkaStoreExceptionType.TIMEOUT_EXCEPTION, exception.getExceptionType());
    }

    @Test
    public void testProcessGsiTableDataWithGenericException() {
        when(kafkaStreams.store(any(StoreQueryParameters.class)))
                .thenThrow(new RuntimeException("Unexpected error"));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            gsiActivityService.getGsiTrendsMap();
        });

        assertEquals("Exception occurred while retrieving counts info KTable.", exception.getMessage());
    }



}
