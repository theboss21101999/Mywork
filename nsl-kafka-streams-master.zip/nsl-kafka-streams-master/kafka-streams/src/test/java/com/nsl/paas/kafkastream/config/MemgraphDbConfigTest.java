package com.nsl.paas.kafkastream.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.neo4j.driver.Driver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = MemgraphDbConfig.class)
@TestPropertySource(properties = {
        "memgraph.uri=bolt://localhost:7687",
        "memgraph.username=admin",
        "memgraph.password=secret"
})
public class MemgraphDbConfigTest {

    @Autowired
    private Driver memgraphDriver;

    @Test
    public void testMemgraphDriverBean() {
        assertNotNull(memgraphDriver);
        // Add more assertions as needed
    }
}
