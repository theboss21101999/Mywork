package com.nsl.paas.kafkastream.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class SecurityConfigTest {

    @Mock
    private Environment environment;

    @InjectMocks
    private SecurityConfig securityConfig;

    private static final String TEST_USERNAME = "test_user";
    private static final String TEST_PASSWORD = "test_password";
    private static final boolean TEST_SECURITY_ENABLED = true;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(securityConfig, "name", TEST_USERNAME);
        ReflectionTestUtils.setField(securityConfig, "pwd", TEST_PASSWORD);
        ReflectionTestUtils.setField(securityConfig, "securityEnabled", TEST_SECURITY_ENABLED);
    }

    @Test
    public void testInMemoryUserDetailsManager() {
        // Act
        InMemoryUserDetailsManager userDetailsManager = securityConfig.inMemoryUserDetailsManager();

        // Assert
        assertNotNull(userDetailsManager, "User details manager should not be null");
        assertNotNull(userDetailsManager.loadUserByUsername(TEST_USERNAME), "User details should not be null");
    }

    @Test
    public void testPasswordEncoder() {
        // Act
        String encodedPassword = securityConfig.encoder().encode(TEST_PASSWORD);

        // Assert
        assertNotEquals(TEST_PASSWORD, encodedPassword, "Password should be encoded");
        assertTrue(securityConfig.encoder().matches(TEST_PASSWORD, encodedPassword), "Encoded password should match original");
    }

}
