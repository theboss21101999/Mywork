package com.nsl.paas.kafkastream.serviceImpl;

import static com.nsl.paas.kafkastream.constants.AppConstants.GET_PARENT_NODES_FOR_CU_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.nsl.paas.kafkastream.dto.PathDto;
import com.nsl.paas.kafkastream.dto.NodeDto;
import com.nsl.paas.kafkastream.model.GsiTrendsValueInfo;
import com.nsl.paas.kafkastream.repository.GraphDbRepository;
import com.nsl.paas.kafkastream.service.GsiActivityService;
import org.jobrunr.scheduling.JobScheduler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class MemgraphServiceImplTest {

    @Mock
    private GsiActivityService gsiActivityService;

    @Mock
    private GraphDbRepository graphDbRepository;

    @Mock
    private JobScheduler jobScheduler;

    @InjectMocks
    private MemgraphServiceImpl memgraphService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }


    @Test
    public void testFetchAndSaveNodesAndRelationships() {
        // Given
        ConcurrentHashMap<Long, GsiTrendsValueInfo> mockMap = new ConcurrentHashMap<>();
        when(gsiActivityService.getGsiTrendsMap()).thenReturn(mockMap);

        // When
        memgraphService.fetchAndSaveNodesAndRelationships();

        // Then
        verify(graphDbRepository, times(1)).executeSaveCall(any());
    }

    @Test
    public void testGetDependencyGraphByBetId() {
        // Given
        Long betId = 1L;
        String betType = GSI;
        when(graphDbRepository.executeReadCall(any())).thenReturn(Arrays.asList()); // Mocking empty result

        // When
        List<PathDto> result = memgraphService.getDependencyGraphByBetId(betId, betType);

        // Then
        verify(graphDbRepository, times(1)).executeReadCall(any());
        assertNotNull(result);
    }

    @Test
    public void testGetListOfNodes() {
        // Given
        Long betId = 1L;
        String methodName = GET_PARENT_NODES_FOR_CU_ID;
        when(graphDbRepository.executeReadCall(any())).thenReturn(Arrays.asList()); // Mocking empty result

        // When
        List<NodeDto> result = memgraphService.getListOfNodes(betId, methodName);

        // Then
        verify(graphDbRepository, times(1)).executeReadCall(any());
        assertNotNull(result);
    }

    // Additional test cases can be added here for more methods
}
