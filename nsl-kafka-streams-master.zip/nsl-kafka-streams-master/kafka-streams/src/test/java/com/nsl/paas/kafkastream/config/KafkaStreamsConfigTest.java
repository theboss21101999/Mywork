package com.nsl.paas.kafkastream.config;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.config.KafkaStreamsConfiguration;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
public class KafkaStreamsConfigTest {

    @InjectMocks
    private KafkaStreamsConfig kafkaStreamsConfig;

    private static final String TEST_BOOTSTRAP_ADDRESS = "localhost:9092";

    @BeforeEach
    public void setUp() throws NoSuchFieldException, IllegalAccessException {
        setPrivateField(kafkaStreamsConfig, "bootstrapAddress", TEST_BOOTSTRAP_ADDRESS);
    }

    private void setPrivateField(Object target, String fieldName, String value) throws NoSuchFieldException, IllegalAccessException {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    public void kStreamsConfigBeanShouldBeConfiguredCorrectly() {
        // Act
        KafkaStreamsConfiguration kafkaStreamsConfiguration = kafkaStreamsConfig.kStreamsConfig();

        // Assert
        assertNotNull(kafkaStreamsConfiguration, "KafkaStreamsConfiguration bean should not be null");

        Properties configProps = kafkaStreamsConfiguration.asProperties();

        // Convert Properties to Map<String, Object>
        Map<String, Object> configMap = new HashMap<>();
        for (String name : configProps.stringPropertyNames()) {
            configMap.put(name, configProps.getProperty(name));
        }

        assertEquals("streamers-consumer-app-qa3", configMap.get(StreamsConfig.APPLICATION_ID_CONFIG), "Application ID should match");
        assertEquals("latest", configMap.get("auto.offset.reset"), "Auto offset reset should match");
        assertEquals(TEST_BOOTSTRAP_ADDRESS, configMap.get(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG), "Bootstrap servers should match");
        assertEquals(Serdes.String().getClass().getName(), configMap.get(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG), "Default key serde should match");
        assertEquals(KafkaAvroSerializer.class.getName(), configMap.get(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG), "Default value serde should match");
    }
}
