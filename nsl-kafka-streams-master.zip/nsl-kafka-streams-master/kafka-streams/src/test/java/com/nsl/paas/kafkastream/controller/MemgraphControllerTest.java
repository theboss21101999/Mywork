package com.nsl.paas.kafkastream.controller;

import com.nsl.paas.kafkastream.dto.APIResponse;
import com.nsl.paas.kafkastream.dto.NodeDto;
import com.nsl.paas.kafkastream.dto.PathDto;
import com.nsl.paas.kafkastream.service.MemgraphService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static com.nsl.paas.kafkastream.constants.AppConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

public class MemgraphControllerTest {

    @Mock
    private MemgraphService memgraphService;

    @InjectMocks
    private MemgraphController memgraphController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetDependencyGraphByEntityId_Success() {
        Long entityId = 1L;
        List<PathDto> mockResult = new ArrayList<>();
        // Add mock data as needed

        when(memgraphService.getDependencyGraphByBetId(entityId, GENERAL_ENTITY)).thenReturn(mockResult);

        ResponseEntity<APIResponse> responseEntity = memgraphController.getDependencyGraphByEntityId(entityId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Success", responseEntity.getBody().message()); // Replace with actual Success

        verify(memgraphService, times(1)).getDependencyGraphByBetId(entityId, GENERAL_ENTITY);
    }

    @Test
    public void testGetDependencyGraphByEntityId_Exception() {
        Long entityId = 2L;

        when(memgraphService.getDependencyGraphByBetId(entityId, GENERAL_ENTITY)).thenThrow(new RuntimeException("Service exception"));

        ResponseEntity<APIResponse> responseEntity = memgraphController.getDependencyGraphByEntityId(entityId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Error processing getDependencyGraphByEntityId request: Service exception", responseEntity.getBody().message());

        verify(memgraphService, times(1)).getDependencyGraphByBetId(entityId, GENERAL_ENTITY);
    }

    @Test
    public void testGetDependencyGraphByChangeUnitId_Success() {
        Long cuId = 1L;
        List<PathDto> mockResult = new ArrayList<>();
        // Add mock data as needed

        when(memgraphService.getDependencyGraphByBetId(cuId, CHANGE_UNIT)).thenReturn(mockResult);

        ResponseEntity<APIResponse> responseEntity = memgraphController.getDependencyGraphByChangeUnitId(cuId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Success", responseEntity.getBody().message()); // Replace with actual Success

        verify(memgraphService, times(1)).getDependencyGraphByBetId(cuId, CHANGE_UNIT);
    }

    @Test
    public void testGetDependencyGraphByChangeUnitId_Exception() {
        Long cuId = 2L;

        when(memgraphService.getDependencyGraphByBetId(cuId, CHANGE_UNIT)).thenThrow(new RuntimeException("Service exception"));

        ResponseEntity<APIResponse> responseEntity = memgraphController.getDependencyGraphByChangeUnitId(cuId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Error processing getDependencyGraphByChangeUnitId request: Service exception", responseEntity.getBody().message());

        verify(memgraphService, times(1)).getDependencyGraphByBetId(cuId, CHANGE_UNIT);
    }

    @Test
    public void testGetDependencyGraphByGsiId_Success() {
        Long gsiId = 1L;
        List<PathDto> mockResult = new ArrayList<>();
        // Add mock data as needed

        when(memgraphService.getDependencyGraphByBetId(gsiId, GSI)).thenReturn(mockResult);

        ResponseEntity<APIResponse> responseEntity = memgraphController.getDependencyGraphByGsiId(gsiId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Success", responseEntity.getBody().message()); // Replace with actual Success

        verify(memgraphService, times(1)).getDependencyGraphByBetId(gsiId, GSI);
    }

    @Test
    public void testGetDependencyGraphByGsiId_Exception() {
        Long gsiId = 2L;

        when(memgraphService.getDependencyGraphByBetId(gsiId, GSI)).thenThrow(new RuntimeException("Service exception"));

        ResponseEntity<APIResponse> responseEntity = memgraphController.getDependencyGraphByGsiId(gsiId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Error processing getDependencyGraphByGsiId request: Service exception", responseEntity.getBody().message());

        verify(memgraphService, times(1)).getDependencyGraphByBetId(gsiId, GSI);
    }

    @Test
    public void testGetParentNodesForCuId_Success() {
        Long cuId = 1L;
        List<NodeDto> mockResult = new ArrayList<>();
        // Add mock data as needed

        when(memgraphService.getListOfNodes(cuId, GET_PARENT_NODES_FOR_CU_ID)).thenReturn(mockResult);

        ResponseEntity<APIResponse> responseEntity = memgraphController.getParentNodesForCuId(cuId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Success", responseEntity.getBody().message()); // Replace with actual Success

        verify(memgraphService, times(1)).getListOfNodes(cuId, GET_PARENT_NODES_FOR_CU_ID);
    }

    @Test
    public void testGetParentNodesForCuId_Exception() {
        Long cuId = 2L;

        when(memgraphService.getListOfNodes(cuId, GET_PARENT_NODES_FOR_CU_ID)).thenThrow(new RuntimeException("Service exception"));

        ResponseEntity<APIResponse> responseEntity = memgraphController.getParentNodesForCuId(cuId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Error processing getParentNodesForCuId request: Service exception", responseEntity.getBody().message());

        verify(memgraphService, times(1)).getListOfNodes(cuId, GET_PARENT_NODES_FOR_CU_ID);
    }

    @Test
    public void testGetChildNodesForCuId_Success() {
        Long cuId = 1L;
        List<NodeDto> mockResult = new ArrayList<>();
        // Add mock data as needed

        when(memgraphService.getListOfNodes(cuId, GET_CHILD_NODES_FOR_CU_ID)).thenReturn(mockResult);

        ResponseEntity<APIResponse> responseEntity = memgraphController.getChildNodesForCuId(cuId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Success", responseEntity.getBody().message()); // Replace with actual Success

        verify(memgraphService, times(1)).getListOfNodes(cuId, GET_CHILD_NODES_FOR_CU_ID);
    }

    @Test
    public void testGetChildNodesForCuId_Exception() {
        Long cuId = 1L;

        when(memgraphService.getListOfNodes(cuId, GET_CHILD_NODES_FOR_CU_ID)).thenThrow(new RuntimeException("Service exception"));

        ResponseEntity<APIResponse> responseEntity = memgraphController.getChildNodesForCuId(cuId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Error processing getChildNodesForCuId request: Service exception", responseEntity.getBody().message());

        verify(memgraphService, times(1)).getListOfNodes(cuId, GET_CHILD_NODES_FOR_CU_ID);
    }

    @Test
    public void testGetCuNodesForGsiId_Success() {
        Long gsiId = 1L;
        List<NodeDto> mockResult = new ArrayList<>();
        // Add mock data as needed

        when(memgraphService.getListOfNodes(gsiId, GET_CU_NODES_FOR_GSI_ID)).thenReturn(mockResult);

        ResponseEntity<APIResponse> responseEntity = memgraphController.getCuNodesForGsiId(gsiId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Success", responseEntity.getBody().message()); // Replace with actual Success

        verify(memgraphService, times(1)).getListOfNodes(gsiId, GET_CU_NODES_FOR_GSI_ID);
    }

    @Test
    public void testGetCuNodesForGsiId_Exception() {
        Long gsiId = 2L;

        when(memgraphService.getListOfNodes(gsiId, GET_CU_NODES_FOR_GSI_ID)).thenThrow(new RuntimeException("Service exception"));

        ResponseEntity<APIResponse> responseEntity = memgraphController.getCuNodesForGsiId(gsiId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Error processing getCuNodesForGsiId request: Service exception", responseEntity.getBody().message());

        verify(memgraphService, times(1)).getListOfNodes(gsiId, GET_CU_NODES_FOR_GSI_ID);
    }

    @Test
    public void testGetGeNodesForGsiId_Success() {
        Long gsiId = 1L;
        List<NodeDto> mockResult = new ArrayList<>();
        // Add mock data as needed

        when(memgraphService.getListOfNodes(gsiId, GET_GE_NODES_FOR_GSI_ID)).thenReturn(mockResult);

        ResponseEntity<APIResponse> responseEntity = memgraphController.getGeNodesForGsiId(gsiId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Success", responseEntity.getBody().message()); // Replace with actual Success

        verify(memgraphService, times(1)).getListOfNodes(gsiId, GET_GE_NODES_FOR_GSI_ID);
    }

    @Test
    public void testGetGeNodesForGsiId_Exception() {
        Long gsiId = 2L;

        when(memgraphService.getListOfNodes(gsiId, GET_GE_NODES_FOR_GSI_ID)).thenThrow(new RuntimeException("Service exception"));

        ResponseEntity<APIResponse> responseEntity = memgraphController.getGeNodesForGsiId(gsiId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Error processing getGeNodesForGsiId request: Service exception", responseEntity.getBody().message());

        verify(memgraphService, times(1)).getListOfNodes(gsiId, GET_GE_NODES_FOR_GSI_ID);
    }

    @Test
    public void testGetGsiNodesForGeId_Success() {
        Long geId = 1L;
        List<NodeDto> mockResult = new ArrayList<>();
        // Add mock data as needed

        when(memgraphService.getListOfNodes(geId, GET_GSI_NODES_FOR_GE_ID)).thenReturn(mockResult);

        ResponseEntity<APIResponse> responseEntity = memgraphController.getGsiNodesForGeId(geId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Success", responseEntity.getBody().message()); // Replace with actual Success

        verify(memgraphService, times(1)).getListOfNodes(geId, GET_GSI_NODES_FOR_GE_ID);
    }

    @Test
    public void testGetGsiNodesForGeId_Exception() {
        Long geId = 1L;

        when(memgraphService.getListOfNodes(geId, GET_GSI_NODES_FOR_GE_ID)).thenThrow(new RuntimeException("Service exception"));

        ResponseEntity<APIResponse> responseEntity = memgraphController.getGsiNodesForGeId(geId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Error processing getGsiNodesForGeId request: Service exception", responseEntity.getBody().message());

        verify(memgraphService, times(1)).getListOfNodes(geId, GET_GSI_NODES_FOR_GE_ID);
    }

    @Test
    public void testGetCuNodesForGeId_Success() {
        Long geId = 1L;
        List<NodeDto> mockResult = new ArrayList<>();
        // Add mock data as needed

        when(memgraphService.getListOfNodes(geId, GET_CU_NODES_FOR_GE_ID)).thenReturn(mockResult);

        ResponseEntity<APIResponse> responseEntity = memgraphController.getCuNodesForGeId(geId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Success", responseEntity.getBody().message()); // Replace with actual Success

        verify(memgraphService, times(1)).getListOfNodes(geId, GET_CU_NODES_FOR_GE_ID);
    }

    @Test
    public void testGetCuNodesForGeId_Exception() {
        Long geId = 2L;

        when(memgraphService.getListOfNodes(geId, GET_CU_NODES_FOR_GE_ID)).thenThrow(new RuntimeException("Service exception"));

        ResponseEntity<APIResponse> responseEntity = memgraphController.getCuNodesForGeId(geId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Error processing getCuNodesForGeId request: Service exception", responseEntity.getBody().message());

        verify(memgraphService, times(1)).getListOfNodes(geId, GET_CU_NODES_FOR_GE_ID);
    }

    @Test
    public void testGetAttributeNodesForGeId_Success() {
        Long geId = 1L;
        List<NodeDto> mockResult = new ArrayList<>();
        // Add mock data as needed

        when(memgraphService.getListOfNodes(geId, GET_CHILD_NODES_FOR_GE_ID)).thenReturn(mockResult);

        ResponseEntity<APIResponse> responseEntity = memgraphController.getAttributeNodesForGeId(geId);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals("Success", responseEntity.getBody().message()); // Replace with actual Success

        verify(memgraphService, times(1)).getListOfNodes(geId, GET_CHILD_NODES_FOR_GE_ID);
    }

    @Test
    public void testGetAttributeNodesForGeId_Exception() {
        Long geId = 2L;

        when(memgraphService.getListOfNodes(geId, GET_CHILD_NODES_FOR_GE_ID)).thenThrow(new RuntimeException("Service exception"));

        ResponseEntity<APIResponse> responseEntity = memgraphController.getAttributeNodesForGeId(geId);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
        assertEquals("Error processing getAttributeNodesForGeId request: Service exception", responseEntity.getBody().message());

        verify(memgraphService, times(1)).getListOfNodes(geId, GET_CHILD_NODES_FOR_GE_ID);
    }
}
