package com.nsl.paas.kafkastream.topology.unittesting;

// ... (other imports)

import com.nsl.paas.kafkastream.dto.GsiFinalTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionValueDto;
import com.nsl.paas.kafkastream.serdes.JsonDeserializer;
import com.nsl.paas.kafkastream.serdes.SerdesFactory;
import com.nsl.paas.kafkastream.topology.TransactionProcessorAvro;
import io.confluent.kafka.schemaregistry.client.MockSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.Encoder;
import org.apache.avro.io.EncoderFactory;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import tech.allegro.schema.json2avro.converter.JsonAvroConverter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Properties;

import static org.apache.kafka.streams.StreamsConfig.*;
import static org.apache.kafka.streams.StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
@DirtiesContext
public class TransactionProcessorAvroTest {
    @Autowired
    private TransactionProcessorAvro transactionProcessorAvro;
    private static final String MOCK_SCHEMA_REGISTRY_URL = "http://10.16.2.199:8081";
    private final MockSchemaRegistryClient schemaRegistryClient = new MockSchemaRegistryClient();

    @BeforeEach
    public void setUp() throws RestClientException, IOException {
        // Register Avro schema in the Mock Schema Registry
        registerAvroSchema();
    }

    @Test
    void txnTransDataAnalysis() throws Exception {
        StreamsBuilder streamsBuilder = new StreamsBuilder();
        transactionProcessorAvro.txnTransDataAnalysis(streamsBuilder);
        Topology topology = streamsBuilder.build();
        Properties props = new Properties();
        props.put(APPLICATION_ID_CONFIG, "test");
        props.put(BOOTSTRAP_SERVERS_CONFIG, "dummy:1234");
        props.put(DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        props.put(DEFAULT_VALUE_SERDE_CLASS_CONFIG, KafkaAvroSerializer.class.getName());
        props.put(AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, MOCK_SCHEMA_REGISTRY_URL);
        try (TopologyTestDriver topologyTestDriver = new TopologyTestDriver(topology, props)) {
            String schemaSubject = "TxnTransRequestAvro-value";
            // Fetch the Avro schema registered in the Mock Schema Registry
            Schema registeredSchema = schemaRegistryClient.getBySubjectAndId(schemaSubject, 1);
            TestInputTopic<String, GenericRecord> inputTopic = topologyTestDriver.createInputTopic(
                    "TxnTransRequestAvro",
                    new StringSerializer(),
                    SerdesFactory.getAvroSerde(MOCK_SCHEMA_REGISTRY_URL).serializer()
            );
            TestOutputTopic<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> outputTopic = topologyTestDriver.createOutputTopic("gsiTableDataStream", new JsonDeserializer<>(GsiFinalTransactionKeyDto.class), new JsonDeserializer<>(GsiFinalTransactionValueDto.class));
            //jsons

            String json1="{\"data\":{\"transactionDto\":{\"executionState\":[{\"containerCuId\":825770750105,\"referenceContainerCuId\":825770750105,\"currentContextualId\":\"GS825770750105\",\"isParallelCuContainer\":false,\"txnDataSaveMode\":\"DEFAULT\"}],\"hasSubtransactionalEntity\":false,\"contextCacheMap\":{},\"containerCuDisplayName\":\"Test GSI 12345\",\"transactionId\":\"633673673444\",\"triggerCuId\":872962544743,\"containerCuId\":825770750105,\"containerCuName\":\"Test GSI\",\"transactionStatus\":\"TRIGGERED\",\"triggerCuName\":\"Test CU\",\"dateTime\":1707908163148,\"assignedUserId\":\"1943859452520\",\"assignedStatus\":\"ASSIGNED\",\"startTime\":1707908163142,\"executionStatus\":\"COMPLETED\",\"isUpdateAssigneeApplicable\":false,\"id\":633673673444,\"ownerId\":1943859452520,\"createdAt\":1707908163142,\"createdBy\":1943859452520,\"updatedAt\":1707908163172,\"updatedBy\":1943859452520,\"orgUnitId\":664834828061}},\"userContext\":{\"tenantId\":\"ritik\",\"userId\":1943859452520,\"emailId\":\"binod@gmail.com\",\"orgUnitId\":664834828061},\"logEventTime\":1707908163173,\"methodName\":\"save\"}";
            String json2="{\"data\":{\"txnDataDto\":{\"txnData\":{\"txnCULayer\":[{\"type\":\"physical\",\"txnSlotItems\":[{\"isMultiValue\":false,\"item\":{\"TYPE\":\"TxnGeneralEntity\",\"DATA\":{\"name\":\"test ent\",\"generalEntityID\":209991411478,\"transEntityRecords\":[{\"txnNslAttribute\":[{\"name\":\"Qty\",\"nslAttributeID\":2057662021669,\"values\":[\"1\"],\"displayName\":\"Qty\"}],\"txnRecordId\":1731042338089}],\"isLastBatch\":false,\"isMasterData\":true,\"isBulkImport\":false}},\"arrivalTime\":1707908163153}],\"id\":578174494784}],\"gsiId\":825770750105,\"gsiMasterId\":825770750105,\"referenceChangeUnitMasterId\":1368422140663,\"referenceChangeUnitId\":1368422140663,\"triggerCuIndex\":1,\"triggerState\":\"COMPLETED\",\"triggerEndTime\":1707908163226,\"triggeredTime\":1707908163225,\"triggerStartTime\":1707908163153,\"createdBy\":\"1943859452520\",\"updatedBy\":\"1943859452520\",\"updatedAt\":1707908163226,\"createdAt\":1707908163153,\"transactionId\":\"633673673444\",\"cuContextualId\":\"GS825770750105.CU872962544743_1368422140663\"},\"traceableMap\":{\"PHYSICAL\":[{\"id\":209991411478,\"name\":\"test ent\",\"masterId\":209991411478,\"attributeDtos\":[{\"id\":2057662021669,\"name\":\"Qty\",\"isTraceable\":false}]}]}}},\"userContext\":{\"tenantId\":\"ritik\",\"userId\":1943859452520,\"emailId\":\"binod@gmail.com\",\"orgUnitId\":664834828061},\"logEventTime\":1707908163232,\"methodName\":\"saveData\"}";
            String json3="{\"data\":{\"transactionDto\":{\"executionState\":[],\"masterTransactionIdRecords\":{},\"hasSubtransactionalEntity\":false,\"contextCacheMap\":{},\"containerCuDisplayName\":\"Test GSI 12345\",\"transactionId\":\"633673673444\",\"triggerCuId\":872962544743,\"containerCuId\":825770750105,\"containerCuName\":\"Test GSI\",\"transactionStatus\":\"COMPLETED\",\"triggerCuName\":\"Test CU\",\"dateTime\":1707908163148,\"assignedUserId\":\"1943859452520\",\"assignedStatus\":\"ASSIGNED\",\"startTime\":1707908163142,\"executionStatus\":\"COMPLETED\",\"endTime\":1707908163233,\"isUpdateAssigneeApplicable\":false,\"id\":633673673444,\"ownerId\":1943859452520,\"createdAt\":1707908163142,\"createdBy\":1943859452520,\"updatedAt\":1707908163234,\"updatedBy\":1943859452520,\"orgUnitId\":664834828061}},\"userContext\":{\"tenantId\":\"ritik\",\"userId\":1943859452520,\"emailId\":\"binod@gmail.com\",\"orgUnitId\":664834828061},\"logEventTime\":1707908163234,\"methodName\":\"save\"}";
            String json4="{\"data\":{\"transactionDto\":{\"executionState\":[],\"masterTransactionIdRecords\":{},\"hasSubtransactionalEntity\":false,\"contextCacheMap\":{},\"containerCuDisplayName\":\"Test GSI 12345\",\"transactionId\":\"633673673444\",\"triggerCuId\":872962544743,\"containerCuId\":825770750105,\"containerCuName\":\"Test GSI\",\"transactionStatus\":\"COMPLETED\",\"triggerCuName\":\"Test CU\",\"dateTime\":1707908163148,\"assignedUserId\":\"1943859452520\",\"assignedStatus\":\"ASSIGNED\",\"startTime\":1707908163142,\"executionStatus\":\"COMPLETED\",\"endTime\":1707908163233,\"isUpdateAssigneeApplicable\":false,\"id\":633673673444,\"ownerId\":1943859452520,\"createdAt\":1707908163142,\"createdBy\":1943859452520,\"updatedAt\":1707908163234,\"updatedBy\":1943859452520,\"orgUnitId\":664834828061}},\"userContext\":{\"tenantId\":\"ritik\",\"userId\":1943859452520,\"emailId\":\"binod@gmail.com\",\"orgUnitId\":664834828061},\"logEventTime\":1707908163234,\"methodName\":\"save\"}";
            String json5="{\"data\":{\"transactionDto\":{\"executionState\":[{\"containerCuId\":1005634507757,\"referenceContainerCuId\":1005634507757,\"currentCuId\":53077901834,\"currentContextualId\":\"GS1005634507757.CU53077901834_905943956474\",\"isParallelCuContainer\":false,\"txnDataSaveMode\":\"DEFAULT\"}],\"masterTransactionIdRecords\":{},\"hasSubtransactionalEntity\":false,\"contextCacheMap\":{},\"isTransactionManagement\":false,\"containerCuDisplayName\":\"fhgjhgjk\",\"transactionId\":\"323583520454\",\"triggerCuId\":1236247316298,\"containerCuId\":1005634507757,\"containerCuName\":\"fhgjhgjk\",\"transactionStatus\":\"FAILED\",\"triggerCuName\":\"hypo_uiyyiuhkj\",\"dateTime\":1703845028017,\"assignedUserId\":\"462585056276\",\"assignedStatus\":\"ASSIGNED\",\"startTime\":1703845028007,\"transactionFailureMessage\":\"Exception in executing current Trigger CU hypo_uiyyiuhkj: Execution of reserved CU with name: hypo_uiyyiuhkj has failed due to: 500 Internal Server Error: [Internal Server Error]\",\"executionStatus\":\"IN_PROGRESS\",\"isUpdateAssigneeApplicable\":false,\"id\":323583520454,\"ownerId\":462585056276,\"createdAt\":1703845028008,\"createdBy\":462585056276,\"updatedAt\":1703845068753,\"updatedBy\":462585056276,\"orgUnitId\":1436616167409}},\"userContext\":{\"tenantId\":\"dsd\",\"userId\":462585056276,\"emailId\":\"mohith@gmail.com\",\"orgUnitId\":1436616167409},\"logEventTime\":1703845068755,\"methodName\":\"save\"}";
            // GenericRecord converted json
            GenericData.Record record1 = jsonToAvro(json1, registeredSchema);
            GenericData.Record record2 = jsonToAvro(json2, registeredSchema);
            GenericData.Record record3 = jsonToAvro(json3, registeredSchema);
            GenericData.Record record4 = jsonToAvro(json4, registeredSchema);
            GenericData.Record record5 = jsonToAvro(json5, registeredSchema);
            // injecting the values into the pipe
            inputTopic.pipeInput("key1", record1);
            inputTopic.pipeInput("key2", record2);
            inputTopic.pipeInput("key3", record3);
            inputTopic.pipeInput("key4", record4);
            inputTopic.pipeInput("key5",record5);
            assertNotNull(outputTopic.readKeyValuesToList());
        }
    }

    private void registerAvroSchema() throws RestClientException, IOException {
        String schemaSubject = "TxnTransRequestAvro-value";
        // Load Avro schema from file
        Schema loadedSchema = new Schema.Parser().parse(getClass().getResourceAsStream("/schema.avsc"));
        String schemaString = loadedSchema.toString(true);
        // Register schema with the Mock Schema Registry
        int schemaId = schemaRegistryClient.register(schemaSubject, loadedSchema);
        System.out.println("Registered schema with ID " + schemaId + ": " + schemaString);
    }

    private GenericData.Record jsonToAvro(String json, Schema schema) throws IOException {
        JsonAvroConverter avroConverter = new JsonAvroConverter();
        byte[] jsonBytes = json.getBytes();
        GenericData.Record avroRecord = avroConverter.convertToGenericDataRecord(jsonBytes, schema);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        DatumWriter<GenericRecord> datumWriter = new GenericDatumWriter<>(schema);
        Encoder encoder = EncoderFactory.get().binaryEncoder(outputStream, null);
        try {
            datumWriter.write(avroRecord, encoder);
            encoder.flush();
            byte[] avroBytes = outputStream.toByteArray();
            int avroSize = avroBytes.length;
            System.out.println("Produced Avro record (Size: " + avroSize + " bytes): " + avroRecord.toString());
            return avroRecord;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}


