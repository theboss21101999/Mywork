package com.nsl.paas.kafkastream.enums;

public enum KafkaStoreExceptionType {
    INVALID_STATE_STORE_EXCEPTION,
    SERIALIZATION_EXCEPTION,
    TIMEOUT_EXCEPTION,
    NOT_FOUND_EXCEPTION

}
