package com.nsl.paas.kafkastream.model;

import java.util.Set;

public class ContainerCuInfo {

    private String containerCuName;
    private long totalTransactions;
    private long totalCompletedTransactions;
    private long totalIncompleteTransactions;
    private long totalFailedTransactions;
    private long totalDuration;
    private long lastAddedDuration;
    private Set<Long> transactionIds;

    // Giving default constructor so that jackson can perform serdes.
    public ContainerCuInfo() {
    }

    public ContainerCuInfo(String containerCuName, long totalTransactions,
        long totalCompletedTransactions, long totalIncompleteTransactions,
        long totalFailedTransactions,
        long totalDuration, long lastAddedDuration, Set<Long> transactionIds) {
        this.containerCuName = containerCuName;
        this.totalTransactions = totalTransactions;
        this.totalCompletedTransactions = totalCompletedTransactions;
        this.totalIncompleteTransactions = totalIncompleteTransactions;
        this.totalFailedTransactions = totalFailedTransactions;
        this.totalDuration = totalDuration;
        this.lastAddedDuration = lastAddedDuration;
        this.transactionIds = transactionIds;
    }

    public Set<Long> getTransactionIds() {
        return transactionIds;
    }

    public void setTransactionIds(Set<Long> transactionIds) {
        this.transactionIds = transactionIds;
    }

    public String getContainerCuName() {
        return containerCuName;
    }

    public void setContainerCuName(String containerCuName) {
        this.containerCuName = containerCuName;
    }

    public long getTotalTransactions() {
        return totalTransactions;
    }

    public void setTotalTransactions(long totalTransactions) {
        this.totalTransactions = totalTransactions;
    }

    public long getTotalCompletedTransactions() {
        return totalCompletedTransactions;
    }

    public void setTotalCompletedTransactions(long totalCompletedTransactions) {
        this.totalCompletedTransactions = totalCompletedTransactions;
    }

    public long getTotalIncompleteTransactions() {
        return totalIncompleteTransactions;
    }

    public void setTotalIncompleteTransactions(long totalIncompleteTransactions) {
        this.totalIncompleteTransactions = totalIncompleteTransactions;
    }

    public long getTotalFailedTransactions() {
        return totalFailedTransactions;
    }

    public void setTotalFailedTransactions(long totalFailedTransactions) {
        this.totalFailedTransactions = totalFailedTransactions;
    }

    public long getLastAddedDuration() {
        return lastAddedDuration;
    }

    public void setLastAddedDuration(long lastAddedDuration) {
        this.lastAddedDuration = lastAddedDuration;
    }

    public long getTotalDuration() {
        return totalDuration;
    }

    public void setTotalDuration(long totalDuration) {
        this.totalDuration = totalDuration;
    }

    @Override
    public String toString() {
        return "ContainerCuInfo{" +
            "containerCuName='" + containerCuName + '\'' +
            ", totalTransactions=" + totalTransactions +
            ", totalCompletedTransactions=" + totalCompletedTransactions +
            ", totalIncompleteTransactions=" + totalIncompleteTransactions +
            ", totalFailedTransactions=" + totalFailedTransactions +
            ", totalDuration=" + totalDuration +
            ", lastAddedDuration=" + lastAddedDuration +
            ", transactionIds=" + transactionIds +
            '}';
    }
}
