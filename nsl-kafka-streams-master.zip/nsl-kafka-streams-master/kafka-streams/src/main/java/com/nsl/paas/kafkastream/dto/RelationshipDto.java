package com.nsl.paas.kafkastream.dto;

public record RelationshipDto(String type, long parentNodeId, long childNodeId) {
}