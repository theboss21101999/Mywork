package com.nsl.paas.kafkastream.utils;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;

/**
 * Utility class to return GenericRecord using ObjectGenericRecordReader.
 */
public class ObjectToAvroUtil {

    // ObjectGenericRecordReader instance for converting Java objects to Avro GenericRecord
    private final ObjectGenericRecordReader recordReaderNew = new ObjectGenericRecordReader();

    /**
     * Factory method to create an instance of ObjectToAvroUtil.
     *
     * @return ObjectToAvroUtil instance.
     */
    public static ObjectToAvroUtil get() {
        return new ObjectToAvroUtil();
    }

    /**
     * Converts a Java object to an Avro GenericRecord.
     *
     * @param object The Java object to convert.
     * @param schema The Avro schema for the GenericRecord.
     * @return The Avro GenericRecord.
     */
    public GenericData.Record ConvertToGenericDataRecord(Object object, Schema schema) {
        return this.recordReaderNew.read(object, schema);
    }
}
