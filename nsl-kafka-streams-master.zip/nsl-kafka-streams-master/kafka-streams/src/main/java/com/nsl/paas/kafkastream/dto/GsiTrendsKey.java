package com.nsl.paas.kafkastream.dto;

public record GsiTrendsKey(String tenantName,
                           Long containerId,
                           Long gsiId) {
}
