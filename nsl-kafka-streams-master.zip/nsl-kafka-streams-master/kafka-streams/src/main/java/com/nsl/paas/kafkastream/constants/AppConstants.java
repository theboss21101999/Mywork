package com.nsl.paas.kafkastream.constants;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;

public class AppConstants {

    // Table Names
    public static final String ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_ONE_HOUR = "ActivityTableOneHour";
    public static final String ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_THREE_HOUR = "ActivityTableThreeHour";
    public static final String ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_SIX_HOUR = "ActivityTableSixHour";
    public static final String ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWELVE_HOUR = "ActivityTableTwelveHour";
    public static final String ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWENTY_FOUR_HOUR = "ActivityTableTwentyFourHour";
    public static final String GSI_SUCCESS_COUNT_TABLE_NAME= "gsiSuccessCountTable";
    public static final String GSI_FAILED_COUNT_TABLE_NAME= "gsiFailedCountTable";
    public static final String GSI_EXECUTION_DETAILS_TABLE_NAME = "gsiDetailsTable";
    public static final String CU_DETAILS_TABLE="cuDetailsTable";
    public static final String GSI_TRENDS_ANALYSIS_TABLE_NAME = "gsiTrendsAnalysisTable";

    // Attributes
    public static final String EXECUTION_STATE = "executionState";
    public static final String TRIGGERED_STATUS = "TRIGGERED";
    public static final String INCOMPLETE_STATUS = "INCOMPLETE";
    public static final String USER_ID = "userId";
    public static final String EMAIL_ID = "emailId";
    public static final String TENANT_ID = "tenantId";
    public static final String CONTAINER_CU_NAME = "containerCuName";
    public static final String GSI_NAME = "gsiName";
    public static final String CONTAINER_CU_NAMES = "containerCuNames";
    public static final String AVERAGE_DURATION = "avgDuration";
    public static final String TOTAL_DURATION = "totalDuration";
    public static final String READABLE_TOTAL_DURATION = "readableTotalDuration";
    public static final String LAST_ADDED_DURATION = "lastAddedDuration";
    public static final String LAST_RUN_GSI_NAME = "lastRunContainerCuName";
    public static final String TOTAL_TRANSACTIONS = "totalTransactions";
    public static final String TOTAL_COMPLETED_TRANSACTIONS = "totalCompletedTransactions";
    public static final String TOTAL_INCOMPLETE_TRANSACTIONS = "totalIncompleteTransactions";
    public static final String TOTAL_FAILED_TRANSACTIONS = "totalFailedTransactions";
    public static final String DESCENDING = "desc";
    public static final String USER = "user";
    public static final String ACTIVE_USERS = "activeUsers";
    public static final String TENANT = "tenant";
    public static final String DATA = "data";
    public static final String TRANSACTION_DTO = "transactionDto";
    public static final String CU_ID = "cUId";
    public static final String REFERENCE_CHANGE_UNIT_ID = "referenceChangeUnitId";
    public static final String CU_NAME = "cuName";
    public static final String TRIGGER_STATE = "triggerState";
    public static final String TRIGGERED_TIME = "triggeredTime";
    public static final String GSI_START_TIME = "startTime";
    public static final String CU_START_TIME = "triggerStartTime";
    public static final String CU_END_TIME = "triggerEndTime";
    public static final String GSI_END_TIME = "endTime";
    public static final  String TRANSACTION_STATUS = "transactionStatus";
    public static final String TRIGGER_CU_NAME = "triggerCuName";
    public static final String CURRENT_CU_NAME = "currentCuName";
    public static final String TRANSACTION_ID = "transactionId";
    public static final String ORG_UNIT_ID = "orgUnitId";
    public static final String COMPLETED_STATUS = "COMPLETED";
    public static final String FAILED_STATUS = "FAILED";
    public static final String TXN_DATA_DTO = "txnDataDto";
    public static final String TXN_DATA = "txnData";
    public static final String DURATION = "duration";
    public static final String GSI_ID = "gsiId";
    public static final String CONTAINER_CU_ID = "containerCuId";

    // Serdes
    public static final Serde<String> STRING_SERDE = Serdes.String();
    public static final Serde<Long> LONG_SERDE = Serdes.Long();

    // Unspecific
    public static final String SUCCESS_MSG = "Success";
    public static final String DISPLAY_CONTROLLER = "DISPLAY_CONTROLLER";
    public static final String TRANSACTION_CONTROLLER = "TRANSACTION_CONTROLLER";
    public static final String KTABLE_TO_KAFKA_JOB_NAME = "ktable-to-kafka";
    public static final String KTABLE_TO_KAFKA_JOB_ID = "kafka-topic-save-sync";
    // Memgraph
    public static final String MEMGRAPH_JOB_NAME = "ktable-to-memgraph-sync";
    public static final String MEMGRAPH_JOB_ID = "memgraph-save-sync";
    public static final String GSI_NODES = "gsiNodeList";
    public static final String CU_NODES = "cuNodeList";
    public static final String GE_NODES = "generalEntityList";
    public static final String RELATIONSHIPS = "relationshipList";
    public static final String GSI = "GSI";
    public static final String CHANGE_UNIT = "ChangeUnit";
    public static final String GENERAL_ENTITY = "GeneralEntity";
    public static final String PATH = "path";
    public static final String PATH_ONE = "path1";
    public static final String PATH_TWO = "path2";
    public static final String NAME = "name";
    public static final String ID = "id";
    public static final String GET_PARENT_NODES_FOR_CU_ID = "getParentNodesForCuId";
    public static final String GET_CHILD_NODES_FOR_CU_ID = "getChildNodesForCuId";
    public static final String GET_CU_NODES_FOR_GSI_ID = "getCuNodesForGsiId";
    public static final String GET_GE_NODES_FOR_GSI_ID = "getGeNodesForGsiId";
    public static final String GET_GSI_NODES_FOR_GE_ID = "getGsiNodesForGeId";
    public static final String GET_CU_NODES_FOR_GE_ID = "getCuNodesForGeId";
    public static final String GET_CHILD_NODES_FOR_GE_ID = "getChildNodesForGeId";
    public static final String GE = "ge";
    public static final String CU = "cu";
    public static final String TXN_CU_LAYER = "txnCULayer";
    public static final String TXN_SLOT_ITEMS = "txnSlotItems";
    public static final String ITEM = "item";
    public static final String GENERAL_ENTITY_ID = "generalEntityID";
    public static final String GENERAL_ENTITY_MASTER_ID = "generalEntityMasterId";
    public static final String ITEM_DATA = "DATA";
    public static final String CU_TYPE = "cuType";
    public static final String NSL_ATTRIBUTE_ID = "nslAttributeID";
    public static final String ATTRIBUTE = "attribute";
    public static final String ATRRIBUTE_NODES = "attributeList";
    public static final String KEYS = "Keys";
    public static final String CU_ROW_KEYS = "cuRowKeys";
    public static final String TRANS_ENTITY_RECORDS = "transEntityRecords";
    public static final String TXN_NSL_ATTRIBUTE = "txnNslAttribute";
    public static final String RESULT = "result";
    public static final String AGENTS = "agents";
    public static final String AGENT_TYPE = "agentType";
    public static final String IS_RESERVED = "isReserved";
    public static final String RESERVED_CU_TYPE = "reservedCUType";
    public static final String CU_SYSTEM_PROPERTIES = "cuSystemProperties";
    public static final String EXT_SOLNS_TYPE = "extSolnsType";
    public static final String ADAPTER = "adapter";
    public static final String RESERVED_CU_METHOD_TYPE = "reservedCuMethodType";
    public static final String TRAN_TYPE = "tranType";
    public static final String GSI_UNIQUE_ENTRIES = "gsiUniqueEntries";
    public static final String BOOK_ID="id";
    public static final String BOOK_NAME="name";
}
