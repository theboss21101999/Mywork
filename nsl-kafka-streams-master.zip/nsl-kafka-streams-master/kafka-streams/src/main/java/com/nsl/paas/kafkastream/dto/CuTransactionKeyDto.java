package com.nsl.paas.kafkastream.dto;

public record CuTransactionKeyDto(long transactionId,
                                  long referenceChangeUnitId,
                                  String tenantId) {
}
