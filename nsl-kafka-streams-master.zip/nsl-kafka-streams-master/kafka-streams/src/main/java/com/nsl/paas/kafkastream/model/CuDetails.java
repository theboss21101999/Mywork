package com.nsl.paas.kafkastream.model;

public class CuDetails {
    private String cuName;
    private String agentType;
    private boolean isReserved;
    private String cuCategory;
    private String methodType;

    public CuDetails() {
    }

    // Constructor
    public CuDetails(String cuName, String agentType,boolean isReserved,String cuCategory,String methodType) {
        this.cuName = cuName;
        this.agentType = agentType;
        this.isReserved= isReserved;
        this.cuCategory=cuCategory;
        this.methodType=methodType;
    }

    public String getCuName() {
        return cuName;
    }

    public void setCuName(String cuName) {
        this.cuName = cuName;
    }

    public String getAgentType() {
        return agentType;
    }

    public void setAgentType(String agentType) {
        this.agentType = agentType;
    }

    public String getCuCategory() {return cuCategory;}

    public void setCuCategory(String cuCategory) {this.cuCategory = cuCategory;}

    public boolean isReserved() {return isReserved;}

    public void setReserved(boolean reserved) {isReserved = reserved;}

    public String getMethodType() {return methodType;}

    public void setMethodType(String methodType) {this.methodType = methodType;}


}