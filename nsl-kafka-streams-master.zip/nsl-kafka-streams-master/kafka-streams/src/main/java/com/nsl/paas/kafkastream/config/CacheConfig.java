package com.nsl.paas.kafkastream.config;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.nsl.paas.kafkastream.model.CuDetails;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.util.concurrent.TimeUnit;

@Configuration

public class CacheConfig {
    @Bean
    public Cache<Long, CuDetails> guavaCache() {
        return CacheBuilder.newBuilder()
                .maximumSize(100)
                .expireAfterAccess(10, TimeUnit.MINUTES)
                .build();
    }
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
