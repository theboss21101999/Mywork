package com.nsl.paas.kafkastream.dto;

public record UserKeyDto(long userId,
                         String emailId)
{

}
