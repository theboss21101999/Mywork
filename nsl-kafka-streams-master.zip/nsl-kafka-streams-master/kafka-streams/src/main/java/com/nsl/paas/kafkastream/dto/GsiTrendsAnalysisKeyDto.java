package com.nsl.paas.kafkastream.dto;

public record GsiTrendsAnalysisKeyDto(Long transactionId,
                                      String tenantId,
                                      Long containerId) {
}
