package com.nsl.paas.kafkastream.dto;

public record TransactionStatus(long transactionId, String status, long updatedAt) {

}
