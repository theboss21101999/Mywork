package com.nsl.paas.kafkastream.serdes;

import com.nsl.paas.kafkastream.dto.GsiTrendsKey;
import com.nsl.paas.kafkastream.dto.UserKeyDto;
import com.nsl.paas.kafkastream.dto.CuTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.CuTransactionValueDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionValueDto;
import com.nsl.paas.kafkastream.dto.GsiTrendsAnalysisKeyDto;
import com.nsl.paas.kafkastream.dto.GsiTrendsAnalysisValueDto;
import com.nsl.paas.kafkastream.model.GsiTrendsValueInfo;
import com.nsl.paas.kafkastream.model.TenantActivityInfo;
import com.nsl.paas.kafkastream.model.UserActivityInfo;
import io.confluent.kafka.serializers.AbstractKafkaAvroSerDeConfig;
import io.confluent.kafka.streams.serdes.avro.GenericAvroSerde;
import java.util.Collections;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;

public class SerdesFactory {

    public static Serde<GsiFinalTransactionKeyDto> gsiFinalTransactionKeyDtoSerde() {

        JsonSerializer<GsiFinalTransactionKeyDto> jsonSerializer = new JsonSerializer<>();

        JsonDeserializer<GsiFinalTransactionKeyDto> jsonDeSerializer = new JsonDeserializer<>(GsiFinalTransactionKeyDto.class);
        return  Serdes.serdeFrom(jsonSerializer, jsonDeSerializer);
    }

    public static Serde<GsiFinalTransactionValueDto> gsiFinalTransactionValueDtoSerde() {

        JsonSerializer<GsiFinalTransactionValueDto> jsonSerializer = new JsonSerializer<>();

        JsonDeserializer<GsiFinalTransactionValueDto> jsonDeSerializer = new JsonDeserializer<>(GsiFinalTransactionValueDto.class);
        return  Serdes.serdeFrom(jsonSerializer, jsonDeSerializer);
    }

    public static Serde<CuTransactionKeyDto> cuTransactionKeyDtoSerde() {

        JsonSerializer<CuTransactionKeyDto> jsonSerializer = new JsonSerializer<>();

        JsonDeserializer<CuTransactionKeyDto> jsonDeSerializer = new JsonDeserializer<>(CuTransactionKeyDto.class);
        return  Serdes.serdeFrom(jsonSerializer, jsonDeSerializer);
    }

    public static Serde<CuTransactionValueDto> cuTransactionValueDtoSerde() {

        JsonSerializer<CuTransactionValueDto> jsonSerializer = new JsonSerializer<>();

        JsonDeserializer<CuTransactionValueDto> jsonDeSerializer = new JsonDeserializer<>(CuTransactionValueDto.class);
        return  Serdes.serdeFrom(jsonSerializer, jsonDeSerializer);
    }

    public static Serde<UserKeyDto> userKeyDtoSerde() {

        JsonSerializer<UserKeyDto> jsonSerializer = new JsonSerializer<>();
        JsonDeserializer<UserKeyDto> jsonDeserializer = new JsonDeserializer<>(UserKeyDto.class);

        return Serdes.serdeFrom(jsonSerializer, jsonDeserializer);
    }

    public static Serde<UserActivityInfo> userActivityInfoSerde() {

        JsonSerializer<UserActivityInfo> jsonSerializer = new JsonSerializer<>();
        JsonDeserializer<UserActivityInfo> jsonDeserializer = new JsonDeserializer<>(UserActivityInfo.class);

        return Serdes.serdeFrom(jsonSerializer, jsonDeserializer);
    }

    public static Serde<TenantActivityInfo> tenantActivityInfoSerde() {

        JsonSerializer<TenantActivityInfo> jsonSerializer = new JsonSerializer<>();
        JsonDeserializer<TenantActivityInfo> jsonDeserializer = new JsonDeserializer<>(TenantActivityInfo.class);

        return Serdes.serdeFrom(jsonSerializer, jsonDeserializer);
    }

    public static Serde<GsiTrendsAnalysisKeyDto> gsiTrendsAnalysisKeyDtoSerde() {

        JsonSerializer<GsiTrendsAnalysisKeyDto> jsonSerializer = new JsonSerializer<>();

        JsonDeserializer<GsiTrendsAnalysisKeyDto> jsonDeSerializer = new JsonDeserializer<>(GsiTrendsAnalysisKeyDto.class);
        return  Serdes.serdeFrom(jsonSerializer, jsonDeSerializer);
    }

    public static Serde<GsiTrendsAnalysisValueDto> gsiTrendsAnalysisValueDtoSerde() {

        JsonSerializer<GsiTrendsAnalysisValueDto> jsonSerializer = new JsonSerializer<>();

        JsonDeserializer<GsiTrendsAnalysisValueDto> jsonDeSerializer = new JsonDeserializer<>(GsiTrendsAnalysisValueDto.class);
        return  Serdes.serdeFrom(jsonSerializer, jsonDeSerializer);
    }

    public static GenericAvroSerde getAvroSerde(final String schemaRegistryUrl) {
        GenericAvroSerde avroSerde = new GenericAvroSerde();

        avroSerde.configure(
            Collections.singletonMap(AbstractKafkaAvroSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistryUrl),
            false
        );

        return avroSerde;
    }

    public static Serde<GsiTrendsKey> GsiTrendsKeySerde() {

        JsonSerializer<GsiTrendsKey> jsonSerializer = new JsonSerializer<>();

        JsonDeserializer<GsiTrendsKey> jsonDeSerializer = new JsonDeserializer<>(GsiTrendsKey.class);
        return  Serdes.serdeFrom(jsonSerializer, jsonDeSerializer);
    }

    public static Serde<GsiTrendsValueInfo> GsiTrendsValueInfoSerde() {

        JsonSerializer<GsiTrendsValueInfo> jsonSerializer = new JsonSerializer<>();

        JsonDeserializer<GsiTrendsValueInfo> jsonDeSerializer = new JsonDeserializer<>(GsiTrendsValueInfo.class);
        return  Serdes.serdeFrom(jsonSerializer, jsonDeSerializer);
    }


}