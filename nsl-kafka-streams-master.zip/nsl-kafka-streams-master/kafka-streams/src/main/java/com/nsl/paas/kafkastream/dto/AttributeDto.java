package com.nsl.paas.kafkastream.dto;

public record AttributeDto(String name,
                           Long attributeId) {
}
