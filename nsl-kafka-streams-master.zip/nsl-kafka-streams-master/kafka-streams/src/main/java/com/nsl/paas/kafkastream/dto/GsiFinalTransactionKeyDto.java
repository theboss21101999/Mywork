package com.nsl.paas.kafkastream.dto;

public record GsiFinalTransactionKeyDto(String containerCuName,
                                        long transactionId,
                                        String tenantId)
{

}