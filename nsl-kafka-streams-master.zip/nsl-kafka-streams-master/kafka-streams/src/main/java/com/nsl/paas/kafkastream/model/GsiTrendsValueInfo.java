package com.nsl.paas.kafkastream.model;

import com.nsl.paas.kafkastream.dto.GeneralEntityDto;
import com.nsl.paas.kafkastream.dto.GsiTrendsKey;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;

public class GsiTrendsValueInfo {

    Long gsiId;
    String tenantId;
    String containerName;
    Long containerId;
    CuDetails containerDetails;
    List<GeneralEntityDto> listOfGeneralEntities;
    LinkedHashSet<Long> transactionIds;
    LinkedHashSet<Long> successTransactionIds;
    LinkedHashMap<Long, Long> failureTransactionIds;
    Long totalTransactionCount;
    Long totalSuccessCount;
    Long totalFailureCount;
    Double minimumTime;
    Double maximumTime;
    Double averageTime;
    Long transId;
    Double totalDuration;
    Double lastDuration;
    List<GsiTrendsValueInfo> listOfCuTrendsValueInfo;
    LinkedHashSet<GsiTrendsKey> rowKeys;


    public GsiTrendsValueInfo() {
        this.gsiId = 0L;
        this.tenantId = "";
        this.containerName = "";
        this.containerId = 0L;
        this.containerDetails = null;
        this.listOfGeneralEntities = new ArrayList<>();
        this.transactionIds = new LinkedHashSet<>();
        this.successTransactionIds = new LinkedHashSet<>();
        this.failureTransactionIds = new LinkedHashMap<>();
        this.totalTransactionCount = 0L;
        this.totalSuccessCount = 0L;
        this.totalFailureCount = 0L;
        this.minimumTime = Double.MAX_VALUE;
        this.maximumTime = Double.MIN_VALUE;
        this.averageTime = 0.0;
        this.transId = 0L;
        this.totalDuration = 0D;
        this.lastDuration = 0D;
        this.listOfCuTrendsValueInfo = new ArrayList<>();
        this.rowKeys = new LinkedHashSet<>();
    }

    public GsiTrendsValueInfo(Long gsiId, String tenantId, String containerName, Long containerId, CuDetails containerDetails,
                              List<GeneralEntityDto> listOfGeneralEntities, LinkedHashSet<Long> transactionIds,
                              LinkedHashSet<Long> successTransactionIds, LinkedHashMap<Long, Long> failureTransactionIds,
                              Long totalTransactionCount, Long totalSuccessCount, Long totalFailureCount,
                              Double minimumTime, Double maximumTime, Double averageTime, Long transId,
                              Double totalDuration, Double lastDuration, List<GsiTrendsValueInfo> listOfCuTrendsValueInfo,
                              LinkedHashSet<GsiTrendsKey> rowKeys) {
        this.gsiId = gsiId;
        this.tenantId = tenantId;
        this.containerName = containerName;
        this.containerId = containerId;
        this.containerDetails = containerDetails;
        this.listOfGeneralEntities = listOfGeneralEntities;
        this.transactionIds = transactionIds;
        this.successTransactionIds = successTransactionIds;
        this.failureTransactionIds = failureTransactionIds;
        this.totalTransactionCount = totalTransactionCount;
        this.totalSuccessCount = totalSuccessCount;
        this.totalFailureCount = totalFailureCount;
        this.minimumTime = minimumTime;
        this.maximumTime = maximumTime;
        this.averageTime = averageTime;
        this.transId = transId;
        this.totalDuration = totalDuration;
        this.lastDuration = lastDuration;
        this.listOfCuTrendsValueInfo = listOfCuTrendsValueInfo;
        this.rowKeys = rowKeys;
    }

    public Long getGsiId() {
        return gsiId;
    }

    public void setGsiId(Long gsiId) {
        this.gsiId = gsiId;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getContainerName() {
        return containerName;
    }

    public void setContainerName(String containerName) {
        this.containerName = containerName;
    }

    public Long getContainerId() {
        return containerId;
    }

    public void setContainerId(Long containerId) {
        this.containerId = containerId;
    }

    public List<GeneralEntityDto> getListOfGeneralEntities() {
        return listOfGeneralEntities;
    }

    public void setListOfGeneralEntities(List<GeneralEntityDto> listOfGeneralEntities) {
        this.listOfGeneralEntities = listOfGeneralEntities;
    }

    public Long getTotalTransactionCount() {
        return totalTransactionCount;
    }

    public void setTotalTransactionCount(Long totalTransactionCount) {
        this.totalTransactionCount = totalTransactionCount;
    }

    public Long getTotalSuccessCount() {
        return totalSuccessCount;
    }

    public void setTotalSuccessCount(Long totalSuccessCount) {
        this.totalSuccessCount = totalSuccessCount;
    }

    public Long getTotalFailureCount() {
        return totalFailureCount;
    }

    public void setTotalFailureCount(Long totalFailureCount) {
        this.totalFailureCount = totalFailureCount;
    }

    public Double getMinimumTime() {
        return minimumTime;
    }

    public void setMinimumTime(Double minimumTime) {
        this.minimumTime = minimumTime;
    }

    public Double getMaximumTime() {
        return maximumTime;
    }

    public void setMaximumTime(Double maximumTime) {
        this.maximumTime = maximumTime;
    }

    public Double getAverageTime() {
        return averageTime;
    }

    public void setAverageTime(Double averageTime) {
        this.averageTime = averageTime;
    }

    public Long getTransId() {
        return transId;
    }

    public void setTransId(Long transId) {
        this.transId = transId;
    }

    public Double getTotalDuration() {
        return totalDuration;
    }

    public void setTotalDuration(Double totalDuration) {
        this.totalDuration = totalDuration;
    }

    public Double getLastDuration() {
        return lastDuration;
    }

    public void setLastDuration(Double lastDuration) {
        this.lastDuration = lastDuration;
    }

    public LinkedHashSet<Long> getTransactionIds() {
        return transactionIds;
    }

    public void setTransactionIds(LinkedHashSet<Long> transactionIds) {
        this.transactionIds = transactionIds;
    }

    public LinkedHashSet<Long> getSuccessTransactionIds() {
        return successTransactionIds;
    }

    public void setSuccessTransactionIds(LinkedHashSet<Long> successTransactionIds) {
        this.successTransactionIds = successTransactionIds;
    }

    public LinkedHashMap<Long, Long> getFailureTransactionIds() {
        return failureTransactionIds;
    }

    public void setFailureTransactionIds(LinkedHashMap<Long, Long> failureTransactionIds) {
        this.failureTransactionIds = failureTransactionIds;
    }

    public List<GsiTrendsValueInfo> getListOfCuTrendsValueInfo() {
        return listOfCuTrendsValueInfo;
    }

    public void setListOfCuTrendsValueInfo(List<GsiTrendsValueInfo> listOfCuTrendsValueInfo) {
        this.listOfCuTrendsValueInfo = listOfCuTrendsValueInfo;
    }

    public LinkedHashSet<GsiTrendsKey> getRowKeys() {
        return rowKeys;
    }

    public void setRowKeys(LinkedHashSet<GsiTrendsKey> rowKeys) {
        this.rowKeys = rowKeys;
    }

    public CuDetails getContainerDetails() {
        return containerDetails;
    }

    public void setContainerDetails(CuDetails containerDetails) {
        this.containerDetails = containerDetails;
    }

    @Override
    public String toString() {
        return "GsiTrendsValueInfo{" +
                "gsiId=" + gsiId +
                ", tenantId='" + tenantId + '\'' +
                ", containerName='" + containerName + '\'' +
                ", containerId=" + containerId +
                ", containerDetails=" + containerDetails +
                ", listOfGeneralEntities=" + listOfGeneralEntities +
                ", transactionIds=" + transactionIds +
                ", successTransactionIds=" + successTransactionIds +
                ", failureTransactionIds=" + failureTransactionIds +
                ", totalTransactionCount=" + totalTransactionCount +
                ", totalSuccessCount=" + totalSuccessCount +
                ", totalFailureCount=" + totalFailureCount +
                ", minimumTime=" + minimumTime +
                ", maximumTime=" + maximumTime +
                ", averageTime=" + averageTime +
                ", transId=" + transId +
                ", totalDuration=" + totalDuration +
                ", lastDuration=" + lastDuration +
                ", listOfCuTrendsValueInfo=" + listOfCuTrendsValueInfo +
                ", rowKeys=" + rowKeys +
                '}';
    }
}
