package com.nsl.paas.kafkastream.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import tech.allegro.schema.json2avro.converter.AvroConversionException;
import tech.allegro.schema.json2avro.converter.JsonGenericRecordReader;

import java.util.Map;

/**
 * A utility class to convert Java objects to Avro GenericRecord.
 */
public class ObjectGenericRecordReader extends JsonGenericRecordReader {

    // ObjectMapper instance to serialize/deserialize Java objects
    private final ObjectMapper mapper;

    /**
     * Constructs a new ObjectGenericRecordReader with ObjectMapper configured with JavaTimeModule.
     */
    public ObjectGenericRecordReader() {
        this.mapper = new ObjectMapper();
        this.mapper.registerModule(new JavaTimeModule());
    }

    /**
     * Converts a Java object to an Avro GenericRecord.
     *
     * @param object The Java object to convert.
     * @param schema The Avro schema for the GenericRecord.
     * @return The Avro GenericRecord.
     * @throws AvroConversionException If conversion fails.
     */
    public GenericData.Record read(Object object, Schema schema) throws AvroConversionException {
        try {

            // Convert the Java object to a Map<String, Object> using ObjectMapper
            Map<String, Object> objectMap = this.mapper.convertValue(object, new TypeReference<>() {});
            return this.read(objectMap, schema);
        } catch (IllegalArgumentException e) {
            throw new AvroConversionException("Failed to convert Java object to Map<String, Object>.", e);
        }
    }
}
