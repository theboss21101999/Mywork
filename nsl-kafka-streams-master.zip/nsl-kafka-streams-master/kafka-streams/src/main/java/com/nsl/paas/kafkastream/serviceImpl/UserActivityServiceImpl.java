package com.nsl.paas.kafkastream.serviceImpl;

import com.nsl.paas.kafkastream.dto.UserKeyDto;
import com.nsl.paas.kafkastream.enums.KafkaStoreExceptionType;
import com.nsl.paas.kafkastream.exceptions.KafkaStoreAccessException;
import com.nsl.paas.kafkastream.exceptions.NotFoundException;
import com.nsl.paas.kafkastream.model.UserActivityInfo;
import com.nsl.paas.kafkastream.service.UserActivityService;
import java.time.Duration;
import java.time.Instant;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import java.util.Set;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.errors.TimeoutException;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StoreQueryParameters;
import org.apache.kafka.streams.errors.InvalidStateStoreException;
import org.apache.kafka.streams.kstream.Windowed;
import org.apache.kafka.streams.state.KeyValueIterator;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyWindowStore;
import org.apache.kafka.streams.state.WindowStoreIterator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;

import static com.nsl.paas.kafkastream.constants.AppConstants.DISPLAY_CONTROLLER;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_ONE_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_THREE_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_SIX_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWELVE_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWENTY_FOUR_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.USER;
import static com.nsl.paas.kafkastream.constants.AppConstants.AVERAGE_DURATION;
import static com.nsl.paas.kafkastream.constants.AppConstants.TENANT_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.DESCENDING;
import static com.nsl.paas.kafkastream.constants.AppConstants.TOTAL_DURATION;
import static com.nsl.paas.kafkastream.constants.AppConstants.TOTAL_COMPLETED_TRANSACTIONS;
import static com.nsl.paas.kafkastream.constants.AppConstants.TOTAL_TRANSACTIONS;
import static com.nsl.paas.kafkastream.constants.AppConstants.TOTAL_INCOMPLETE_TRANSACTIONS;
import static com.nsl.paas.kafkastream.constants.AppConstants.TOTAL_FAILED_TRANSACTIONS;

@Service
public class UserActivityServiceImpl implements UserActivityService {

    @Autowired
    private StreamsBuilderFactoryBean factoryBean;

    private static final Logger log = LoggerFactory.getLogger(UserActivityServiceImpl.class);

    @Override
    public Map<UserKeyDto, UserActivityInfo> getUserActivityInfoByTimeWindow(final int page, final int pageSize,
        final String sortBy, final String sortOrder,
        final int windowSizeInHours) {

        final String tableName = getTableNameByWindowSize(windowSizeInHours);
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyWindowStore<UserKeyDto, UserActivityInfo> windowedUserKTable;

        try {
            assert kafkaStreams != null;
            windowedUserKTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(tableName, QueryableStoreTypes.windowStore())
            );

            // Retrieve all data
            final Instant startTime = Instant.now().minus(Duration.ofHours(windowSizeInHours));
            final Instant endTime = Instant.now();

            log.info("Fetching data from windowed user table for time window of last {} hour.", windowSizeInHours);

            KeyValueIterator<Windowed<UserKeyDto>, UserActivityInfo> allData = windowedUserKTable.fetchAll(startTime, endTime);

            // Sorting logic based on sortBy and sortOrder
            List<Entry<UserKeyDto, UserActivityInfo>> sortedData = new ArrayList<>();
            while (allData.hasNext()) {
                KeyValue<Windowed<UserKeyDto>, UserActivityInfo> iter = allData.next();
                sortedData.add(new SimpleEntry<>(iter.key.key(), iter.value));
            }

            log.info("Success in retrieving data from windowed user table for time window of last {} hour.", windowSizeInHours);

            Comparator<Entry<UserKeyDto, UserActivityInfo>> comparator = getComparator(sortBy, sortOrder);
            sortedData.sort(comparator);

            // Pagination logic
            final int startIdx = (page - 1) * pageSize;
            final int endIdx = Math.min(startIdx + pageSize, sortedData.size());

            // Build paginated result
            Map<UserKeyDto, UserActivityInfo> paginatedResult = new LinkedHashMap<>();
            for (int i = startIdx; i < endIdx; i++) {
                Map.Entry<UserKeyDto, UserActivityInfo> entry = sortedData.get(i);
                paginatedResult.put(entry.getKey(), entry.getValue());
            }

            return paginatedResult;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public UserActivityInfo getActivityByUserIdAndTimeWindow(final long userId, final String emailId, final int windowSizeInHours,
        final String controller) {

        final String tableName = getTableNameByWindowSize(windowSizeInHours);
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        final UserKeyDto key = new UserKeyDto(userId, emailId);
        ReadOnlyWindowStore<UserKeyDto, UserActivityInfo> windowedUserKTable;

        try {
            assert kafkaStreams != null;
            windowedUserKTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(tableName, QueryableStoreTypes.windowStore())
            );

            final Instant startTime = Instant.now().minus(Duration.ofHours(windowSizeInHours));
            final Instant endTime = Instant.now();

            log.info("Retrieving user activity info for key: {} for the last: {} hour.", key, windowSizeInHours);

            WindowStoreIterator<UserActivityInfo> iterator = windowedUserKTable.fetch(key, startTime, endTime);

            UserActivityInfo userActivityInfo;

            if (iterator.hasNext()) {
                KeyValue<Long, UserActivityInfo> keyValue = iterator.next();
                userActivityInfo = keyValue.value;
            } else {
                // If no value found in the specified window, populate with default values
                userActivityInfo = UserActivityInfo.Builder()
                    .withTenantIds(getTenantIdFromFirstWindowedKey(windowedUserKTable, key))
                    .build();

                if (controller.equals(DISPLAY_CONTROLLER)) {
                    log.warn("The given user either does not exist or has not done any activity in given time window. " +
                        "User key: {}, time window: {} hour", key, windowSizeInHours);
                } else {
                    log.error("The given user either does not exist or has not done any activity in given time window. " +
                        "User key: {}, time window: {} hour", key, windowSizeInHours);

                    final String errMsg = "The given user either does not exist or has not done any activity in given time window. " +
                        "User key: " + key + ", time window: " + windowSizeInHours + " hour";

                    throw new NotFoundException(errMsg);
                }
            }

            log.info("Successfully retrieved user activity info for key: {} for the last: {} hour.", key, windowSizeInHours);

            iterator.close();

            return userActivityInfo;
        } catch (NotFoundException e) {
            throw new NotFoundException(e.getMessage());
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving user activity data for key "
                + key + "for time window " + "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving user activity data for key "
                + key + "for time window " + "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving user activity data for key "
                + key + "for time window " + "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving user activity data for key "
                + key + "for time window " + "of last " + windowSizeInHours + " hour.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    private Set<String> getTenantIdFromFirstWindowedKey(final ReadOnlyWindowStore<UserKeyDto, UserActivityInfo> windowedUserKTable,
        final UserKeyDto key) {
        KeyValueIterator<Windowed<UserKeyDto>, UserActivityInfo> iterator = windowedUserKTable.all();
        Set<String> tenantIds = new HashSet<>();

        while (iterator.hasNext()) {
            KeyValue<Windowed<UserKeyDto>, UserActivityInfo> keyValue = iterator.next();
            if (keyValue.key.key().emailId().equals(key.emailId()) && keyValue.key.key().userId() == key.userId()) {
                tenantIds = keyValue.value.getTenants();
                break;
            }
        }

        iterator.close();

        return tenantIds;
    }

    @Override
    public List<UserActivityInfo> getUserActivityListByTimeWindow(final int windowSizeInHours) {

        final String tableName = getTableNameByWindowSize(windowSizeInHours);
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyWindowStore<UserKeyDto, UserActivityInfo> windowedUserKTable;

        try {
            assert kafkaStreams != null;
            windowedUserKTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(tableName, QueryableStoreTypes.windowStore())
            );

            // Retrieve all data
            final Instant startTime = Instant.now().minus(Duration.ofHours(windowSizeInHours));
            final Instant endTime = Instant.now();

            log.info("Fetching data from windowed user table for time window of last {} hour.", windowSizeInHours);

            KeyValueIterator<Windowed<UserKeyDto>, UserActivityInfo> allData = windowedUserKTable.fetchAll(startTime, endTime);

            List<UserActivityInfo> result = new ArrayList<>();

            while (allData.hasNext()) {
                KeyValue<Windowed<UserKeyDto>, UserActivityInfo> kv = allData.next();
                result.add(kv.value);
            }

            log.info("Success in retrieving data from windowed user table for time window of last {} hour.", windowSizeInHours);

            return result;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public Long getActiveUserCountByTimeWindow(final int windowSizeInHours) {

        final String tableName = getTableNameByWindowSize(windowSizeInHours);
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyWindowStore<UserKeyDto, UserActivityInfo> windowedUserKTable;

        try {
            assert kafkaStreams != null;
            windowedUserKTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(tableName, QueryableStoreTypes.windowStore())
            );

            final Instant startTime = Instant.now().minus(Duration.ofHours(windowSizeInHours));
            final Instant endTime = Instant.now();

            log.info("Retrieving data from windowed users activity table to get count of active users for last: {} hour.", windowSizeInHours);

            KeyValueIterator<Windowed<UserKeyDto>, UserActivityInfo> iterator = windowedUserKTable.fetchAll(startTime, endTime);

            Long count = 0L;
            while (iterator.hasNext()) {
                iterator.next();
                count++;
            }

            iterator.close();

            log.info("Success in getting count of active users for last {} hour.", windowSizeInHours);

            return count;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving user activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    private String getTableNameByWindowSize(final int duration) {
        String baseTableName;
        switch (duration) {
            case 1 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_ONE_HOUR;
            case 3 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_THREE_HOUR;
            case 6 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_SIX_HOUR;
            case 12 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWELVE_HOUR;
            case 24 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWENTY_FOUR_HOUR;
            default -> throw new IllegalArgumentException("Unsupported duration: " + duration);
        }

        return USER + "_" + baseTableName;
    }

    private Comparator<Map.Entry<UserKeyDto, UserActivityInfo>> getComparator(final String sortBy, final String sortOrder) {

        Comparator<Map.Entry<UserKeyDto, UserActivityInfo>> comparator = switch (sortBy) {
            case AVERAGE_DURATION -> Comparator.comparingLong(entry -> entry.getValue().getAvgDuration());
            case TOTAL_DURATION -> Comparator.comparingLong(entry -> entry.getValue().getTotalDuration());
            case TOTAL_TRANSACTIONS -> Comparator.comparingLong(entry -> entry.getValue().getTotalTransactions());
            case TOTAL_FAILED_TRANSACTIONS ->
                Comparator.comparingLong(entry -> entry.getValue().getTotalFailedTransactions());
            case TOTAL_COMPLETED_TRANSACTIONS ->
                Comparator.comparingLong(entry -> entry.getValue().getTotalCompletedTransactions());
            case TOTAL_INCOMPLETE_TRANSACTIONS ->
                Comparator.comparingLong(entry -> entry.getValue().getTotalIncompleteTransactions());
//            case TENANT_ID -> Comparator.comparing(entry -> entry.getValue().getTenantId());
            default -> throw new IllegalArgumentException("Invalid sortBy parameter");
        };

        if (comparator != null) {
            if (DESCENDING.equalsIgnoreCase(sortOrder)) {
                return comparator.reversed();
            } else {
                return comparator;
            }
        } else {
            throw new IllegalArgumentException("Invalid sortBy parameter");
        }
    }
}