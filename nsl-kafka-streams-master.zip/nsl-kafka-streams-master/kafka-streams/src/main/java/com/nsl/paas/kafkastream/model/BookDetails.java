package com.nsl.paas.kafkastream.model;

public class BookDetails {
    private long bookId;
    private String bookName;
    public BookDetails(){

    }
    //constructor
    public BookDetails(long bookId, String bookName) {
        this.bookId = bookId;
        this.bookName = bookName;
    }

    public long getBookId() {
        return bookId;
    }
    public void setBookId(long bookId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }


}
