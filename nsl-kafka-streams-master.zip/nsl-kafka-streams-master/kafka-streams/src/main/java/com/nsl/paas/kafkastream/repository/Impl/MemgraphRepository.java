package com.nsl.paas.kafkastream.repository.Impl;

import com.nsl.paas.kafkastream.repository.GraphDbRepository;
import java.util.List;
import java.util.Set;
import org.neo4j.driver.Driver;
import org.neo4j.driver.Record;
import org.neo4j.driver.Result;
import org.neo4j.driver.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import static com.nsl.paas.kafkastream.constants.AppConstants.ATRRIBUTE_NODES;
import static com.nsl.paas.kafkastream.constants.AppConstants.GE_NODES;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI_NODES;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_NODES;
import static com.nsl.paas.kafkastream.constants.AppConstants.RELATIONSHIPS;

@Repository
public class MemgraphRepository implements GraphDbRepository, AutoCloseable {
    private static final Logger log = LoggerFactory.getLogger(MemgraphRepository.class);
    private final Driver memgraphClient;

    @Autowired
    public MemgraphRepository(Driver memgraphClient) {
        this.memgraphClient = memgraphClient;
    }

    @Override
    public void saveIndexes(final List<String> createIndexQueries) {

        try (Session session = memgraphClient.session()) {
            for (String createIndexQuery: createIndexQueries) {
                log.info("Trying to create index for {}", createIndexQuery.substring(17));
                session.run(createIndexQuery);
                log.info("Success in creating index for {}", createIndexQuery.substring(17));
            }
        }
    }

    @Override
    public void executeSaveCall(final List<Set<String>> nodesAndRelationships) {
        log.info("Executing queries to save nodes and relationships.");
        try (Session session = memgraphClient.session()) {
            int index = 0;
            String[] keys = {GSI_NODES, CU_NODES, GE_NODES, ATRRIBUTE_NODES, RELATIONSHIPS};
            for (Set<String> queries: nodesAndRelationships) {
                String key = keys[index];

                if (RELATIONSHIPS.equals(key)) {
                    log.info("Trying to save relationships.");
                } else {
                    log.info("Trying to save {}.", key);
                }
                queries.forEach(query -> {
                    session.executeWriteWithoutResult(tx -> {
                        tx.run(query);
                    });
                });

                if (RELATIONSHIPS.equals(key)) {
                    log.info("Success in saving relationships.");
                } else {
                    log.info("Success in saving {}.", key);
                }

                index++;
            }
        }
    }

    @Override
    public List<Record> executeReadCall(final String query) {
        log.info("Trying execute read query.");
        try (Session session = memgraphClient.session()) {
            List<Record> result = session.executeRead(tx -> {
                Result queryResult = tx.run(query);
                List<Record> records = queryResult.list();
                return records;
            });

            log.info("Success in executing read query and retrieving result from graph db.");

            return result;
        }
    }

    @Override
    public void close() throws RuntimeException {
        memgraphClient.close();
    }
}