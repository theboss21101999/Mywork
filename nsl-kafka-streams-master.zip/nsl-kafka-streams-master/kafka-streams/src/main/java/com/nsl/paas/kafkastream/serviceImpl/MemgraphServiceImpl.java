package com.nsl.paas.kafkastream.serviceImpl;

import com.nsl.paas.kafkastream.dto.AttributeDto;
import com.nsl.paas.kafkastream.dto.GeneralEntityDto;
import com.nsl.paas.kafkastream.dto.NodeDto;
import com.nsl.paas.kafkastream.dto.PathDto;
import com.nsl.paas.kafkastream.dto.RelationshipDto;
import com.nsl.paas.kafkastream.model.GsiTrendsValueInfo;
import com.nsl.paas.kafkastream.repository.GraphDbRepository;
import com.nsl.paas.kafkastream.service.GsiActivityService;
import com.nsl.paas.kafkastream.service.MemgraphService;
import jakarta.annotation.PostConstruct;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.List;
import java.util.HashMap;

import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.jobrunr.jobs.annotations.Job;
import org.jobrunr.scheduling.JobScheduler;
import org.jobrunr.spring.annotations.Recurring;
import org.neo4j.driver.Record;
import org.neo4j.driver.types.Node;
import org.neo4j.driver.types.Path;
import org.neo4j.driver.types.Relationship;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.nsl.paas.kafkastream.constants.AppConstants.ATTRIBUTE;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU;
import static com.nsl.paas.kafkastream.constants.AppConstants.GE;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_CHILD_NODES_FOR_CU_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_CHILD_NODES_FOR_GE_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_CU_NODES_FOR_GE_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_CU_NODES_FOR_GSI_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_GE_NODES_FOR_GSI_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_GSI_NODES_FOR_GE_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_PARENT_NODES_FOR_CU_ID;

import static com.nsl.paas.kafkastream.constants.AppConstants.ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.PATH;
import static com.nsl.paas.kafkastream.constants.AppConstants.PATH_ONE;
import static com.nsl.paas.kafkastream.constants.AppConstants.PATH_TWO;
import static com.nsl.paas.kafkastream.constants.AppConstants.MEMGRAPH_JOB_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.MEMGRAPH_JOB_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI;
import static com.nsl.paas.kafkastream.constants.AppConstants.CHANGE_UNIT;
import static com.nsl.paas.kafkastream.constants.AppConstants.GENERAL_ENTITY;

@Service
public class MemgraphServiceImpl implements MemgraphService {
    private static final Logger log = LoggerFactory.getLogger(MemgraphServiceImpl.class);
    private final GsiActivityService gsiActivityService;
    private final GraphDbRepository graphDbRepository;
    private final JobScheduler jobScheduler;

    @Autowired
    public MemgraphServiceImpl(GsiActivityService gsiActivityService, GraphDbRepository graphDbRepository,
        JobScheduler jobScheduler) {
        this.gsiActivityService = gsiActivityService;
        this.graphDbRepository = graphDbRepository;
        this.jobScheduler = jobScheduler;
    }

    @PostConstruct
    public void scheduleStartupJob() {
        Instant someTimeFromNow = Instant.now().plus(10, ChronoUnit.MINUTES);
        jobScheduler.schedule(someTimeFromNow, this::runWithDelay);
    }

    public void runWithDelay() {
        log.info("Executing scheduled job to save in memgraph few minutes after service startup");

        List<String> indexes = Arrays.asList(
            createIndexQuery(GENERAL_ENTITY),
            createIndexQuery(GSI),
            createIndexQuery(CHANGE_UNIT),
            createIndexQuery(ATTRIBUTE)
        );
        graphDbRepository.saveIndexes(indexes);
        fetchAndSaveNodesAndRelationships();

        log.info("Success in running scheduled job to save in memgraph few minutes after service startup");
    }

    @Recurring(id = MEMGRAPH_JOB_ID, cron = "${schedule.write.to.memgraph}")
    @Job(name = MEMGRAPH_JOB_NAME)
    public void fetchAndSaveNodesAndRelationships() {
        log.info("Executing recurring job to save in memgraph.");

        ConcurrentHashMap<Long, GsiTrendsValueInfo> gsiCuEntityMap = gsiActivityService.getGsiTrendsMap();
        List<Set<String>> nodesAndRelationships = createNodesAndRelationships(gsiCuEntityMap);
        graphDbRepository.executeSaveCall(nodesAndRelationships);

        log.info("Success in executing recurring job: {}", MEMGRAPH_JOB_NAME);
    }

    @Override
    public List<PathDto> getDependencyGraphByBetId(final Long betId, final String betType) {
        log.info("Trying to fetch dependency graph by betId {} and bet type {}", betId, betType);

        List<PathDto> pathList = new ArrayList<>();
        Map<Long, Long> internalIdToIdResolutionMap = new HashMap<>();

        final String query = getDependencyGraphQueryByBetType(betId, betType);
        List<Record> paths = graphDbRepository.executeReadCall(query);

        for (Record path: paths) {
            if (CHANGE_UNIT.equals(betType)) {
                final Path p1 = path.get(PATH_ONE).asPath();
                processDependencyGraphQueryResult(internalIdToIdResolutionMap, pathList, p1);
                final Path p2 = path.get(PATH_TWO).asPath();
                processDependencyGraphQueryResult(internalIdToIdResolutionMap, pathList, p2);
            } else {
                final Path p = path.get(PATH).asPath();
                processDependencyGraphQueryResult(internalIdToIdResolutionMap, pathList, p);
            }
        }

        log.info("Success in retrieving dependency graph.");

        return pathList;
    }

    @Override
    public List<NodeDto> getListOfNodes(final Long betId, final String methodName) {
        final String query = getQueryByMethodName(betId, methodName);
        List<Record> response = graphDbRepository.executeReadCall(query);
        List<NodeDto> result = new ArrayList<>();

        for (Record node: response) {
            Node n = null;
            if (GET_PARENT_NODES_FOR_CU_ID.equals(methodName)) n = node.get(GSI.toLowerCase(Locale.ENGLISH)).asNode();
            if (GET_CHILD_NODES_FOR_CU_ID.equals(methodName)) n = node.get(GE).asNode();
            if (GET_CU_NODES_FOR_GSI_ID.equals(methodName)) n = node.get(CU).asNode();
            if (GET_GE_NODES_FOR_GSI_ID.equals(methodName)) n = node.get(GE).asNode();
            if (GET_GSI_NODES_FOR_GE_ID.equals(methodName)) n = node.get(GSI.toLowerCase(Locale.ENGLISH)).asNode();
            if (GET_CU_NODES_FOR_GE_ID.equals(methodName)) n = node.get(CU).asNode();
            if (GET_CHILD_NODES_FOR_GE_ID.equals(methodName)) n = node.get(ATTRIBUTE).asNode();

            if (n != null) {
                String label = n.labels().toString();
                String name = n.get(NAME).asString();
                Long id = n.get(ID).asLong();

                result.add(new NodeDto(label, id, name));
            }
        }

        if (!response.isEmpty()) {
            NodeDto rootNode = extractRootNodeFromResponse(response.get(0), methodName);
            if (rootNode != null) result.add(rootNode);
        }

        return result;
    }

    private NodeDto extractRootNodeFromResponse(final Record record, final String methodName) {
        NodeDto node = null;
        Node n = null;

        if (GET_PARENT_NODES_FOR_CU_ID.equals(methodName)) n = record.get(CU).asNode();
        if (GET_CHILD_NODES_FOR_CU_ID.equals(methodName)) n = record.get(CU).asNode();
        if (GET_CU_NODES_FOR_GSI_ID.equals(methodName)) n = record.get(GSI.toLowerCase(Locale.ENGLISH)).asNode();
        if (GET_GE_NODES_FOR_GSI_ID.equals(methodName)) n = record.get(GSI.toLowerCase(Locale.ENGLISH)).asNode();
        if (GET_GSI_NODES_FOR_GE_ID.equals(methodName)) n = record.get(GE).asNode();
        if (GET_CU_NODES_FOR_GE_ID.equals(methodName)) n = record.get(GE).asNode();
        if (GET_CHILD_NODES_FOR_GE_ID.equals(methodName)) n = record.get(GE).asNode();

        if (n != null) {
            String label = n.labels().toString();
            String name = n.get(NAME).asString();
            Long id = n.get(ID).asLong();
            node = new NodeDto(label, id, name);
        }

        return node;
    }

    private void processDependencyGraphQueryResult(Map<Long, Long> internalIdToIdResolutionMap,
        List<PathDto> pathList, Path p) {

        Map<Long, NodeDto> nodeDtoMap = new HashMap<>();
        List<RelationshipDto> relationships = new ArrayList<>();

        Node pathStartInternalNode = p.start();
        Node pathEndInternalNode = p.end();

        NodeDto pathStartNode = new NodeDto(pathStartInternalNode.labels().toString(),
            pathStartInternalNode.get(ID).asLong(), pathStartInternalNode.get(NAME).asString());

        NodeDto pathEndNode = new NodeDto(pathEndInternalNode.labels().toString(),
            pathEndInternalNode.get(ID).asLong(), pathEndInternalNode.get(NAME).asString());

        final int pathLength = p.length();

        List<Relationship> relationshipsIterator = (List<Relationship>) p.relationships();
        List<Node> nodes = (List<Node>) p.nodes();

        nodes.forEach(node -> {
            Long internalId = node.id();
            Long id = node.get(ID).asLong();
            String name = node.get(NAME).asString();
            String label = node.labels().toString();

            internalIdToIdResolutionMap.put(internalId, id);
            nodeDtoMap.put(id, new NodeDto(label, id, name));
        });

        relationshipsIterator.forEach(relationship -> {
            String type = relationship.type();
            Long startNodeInternalId = Long.valueOf(relationship.startNodeElementId());
            Long endNodeInternalId = Long.valueOf(relationship.endNodeElementId());

            Long startId = internalIdToIdResolutionMap.get(startNodeInternalId);
            Long endId = internalIdToIdResolutionMap.get(endNodeInternalId);

            relationships.add(new RelationshipDto(type, endId, startId));
        });

        pathList.add(new PathDto(pathStartNode, pathEndNode, pathLength, nodeDtoMap, relationships));
    }

    private String getDependencyGraphQueryByBetType(final Long betId, final String betType) {
        final String query = switch (betType) {
            case GSI -> "MATCH path=(gsi:GSI)<-[:CHILD_OF*1..]-(cu:ChangeUnit)<-[:CHILD_OF*]-(ge:GeneralEntity)\n"
                + "WHERE gsi.id = "+ betId + "RETURN path";
            case CHANGE_UNIT -> "MATCH path1=(gsi:GSI)<-[:CHILD_OF]-(cu:ChangeUnit),\n"
                + "      path2=(cu)<-[:CHILD_OF]-(ge:GeneralEntity)\n"
                + "WHERE cu.id = " + betId + "RETURN path1, path2";
            case GENERAL_ENTITY -> "MATCH path=(ge:GeneralEntity)-[:CHILD_OF*]->(cu:ChangeUnit)-[:CHILD_OF]->(gsi:GSI)\n"
                + "WHERE ge.id = " + betId + "RETURN path";
            default -> throw new IllegalArgumentException("Invalid betType parameter");
        };

        return query;
    }

    private String getQueryByMethodName(final Long betId, final String methodName) {
        final String query = switch (methodName) {
            case GET_PARENT_NODES_FOR_CU_ID -> "MATCH (gsi:GSI)<-[:CHILD_OF]-(cu:ChangeUnit)\n"
                + "WHERE cu.id = " + betId +"RETURN cu, gsi";
            case GET_CHILD_NODES_FOR_CU_ID -> "MATCH (cu:ChangeUnit)<-[:CHILD_OF]-(ge:GeneralEntity)\n"
                + "WHERE cu.id = " + betId + "RETURN cu, ge";
            case GET_CU_NODES_FOR_GSI_ID -> "MATCH (gsi:GSI)<-[:CHILD_OF*1..]-(cu:ChangeUnit)\n"
                + "WHERE gsi.id = " + betId + "RETURN gsi, cu";
            case GET_GE_NODES_FOR_GSI_ID -> "MATCH (gsi:GSI)<-[:CHILD_OF]-(cu:ChangeUnit)<-[:CHILD_OF]-(ge:GeneralEntity)\n"
                + "WHERE gsi.id = " + betId + "RETURN gsi, ge";
            case GET_GSI_NODES_FOR_GE_ID -> "MATCH (ge:GeneralEntity)-[:CHILD_OF]->(cu:ChangeUnit)-[:CHILD_OF]->(gsi:GSI)\n"
                + "WHERE ge.id = " + betId + "RETURN ge, gsi";
            case GET_CU_NODES_FOR_GE_ID -> "MATCH (ge:GeneralEntity)-[:CHILD_OF]->(cu:ChangeUnit)\n"
                + "WHERE ge.id = "+ betId + "RETURN ge, cu";
            case GET_CHILD_NODES_FOR_GE_ID -> "MATCH (ge:GeneralEntity)<-[:CHILD_OF]-(attribute:attribute)\n"
                    + "WHERE ge.id = " + betId + "RETURN ge, attribute";
            default -> throw new IllegalStateException("Unexpected value: " + methodName);
        };

        return query;
    }

    private List<Set<String>> createNodesAndRelationships(final ConcurrentHashMap<Long, GsiTrendsValueInfo> gsiCuEntityMap) {
        Set<String> gsiNodes = new HashSet<>();
        Set<String> changeUnitNodes = new HashSet<>();
        Set<String> generalEntityNodes = new HashSet<>();
        Set<String> attributeNodes = new HashSet<>();
        Set<String> relationships = new HashSet<>();

        for (Map.Entry<Long, GsiTrendsValueInfo> entry: gsiCuEntityMap.entrySet()) {
            GsiTrendsValueInfo gsiTrendsValueInfo = entry.getValue();
            long gsiId = gsiTrendsValueInfo.getGsiId();
            String gsiName = gsiTrendsValueInfo.getContainerName();

            gsiNodes.add(createNodeQuery(GSI, gsiId, gsiName));

            if (gsiTrendsValueInfo.getListOfGeneralEntities() != null) {
                for (GeneralEntityDto generalEntity: gsiTrendsValueInfo.getListOfGeneralEntities()) {
                    generalEntityNodes.add(createNodeQuery(GENERAL_ENTITY, generalEntity.geId(), generalEntity.name()));

                    relationships.add(createRelationshipQuery(gsiId, GSI, generalEntity.geId(), GENERAL_ENTITY));
                }
            }

            for (GsiTrendsValueInfo cuData : gsiTrendsValueInfo.getListOfCuTrendsValueInfo()) {

                Long cuId = cuData.getContainerId();
                String cuName = cuData.getContainerName();

                //handling embedded/logic/nested gsi's
                if(!cuData.getListOfCuTrendsValueInfo().isEmpty()){
                    gsiNodes.add(createNodeQuery(GSI, gsiId, gsiName));
                    relationships.add(createRelationshipQuery(gsiId, GSI, cuId, GSI));
                    ConcurrentHashMap<Long, GsiTrendsValueInfo> embeddedGsiMap = new ConcurrentHashMap<>();
                    embeddedGsiMap.put(cuId,cuData);
                    createNodesAndRelationships(embeddedGsiMap);
                }

                changeUnitNodes.add(createNodeQuery(CHANGE_UNIT, cuId, cuName));
                relationships.add(createRelationshipQuery(gsiId, GSI, cuId, CHANGE_UNIT));

                for (GeneralEntityDto generalEntity: cuData.getListOfGeneralEntities()) {
                    generalEntityNodes.add(createNodeQuery(GENERAL_ENTITY, generalEntity.geId(), generalEntity.name()));
                    relationships.add(createRelationshipQuery(cuId, CHANGE_UNIT, generalEntity.geId(),
                            GENERAL_ENTITY));
                    if(Objects.nonNull(generalEntity.listOfAttributes())){
                        for(AttributeDto attribute : generalEntity.listOfAttributes()){
                            attributeNodes.add(createNodeQuery(ATTRIBUTE,attribute.attributeId(),attribute.name()));
                            relationships.add(createRelationshipQuery(generalEntity.geId(),GENERAL_ENTITY,
                                    attribute.attributeId(),ATTRIBUTE));
                        }
                    }
                }
            }
        }

        List<Set<String>> nodesAndRelationshipsList = new ArrayList<>();
        nodesAndRelationshipsList.add(gsiNodes);
        nodesAndRelationshipsList.add(changeUnitNodes);
        nodesAndRelationshipsList.add(generalEntityNodes);
        nodesAndRelationshipsList.add(attributeNodes);
        nodesAndRelationshipsList.add(relationships);

        return nodesAndRelationshipsList;
    }

    private String createIndexQuery(final String label) {
        return "CREATE INDEX ON :" + label + "(id);";
    }

    private String createNodeQuery(final String betType, final Long betId, final String betName) {
        return "MERGE (n:" + betType + " {id: " + betId + ", name:'" + betName + "'});";
    }

    private String createRelationshipQuery(final Long parentBetId, final String parentBetType, final Long childBetId, final String childBetType) {
        return "MATCH (a:" + childBetType + " {id: " + childBetId + "}),(b:" + parentBetType + " {id: " + parentBetId + "}) MERGE (a)-[r:CHILD_OF]->(b);";
    }
}