package com.nsl.paas.kafkastream.utils;

import com.nsl.paas.kafkastream.dto.EsKeyDto;
import com.nsl.paas.kafkastream.dto.UserKeyDto;
import com.nsl.paas.kafkastream.model.TenantActivityInfo;
import com.nsl.paas.kafkastream.model.UserActivityInfo;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.reflect.ReflectData;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StoreQueryParameters;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyWindowStore;
import org.jobrunr.jobs.annotations.Job;
import org.jobrunr.scheduling.JobScheduler;
import org.jobrunr.spring.annotations.Recurring;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import java.time.Duration;
import java.time.Instant;
import static com.nsl.paas.kafkastream.constants.AppConstants.KTABLE_TO_KAFKA_JOB_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.KTABLE_TO_KAFKA_JOB_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_ONE_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_THREE_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_SIX_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWELVE_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWENTY_FOUR_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.USER;
import static com.nsl.paas.kafkastream.constants.AppConstants.TENANT;

@Component
public class KtableBackupUtil {
    private static final Logger log = LoggerFactory.getLogger(KtableBackupUtil.class);

    @Value("${table.window.size}")
    private int tableWindowSize;

    @Value("${table.name.prefix.user}")
    private String userTableNamePrefix;

    @Value("${table.name.prefix.tenant}")
    private String tenantTableNamePrefix;

    @Value("${topic.name.prefix.user}")
    private String userTopicNamePrefix;

    @Value("${topic.name.prefix.tenant}")
    private String tenantTopicNamePrefix;

    @Autowired
    private StreamsBuilderFactoryBean factoryBean;

    @Autowired
    private KafkaTemplate<Object, Object> kafkaTemplate;

    @Autowired
    private JobScheduler jobScheduler;

    @Recurring(id = KTABLE_TO_KAFKA_JOB_ID, cron = "${schedule.backup.to.es}")
    @Job(name = KTABLE_TO_KAFKA_JOB_NAME)
    public void publishKTableDataToKafka() {
        KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        if (kafkaStreams != null && kafkaStreams.state().isRunningOrRebalancing()) {
            sendDatatoTopic(kafkaStreams);
        } else {
            log.warn("KafkaStreams is not running or rebalancing. State is: {}", kafkaStreams != null ? kafkaStreams.state() : "UNKNOWN");
        }
    }

    private void sendDatatoTopic(KafkaStreams kafkaStreams) {
        processTableData(kafkaStreams, this::getTableNameByWindowSize, this::getTopicNameByWindowSize, EsKeyDto.class, UserActivityInfo.class, userTableNamePrefix, userTopicNamePrefix);
        processTableData(kafkaStreams, this::getTableNameByWindowSize, this::getTopicNameByWindowSize, EsKeyDto.class, TenantActivityInfo.class, tenantTableNamePrefix, tenantTopicNamePrefix);
    }

    private <K, V> void processTableData(KafkaStreams kafkaStreams, TableNameFunction tableNameFunction, TopicNameFunction topicNameFunction, Class<K> keyClass, Class<V> valueClass, String tableNamePrefix, String topicNamePrefix) {
        String tableName = tableNameFunction.getName(tableWindowSize, tableNamePrefix);
        String topicName = topicNameFunction.getName(tableWindowSize, topicNamePrefix);
        Schema keySchema = ReflectData.get().getSchema(keyClass);
        Schema valueSchema = ReflectData.get().getSchema(valueClass);

        try {
            ReadOnlyWindowStore<K, V> windowStore = kafkaStreams.store(StoreQueryParameters.fromNameAndType(tableName, QueryableStoreTypes.windowStore()));
            Instant startTime = Instant.now().minus(Duration.ofHours(tableWindowSize));
            Instant endTime = Instant.now();

            try (var allData = windowStore.fetchAll(startTime, endTime)) {
                if (!allData.hasNext()) {
                    log.info("No activity data received in the last {} hours for table {}", tableWindowSize, tableName);
                }

                while (allData.hasNext()) {
                    var entry = allData.next();
                    EsKeyDto key = new EsKeyDto(System.currentTimeMillis());
                    V value = entry.value;
                    GenericRecord keyAvro = ObjectToAvroUtil.get().ConvertToGenericDataRecord(key, keySchema);
                    GenericRecord valueAvro = ObjectToAvroUtil.get().ConvertToGenericDataRecord(value, valueSchema);
                    kafkaTemplate.send(topicName, keyAvro, valueAvro);
                    log.debug("Sent activity data to Kafka topic: {}, Key: {}, Value: {}", topicName, key, value);
                }
            }
        } catch (Exception e) {
            log.error("Error accessing or processing table store: {}", tableName, e);
        }
    }

    @FunctionalInterface
    private interface TableNameFunction {
        String getName(int duration, String prefix);
    }

    @FunctionalInterface
    private interface TopicNameFunction {
        String getName(int duration, String prefix);
    }

    private String getTableNameByWindowSize(int duration, String prefix) {
        String baseTableName = switch (duration) {
            case 1 -> ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_ONE_HOUR;
            case 3 -> ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_THREE_HOUR;
            case 6 -> ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_SIX_HOUR;
            case 12 -> ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWELVE_HOUR;
            case 24 -> ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWENTY_FOUR_HOUR;
            default -> throw new IllegalArgumentException("Unsupported duration: " + duration);
        };
        return prefix + "_" + baseTableName;
    }

    private String getTopicNameByWindowSize(int duration, String prefix) {
        String windowDuration = switch (duration) {
            case 1 -> "one_hour";
            case 3 -> "three_hour";
            case 6 -> "six_hour";
            case 12 -> "twelve_hour";
            case 24 -> "twenty_four_hour";
            default -> throw new IllegalArgumentException("Unsupported window size: " + duration);
        };
        return prefix + "." + windowDuration;
    }
}
