package com.nsl.paas.kafkastream.repository;

import java.util.List;
import java.util.Set;
import org.neo4j.driver.Record;

public interface GraphDbRepository {
    void saveIndexes(final List<String> indexes);
    void executeSaveCall(final List<Set<String>> nodesAndRelationships);
    List<Record> executeReadCall(final String query);
}