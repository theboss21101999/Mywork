package com.nsl.paas.kafkastream.config;

import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class MemgraphDbConfig {

    @Value("${memgraph.uri}")
    private String uri;

    @Value("${memgraph.username:}")
    private String username;

    @Value("${memgraph.password:}")
    private String password;

    /**
     * Creates a singleton Neo4j Driver instance for connecting to Memgraph.
     * This driver is thread-safe and should be reused across the application.
     *
     * @return The configured Neo4j Driver instance.
     */
    @Bean
    @Scope("singleton")
    public Driver memgraphDriver() {
        return GraphDatabase.driver(uri, AuthTokens.basic(username, password));
    }
}