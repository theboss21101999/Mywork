package com.nsl.paas.kafkastream.config;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuration class for setting up Kafka Avro serialization.
 */

@Configuration
public class KafkaAvroConfig {

    /**
     * Define Kafka template bean.
     * @return KafkaTemplate instance.
     */
    @Bean
    public KafkaTemplate<Object, Object> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }

    @Value(value = "${spring.kafka.bootstrap-servers}")
    private String bootstrapAddress;

    @Value(value = "${kafka.schema.registry.url}")
    private String schemaRegistryUrl;

    /**
     * Define Kafka producer factory.
     * @return ProducerFactory instance.
     */
    @Bean
    public ProducerFactory<Object, Object> producerFactory() {
        Map<String, Object> producerProps = new HashMap<>();

        // Set the Kafka broker address
        producerProps.put("bootstrap.servers", bootstrapAddress);

        // Configure Avro serializers for key and value
        producerProps.put("key.serializer", KafkaAvroSerializer.class.getName());
        producerProps.put("value.serializer", KafkaAvroSerializer.class.getName());

        // Set the URL for the Avro schema registry
        producerProps.put("schema.registry.url", schemaRegistryUrl);



        // Create and return DefaultKafkaProducerFactory
        return new DefaultKafkaProducerFactory<>(producerProps);
    }
}
