package com.nsl.paas.kafkastream.service;

import com.nsl.paas.kafkastream.dto.CuTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.CuTransactionValueDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionValueDto;
import com.nsl.paas.kafkastream.model.GsiTrendsValueInfo;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public interface GsiActivityService {

    Long getCompletedGsiCountByGsiName(final String gsiName);

    Long getFailedGsiCountByGsiName(final String gsiName);

    GsiFinalTransactionValueDto getGsiDurationByTxnIdAndNameAndTenantId(final String gsiName,
                                            final long transactionId, final String tenantId);

    Map<String, Long> getCompletedGsiCountMap();

    Map<CuTransactionKeyDto, CuTransactionValueDto> getCuExecutionActivityMap();

    Map<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> getGsiExecutionActivityMap();

    List<Map<String, String>> getGsiExecutionActivityMapAsList();

    List<Map<String, String>> getCuExecutionActivityMapAsList();

    List<Map<String, Long>> getGsiAnalyticsMapAsList();

    ConcurrentHashMap<Long, GsiTrendsValueInfo> getGsiTrendsMap();

    ConcurrentHashMap<Long, GsiTrendsValueInfo> getGsiTrendsMapByName(String gsiName);

    Map<String, Set<String>> getReservedCuTypes();

}
