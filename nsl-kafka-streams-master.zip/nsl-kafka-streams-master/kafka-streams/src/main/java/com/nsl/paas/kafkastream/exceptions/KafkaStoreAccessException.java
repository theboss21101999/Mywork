package com.nsl.paas.kafkastream.exceptions;

import com.nsl.paas.kafkastream.enums.KafkaStoreExceptionType;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class KafkaStoreAccessException extends RuntimeException {
    private final KafkaStoreExceptionType exceptionType;

    public KafkaStoreAccessException(String message, KafkaStoreExceptionType exceptionType) {
        super(message);
        this.exceptionType = exceptionType;
    }

    public KafkaStoreAccessException(String message, Throwable cause, KafkaStoreExceptionType exceptionType) {
        super(message, cause);
        this.exceptionType = exceptionType;
    }

    public KafkaStoreExceptionType getExceptionType() {
        return exceptionType;
    }
}