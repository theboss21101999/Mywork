package com.nsl.paas.kafkastream.topology;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.cache.Cache;
import com.nsl.paas.kafkastream.dto.AttributeDto;
import com.nsl.paas.kafkastream.dto.GeneralEntityDto;
import com.nsl.paas.kafkastream.dto.GsiTrendsKey;
import com.nsl.paas.kafkastream.dto.TransactionStatus;
import com.nsl.paas.kafkastream.dto.UserKeyDto;
import com.nsl.paas.kafkastream.dto.CuTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.CuTransactionValueDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionValueDto;
import com.nsl.paas.kafkastream.model.*;
import com.nsl.paas.kafkastream.serdes.SerdesFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

import org.apache.avro.generic.GenericArray;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.common.utils.Bytes;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Grouped;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KeyValueMapper;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.kstream.TimeWindows;
import org.apache.kafka.streams.kstream.ValueMapper;
import org.apache.kafka.streams.kstream.Windowed;
import org.apache.kafka.streams.kstream.KTable;

import org.apache.kafka.streams.state.KeyValueStore;
import org.apache.kafka.streams.state.WindowStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

import static com.nsl.paas.kafkastream.constants.AppConstants.*;
import static com.nsl.paas.kafkastream.utils.TimeUtil.getReadableTimeFromMilliseconds;

@Component
public class TransactionProcessorAvro {

    @Value(value = "${kafka.avro.topic.name}")
    private String topic;

    @Value(value = "${kafka.schema.registry.url}")
    private String schemaRegistryUrl;

    @Value(value = "${gsi.table.kafka.topic.name}")
    private String gsiTableTopic;

    @Value(value = "${cu.table.kafka.topic.name}")
    private String cuTableTopic;

    @Value(value = "${nsl.bet.store.base.url}")
    private String nslBetStoreBaseUrl;

    @Value(value = "${es.topology.data.publish.flag:false}")
    private boolean publishToEsFlag;

    private static final Logger log = LoggerFactory.getLogger(TransactionProcessorAvro.class);

    private final Cache<Long, CuDetails> cache;
    private final Cache<Long,BookDetails>cache1;

    private final RestTemplate restTemplate;

    private final ObjectMapper objectMapper = new ObjectMapper();

    private static final List<Map<Long, TransactionStatus>> transactionStatusMaps = new ArrayList<>();
    private static final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
    private static final long RETENTION_PERIOD_MINUTES = 30;

    public TransactionProcessorAvro(Cache<Long, CuDetails> cache, Cache<Long, BookDetails> cache1, RestTemplate restTemplate) {
        this.cache = cache;
        this.cache1 = cache1;
        this.restTemplate = restTemplate;

        // populate transactionStatusMaps with concurrent hashmaps for each windowed KTable.
        IntStream.rangeClosed(1, 10)
            .forEach(i -> transactionStatusMaps.add(new ConcurrentHashMap<>()));

        // Initialize scheduler to clean up above maps every 10 minutes.
        executorService.scheduleAtFixedRate(TransactionProcessorAvro::cleanupTransactionStatusMaps, 5, 10, TimeUnit.MINUTES);
    }

    private static void cleanupTransactionStatusMaps() {
        long expirationThreshold = System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(RETENTION_PERIOD_MINUTES);

        // Removing entries from map which are older than 30 minutes.
        transactionStatusMaps.parallelStream().forEach(map -> {
            map.entrySet().removeIf(entry -> entry.getValue().updatedAt() < expirationThreshold);
        });
    }

    @Autowired
    public void txnTransDataAnalysis(StreamsBuilder streamsBuilder) {

        KStream<String, GenericRecord> avroStream = streamsBuilder.stream(topic,
            Consumed.with(STRING_SERDE, SerdesFactory.getAvroSerde(schemaRegistryUrl)));

        //count of GSIs that are successfully completed
        gsiCompletionAnalysis(avroStream);

        //count of events of GSIs failures for the transaction.
        gsiFailureEventsAnalysis(avroStream);

        //GSI level analysis of transactions.
        gsiExecutionAnalysis(avroStream);

        // CU level analysis of transactions.
        cuExecutionAnalysis(avroStream);

        //Hierarchical analysis of GSIs trends and its associated Cus.
        gsiTrendsAnalysis(avroStream);

        // User & Tenant Activity Analysis using windowed operations.
        generateWindowedKTablesForUserAndTenantActivity(avroStream);
    }

    private void generateWindowedKTablesForUserAndTenantActivity(
        KStream<String, GenericRecord> avroStream) {

        // Transform KStream to have transactionId as key and latest message for that txnId as value.
        KStream<Long, GenericRecord> transformedStream = getTransformedStream(avroStream);

        // Tenant & User level activity for time windows of 1 hour, 3 hour, 6 hour, 12 hour & 24 hour.
        var durations = new Duration[] {
            Duration.ofHours(1),
            Duration.ofHours(3),
            Duration.ofHours(6),
            Duration.ofHours(12),
            Duration.ofHours(24)
        };

        int transactionStatusMapListIndex = 0;
        for (Duration duration : durations) {
            userActivityAnalysis(transformedStream, duration, getTableName(duration, USER), transactionStatusMapListIndex);
            tenantActivityAnalysis(transformedStream, duration, getTableName(duration, TENANT), transactionStatusMapListIndex + 5);
            transactionStatusMapListIndex++;
        }
    }

    private KStream<Long, GenericRecord> getTransformedStream(KStream<String, GenericRecord> avroStream) {
        return avroStream
            .map((k,v) -> {
                Long transactionId = extractTransactionId(v);
                return KeyValue.pair(transactionId, v);
            })
            .groupByKey(Grouped.with(LONG_SERDE, SerdesFactory.getAvroSerde(schemaRegistryUrl)))
            .reduce((previous, latest) -> latest)
            .toStream();
    }

    private void userActivityAnalysis(KStream<Long, GenericRecord> transformedStream,
        final Duration windowSize, final String tableName, final int index) {

        KTable<Windowed<UserKeyDto>, UserActivityInfo> windowedUserActivityInfoTable = transformedStream
            .map((k,v) -> {
                UserKeyDto key = extractUserKeyDto(v);
                return KeyValue.pair(key, v);
            })
            .groupByKey(Grouped.with(SerdesFactory.userKeyDtoSerde(), SerdesFactory.getAvroSerde(schemaRegistryUrl)))
            .windowedBy(TimeWindows.ofSizeAndGrace(windowSize, getGracePeriodByWindowSize(windowSize)))
            .aggregate(
                () -> UserActivityInfo.Builder().build(),
                (userKeyDto, kafkaMessage, currentUserActivityInfo) -> aggregateUserActivityInfo(userKeyDto, currentUserActivityInfo, kafkaMessage, index),
                Materialized.<UserKeyDto, UserActivityInfo, WindowStore<Bytes, byte[]>>as(tableName)
                    .withKeySerde(SerdesFactory.userKeyDtoSerde())
                    .withValueSerde(SerdesFactory.userActivityInfoSerde())
                    .withRetention(getRetentionPeriodByWindowSize(windowSize))
            )
            .filter((windowedKey, userActivityInfo) -> userActivityInfo.getTotalTransactions() > 0);
    }

    private UserActivityInfo aggregateUserActivityInfo(UserKeyDto userKeyDto, UserActivityInfo userActivityInfo, GenericRecord kafkaMessage, int index) {
        GenericRecord data = (GenericRecord) kafkaMessage.get(DATA);
        GenericRecord transactionDtoNode = (GenericRecord) data.get(TRANSACTION_DTO);
        GenericRecord userContext = extractUserContext(kafkaMessage);

        Long transactionId = extractTransactionId(kafkaMessage);
        Map<Long, TransactionStatus> transactionStatusMap = transactionStatusMaps.get(index);

        Set<String> tenants = userActivityInfo.getTenants() != null ? userActivityInfo.getTenants() : new HashSet<>();
        String tenantId = (userContext != null && userContext.get(TENANT_ID) != null) ? userContext.get(TENANT_ID).toString() : null;
        if (tenantId != null) tenants.add(tenantId);

        // Extract GSIs executed in the given time window with their unique transaction counts.
        Map<String, ContainerCuInfo> containerCuNames = userActivityInfo.getContainerCuNames();
        if (containerCuNames == null) containerCuNames = new HashMap<>();
        aggregateActiveGsiInfo(transactionId, containerCuNames, transactionStatusMap, transactionDtoNode);

        // Compute Total Duration & success, failure, incomplete counts for given time window for a given user.
        Map<String, Object> resultMap = aggregateDurationAndCountsInfo(userActivityInfo, transactionStatusMap,
            transactionId, transactionDtoNode, containerCuNames);

        return UserActivityInfo.Builder()
            .withUserId(userKeyDto.userId())
            .withEmailId(userKeyDto.emailId())
            .withTenantIds(tenants)
            .withContainerCuNames(containerCuNames)
            .withAvgDuration((Long) resultMap.get(AVERAGE_DURATION))
            .withTotalDuration((Long) resultMap.get(TOTAL_DURATION))
            .withReadableTotalDuration((String) resultMap.get(READABLE_TOTAL_DURATION))
            .withTotalTransactions( (Long) resultMap.get(TOTAL_TRANSACTIONS))
            .withTotalCompletedTransactions((Long) resultMap.get(TOTAL_COMPLETED_TRANSACTIONS))
            .withTotalFailedTransactions((Long) resultMap.get(TOTAL_FAILED_TRANSACTIONS))
            .withTotalIncompleteTransactions((Long) resultMap.get(TOTAL_INCOMPLETE_TRANSACTIONS))
            .withLastRunContainerCuName(String.valueOf(resultMap.get(LAST_RUN_GSI_NAME)))
            .build();
    }

    private void tenantActivityAnalysis(KStream<Long, GenericRecord> transformedStream, final Duration windowSize,
        final String tableName, final int index) {

        KTable<Windowed<String>, TenantActivityInfo> windowedTenantActivityInfoTable = transformedStream
            .map((k,v) -> {
                String key = extractTenantId(v);
                return KeyValue.pair(key, v);
            })
            .groupByKey(Grouped.with(STRING_SERDE, SerdesFactory.getAvroSerde(schemaRegistryUrl)))
            .windowedBy(TimeWindows.ofSizeAndGrace(windowSize, getGracePeriodByWindowSize(windowSize)))
            .aggregate(
                () -> TenantActivityInfo.builder().build(),
                (tenantId, kafkaMessage, currentTenantActivityInfo) -> aggregateTenantActivityInfo(tenantId, currentTenantActivityInfo, kafkaMessage, index),
                Materialized.<String, TenantActivityInfo, WindowStore<Bytes, byte[]>>as(tableName)
                    .withKeySerde(STRING_SERDE)
                    .withValueSerde(SerdesFactory.tenantActivityInfoSerde())
                    .withRetention(getRetentionPeriodByWindowSize(windowSize))
            )
            .filter((windowedKey, tenantActivityInfo) -> tenantActivityInfo.getTotalTransactions() > 0);
    }

    private TenantActivityInfo aggregateTenantActivityInfo(String tenantId, TenantActivityInfo tenantActivityInfo, GenericRecord kafkaMessage, int index) {
        GenericRecord data = (GenericRecord) kafkaMessage.get(DATA);
        GenericRecord transactionDtoNode = (GenericRecord) data.get(TRANSACTION_DTO);
        GenericRecord userContext = extractUserContext(kafkaMessage);

        Long transactionId = extractTransactionId(kafkaMessage);
        Map<Long, TransactionStatus> transactionStatusMap = transactionStatusMaps.get(index);

        // Extract active users (doing transactions) in given time window for given tenant.
        Set<UserKeyDto> users = tenantActivityInfo.getUsers();
        if (users == null) users = new HashSet<>();
        aggregateActiveUserInfo(users, userContext);

        // Extract GSIs executed in the given time window with their unique transaction counts.
        Map<String, ContainerCuInfo> containerCuNames = tenantActivityInfo.getContainerCuNames();
        if (containerCuNames == null) containerCuNames = new HashMap<>();
        aggregateActiveGsiInfo(transactionId, containerCuNames, transactionStatusMap, transactionDtoNode);

        // Compute total duration and success, failure, incomplete counts in given time window for each tenant.
        Map<String, Object> resultMap = aggregateDurationAndCountsInfo(tenantActivityInfo, transactionStatusMap,
            transactionId, transactionDtoNode, containerCuNames);

        return TenantActivityInfo.builder()
            .withTenantId(tenantId)
            .withUsers(users)
            .withContainerCuNames(containerCuNames)
            .withAvgDuration((Long) resultMap.get(AVERAGE_DURATION))
            .withTotalDuration((Long) resultMap.get(TOTAL_DURATION))
            .withReadableTotalDuration((String) resultMap.get(READABLE_TOTAL_DURATION))
            .withTotalTransactions((Long) resultMap.get(TOTAL_TRANSACTIONS))
            .withTotalFailedTransactions((Long) resultMap.get(TOTAL_FAILED_TRANSACTIONS))
            .withTotalIncompleteTransactions((Long) resultMap.get(TOTAL_INCOMPLETE_TRANSACTIONS))
            .withTotalCompletedTransactions((Long) resultMap.get(TOTAL_COMPLETED_TRANSACTIONS))
            .withLastRunContainerCuName(String.valueOf(resultMap.get(LAST_RUN_GSI_NAME)))
            .build();
    }

    private void aggregateActiveUserInfo(Set<UserKeyDto> users, GenericRecord userContext) {
        if (userContext != null && userContext.get(USER_ID) != null && userContext.get(EMAIL_ID) != null) {

            long userId = Long.parseLong(userContext.get(USER_ID).toString());
            String emailId = userContext.get(EMAIL_ID).toString();

            users.add(new UserKeyDto(userId, emailId));
        }
    }

    private void aggregateActiveGsiInfo(Long transactionId,
        Map<String, ContainerCuInfo> containerCuNames, Map<Long, TransactionStatus> transactionStatusMap,
        GenericRecord transactionDtoNode) {

        if (transactionDtoNode != null && transactionDtoNode.get(CONTAINER_CU_NAME) != null &&
            transactionId != null && transactionStatusMap.get(transactionId) == null) {

            String containerCuName = transactionDtoNode.get(CONTAINER_CU_NAME).toString();

            ContainerCuInfo containerCuInfo = containerCuNames.computeIfAbsent(containerCuName, k -> {
                ContainerCuInfo newContainerCuInfo = new ContainerCuInfo();
                newContainerCuInfo.setContainerCuName(k);
                newContainerCuInfo.setTotalTransactions(0L);
                newContainerCuInfo.setTotalIncompleteTransactions(0L);
                newContainerCuInfo.setTransactionIds(new HashSet<>());
                return newContainerCuInfo;
            });
        }
    }

    private Map<String, Object> aggregateDurationAndCountsInfo(ActivityInfo activityInfo,
        Map<Long, TransactionStatus> transactionStatusMap, Long transactionId,
        GenericRecord transactionDtoNode, Map<String, ContainerCuInfo> containerCuNames) {

        Map<String, Object> resultMap = new HashMap<>();

        long totalTransactions = activityInfo.getTotalTransactions();
        long totalIncompleteTransactions = activityInfo.getTotalIncompleteTransactions();
        long totalCompletedTransactions = activityInfo.getTotalCompletedTransactions();
        long totalFailedTransactions = activityInfo.getTotalFailedTransactions();

        if (isNewTransaction(transactionDtoNode, transactionId, transactionStatusMap, containerCuNames)) {
            totalTransactions++;
            totalIncompleteTransactions++;

            updateContainerCuInfo(transactionDtoNode, containerCuNames,
                transactionId, TRIGGERED_STATUS);

            transactionStatusMap.put(transactionId,
                new TransactionStatus(transactionId, INCOMPLETE_STATUS, System.currentTimeMillis()));
        }

        if (isCompletedTransaction(transactionDtoNode, transactionId, transactionStatusMap, containerCuNames)) {
            totalCompletedTransactions++;
            totalIncompleteTransactions--;

            updateContainerCuInfo(transactionDtoNode, containerCuNames,
                transactionId, COMPLETED_STATUS);

            transactionStatusMap.put(transactionId,
                new TransactionStatus(transactionId, COMPLETED_STATUS, System.currentTimeMillis()));
        }

        if (isFailedTransaction(transactionDtoNode, transactionId, transactionStatusMap, containerCuNames)) {
            totalFailedTransactions++;

            updateContainerCuInfo(transactionDtoNode, containerCuNames,
                transactionId, FAILED_STATUS);

            transactionStatusMap.put(transactionId,
                new TransactionStatus(transactionId, FAILED_STATUS, System.currentTimeMillis()));
        }

        List<Long> countValues = handleEdgeCases(totalIncompleteTransactions, totalTransactions);
        totalIncompleteTransactions = countValues.get(0);
        totalTransactions = countValues.get(1);

        String lastRunContainerCuName = activityInfo.getLastRunContainerCuName();
        if (transactionDtoNode.get(CONTAINER_CU_NAME) != null) {
            String containerCuName = String.valueOf(transactionDtoNode.get(CONTAINER_CU_NAME));
            lastRunContainerCuName = containerCuName;
        }

        if (isPendingTransaction(transactionDtoNode, transactionId, transactionStatusMap, containerCuNames)) {
            calculateAndUpdateTotalDurationForGsi(transactionDtoNode, containerCuNames, transactionId);
        }

        long totalDuration = activityInfo.getTotalDuration();
        if (containerCuNames.size() != 0) totalDuration = 0;
        for (ContainerCuInfo containerCuInfo: containerCuNames.values()) {
            totalDuration = totalDuration + containerCuInfo.getTotalDuration();
        }

        long avgDuration = totalTransactions != 0 ? totalDuration / totalTransactions : activityInfo.getAvgDuration();
        String readableTotalDuration = getReadableTimeFromMilliseconds(totalDuration);

        resultMap.put(TOTAL_DURATION, totalDuration);
        resultMap.put(TOTAL_COMPLETED_TRANSACTIONS, totalCompletedTransactions);
        resultMap.put(TOTAL_TRANSACTIONS, totalTransactions);
        resultMap.put(TOTAL_INCOMPLETE_TRANSACTIONS, totalIncompleteTransactions);
        resultMap.put(TOTAL_FAILED_TRANSACTIONS, totalFailedTransactions);
        resultMap.put(READABLE_TOTAL_DURATION, readableTotalDuration);
        resultMap.put(AVERAGE_DURATION, avgDuration);
        resultMap.put(LAST_RUN_GSI_NAME, lastRunContainerCuName);

        return resultMap;
    }

    private boolean isPendingTransaction(GenericRecord transactionDtoNode, Long transactionId,
        Map<Long, TransactionStatus> transactionStatusMap, Map<String, ContainerCuInfo> containerCuNames) {

        return !isNewTransaction(transactionDtoNode, transactionId, transactionStatusMap, containerCuNames) &&
            !isCompletedTransaction(transactionDtoNode, transactionId, transactionStatusMap, containerCuNames) &&
            !isFailedTransaction(transactionDtoNode, transactionId, transactionStatusMap, containerCuNames);
    }

    private boolean isCompletedTransaction(GenericRecord transactionDtoNode, Long transactionId,
        Map<Long, TransactionStatus> transactionStatusMap, Map<String, ContainerCuInfo> containerCuNames) {

        return transactionDtoNode != null
               && transactionDtoNode.get(TRANSACTION_STATUS) != null &&
               COMPLETED_STATUS.equals(transactionDtoNode.get(TRANSACTION_STATUS).toString()) &&
               transactionId != null &&
               INCOMPLETE_STATUS.equals(transactionStatusMap.get(transactionId).status()) &&
               transactionDtoNode.get(CONTAINER_CU_NAME) != null &&
               containerCuNames.get(String.valueOf(transactionDtoNode.get(CONTAINER_CU_NAME))) != null;
    }

    private boolean isFailedTransaction(GenericRecord transactionDtoNode, Long transactionId,
        Map<Long, TransactionStatus> transactionStatusMap, Map<String, ContainerCuInfo> containerCuNames) {

        return transactionDtoNode != null &&
               transactionDtoNode.get(TRANSACTION_STATUS) != null &&
               FAILED_STATUS.equals(transactionDtoNode.get(TRANSACTION_STATUS).toString()) &&
               transactionId != null &&
               INCOMPLETE_STATUS.equals(transactionStatusMap.get(transactionId).status()) &&
               transactionDtoNode.get(CONTAINER_CU_NAME) != null &&
               containerCuNames.get(String.valueOf(transactionDtoNode.get(CONTAINER_CU_NAME))) != null;
    }

    private boolean isNewTransaction(GenericRecord transactionDtoNode, Long transactionId,
        Map<Long, TransactionStatus> transactionStatusMap, Map<String, ContainerCuInfo> containerCuNames) {

        return transactionId != null &&
            transactionStatusMap.get(transactionId) == null &&
            transactionDtoNode.get(CONTAINER_CU_NAME) != null &&
            containerCuNames.get(String.valueOf(transactionDtoNode.get(CONTAINER_CU_NAME))) != null;
    }

    private void updateContainerCuInfo(GenericRecord transactionDtoNode,
        Map<String, ContainerCuInfo> containerCuNames, Long transactionId, String status) {

        String containerCuName = String.valueOf(transactionDtoNode.get(CONTAINER_CU_NAME));
        ContainerCuInfo containerCuInfo = containerCuNames.get(containerCuName);

        long totalTransactions = containerCuInfo.getTotalTransactions();
        long failureOrSuccessCount = status.equals(COMPLETED_STATUS) ? containerCuInfo.getTotalCompletedTransactions() : containerCuInfo.getTotalFailedTransactions();
        long totalIncompleteTransactions = containerCuInfo.getTotalIncompleteTransactions();

        if (status.equals(COMPLETED_STATUS) || status.equals(FAILED_STATUS)) {
            failureOrSuccessCount++;
            if (status.equals(COMPLETED_STATUS)) totalIncompleteTransactions--;

            List<Long> countValues = handleEdgeCases(totalIncompleteTransactions, totalTransactions);

            containerCuInfo.setTotalIncompleteTransactions(countValues.get(0));
            containerCuInfo.setTotalTransactions(countValues.get(1));

            if (status.equals(COMPLETED_STATUS)) {
                containerCuInfo.setTotalCompletedTransactions(failureOrSuccessCount);
            } else {
                containerCuInfo.setTotalFailedTransactions(failureOrSuccessCount);
            }
        } else {
            containerCuInfo.setTotalTransactions(totalTransactions + 1);
            containerCuInfo.setTotalIncompleteTransactions(totalIncompleteTransactions + 1);
        }

        calculateAndUpdateTotalDurationForGsi(transactionDtoNode, containerCuNames, transactionId);
    }

    private List<Long> handleEdgeCases(long totalIncompleteTransactions, long totalTransactions) {

        // Edge case fix where total incomplete was negative
        // And total transaction count was not increasing.
        while (totalIncompleteTransactions < 0) {
            totalIncompleteTransactions++;
            totalTransactions++;
        }

        return Arrays.asList(totalIncompleteTransactions, totalTransactions);
    }

    private void calculateAndUpdateTotalDurationForGsi(GenericRecord transactionDtoNode,
        Map<String, ContainerCuInfo> containerCuNames, Long transactionId) {

        if (transactionDtoNode.get(CONTAINER_CU_NAME) != null) {
            String containerCuName = String.valueOf(transactionDtoNode.get(CONTAINER_CU_NAME));
            ContainerCuInfo containerCuInfo = containerCuNames.get(containerCuName);

            if (containerCuInfo != null) {
                long startTime = (transactionDtoNode.get(GSI_START_TIME) != null) ? Long.parseLong(transactionDtoNode.get(GSI_START_TIME).toString()) : System.currentTimeMillis();
                long endTime = (transactionDtoNode.get(GSI_END_TIME) != null) ? Long.parseLong(transactionDtoNode.get(GSI_END_TIME).toString()) : System.currentTimeMillis();
                long duration = endTime - startTime;

                Set<Long> transactionIds = containerCuInfo.getTransactionIds();

                long totalGsiDuration = containerCuInfo.getTotalDuration();
                if (transactionIds != null && transactionIds.contains(transactionId)) {
                    totalGsiDuration = totalGsiDuration + duration - containerCuInfo.getLastAddedDuration();
                } else {
                    totalGsiDuration = totalGsiDuration + duration;
                    if (transactionIds == null) {
                        transactionIds = new HashSet<>();
                        containerCuInfo.setTransactionIds(transactionIds);
                    }
                    transactionIds.add(transactionId);
                }

                containerCuInfo.setTotalDuration(totalGsiDuration);
                containerCuInfo.setLastAddedDuration(duration);
            }
        }
    }

    private Duration getGracePeriodByWindowSize(final Duration windowSize) {
        int size = (int) windowSize.toHours();

        switch (size) {
            case 1:
                return Duration.ofMinutes(5);
            case 3:
            case 6:
                return Duration.ofMinutes(10);
            case 12:
            case 24:
                return Duration.ofMinutes(15);
            default:
                return Duration.ofMinutes(7);
        }
    }

    private Duration getRetentionPeriodByWindowSize(final Duration windowSize) {
        int size = (int) windowSize.toHours();

        switch (size) {
            case 1:
            case 3:
            case 6:
            case 12:
                return Duration.ofHours(24);
            case 24:
                return Duration.ofHours(48);
            default:
                return Duration.ofDays(7);
        }
    }

    private void gsiCompletionAnalysis(KStream<String, GenericRecord> avroStream) {
        // count of GSIs that are successfully completed
        KTable<String, Long> gsiSuccessCountTable = avroStream
                .mapValues((ValueMapper<GenericRecord, String>) value -> {
                    String gsiName = extractSuccessContainerCuName(value);
                    return gsiName;
                })
                .filter((key, containerCuName) -> containerCuName != null)
                .groupBy((key, containerCuName) -> containerCuName, Grouped.with(STRING_SERDE, STRING_SERDE))
                .count(Materialized.as(GSI_SUCCESS_COUNT_TABLE_NAME));
    }

    private void gsiFailureEventsAnalysis(KStream<String, GenericRecord> avroStream){
        KTable<String, Long> gsiFailedCountTable = avroStream
                .mapValues((ValueMapper<GenericRecord, String>) jsonString -> {
                    String gsiName = extractFailureContainerCuName(jsonString);
                    return gsiName;
                })
                .filter((key, containerCuName) -> containerCuName != null)
                .groupBy((key, containerCuName) -> containerCuName, Grouped.with(STRING_SERDE, STRING_SERDE))
                .count(Materialized.as(GSI_FAILED_COUNT_TABLE_NAME));

    }

    private void gsiExecutionAnalysis(KStream<String, GenericRecord> avroStream) {
        KTable<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> gsiExecutionDurationTable = avroStream
                .flatMap((KeyValueMapper<String, GenericRecord, Iterable<? extends KeyValue<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto>>>) (key, value) -> {
                    GenericRecord transactionDto = extractTransactionDto(value);
                    GenericRecord userContext=extractUserContext(value);

                    if (transactionDto != null && userContext!=null) {
                        String gsiName = transactionDto.get(CONTAINER_CU_NAME).toString();
                        long transactionId = Long.parseLong(transactionDto.get(TRANSACTION_ID).toString());
                        String tenantId = userContext.get(TENANT_ID).toString();
                        long startTime = Long.parseLong(transactionDto.get(GSI_START_TIME).toString());
                        long endTime = System.currentTimeMillis();
                        if (transactionDto.get(GSI_END_TIME) != null) {
                            endTime = Long.parseLong(transactionDto.get(GSI_END_TIME).toString());
                        }
                        double duration = ((double) (endTime - startTime) / 1000);
                        String transactionStatus = transactionDto.get(TRANSACTION_STATUS).toString();
                        String currentCuName = transactionDto.get(TRIGGER_CU_NAME).toString();
                        String emailId = userContext.get(EMAIL_ID).toString();
                        long lastUpdated = System.currentTimeMillis();
//                        long userId=userContext.path(USER_ID).asLong();
//                        long orgUnitId=userContext.path(ORG_UNIT_ID).asLong();
                        return Collections.singletonList(new KeyValue<>(new GsiFinalTransactionKeyDto(gsiName, transactionId, tenantId),
                                new GsiFinalTransactionValueDto(gsiName,transactionId,tenantId,convertEpochTimeToDateTime(startTime),convertEpochTimeToDateTime(endTime),duration,transactionStatus,currentCuName,emailId,lastUpdated)));
                    }
                    return Collections.emptyList();
                })
                .toTable(Materialized.<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto, KeyValueStore<org.apache.kafka.common.utils.Bytes, byte[]>>as(GSI_EXECUTION_DETAILS_TABLE_NAME)
                        .withKeySerde(SerdesFactory.gsiFinalTransactionKeyDtoSerde())
                        .withValueSerde(SerdesFactory.gsiFinalTransactionValueDtoSerde()));

        if(publishToEsFlag){ //push records to kafka topic
            gsiExecutionDurationTable.toStream().to(gsiTableTopic, Produced.with(SerdesFactory.gsiFinalTransactionKeyDtoSerde(), SerdesFactory.gsiFinalTransactionValueDtoSerde()));

        }
    }

    private String extractSuccessContainerCuName(GenericRecord avroRecord) {
        try {
            // Extracting values from the Avro record
            GenericRecord data = (GenericRecord) avroRecord.get(DATA);
            GenericRecord transactionDto = (GenericRecord) data.get(TRANSACTION_DTO);

            if (transactionDto != null && COMPLETED_STATUS.equals(transactionDto.get(TRANSACTION_STATUS).toString())) {
                Object containerCuNameNode = transactionDto.get(CONTAINER_CU_NAME);

                if (containerCuNameNode instanceof CharSequence) {
                    return containerCuNameNode.toString();
                }
            }

        } catch (Exception e) {
            log.error("Error extracting values from Avro record: {}", e.getMessage(), e);
        }

        return null; // Return null if extraction fails
    }

    private String extractFailureContainerCuName(GenericRecord avroRecord) {
        try {
            // Extracting values from the Avro record
            GenericRecord data = (GenericRecord) avroRecord.get(DATA);
            GenericRecord transactionDto = (GenericRecord) data.get(TRANSACTION_DTO);

            if (transactionDto != null && FAILED_STATUS.equals(transactionDto.get(TRANSACTION_STATUS).toString())) {
                Object containerCuNameNode = transactionDto.get(CONTAINER_CU_NAME);

                if (containerCuNameNode instanceof CharSequence) {
                    return containerCuNameNode.toString();
                }
            }

        } catch (Exception e) {
            log.error("Error extracting values from Avro record: {}", e.getMessage(), e);
        }

        return null;
    }

    private GenericRecord extractTransactionDto(GenericRecord avroRecord) {
        GenericRecord data = (GenericRecord) avroRecord.get(DATA);
        GenericRecord transactionDto = (GenericRecord) data.get(TRANSACTION_DTO);
        if(transactionDto!=null) {
            if (transactionDto.get(CONTAINER_CU_NAME) != null
                    && transactionDto.get(TRIGGER_CU_NAME) != null
                    && transactionDto.get(TRANSACTION_STATUS) != null) {
                return transactionDto;
            }
        }
        return null;
    }

    private GenericRecord extractUserContext(GenericRecord avroRecord) {
        return (GenericRecord) avroRecord.get("userContext");
    }

    private static LocalDateTime convertEpochTimeToDateTime(long epochMillis) {
        Instant instant = Instant.ofEpochMilli(epochMillis);
        return LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
    }

    private String getTableName(Duration duration, String type) {
        String baseTableName;
        switch ((int) duration.toHours()) {
            case 1 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_ONE_HOUR;
            case 3 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_THREE_HOUR;
            case 6 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_SIX_HOUR;
            case 12 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWELVE_HOUR;
            case 24 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWENTY_FOUR_HOUR;
            default -> throw new IllegalArgumentException("Unsupported duration: " + duration);
        }

        return type + "_" + baseTableName;
    }

    private UserKeyDto extractUserKeyDto(GenericRecord kafkaMessage) {
        GenericRecord userContext;
        userContext = extractUserContext(kafkaMessage);

        if (userContext != null && userContext.get(EMAIL_ID) != null && userContext.get(USER_ID) != null) {
            return new UserKeyDto(Long.parseLong(userContext.get(USER_ID).toString()),
                userContext.get(EMAIL_ID).toString());
        }

        return null;
    }

    private Long extractTransactionId(GenericRecord kafkaMessage) {
        GenericRecord transactionDto;
        transactionDto = extractTransactionDto(kafkaMessage);

        if (transactionDto != null && transactionDto.get(TRANSACTION_ID) != null) {
            return Long.parseLong(transactionDto.get(TRANSACTION_ID).toString());
        }

        return null;
    }

    private String extractTenantId(GenericRecord kafkaMessage) {
        GenericRecord userContext;
        userContext = extractUserContext(kafkaMessage);

        if (userContext != null && userContext.get(TENANT_ID) != null) {
            return userContext.get(TENANT_ID).toString();
        }

        return null;
    }

    private void cuExecutionAnalysis(KStream<String, GenericRecord> avroStream) {
        KTable<CuTransactionKeyDto, CuTransactionValueDto> cuDataAnalysis= avroStream
                .flatMap((KeyValueMapper<String, GenericRecord, Iterable<? extends KeyValue<CuTransactionKeyDto, CuTransactionValueDto>>>) (key, value) -> {

                    GenericRecord txnData = extractTxnDataDto(value);
                    GenericRecord userContext=extractUserContext(value);

                    if (txnData != null && userContext!=null) {
                        long transactionId = Long.parseLong(txnData.get(TRANSACTION_ID).toString());
                        long cUId = Long.parseLong(txnData.get(REFERENCE_CHANGE_UNIT_ID).toString());
                        String tenantId=userContext.get(TENANT_ID).toString();
                        CuDetails cuDetails = getCuDetails(cUId, tenantId);
                        String cUName = cuDetails.getCuName();
                        long triggerStartTime = Long.parseLong(txnData.get(CU_START_TIME).toString());
                        long triggeredTime = triggerStartTime;
                        if(txnData.get(TRIGGERED_TIME)!=null){
                            triggeredTime= Long.parseLong(txnData.get(TRIGGERED_TIME).toString());
                        }
                        long triggerEndTime = System.currentTimeMillis();
                        if (txnData.get(CU_END_TIME)!=null){
                            triggerEndTime = Long.parseLong(txnData.get(CU_END_TIME).toString());
                        }
                        double duration=((double) (triggerEndTime - triggerStartTime) /1000);
                        String triggerState=txnData.get(TRIGGER_STATE).toString();
                        if(cuDetails.isReserved() && txnData.get(CU_END_TIME) == null && Objects.equals(triggerState,TRIGGERED_STATUS)){
                            triggerState = FAILED_STATUS;
                        }
//                        long userId= Long.parseLong(userContext.get(USER_ID).toString());
                        String emailId=userContext.get(EMAIL_ID).toString();
//                        long orgUnitId= Long.parseLong(userContext.path(ORG_UNIT_ID).toString());
                        long lastUpdated = System.currentTimeMillis();
                        if(triggerState.equals(FAILED_STATUS)) {
                            return Collections.singletonList(new KeyValue<>(new CuTransactionKeyDto(transactionId, cUId, tenantId),
                                    new CuTransactionValueDto(transactionId, cUName, cUId, cuDetails, tenantId, convertEpochTimeToDateTime(triggerStartTime), convertEpochTimeToDateTime(triggeredTime), convertEpochTimeToDateTime(triggerEndTime), duration, triggerState, emailId, lastUpdated)));
                        }
                    }
                    return Collections.emptyList();
                })
                .toTable(Materialized.<CuTransactionKeyDto, CuTransactionValueDto, KeyValueStore<org.apache.kafka.common.utils.Bytes, byte[]>>as(CU_DETAILS_TABLE)
                        .withKeySerde(SerdesFactory.cuTransactionKeyDtoSerde())
                        .withValueSerde(SerdesFactory.cuTransactionValueDtoSerde())
        // Setting retention period to 1 day (86400000 milliseconds)
                        .withRetention(Duration.ofMillis(86400000)));
        if(publishToEsFlag){ //push records to kafka topic
            cuDataAnalysis.toStream().to(cuTableTopic, Produced.with(SerdesFactory.cuTransactionKeyDtoSerde(), SerdesFactory.cuTransactionValueDtoSerde()));
        }
    }

    private  GenericRecord extractTxnDataDto(GenericRecord avroRecord){
        GenericRecord data = (GenericRecord) avroRecord.get(DATA);
        GenericRecord txnDataDto = (GenericRecord) data.get(TXN_DATA_DTO);
        if(txnDataDto!=null){
            GenericRecord txnData = (GenericRecord) txnDataDto.get(TXN_DATA);
            if(txnData.get(REFERENCE_CHANGE_UNIT_ID)!=null && txnData.get(TRIGGER_STATE)!=null){
                return  txnData;
            }
        }
        return null;
    }

    public CuDetails getCuDetails(final long referenceChangeUnitId, final String tenantId) {
        try {
            String URL = nslBetStoreBaseUrl + "cu/id/" + referenceChangeUnitId + "?"+TENANT_ID+"=" + tenantId;
            CuDetails cuDetails = cache.getIfPresent(referenceChangeUnitId);
            if (cuDetails != null) {
                return cuDetails;
            }
            ResponseEntity<String> responseEntity = restTemplate.getForEntity(URL, String.class);
            String responseData = responseEntity.getBody();
            JsonNode rootNode = objectMapper.readTree(responseData);
            JsonNode result = rootNode.path(RESULT);
            String cuName = result.path(NAME).asText();
            String agentType = result.path(AGENTS).get(0).path(AGENT_TYPE).asText();// Assuming there's only one agent
            boolean isReserved=result.path(IS_RESERVED).asBoolean();
            String cuCategory=result.path(RESERVED_CU_TYPE).asText();
            String methodType=null;
            if(result.path(CU_SYSTEM_PROPERTIES).get(EXT_SOLNS_TYPE)!=null){
                if(Objects.equals(result.path(CU_SYSTEM_PROPERTIES).get(EXT_SOLNS_TYPE).asText(), "Adapter"))
                {
                    cuCategory=result.path(CU_SYSTEM_PROPERTIES).get(EXT_SOLNS_TYPE).asText();
                }
                if(result.path(CU_SYSTEM_PROPERTIES).get(ADAPTER)!=null){
                    methodType=result.path(CU_SYSTEM_PROPERTIES).get(ADAPTER).asText();
                }
            }
            cuDetails = new CuDetails(cuName, agentType,isReserved,cuCategory,methodType);
            cache.put(referenceChangeUnitId, cuDetails);
            return cuDetails;
        } catch (Exception e) {
            log.warn("Error in resolving cuId to cuName for id: {} in tenant: {}, {}", referenceChangeUnitId, tenantId, e.getMessage());
            return new CuDetails("CORRUPTED CU", "UNKNOWN AGENT",false,"UNKNOWN CU","UNKNOWN METHOD");
        }
    }
    public BookDetails getBookDetails(final long gsiId, final String tenantId) {
        try {
            String URL = nslBetStoreBaseUrl + "book/getBookByGsiId/" + gsiId + "?"+TENANT_ID+"=" + tenantId;
            BookDetails bookDetails = cache1.getIfPresent(gsiId);
            if (bookDetails != null) {
                return bookDetails;
            }
            ResponseEntity<String> responseEntity = restTemplate.getForEntity(URL, String.class);
            String responseData = responseEntity.getBody();
            JsonNode rootNode = objectMapper.readTree(responseData);
            JsonNode result = rootNode.path(RESULT);
            long bookId = result.path(BOOK_ID).asLong();
            String bookName=result.path(BOOK_NAME).asText();

            bookDetails = new BookDetails(bookId,bookName);
            cache1.put(gsiId, bookDetails);
            return bookDetails;
        } catch (Exception e) {
            log.warn("Error in getting bookId from gsiId for id: {} in tenant: {}, {}", gsiId, tenantId, e.getMessage());
            return new BookDetails(0,null);
        }
    }


    private void gsiTrendsAnalysis(KStream<String, GenericRecord> avroStream){

        KStream<GsiTrendsKey, GsiTrendsValueInfo> unifiedStream1 = getUnifiedStream1(avroStream);
        KStream<GsiTrendsKey, GsiTrendsValueInfo> unifiedStream2 = getUnifiedStream2(avroStream);

        KStream<GsiTrendsKey, GsiTrendsValueInfo> mergedStream = unifiedStream1.merge(unifiedStream2);

        KTable<GsiTrendsKey, GsiTrendsValueInfo> gsiTrends = mergedStream
                .groupByKey(Grouped.with(SerdesFactory.GsiTrendsKeySerde(),SerdesFactory.GsiTrendsValueInfoSerde()))
                .aggregate(
                        GsiTrendsValueInfo::new,
                        (key, currGsiTrendsValue, aggGsiTrendsValue) -> getAggregatedTrendsValue(currGsiTrendsValue,
                                aggGsiTrendsValue),
                        Materialized.<GsiTrendsKey, GsiTrendsValueInfo, KeyValueStore<org.apache.kafka.common.utils.Bytes, byte[]>>as(GSI_TRENDS_ANALYSIS_TABLE_NAME)
                                .withKeySerde(SerdesFactory.GsiTrendsKeySerde())
                                .withValueSerde(SerdesFactory.GsiTrendsValueInfoSerde())
                );
        //gsiTrends.toStream().print(Printed.toSysOut());

    }

    private GsiTrendsValueInfo getAggregatedTrendsValue(GsiTrendsValueInfo currGsiTrendsValue,
                                                        GsiTrendsValueInfo aggGsiTrendsValue){

        Long gsiId = currGsiTrendsValue.getGsiId();
        String tenantId = currGsiTrendsValue.getTenantId();
        String containerName = currGsiTrendsValue.getContainerName();
        Long containerId = currGsiTrendsValue.getContainerId();
        CuDetails containerDetails = currGsiTrendsValue.getContainerDetails();
        List<GeneralEntityDto> listOfEntity = currGsiTrendsValue.getListOfGeneralEntities();
        LinkedHashSet<Long> transactionIds = aggGsiTrendsValue.getTransactionIds();
        LinkedHashSet<Long> successTransactionIds = aggGsiTrendsValue.getSuccessTransactionIds();
        LinkedHashMap<Long, Long> failureTransactionIds = aggGsiTrendsValue.getFailureTransactionIds();
        Double minimumTime = aggGsiTrendsValue.getMinimumTime();
        Double maximumTime = aggGsiTrendsValue.getMaximumTime();
        Long lastTransId = aggGsiTrendsValue.getTransId();
        Double totalDuration = aggGsiTrendsValue.getTotalDuration();
        Double lastDuration = aggGsiTrendsValue.getLastDuration();
        Long latestTransactionId = currGsiTrendsValue.getTransId();
        LinkedHashSet<GsiTrendsKey> keys = aggGsiTrendsValue.getRowKeys();

        if(!transactionIds.contains(latestTransactionId)){
            transactionIds.add(latestTransactionId);
            totalDuration = totalDuration + currGsiTrendsValue.getTotalDuration();
            maximumTime = Math.max(maximumTime,lastDuration);
            if(lastTransId!=0){
                minimumTime = Math.min(minimumTime,lastDuration);
            }
        }else{
            totalDuration = totalDuration - lastDuration + currGsiTrendsValue.getTotalDuration();
        }

        if(currGsiTrendsValue.getTotalSuccessCount() == 1){
            successTransactionIds.add(latestTransactionId);
            failureTransactionIds.remove(latestTransactionId);
        }
        if(currGsiTrendsValue.getTotalFailureCount() == 1){
            failureTransactionIds.put(latestTransactionId,currGsiTrendsValue.getFailureTransactionIds().get(latestTransactionId));
        }
        Long totalTransactionCount = (long) transactionIds.size();
        Long successCount = (long) successTransactionIds.size();
        Long failureCount = (long) failureTransactionIds.size();
        double avgDuration = totalDuration/totalTransactionCount;
        avgDuration = getRoundedValue(avgDuration);
        minimumTime = getRoundedValue(minimumTime);
        lastTransId = currGsiTrendsValue.getTransId();
        lastDuration = getRoundedValue(currGsiTrendsValue.getLastDuration());
        keys.addAll(currGsiTrendsValue.getRowKeys());

        return new GsiTrendsValueInfo(gsiId,tenantId,containerName,containerId, containerDetails,listOfEntity, transactionIds,
                successTransactionIds, failureTransactionIds,totalTransactionCount,successCount, failureCount,
                minimumTime,maximumTime,avgDuration,lastTransId,totalDuration,lastDuration,new ArrayList<>(),
                keys);
    }

    private KStream<GsiTrendsKey, GsiTrendsValueInfo> getUnifiedStream1(KStream<String, GenericRecord> avroStream) {
        return avroStream.flatMap((key, value) -> {

            List<KeyValue<GsiTrendsKey, GsiTrendsValueInfo>> results = new ArrayList<>();

            GenericRecord txnData = extractTxnDataDto(value);
            GenericRecord transactionDto = extractTransactionDto(value);
            GenericRecord userContext = extractUserContext(value);

            List<KeyValue<GsiTrendsKey, GsiTrendsValueInfo>> keyValue = new ArrayList<>();
            if (transactionDto != null && userContext != null) {
                keyValue = createKeyValue(transactionDto, userContext);

            } else if (txnData != null && userContext != null) {
                keyValue = createKeyValue(txnData, userContext);
            }
            for(KeyValue<GsiTrendsKey, GsiTrendsValueInfo> kv:keyValue){
                if (isValidKeyValue(kv.key,kv.value)) {
                    results.add(kv);
                }
            }

            return results;
        });
    }

    private List<KeyValue<GsiTrendsKey, GsiTrendsValueInfo>> createKeyValue(GenericRecord avroMessage,
                                                                     GenericRecord userData){

        List<KeyValue<GsiTrendsKey, GsiTrendsValueInfo>> result = new ArrayList<>();

        String tenantId = extractGenericProperty(userData,TENANT_ID, String.class);
        Long transactionId = extractGenericProperty(avroMessage,TRANSACTION_ID,Long.class);
        Long containerId = avroMessage.getSchema().getField(CONTAINER_CU_ID)==null ?
                extractGenericProperty(avroMessage,REFERENCE_CHANGE_UNIT_ID,Long.class) :
                extractGenericProperty(avroMessage,CONTAINER_CU_ID,Long.class);
        String containerName = avroMessage.getSchema().getField(CONTAINER_CU_NAME)==null  ?
                getCuDetails(containerId,tenantId).getCuName() :
                extractGenericProperty(avroMessage,CONTAINER_CU_NAME,String.class);
        Long referenceChangeUnitId = avroMessage.getSchema().getField(REFERENCE_CHANGE_UNIT_ID)==null ?
                null : extractGenericProperty(avroMessage,REFERENCE_CHANGE_UNIT_ID,Long.class);
        List<GeneralEntityDto> listOfEntity =new ArrayList<>();
        CuDetails containerDetails = null;
        if(referenceChangeUnitId!=null){
            containerDetails = getCuDetails(referenceChangeUnitId,tenantId);
            listOfEntity = fetchAllEntity(avroMessage);
        }
        Long gsiId = avroMessage.getSchema().getField(GSI_ID)==null ? containerId :
            extractGenericProperty(avroMessage,GSI_ID,Long.class);
        Long totalTransactionCount = 0L;
        String transactionStatus = avroMessage.getSchema().getField(TRANSACTION_STATUS)==null ?
            extractGenericProperty(avroMessage,TRIGGER_STATE,String.class) :
            extractGenericProperty(avroMessage,TRANSACTION_STATUS,String.class);
        Long successCount = transactionStatus.equals(COMPLETED_STATUS)  ? 1L : 0L;
        Long failureCount = transactionStatus.equals(FAILED_STATUS)  ? 1L : 0L;
        Long startTime = avroMessage.getSchema().getField(GSI_START_TIME)!=null ?
            extractGenericProperty(avroMessage,GSI_START_TIME,Long.class) :
            extractGenericProperty(avroMessage,CU_START_TIME,Long.class);
        Long endTime = avroMessage.getSchema().getField(GSI_END_TIME)!=null ?
            extractGenericProperty(avroMessage,GSI_END_TIME, Long.class) :
            extractGenericProperty(avroMessage,CU_END_TIME, Long.class);

        if(containerDetails != null && containerDetails.isReserved() && endTime == null &&
                Objects.equals(transactionStatus, TRIGGERED_STATUS)){
            failureCount = 1L;
        }

        if(endTime == null){
            endTime = System.currentTimeMillis();
        }

        //Adding timestamp to failure transIds
        LinkedHashMap<Long, Long> failureTransactionIds = new LinkedHashMap<>();
        if(failureCount == 1L){
            failureTransactionIds.put(transactionId,endTime);
        }

        Double duration = (endTime-startTime)/1000.0;
        Double minimumTime = Double.MAX_VALUE;
        Double maximumTime = Double.MIN_VALUE;
        Double averageTime = 0D;

        String tranType = avroMessage.getSchema().getField(TRAN_TYPE)!=null?
                extractGenericProperty(avroMessage,TRAN_TYPE,String.class) : null;
        Long baseContextualGsiId = getBaseContextualGsiId(avroMessage);
        Long executionStateContainerId = getExecutionStateContainerId(avroMessage);

        //creating keyValue for logic/embedded/nested gsi's
        if(tranType!=null && !Objects.equals(baseContextualGsiId, containerId)){
            containerDetails = new CuDetails();
            result.add(KeyValue.pair(new GsiTrendsKey(tenantId, containerId,baseContextualGsiId),new GsiTrendsValueInfo(baseContextualGsiId,tenantId,containerName,
                    containerId, containerDetails, listOfEntity, new LinkedHashSet<>(), new LinkedHashSet<>(), failureTransactionIds,
                    totalTransactionCount, successCount, failureCount, minimumTime, maximumTime, averageTime, transactionId,
                    duration, duration,new ArrayList<>(),new LinkedHashSet<>())));
        }
        else if(executionStateContainerId!=null && !Objects.equals(executionStateContainerId, containerId)){
            containerDetails = new CuDetails();
            result.add(KeyValue.pair(new GsiTrendsKey(tenantId, containerId,executionStateContainerId),new GsiTrendsValueInfo(executionStateContainerId,tenantId,containerName,
                    containerId, containerDetails, listOfEntity, new LinkedHashSet<>(), new LinkedHashSet<>(), failureTransactionIds,
                    totalTransactionCount, successCount, failureCount, minimumTime, maximumTime, averageTime, transactionId,
                    duration, duration,new ArrayList<>(),new LinkedHashSet<>())));
        }

        result.add(KeyValue.pair(new GsiTrendsKey(tenantId, containerId,gsiId),new GsiTrendsValueInfo(gsiId,tenantId,containerName,
                containerId, containerDetails, listOfEntity, new LinkedHashSet<>(), new LinkedHashSet<>(), failureTransactionIds,
                totalTransactionCount, successCount, failureCount, minimumTime, maximumTime, averageTime, transactionId,
                duration, duration,new ArrayList<>(),new LinkedHashSet<>())));

        return result;
    }

    private KStream<GsiTrendsKey, GsiTrendsValueInfo> getUnifiedStream2(KStream<String, GenericRecord> avroStream) {
        return avroStream.flatMap((key, value) -> {
            List<KeyValue<GsiTrendsKey, GsiTrendsValueInfo>> results = new ArrayList<>();

            GenericRecord txnData = extractTxnDataDto(value);
            GenericRecord transactionDto = extractTransactionDto(value);
            GenericRecord userContext = extractUserContext(value);

            List<KeyValue<GsiTrendsKey, GsiTrendsValueInfo>> keys = new ArrayList<>();

            if (transactionDto != null && userContext != null) {
                keys = createKeys(transactionDto,userContext);
            } else if (txnData != null && userContext != null) {
                keys = createKeys(txnData,userContext);
            }

            for(KeyValue<GsiTrendsKey, GsiTrendsValueInfo> kv : keys){
                if (isValidKeyValue(kv.key,kv.value)) {
                    results.add(kv);
                }
            }
            return results;
        });
    }

    private List<KeyValue<GsiTrendsKey, GsiTrendsValueInfo>> createKeys(GenericRecord avroMessage,
        GenericRecord userData) {

        List<KeyValue<GsiTrendsKey, GsiTrendsValueInfo>> result = new ArrayList<>();

        String tenantId = extractGenericProperty(userData,TENANT_ID, String.class);
        Long gsiId = avroMessage.getSchema().getField(GSI_ID)==null ? extractGenericProperty(avroMessage,CONTAINER_CU_ID,Long.class) :
                extractGenericProperty(avroMessage,GSI_ID,Long.class);
        String containerName = avroMessage.getSchema().getField(CONTAINER_CU_NAME)==null  ?
                null :
                extractGenericProperty(avroMessage,CONTAINER_CU_NAME,String.class);
        Long referenceChangeUnitId = avroMessage.getSchema().getField(REFERENCE_CHANGE_UNIT_ID)==null ?
                null : extractGenericProperty(avroMessage,REFERENCE_CHANGE_UNIT_ID,Long.class);
        GsiTrendsValueInfo gsiTrendsValueInfo =  new GsiTrendsValueInfo();

        String tranType = avroMessage.getSchema().getField(TRAN_TYPE)!=null?
                extractGenericProperty(avroMessage,TRAN_TYPE,String.class) : null;
        Long baseContextualGsiId = getBaseContextualGsiId(avroMessage);
        Long executionStateContainerId = getExecutionStateContainerId(avroMessage);

        if(referenceChangeUnitId==null){

            //creating cuKeys for logic/embedded/nested gsi's
            GsiTrendsValueInfo logicGsiTrendsValueInfo =  new GsiTrendsValueInfo();
            if(tranType!=null && !Objects.equals(baseContextualGsiId, gsiId)){

                logicGsiTrendsValueInfo.getRowKeys().add(new GsiTrendsKey(tenantId, gsiId, baseContextualGsiId));
                result.add(KeyValue.pair(new GsiTrendsKey(CU_ROW_KEYS, baseContextualGsiId, baseContextualGsiId), logicGsiTrendsValueInfo));
            }
            else if(executionStateContainerId!=null && !Objects.equals(executionStateContainerId, gsiId)) {

                logicGsiTrendsValueInfo.getRowKeys().add(new GsiTrendsKey(tenantId, gsiId, executionStateContainerId));
                result.add(KeyValue.pair(new GsiTrendsKey(CU_ROW_KEYS, executionStateContainerId, executionStateContainerId), logicGsiTrendsValueInfo));
            }

            //normal gsi keys
            gsiTrendsValueInfo.getRowKeys().add(new GsiTrendsKey(tenantId,gsiId,gsiId));
            result.add(KeyValue.pair(new GsiTrendsKey(containerName+KEYS,
                    1L,1L),gsiTrendsValueInfo));

            //creating keys for unique gsi's in the table
            GsiTrendsValueInfo gsiNameInfo = new GsiTrendsValueInfo();
            gsiNameInfo.getRowKeys().add(new GsiTrendsKey(containerName,1L,1L));
            result.add(KeyValue.pair(new GsiTrendsKey(GSI_UNIQUE_ENTRIES,
                    1L,1L),gsiNameInfo));

        }else {

            //creating cuKeys for normal gsi's
            gsiTrendsValueInfo.getRowKeys().add(new GsiTrendsKey(tenantId, referenceChangeUnitId, gsiId));
            result.add(KeyValue.pair(new GsiTrendsKey(CU_ROW_KEYS, gsiId, gsiId), gsiTrendsValueInfo));
        }

        return result;
    }

    private List<GeneralEntityDto> fetchAllEntity(GenericRecord txnData){

        Map<String, GeneralEntityDto> mapOfEntity = new HashMap<>();

        GenericArray<GenericRecord> txnCULayer = extractGenericProperty(txnData,TXN_CU_LAYER,GenericArray.class);

        if (txnCULayer != null){
            for(GenericRecord layer : txnCULayer){

                GenericArray<GenericRecord> txnSlotItems = extractGenericProperty(layer,TXN_SLOT_ITEMS,GenericArray.class);

                if(txnSlotItems != null){
                    for(GenericRecord entity : txnSlotItems){
                        GenericRecord item = (GenericRecord)entity.get(ITEM);
                        if(item==null){continue;}
                        GenericRecord Data = extractGenericProperty(item,ITEM_DATA,GenericRecord.class);
                        if(Data!=null){
                            Long geId = extractGenericProperty(Data,GENERAL_ENTITY_ID,Long.class);
                            String name = extractGenericProperty(Data,NAME,String.class);
                            Long geMasterId = extractGenericProperty(Data,GENERAL_ENTITY_MASTER_ID,Long.class);
                            List<AttributeDto> listOfAttribute = fetchAllAttributes(Data);
                            GeneralEntityDto generalEntityDto = new GeneralEntityDto(geId,name,geMasterId,listOfAttribute);
                            mapOfEntity.put(name,generalEntityDto);
                        }
                    }
                }
            }
        }

        return new ArrayList<>(mapOfEntity.values());
    }

    private List<AttributeDto> fetchAllAttributes(GenericRecord Data){

        List<AttributeDto> attributeDtoList = new ArrayList<>();
        GenericArray<GenericRecord> transEntityRecords = extractGenericProperty(Data,TRANS_ENTITY_RECORDS,GenericArray.class);

        if(transEntityRecords!=null){
            for(GenericRecord records : transEntityRecords){

                GenericArray<GenericRecord> txnNslAttribute = extractGenericProperty(records,TXN_NSL_ATTRIBUTE,GenericArray.class);

                if(txnNslAttribute!=null){
                    for(GenericRecord attribute : txnNslAttribute){

                        String name = extractGenericProperty(attribute,NAME,String.class);
                        Long attributeId = extractGenericProperty(attribute,NSL_ATTRIBUTE_ID,Long.class);
                        attributeDtoList.add(new AttributeDto(name,attributeId));
                    }
                }
            }
        }

        return attributeDtoList;
    }

    private Long getExecutionStateContainerId(GenericRecord avroMessage){

        if(avroMessage.getSchema().getField(EXECUTION_STATE)==null){
            return null;
        }

        GenericArray<GenericRecord> executionArray = extractGenericProperty(avroMessage,EXECUTION_STATE,GenericArray.class);

        if(executionArray!=null){
            for(GenericRecord record : executionArray){
                return extractGenericProperty(record,CONTAINER_CU_ID,Long.class);
            }
        }
        return null;
    }

    private Long getBaseContextualGsiId(GenericRecord avroMessage){

        if(avroMessage.getSchema().getField("baseContextualId")==null){
            return null;
        }

        String contextualId = extractGenericProperty(avroMessage,"baseContextualId",String.class);
        if(contextualId==null){
            return null;
        }

        Pattern pattern = Pattern.compile("GS(\\d+)");
        Matcher matcher = pattern.matcher(contextualId);
        if (matcher.find()) {
            return Long.parseLong(matcher.group(1));
        } else {
            return null;
        }
    }

    private <T> T extractGenericProperty(GenericRecord Data, String property, Class<T> type){

        Object value = Data.get(property);
        if(value == null){
            return null;
        }
        else if(type.equals(String.class)){
            return type.cast(value.toString());
        }
        else if(type.equals(Long.class)){
            return type.cast(Long.valueOf(value.toString()));
        }
        else if(type.equals(GenericArray.class)){
            return  type.cast(value);
        }
        else if(type.equals(GenericRecord.class)){
            return type.cast(value);
        }
        return null;
    }

    private boolean isValidKeyValue(GsiTrendsKey key,GsiTrendsValueInfo value) {
        return key != null && value != null;
    }

    private double getRoundedValue(Double value){
        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(2,RoundingMode.HALF_UP);
        return bd.doubleValue();
    }

}
