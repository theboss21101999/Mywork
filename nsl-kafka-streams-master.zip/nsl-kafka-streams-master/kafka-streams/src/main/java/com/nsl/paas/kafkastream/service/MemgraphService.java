package com.nsl.paas.kafkastream.service;

import com.nsl.paas.kafkastream.dto.NodeDto;
import com.nsl.paas.kafkastream.dto.PathDto;
import java.util.List;

public interface MemgraphService {

    List<PathDto> getDependencyGraphByBetId(final Long betId, final String betType);
    List<NodeDto> getListOfNodes(final Long betId, final String methodName);

}
