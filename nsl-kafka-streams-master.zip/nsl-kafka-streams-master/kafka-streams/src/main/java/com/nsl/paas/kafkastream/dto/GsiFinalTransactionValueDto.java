package com.nsl.paas.kafkastream.dto;

import java.time.LocalDateTime;

public record GsiFinalTransactionValueDto(String gsiName,
                                          long transactionId,
                                          String tenantId,
                                          LocalDateTime startTime,
                                          LocalDateTime endTime,
                                          double duration,
                                          String transactionStatus,
                                          String currentCuName,
                                          String emailId,
                                          long lastUpdated)
{

}