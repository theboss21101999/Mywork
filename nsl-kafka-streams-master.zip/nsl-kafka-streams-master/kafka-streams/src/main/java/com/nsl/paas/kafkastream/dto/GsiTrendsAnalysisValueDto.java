package com.nsl.paas.kafkastream.dto;

import java.util.List;

public record GsiTrendsAnalysisValueDto(Long gsiId,
                                        Long referenceChangeUnitId,
                                        String Name,
                                        String containerType,
                                        Long startTime,
                                        Long endTime,
                                        String transactionStatus,
                                        Long userId,
                                        String emailId,
                                        List<GeneralEntityDto> listOfEntity)
                                        {

}
