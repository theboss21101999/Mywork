package com.nsl.paas.kafkastream.utils;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class CsvUtils {

    public static void writeGsiExecutionDataToCsv(List<Map<String, String>> gsiExecutionDataList, String csvFilePath) {
        try (FileWriter writer = new FileWriter(csvFilePath)) {
            // Write CSV header dynamically based on keys
            if (!gsiExecutionDataList.isEmpty()) {
                Map<String, String> firstRow = gsiExecutionDataList.get(0);
                String csvHeader = String.join(",", firstRow.keySet()) + "\n";
                writer.append(csvHeader);
            }

            // Write data rows
            for (Map<String, String> rowData : gsiExecutionDataList) {
                writer.append(String.join(",", rowData.values()));
                writer.append("\n");
            }

            System.out.println("CSV written successfully to " + csvFilePath);
        } catch (IOException e) {
            System.err.println("Error writing CSV: " + e.getMessage());
        }
    }
}
