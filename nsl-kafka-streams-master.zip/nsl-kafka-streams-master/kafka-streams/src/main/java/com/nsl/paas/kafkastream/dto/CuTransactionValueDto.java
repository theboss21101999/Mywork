package com.nsl.paas.kafkastream.dto;

import com.nsl.paas.kafkastream.model.CuDetails;

import java.time.LocalDateTime;

public record CuTransactionValueDto(long transactionId,
                                    String cUName,
                                    long cUId,
                                    CuDetails cuDetails,
                                    String tenantId,
                                    LocalDateTime triggerStartTime,
                                    LocalDateTime triggeredTime,
                                    LocalDateTime triggerEndTime,
                                    double duration,
                                    String triggerState,
                                    String emailId,
                                    long lastUpdated) {
}
