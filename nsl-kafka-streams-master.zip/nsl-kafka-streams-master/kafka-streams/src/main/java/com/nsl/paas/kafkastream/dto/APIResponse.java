package com.nsl.paas.kafkastream.dto;

public record APIResponse(String message,
                          Object result,
                          Integer status) {

}