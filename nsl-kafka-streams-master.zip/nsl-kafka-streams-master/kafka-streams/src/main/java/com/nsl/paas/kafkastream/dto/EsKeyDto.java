package com.nsl.paas.kafkastream.dto;

public record EsKeyDto(long lastUpdated) {
}
