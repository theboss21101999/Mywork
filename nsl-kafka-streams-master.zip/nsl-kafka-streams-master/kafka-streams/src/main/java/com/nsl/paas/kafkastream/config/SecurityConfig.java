package com.nsl.paas.kafkastream.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Value(value = "${app.username}")
    private String name;

    @Value(value = "${app.password}")
    private String pwd;

    @Value(value = "${app.security.enabled:false}")
    private boolean securityEnabled;

    @Bean
    public InMemoryUserDetailsManager inMemoryUserDetailsManager(){
        UserDetails admin = User.builder().username(name).password(encoder().encode(pwd)).build();

        return new InMemoryUserDetailsManager(admin);
    }

    @Bean
    public PasswordEncoder encoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        if (securityEnabled) {
            http.httpBasic(Customizer.withDefaults())
                .authorizeHttpRequests(authorize ->
                    authorize
                        .requestMatchers("/login", "/redoc", "/v3/api-docs/**", "/swagger-ui/index.html", "/swagger-ui/**","/actuator/**").permitAll()
                        .requestMatchers("/resources/**, /static/**").permitAll()
                        .requestMatchers("/style.css").permitAll()
                        .requestMatchers("/images/**").permitAll()
                        .anyRequest()
                        .authenticated()
                )
                .csrf(AbstractHttpConfigurer::disable)
                .formLogin(form ->
                    form
                        .loginPage("/login")
                        .loginProcessingUrl("/autUser")
                        .defaultSuccessUrl("/home", true)
                        .permitAll()
                )
                .logout(logout ->
                    logout
                        .logoutUrl("/logout")
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                );

            return http.build();
        } else {
            http.httpBasic(Customizer.withDefaults())
                .authorizeHttpRequests(authorize ->
                    authorize
                        .requestMatchers("/**").permitAll()
                        .anyRequest()
                        .authenticated()
                );

            return http.build();
        }
    }
}
