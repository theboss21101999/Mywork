package com.nsl.paas.kafkastream.model;

import java.util.Map;

public interface ActivityInfo {
    long getTotalTransactions();
    long getTotalIncompleteTransactions();
    long getAvgDuration();
    long getTotalDuration();
    String getReadableTotalDuration();
    long getTotalCompletedTransactions();
    long getTotalFailedTransactions();
    Map<String, ContainerCuInfo> getContainerCuNames();
    String getLastRunContainerCuName();
}