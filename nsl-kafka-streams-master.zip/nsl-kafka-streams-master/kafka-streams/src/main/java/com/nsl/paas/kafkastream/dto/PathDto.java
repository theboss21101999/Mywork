package com.nsl.paas.kafkastream.dto;

import java.util.List;
import java.util.Map;

public record PathDto(NodeDto pathStartNode, NodeDto pathEndNode, int pathLength, Map<Long ,NodeDto> nodes,
                      List<RelationshipDto> relationships) {
}