package com.nsl.paas.kafkastream.model;

import com.nsl.paas.kafkastream.dto.UserKeyDto;
import java.util.Map;
import java.util.Set;

public class TenantActivityInfo implements ActivityInfo {

    private String tenantId;
    private Set<UserKeyDto> users;
    private Map<String, ContainerCuInfo> containerCuNames;
    private long avgDuration;
    private long totalDuration;
    private String readableTotalDuration;
    private long totalTransactions;
    private long totalFailedTransactions;
    private long totalCompletedTransactions;
    private long totalIncompleteTransactions;
    private String lastRunContainerCuName;

    // Giving default constructor so that jackson can perform serdes.
    public TenantActivityInfo() {
    }

    private TenantActivityInfo(Builder builder) {
        this.tenantId = builder.tenantId;
        this.users = builder.users;
        this.containerCuNames = builder.containerCuNames;
        this.avgDuration = builder.avgDuration;
        this.totalDuration = builder.totalDuration;
        this.readableTotalDuration = builder.readableTotalDuration;
        this.totalTransactions = builder.totalTransactions;
        this.totalFailedTransactions = builder.totalFailedTransactions;
        this.totalCompletedTransactions = builder.totalCompletedTransactions;
        this.totalIncompleteTransactions = builder.totalIncompleteTransactions;
        this.lastRunContainerCuName = builder.lastRunContainerCuName;
    }

    public String getTenantId() {
        return tenantId;
    }

    public Set<UserKeyDto> getUsers() {
        return users;
    }

    public Map<String, ContainerCuInfo> getContainerCuNames() {
        return containerCuNames;
    }

    public long getAvgDuration() {
        return avgDuration;
    }

    public long getTotalDuration() {
        return totalDuration;
    }

    public String getReadableTotalDuration() {
        return readableTotalDuration;
    }

    public long getTotalTransactions() {
        return totalTransactions;
    }

    public long getTotalFailedTransactions() {
        return totalFailedTransactions;
    }

    public long getTotalCompletedTransactions() {
        return totalCompletedTransactions;
    }

    public long getTotalIncompleteTransactions() {
        return totalIncompleteTransactions;
    }

    public String getLastRunContainerCuName() {
        return lastRunContainerCuName;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {

        private String tenantId;
        private Set<UserKeyDto> users;
        private Map<String, ContainerCuInfo> containerCuNames;
        private long avgDuration;
        private long totalDuration;
        private String readableTotalDuration;
        private long totalTransactions;
        private long totalFailedTransactions;
        private long totalCompletedTransactions;
        private long totalIncompleteTransactions;
        private String lastRunContainerCuName;

        public Builder withTenantId(String tenantId) {
            this.tenantId = tenantId;
            return this;
        }

        public Builder withUsers(Set<UserKeyDto> users) {
            this.users = users;
            return this;
        }

        public Builder withLastRunContainerCuName(String name) {
            this.lastRunContainerCuName = name;
            return this;
        }

        public Builder withContainerCuNames(Map<String, ContainerCuInfo> containerCuNames) {
            this.containerCuNames = containerCuNames;
            return this;
        }

        public Builder withAvgDuration(long avgDuration) {
            this.avgDuration = avgDuration;
            return this;
        }

        public Builder withTotalDuration(long totalDuration) {
            this.totalDuration = totalDuration;
            return this;
        }

        public Builder withReadableTotalDuration(String readableTotalDuration) {
            this.readableTotalDuration = readableTotalDuration;
            return this;
        }

        public Builder withTotalTransactions(long totalTransactions) {
            this.totalTransactions = totalTransactions;
            return this;
        }

        public Builder withTotalFailedTransactions(long totalFailedTransactions) {
            this.totalFailedTransactions = totalFailedTransactions;
            return this;
        }

        public Builder withTotalCompletedTransactions(long totalCompletedTransactions) {
            this.totalCompletedTransactions = totalCompletedTransactions;
            return this;
        }

        public Builder withTotalIncompleteTransactions(long totalIncompleteTransactions) {
            this.totalIncompleteTransactions = totalIncompleteTransactions;
            return this;
        }

        public TenantActivityInfo build() {
            return new TenantActivityInfo(this);
        }
    }

    @Override
    public String toString() {
        return "TenantActivityInfo{" +
            "tenantId='" + tenantId + '\'' +
            ", users=" + users +
            ", containerCuNames=" + containerCuNames +
            ", avgDuration=" + avgDuration +
            ", totalDuration=" + totalDuration +
            ", readableTotalDuration='" + readableTotalDuration + '\'' +
            ", totalTransactions=" + totalTransactions +
            ", totalFailedTransactions=" + totalFailedTransactions +
            ", totalCompletedTransactions=" + totalCompletedTransactions +
            ", totalIncompleteTransactions=" + totalIncompleteTransactions +
            ", lastRunContainerCuName='" + lastRunContainerCuName + '\'' +
            '}';
    }
}