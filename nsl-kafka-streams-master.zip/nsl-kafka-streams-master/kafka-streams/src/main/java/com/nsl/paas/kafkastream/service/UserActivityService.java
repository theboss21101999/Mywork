package com.nsl.paas.kafkastream.service;

import com.nsl.paas.kafkastream.dto.UserKeyDto;
import com.nsl.paas.kafkastream.model.UserActivityInfo;
import java.util.List;
import java.util.Map;

public interface UserActivityService {

    Map<UserKeyDto, UserActivityInfo> getUserActivityInfoByTimeWindow(final int page, final int pageSize,
                                final String sortBy, final String sortOrder, final int windowSizeInHours);

    UserActivityInfo getActivityByUserIdAndTimeWindow(final long userId, final String emailId,
                                        final int windowSizeInHours, final String controller);

    List<UserActivityInfo> getUserActivityListByTimeWindow(final int windowSizeInHours);

    Long getActiveUserCountByTimeWindow(final int windowSize);

}
