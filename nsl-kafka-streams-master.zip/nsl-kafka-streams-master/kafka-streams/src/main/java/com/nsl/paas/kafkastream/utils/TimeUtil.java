package com.nsl.paas.kafkastream.utils;

import java.util.concurrent.TimeUnit;

public class TimeUtil {

    /**
     * Convert number of milliseconds into a readable time string
     * Example readable time String
     * - 2 days 3 hours 1 minute 1 second
     * - 1 day 1 hour 4 minutes 5 seconds
     * - 10 hours 45 minutes 50 seconds
     * @param numberOfMilliseconds number of milliseconds
     * @return readable time string
     */
    public static String getReadableTimeFromMilliseconds(long numberOfMilliseconds) {

        if(numberOfMilliseconds < 1000) {
            return "1 second";
        }

        long numberOfSeconds = numberOfMilliseconds / 1000;

        long numberOfDays = TimeUnit.SECONDS.toDays(numberOfSeconds);
        numberOfSeconds -= TimeUnit.DAYS.toSeconds(numberOfDays);

        long numberOfHours = TimeUnit.SECONDS.toHours(numberOfSeconds);
        numberOfSeconds -= TimeUnit.HOURS.toSeconds(numberOfHours);

        long numberOfMinutes = TimeUnit.SECONDS.toMinutes(numberOfSeconds);
        numberOfSeconds -= TimeUnit.MINUTES.toSeconds(numberOfMinutes);

        StringBuilder stringBuilder = new StringBuilder();

        if(numberOfDays > 0) {
            if(numberOfDays == 1)
                stringBuilder.append(String.format("%d day ", numberOfDays));
            else
                stringBuilder.append(String.format("%d days ", numberOfDays));
        }

        if(numberOfHours > 0) {
            if(numberOfHours == 1)
                stringBuilder.append(String.format("%d hour ", numberOfHours));
            else
                stringBuilder.append(String.format("%d hours ", numberOfHours));
        }

        if(numberOfMinutes > 0) {
            if(numberOfMinutes == 1)
                stringBuilder.append(String.format("%d minute ", numberOfMinutes));
            else
                stringBuilder.append(String.format("%d minutes ", numberOfMinutes));
        }

        if(numberOfSeconds > 0) {
            if(numberOfSeconds == 1)
                stringBuilder.append(String.format("%d second ", numberOfSeconds));
            else
                stringBuilder.append(String.format("%d seconds ", numberOfSeconds));
        }

        return stringBuilder.toString();
    }
}
