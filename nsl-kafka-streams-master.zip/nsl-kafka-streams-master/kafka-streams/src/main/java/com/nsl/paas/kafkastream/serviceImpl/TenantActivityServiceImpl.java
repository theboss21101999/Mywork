package com.nsl.paas.kafkastream.serviceImpl;

import com.nsl.paas.kafkastream.enums.KafkaStoreExceptionType;
import com.nsl.paas.kafkastream.exceptions.KafkaStoreAccessException;
import com.nsl.paas.kafkastream.exceptions.NotFoundException;
import com.nsl.paas.kafkastream.model.TenantActivityInfo;
import com.nsl.paas.kafkastream.service.TenantActivityService;
import java.time.Duration;
import java.time.Instant;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.errors.TimeoutException;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StoreQueryParameters;
import org.apache.kafka.streams.errors.InvalidStateStoreException;
import org.apache.kafka.streams.kstream.Windowed;
import org.apache.kafka.streams.state.KeyValueIterator;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyWindowStore;
import org.apache.kafka.streams.state.WindowStoreIterator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.stereotype.Service;

import static com.nsl.paas.kafkastream.constants.AppConstants.DISPLAY_CONTROLLER;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_ONE_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_THREE_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_SIX_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWELVE_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWENTY_FOUR_HOUR;
import static com.nsl.paas.kafkastream.constants.AppConstants.AVERAGE_DURATION;
import static com.nsl.paas.kafkastream.constants.AppConstants.TENANT_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.ACTIVE_USERS;
import static com.nsl.paas.kafkastream.constants.AppConstants.TENANT;
import static com.nsl.paas.kafkastream.constants.AppConstants.DESCENDING;
import static com.nsl.paas.kafkastream.constants.AppConstants.TOTAL_DURATION;
import static com.nsl.paas.kafkastream.constants.AppConstants.TOTAL_COMPLETED_TRANSACTIONS;
import static com.nsl.paas.kafkastream.constants.AppConstants.TOTAL_TRANSACTIONS;
import static com.nsl.paas.kafkastream.constants.AppConstants.TOTAL_INCOMPLETE_TRANSACTIONS;
import static com.nsl.paas.kafkastream.constants.AppConstants.TOTAL_FAILED_TRANSACTIONS;

@Service
public class TenantActivityServiceImpl implements TenantActivityService {

    @Autowired
    private StreamsBuilderFactoryBean factoryBean;

    private static final Logger log = LoggerFactory.getLogger(TenantActivityServiceImpl.class);

    @Override
    public Map<String, TenantActivityInfo> getTenantActivityInfoByTimeWindow(final int page, final int pageSize,
        final String sortBy, final String sortOrder,
        final int windowSizeInHours) {

        final String tableName = getTableNameByWindowSize(windowSizeInHours);
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyWindowStore<String, TenantActivityInfo> windowedTenantKTable;

        try {
            assert kafkaStreams != null;
            windowedTenantKTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(tableName, QueryableStoreTypes.windowStore())
            );

            // Retrieve all data
            final Instant startTime = Instant.now().minus(Duration.ofHours(windowSizeInHours));
            final Instant endTime = Instant.now();

            log.info("Fetching data from windowed tenant table for time window of last {} hour.", windowSizeInHours);

            KeyValueIterator<Windowed<String>, TenantActivityInfo> allData = windowedTenantKTable.fetchAll(startTime, endTime);

            // Sorting logic based on sortBy and sortOrder
            List<Entry<String, TenantActivityInfo>> sortedData = new ArrayList<>();
            while (allData.hasNext()) {
                KeyValue<Windowed<String>, TenantActivityInfo> iter = allData.next();
                sortedData.add(new SimpleEntry<>(iter.key.key(), iter.value));
            }

            log.info("Success in retrieving data from windowed tenant table for time window of last {} hour.", windowSizeInHours);

            Comparator<Entry<String, TenantActivityInfo>> comparator = getComparator(sortBy, sortOrder);
            sortedData.sort(comparator);

            // Pagination logic
            final int startIdx = (page - 1) * pageSize;
            final int endIdx = Math.min(startIdx + pageSize, sortedData.size());

            // Build paginated result
            Map<String, TenantActivityInfo> paginatedResult = new LinkedHashMap<>();
            for (int i = startIdx; i < endIdx; i++) {
                Map.Entry<String, TenantActivityInfo> entry = sortedData.get(i);
                paginatedResult.put(entry.getKey(), entry.getValue());
            }

            return paginatedResult;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public List<String> getActiveTenantsListByTimeWindow(final int windowSizeInHours) {
        final String tableName = getTableNameByWindowSize(windowSizeInHours);
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();

        ReadOnlyWindowStore<String, TenantActivityInfo> windowedTenantKTable;

        try {
            windowedTenantKTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(tableName, QueryableStoreTypes.windowStore())
            );

            final Instant startTime = Instant.now().minus(Duration.ofHours(windowSizeInHours));
            final Instant endTime = Instant.now();

            log.info("Retrieving data from windowed tenant activity table to get active tenants for last: {} hour.", windowSizeInHours);

            KeyValueIterator<Windowed<String>, TenantActivityInfo> iterator = windowedTenantKTable.fetchAll(startTime, endTime);

            List<String> activeTenants = new ArrayList<>();
            while (iterator.hasNext()) {
                KeyValue<Windowed<String>, TenantActivityInfo> kv = iterator.next();
                activeTenants.add(kv.key.key());
            }

            iterator.close();

            log.info("Success in getting list of active tenants for last {} hour.", windowSizeInHours);

            return activeTenants;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public TenantActivityInfo getActivityByTenantIdAndTimeWindow(final String tenantId, final int windowSizeInHours,
        final String controller) {

        final String tableName = getTableNameByWindowSize(windowSizeInHours);
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyWindowStore<String, TenantActivityInfo> windowedTenantKTable;

        try {
            assert kafkaStreams != null;
            windowedTenantKTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(tableName, QueryableStoreTypes.windowStore())
            );

            final Instant startTime = Instant.now().minus(Duration.ofHours(windowSizeInHours));
            final Instant endTime = Instant.now();

            log.info("Retrieving tenant activity info for tenantId: {} for the last: {} hour.", tenantId, windowSizeInHours);

            WindowStoreIterator<TenantActivityInfo> iterator = windowedTenantKTable.fetch(tenantId, startTime, endTime);

            TenantActivityInfo tenantActivityInfo = TenantActivityInfo.builder().build();

            if (iterator.hasNext()) {
                KeyValue<Long, TenantActivityInfo> keyValue = iterator.next();
                tenantActivityInfo = keyValue.value;
            } else {
                if (controller.equals(DISPLAY_CONTROLLER)) {
                    log.warn("The given tenantId either does not exist or has not done any activity in given time window. " +
                        "tenantId: {}, time window: {} hour", tenantId, windowSizeInHours);
                } else {
                    log.error("The given tenantId either does not exist or has not done any activity in given time window. " +
                        "tenantId {}, time window: {} hour", tenantId, windowSizeInHours);

                    final String errMsg = "The given tenantId either does not exist or has not done any activity in given time window. " +
                        "tenantId " + tenantId + ", time window: " + windowSizeInHours + " hour";

                    throw new NotFoundException(errMsg);
                }
            }

            log.info("Successfully retrieved tenant activity info for tenantId: {} for the last: {} hour.", tenantId, windowSizeInHours);

            return tenantActivityInfo;
        } catch (NotFoundException e) {
            throw new NotFoundException(e.getMessage());
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving tenant activity data for tenantId "
                + tenantId + "for time window " + "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving tenant activity data for tenantId "
                + tenantId + "for time window " + "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving tenant activity data for tenantId "
                + tenantId + "for time window " + "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving tenant activity data for tenantId "
                + tenantId + "for time window " + "of last " + windowSizeInHours + " hour.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public List<TenantActivityInfo> getTenantActivityListByTimeWindow(final int windowSizeInHours) {

        final String tableName = getTableNameByWindowSize(windowSizeInHours);
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyWindowStore<String, TenantActivityInfo> windowedTenantKTable;

        try {
            assert kafkaStreams != null;
            windowedTenantKTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(tableName, QueryableStoreTypes.windowStore())
            );

            // Retrieve all data
            final Instant startTime = Instant.now().minus(Duration.ofHours(windowSizeInHours));
            final Instant endTime = Instant.now();

            log.info("Fetching data from windowed tenant table for time window of last {} hour.", windowSizeInHours);

            KeyValueIterator<Windowed<String>, TenantActivityInfo> allData = windowedTenantKTable.fetchAll(startTime, endTime);

            List<TenantActivityInfo> result = new ArrayList<>();

            while (allData.hasNext()) {
                KeyValue<Windowed<String>, TenantActivityInfo> kv = allData.next();
                result.add(kv.value);
            }

            log.info("Success in retrieving data from windowed tenant table for time window of last {} hour.", windowSizeInHours);

            return result;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public Long getActiveTenantCountByTimeWindow(final int windowSizeInHours) {

        final String tableName = getTableNameByWindowSize(windowSizeInHours);
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();

        ReadOnlyWindowStore<String, TenantActivityInfo> windowedTenantKTable;

        try {
            assert kafkaStreams != null;
            windowedTenantKTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(tableName, QueryableStoreTypes.windowStore())
            );

            final Instant startTime = Instant.now().minus(Duration.ofHours(windowSizeInHours));
            final Instant endTime = Instant.now();

            log.info("Retrieving data from windowed tenant activity table to get count of active tenants for last: {} hour.", windowSizeInHours);

            KeyValueIterator<Windowed<String>, TenantActivityInfo> iterator = windowedTenantKTable.fetchAll(startTime, endTime);

            Long count = 0L;
            while (iterator.hasNext()) {
                iterator.next();
                count++;
            }

            iterator.close();

            log.info("Success in getting count of active tenants for last {} hour.", windowSizeInHours);

            return count;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving tenant activity data for time window " +
                "of last " + windowSizeInHours + " hour.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    private String getTableNameByWindowSize(final int duration) {
        String baseTableName;
        switch (duration) {
            case 1 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_ONE_HOUR;
            case 3 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_THREE_HOUR;
            case 6 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_SIX_HOUR;
            case 12 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWELVE_HOUR;
            case 24 -> baseTableName = ACTIVITY_ANALYSIS_WINDOWED_TABLE_NAME_TWENTY_FOUR_HOUR;
            default -> throw new IllegalArgumentException("Unsupported duration: " + duration);
        }

        return TENANT + "_" + baseTableName;
    }

    private Comparator<Map.Entry<String, TenantActivityInfo>> getComparator(final String sortBy, final String sortOrder) {

        Comparator<Map.Entry<String, TenantActivityInfo>> comparator = switch (sortBy) {
            case AVERAGE_DURATION -> Comparator.comparingLong(entry -> entry.getValue().getAvgDuration());
            case TOTAL_DURATION -> Comparator.comparingLong(entry -> entry.getValue().getTotalDuration());
            case TOTAL_TRANSACTIONS -> Comparator.comparingLong(entry -> entry.getValue().getTotalTransactions());
            case TOTAL_FAILED_TRANSACTIONS ->
                Comparator.comparingLong(entry -> entry.getValue().getTotalFailedTransactions());
            case TOTAL_COMPLETED_TRANSACTIONS ->
                Comparator.comparingLong(entry -> entry.getValue().getTotalCompletedTransactions());
            case TOTAL_INCOMPLETE_TRANSACTIONS ->
                Comparator.comparingLong(entry -> entry.getValue().getTotalIncompleteTransactions());
            case TENANT_ID -> Comparator.comparing(entry -> entry.getValue().getTenantId());
            case ACTIVE_USERS -> Comparator.comparingLong(entry -> entry.getValue().getUsers().size());
            default -> throw new IllegalArgumentException("Invalid sortBy parameter");
        };

        if (comparator != null) {
            if (DESCENDING.equalsIgnoreCase(sortOrder)) {
                return comparator.reversed();
            } else {
                return comparator;
            }
        } else {
            throw new IllegalArgumentException("Invalid sortBy parameter");
        }
    }
}