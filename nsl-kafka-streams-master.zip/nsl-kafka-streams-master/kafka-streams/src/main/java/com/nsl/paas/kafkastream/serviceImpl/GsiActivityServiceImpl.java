package com.nsl.paas.kafkastream.serviceImpl;

import com.nsl.paas.kafkastream.dto.CuTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.CuTransactionValueDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionValueDto;
import com.nsl.paas.kafkastream.dto.GsiTrendsKey;
import com.nsl.paas.kafkastream.enums.KafkaStoreExceptionType;
import com.nsl.paas.kafkastream.exceptions.KafkaStoreAccessException;
import com.nsl.paas.kafkastream.model.CuDetails;
import com.nsl.paas.kafkastream.model.GsiTrendsValueInfo;
import com.nsl.paas.kafkastream.service.GsiActivityService;
import com.nsl.paas.kafkastream.exceptions.NotFoundException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.errors.TimeoutException;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StoreQueryParameters;
import org.apache.kafka.streams.errors.InvalidStateStoreException;
import org.apache.kafka.streams.state.KeyValueIterator;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.stereotype.Service;

import static com.nsl.paas.kafkastream.constants.AppConstants.CU_ROW_KEYS;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_TYPE;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI_SUCCESS_COUNT_TABLE_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI_FAILED_COUNT_TABLE_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI_EXECUTION_DETAILS_TABLE_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI_START_TIME;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI_END_TIME;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_DETAILS_TABLE;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI_TRENDS_ANALYSIS_TABLE_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI_UNIQUE_ENTRIES;
import static com.nsl.paas.kafkastream.constants.AppConstants.IS_RESERVED;
import static com.nsl.paas.kafkastream.constants.AppConstants.KEYS;
import static com.nsl.paas.kafkastream.constants.AppConstants.RESERVED_CU_METHOD_TYPE;
import static com.nsl.paas.kafkastream.constants.AppConstants.RESERVED_CU_TYPE;
import static com.nsl.paas.kafkastream.constants.AppConstants.TRANSACTION_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.TENANT_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.DURATION;
import static com.nsl.paas.kafkastream.constants.AppConstants.TRANSACTION_STATUS;
import static com.nsl.paas.kafkastream.constants.AppConstants.CURRENT_CU_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.EMAIL_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_NAME;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_START_TIME;
import static com.nsl.paas.kafkastream.constants.AppConstants.CU_END_TIME;
import static com.nsl.paas.kafkastream.constants.AppConstants.TRIGGERED_TIME;
import static com.nsl.paas.kafkastream.constants.AppConstants.TRIGGER_STATE;

@Service
public class GsiActivityServiceImpl implements GsiActivityService {

    @Autowired
    private StreamsBuilderFactoryBean factoryBean;

    private static final Logger log = LoggerFactory.getLogger(GsiActivityServiceImpl.class);

    @Override
    public Long getCompletedGsiCountByGsiName(final String gsiName) {
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyKeyValueStore<String, Long> kTable;

        try {
            assert kafkaStreams != null;
            kTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(GSI_SUCCESS_COUNT_TABLE_NAME, QueryableStoreTypes.keyValueStore())
            );

            final Long count = kTable.get(gsiName);

            if (count == null) {
                log.info("GSI name '{}' not found in the kTable for completed transactions.", gsiName);
                final String errMsg = "GSI name '" + gsiName + "' not found in the kTable for completed transactions.";
                throw new NotFoundException(errMsg);
            }

            log.info("Retrieved success count {} for GSI name '{}'", count, gsiName);

            return count;
        } catch (NotFoundException e) {
            throw new NotFoundException(e.getMessage());
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving the completed count for GSI Name: " + gsiName;
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving the completed count for GSI Name: " + gsiName;
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving the completed count for GSI Name: " + gsiName;
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving the completed count for GSI Name: " + gsiName;
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public Long getFailedGsiCountByGsiName(final String gsiName) {
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyKeyValueStore<String, Long> kTable;

        try {
            assert kafkaStreams != null;
            kTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(GSI_FAILED_COUNT_TABLE_NAME, QueryableStoreTypes.keyValueStore())
            );

            final Long count = kTable.get(gsiName);

            if (count == null) {
                log.info("GSI name '{}' not found in the kTable for failed transactions", gsiName);
                final String errMsg = "GSI name '" + gsiName + "' not found in the kTable for failed transactions";
                throw new NotFoundException(errMsg);
            }

            log.info("Retrieved failure count {} for GSI name '{}'", count, gsiName);

            return count;
        } catch (NotFoundException e) {
            throw new NotFoundException(e.getMessage());
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving the failure count for GSI Name: " + gsiName;
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving the failure count for GSI Name: " + gsiName;
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving the failure count for GSI Name: " + gsiName;
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving the failure count for GSI Name: " + gsiName;
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public GsiFinalTransactionValueDto getGsiDurationByTxnIdAndNameAndTenantId(final String gsiName,
        final long transactionId,
        final String tenantId) {

        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyKeyValueStore<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> gsiDuration;

        try {
            assert kafkaStreams != null;
            gsiDuration = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(GSI_EXECUTION_DETAILS_TABLE_NAME, QueryableStoreTypes.keyValueStore())
            );

            final GsiFinalTransactionKeyDto key = new GsiFinalTransactionKeyDto(gsiName, transactionId, tenantId);
            final GsiFinalTransactionValueDto values = gsiDuration.get(key);

            if (values == null) {
                log.error("Key '{}' not found in the GSI duration table for gsiName '{}', transactionId '{}', and tenantId '{}'",
                    key, gsiName, transactionId, tenantId);
                throw new NotFoundException("Key not found in the GSI duration table");
            }

            log.info("Retrieved values for gsiName '{}', transactionId '{}', and tenantId '{}'",
                gsiName, transactionId, tenantId);

            return values;
        } catch (NotFoundException e) {
            throw new NotFoundException(e.getMessage());
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving values for gsiName: " + gsiName
                + " tenantId: " + tenantId + " transactionId: " + transactionId;
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving values for gsiName: " + gsiName
                + " tenantId: " + tenantId + " transactionId: " + transactionId;
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving values for gsiName: " + gsiName
                + " tenantId: " + tenantId + " transactionId: " + transactionId;
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving values for gsiName: " + gsiName
                + " tenantId: " + tenantId + " transactionId: " + transactionId;
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public Map<String, Long> getCompletedGsiCountMap() {
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyKeyValueStore<String, Long> counts;

        try {
            assert kafkaStreams != null;
            counts = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(GSI_SUCCESS_COUNT_TABLE_NAME, QueryableStoreTypes.keyValueStore())
            );

            var iter = counts.all();
            Map<String, Long> out = new HashMap<>();

            while (iter.hasNext()) {
                var kv = iter.next();
                out.put(kv.key, kv.value);
            }

            log.info("Successfully retrieved completed GSI count map.");

            return out;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving completed GSI count list";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving completed GSI count list";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving completed GSI count list";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving completed GSI count list";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public Map<CuTransactionKeyDto, CuTransactionValueDto> getCuExecutionActivityMap() {
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyKeyValueStore<CuTransactionKeyDto, CuTransactionValueDto> cuTable;

        try {
            assert kafkaStreams != null;
            cuTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(CU_DETAILS_TABLE, QueryableStoreTypes.keyValueStore())
            );

            KeyValueIterator<CuTransactionKeyDto, CuTransactionValueDto> iterator = cuTable.all();
            Map<CuTransactionKeyDto, CuTransactionValueDto> out = new HashMap<>();

            while (iterator.hasNext()) {
                KeyValue<CuTransactionKeyDto, CuTransactionValueDto> entry = iterator.next();
                CuTransactionKeyDto key = entry.key;
                CuTransactionValueDto value = entry.value;
                out.put(key, value);
            }

            log.info("Successfully retrieved CU execution activity map.");

            return out;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving CU execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving CU execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving CU execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving CU execution activity map";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public Map<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> getGsiExecutionActivityMap() {
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyKeyValueStore<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> gsiTable;

        try {
            assert kafkaStreams != null;
            gsiTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(GSI_EXECUTION_DETAILS_TABLE_NAME, QueryableStoreTypes.keyValueStore())
            );

            KeyValueIterator<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> iterator = gsiTable.all();
            Map<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> out = new HashMap<>();

            while (iterator.hasNext()) {
                KeyValue<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> entry = iterator.next();
                GsiFinalTransactionKeyDto key = entry.key;
                GsiFinalTransactionValueDto value = entry.value;
                out.put(key, value);
            }

            log.info("Successfully retrieved GSI Execution Activity Map.");

            return out;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving GSI execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving GSI execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving GSI execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving GSI execution activity map";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public List<Map<String, String>> getGsiExecutionActivityMapAsList() {
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyKeyValueStore<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> gsiTable;

        try {
            assert kafkaStreams != null;
            gsiTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(GSI_EXECUTION_DETAILS_TABLE_NAME, QueryableStoreTypes.keyValueStore())
            );

            KeyValueIterator<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> iterator = gsiTable.all();

            // Create a list to hold the GSI execution data
            List<Map<String, String>> gsiExecutionDataList = new ArrayList<>();

            // Iterate through the GSI execution duration table and add data to the list
            while (iterator.hasNext()) {
                KeyValue<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> entry = iterator.next();
                GsiFinalTransactionValueDto value = entry.value;
                // Create a map to hold the key-value pairs for each row
                Map<String, String> rowData = new HashMap<>();
                rowData.put(GSI_NAME, value.gsiName());
                rowData.put(TRANSACTION_ID, String.valueOf(value.transactionId()));
                rowData.put(TENANT_ID, value.tenantId());
                rowData.put(GSI_START_TIME, String.valueOf(value.startTime()));
                rowData.put(GSI_END_TIME, String.valueOf(value.endTime()));
                rowData.put(DURATION, (value.duration()) + " secs");
                rowData.put(TRANSACTION_STATUS, value.transactionStatus());
                rowData.put(CURRENT_CU_NAME, value.currentCuName());
                rowData.put(EMAIL_ID, String.valueOf(value.emailId()));

                // Add the map to the list
                gsiExecutionDataList.add(rowData);
            }

            log.info("Successfully retrieved GSI execution activity data as List.");

            return gsiExecutionDataList;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving GSI execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving GSI execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving GSI execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving GSI execution activity map";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public List<Map<String, String>> getCuExecutionActivityMapAsList() {
        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyKeyValueStore<CuTransactionKeyDto, CuTransactionValueDto> cuTable;

        try {
            assert kafkaStreams != null;
            cuTable = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(CU_DETAILS_TABLE, QueryableStoreTypes.keyValueStore())
            );

            KeyValueIterator<CuTransactionKeyDto, CuTransactionValueDto> iterator = cuTable.all();

            // Create a list to hold the GSI execution data
            List<Map<String, String>> cuDataList = new ArrayList<>();

            // Iterate through the GSI execution duration table and add data to the list
            while (iterator.hasNext()) {
                KeyValue<CuTransactionKeyDto, CuTransactionValueDto> entry = iterator.next();
                CuTransactionValueDto value = entry.value;
                // Create a map to hold the key-value pairs for each row
                Map<String, String> rowData = new HashMap<>();
                rowData.put(TRANSACTION_ID, String.valueOf(value.transactionId()));
                rowData.put(CU_NAME,value.cUName());
                rowData.put(CU_ID, String.valueOf(value.cUId()));
                rowData.put(CU_TYPE,value.cuDetails().getAgentType());
                rowData.put(TENANT_ID, value.tenantId());
                LocalDateTime triggerStartTime = value.triggerStartTime();
                rowData.put(CU_START_TIME, String.valueOf(triggerStartTime));
                LocalDateTime triggeredTime=value.triggeredTime();
                rowData.put(TRIGGERED_TIME, String.valueOf(triggeredTime));
                LocalDateTime triggerEndTime = value.triggerEndTime();
                rowData.put(CU_END_TIME, String.valueOf(triggerEndTime));
                rowData.put(DURATION, (value.duration()) + " secs");
                rowData.put(TRIGGER_STATE,value.triggerState());
                rowData.put(EMAIL_ID, String.valueOf(value.emailId()));
                rowData.put(IS_RESERVED,String.valueOf(value.cuDetails().isReserved()));
                rowData.put(RESERVED_CU_TYPE,value.cuDetails().getCuCategory());
                rowData.put(RESERVED_CU_METHOD_TYPE,value.cuDetails().getMethodType());
                // Add the map to the list
                cuDataList.add(rowData);
            }

            log.info("Successfully retrieved CU execution activity data as List.");

            return cuDataList;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving CU execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving CU execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving CU execution activity map";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving CU execution activity map";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public List<Map<String, Long>> getGsiAnalyticsMapAsList() {

        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyKeyValueStore<String, Long> successCounts;
        ReadOnlyKeyValueStore<String, Long> failureCounts;

        try {
            assert kafkaStreams != null;

            successCounts= kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(GSI_SUCCESS_COUNT_TABLE_NAME, QueryableStoreTypes.keyValueStore())
            );

            failureCounts = kafkaStreams.store(
                StoreQueryParameters.fromNameAndType(GSI_FAILED_COUNT_TABLE_NAME, QueryableStoreTypes.keyValueStore())
            );

            log.info("Retrieving counts from completed GSI count table.");

            var successIter =  successCounts.all();
            Map<String,Long> successOutput = new HashMap<>();

            while(successIter.hasNext()) {
                var kv = successIter.next();
                successOutput.put(kv.key, kv.value);
            }

            log.info("Successfully retrieved counts from completed GSI count table.");


            log.info("Retrieving counts from failed GSI count table.");

            var failureIter =  failureCounts.all();
            Map<String,Long> failureOutput = new HashMap<>();
            while(failureIter.hasNext()) {
                var kv = failureIter.next();
                failureOutput.put(kv.key, kv.value);
            }

            log.info("Successfully retrieved counts from failed GSI count table.");

            List<Map<String, Long>> result = new ArrayList<>();
            result.add(successOutput);
            result.add(failureOutput);

            return result;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving counts from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving counts from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving counts from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving counts from KTable.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    @Override
    public ConcurrentHashMap<Long, GsiTrendsValueInfo> getGsiTrendsMap() {

        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        try {

            if (kafkaStreams == null) {
                throw new IllegalStateException("KafkaStreams instance is not initialized");
            }
            ReadOnlyKeyValueStore<GsiTrendsKey, GsiTrendsValueInfo> gsiTrendsTable = kafkaStreams.store
                    (StoreQueryParameters.fromNameAndType(GSI_TRENDS_ANALYSIS_TABLE_NAME, QueryableStoreTypes.keyValueStore())
            );
            ConcurrentHashMap<Long, GsiTrendsValueInfo> gsiTrendsMap = new ConcurrentHashMap<>(5000,0.75f);

            log.info("Retrieving data from KTable to build GSI TRENDS TreeMap.");

            GsiTrendsValueInfo gsiKeyStore = gsiTrendsTable.get(new GsiTrendsKey(GSI_UNIQUE_ENTRIES,1L,1L));
            LinkedHashSet<GsiTrendsKey> gsiNameKey = gsiKeyStore.getRowKeys();

            for(GsiTrendsKey kv : gsiNameKey){

                ConcurrentHashMap<Long, GsiTrendsValueInfo> result = retrieveGsiTrends(kv.tenantName(),gsiTrendsTable);
                gsiTrendsMap.putAll(result);
            }

            log.info("Success in retrieving data from KTable to build GSI TRENDS TreeMap.");

            return gsiTrendsMap;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving info from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving info from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving info from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving info KTable.";
            throw new RuntimeException(errorMessage, e);
        }
    }
    @Override
    public ConcurrentHashMap<Long, GsiTrendsValueInfo> getGsiTrendsMapByName(String gsiName) {

        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        try {

            if (kafkaStreams == null) {
                throw new IllegalStateException("KafkaStreams instance is not initialized");
            }
            ReadOnlyKeyValueStore<GsiTrendsKey, GsiTrendsValueInfo> gsiTrendsTable = kafkaStreams.store
                    (StoreQueryParameters.fromNameAndType(GSI_TRENDS_ANALYSIS_TABLE_NAME, QueryableStoreTypes.keyValueStore())
            );

            log.info("Retrieving data from KTable to build GSI TRENDS TreeMap for gsi:{}",gsiName);

            ConcurrentHashMap<Long, GsiTrendsValueInfo> gsiTrendsMap = retrieveGsiTrends(gsiName,gsiTrendsTable);

            log.info("Success in retrieving data from KTable to build GSI TRENDS TreeMap for gsi:{}",gsiName);

            return gsiTrendsMap;
        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving info from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving info from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving info from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (NotFoundException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "NotFoundException occurred while retrieving info from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.NOT_FOUND_EXCEPTION);
        }
        catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving info KTable.";
            throw new RuntimeException(errorMessage, e);
        }
    }

    private ConcurrentHashMap<Long, GsiTrendsValueInfo> retrieveGsiTrends(String gsiName,
                                                                          ReadOnlyKeyValueStore<GsiTrendsKey,
                                                                                  GsiTrendsValueInfo> gsiTrendsTable) {

        ConcurrentHashMap<Long, GsiTrendsValueInfo> gsiTrendsMap = new ConcurrentHashMap<>(100, 0.75f);

        GsiTrendsValueInfo gsiKeyStore = gsiTrendsTable.get(new GsiTrendsKey(gsiName + KEYS, 1L, 1L));
        if (gsiKeyStore == null) {
            throw new NotFoundException("GSI: " + gsiName + " does not exist in the system");
        }

        LinkedHashSet<GsiTrendsKey> gsiRows = gsiKeyStore.getRowKeys();
        for (GsiTrendsKey gsiKey : gsiRows) {
            GsiTrendsValueInfo gsiTrendsValueInfo = updateTrendsValueInfo(gsiTrendsTable.get(gsiKey));
            if (gsiTrendsValueInfo != null) {
                gsiTrendsMap.put(gsiKey.gsiId(), gsiTrendsValueInfo);

                GsiTrendsValueInfo cuValueInfo = gsiTrendsTable.get(new GsiTrendsKey(CU_ROW_KEYS, gsiKey.gsiId(), gsiKey.gsiId()));
                if (cuValueInfo != null) {
                    processCuRows(cuValueInfo, gsiTrendsTable, gsiTrendsMap);
                }
            }
        }
        return gsiTrendsMap;
    }

    private void processCuRows(GsiTrendsValueInfo cuValueInfo,
                               ReadOnlyKeyValueStore<GsiTrendsKey, GsiTrendsValueInfo> gsiTrendsTable,
                               ConcurrentHashMap<Long, GsiTrendsValueInfo> gsiTrendsMap) {
        LinkedHashSet<GsiTrendsKey> cuRows = cuValueInfo.getRowKeys();
        for (GsiTrendsKey cuKey : cuRows) {
            GsiTrendsValueInfo cuTrendsValueInfo = updateTrendsValueInfo(gsiTrendsTable.get(cuKey));
            if (cuTrendsValueInfo != null) {
                GsiTrendsValueInfo embeddedCuInfo = gsiTrendsTable.get(new GsiTrendsKey(CU_ROW_KEYS,
                        cuTrendsValueInfo.getContainerId(), cuTrendsValueInfo.getContainerId()));
                if (embeddedCuInfo != null) {
                    processEmbeddedCuRows(embeddedCuInfo, gsiTrendsTable, cuTrendsValueInfo);
                }

                gsiTrendsMap.computeIfPresent(cuKey.gsiId(), (key, value) -> {
                    value.getListOfCuTrendsValueInfo().add(cuTrendsValueInfo);
                    return value;
                });
            }
        }
    }

    private void processEmbeddedCuRows(GsiTrendsValueInfo embeddedCuInfo,
                                       ReadOnlyKeyValueStore<GsiTrendsKey, GsiTrendsValueInfo> gsiTrendsTable,
                                       GsiTrendsValueInfo cuTrendsValueInfo) {
        LinkedHashSet<GsiTrendsKey> embeddedCuRows = embeddedCuInfo.getRowKeys();
        for (GsiTrendsKey embeddedCuKey : embeddedCuRows) {
            GsiTrendsValueInfo embeddedCuTrendsValueInfo = updateTrendsValueInfo(gsiTrendsTable.get(embeddedCuKey));
            if (embeddedCuTrendsValueInfo != null) {
                cuTrendsValueInfo.getListOfCuTrendsValueInfo().add(embeddedCuTrendsValueInfo);
            }
        }
    }

    private GsiTrendsValueInfo updateTrendsValueInfo(GsiTrendsValueInfo valueInfo) {
        if (valueInfo != null) {
            valueInfo.setMinimumTime(Math.min(valueInfo.getMinimumTime(), valueInfo.getLastDuration()));
            valueInfo.setMaximumTime(Math.max(valueInfo.getMaximumTime(), valueInfo.getLastDuration()));
        }
        return valueInfo;
    }


    @Override
    public Map<String, Set<String>> getReservedCuTypes() {

        final KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
        ReadOnlyKeyValueStore<GsiTrendsKey, GsiTrendsValueInfo> gsiTrendsTable;
        try {
            assert kafkaStreams != null;
            gsiTrendsTable = kafkaStreams.store(StoreQueryParameters.fromNameAndType(GSI_TRENDS_ANALYSIS_TABLE_NAME,
                    QueryableStoreTypes.keyValueStore())
            );

            Map<String, Set<String>> reserveCuMap = new HashMap<>();
            log.info("Retrieving data from KTable to fetch unique reservedCu types");

            KeyValueIterator<GsiTrendsKey, GsiTrendsValueInfo> iterator = gsiTrendsTable.all();
            while(iterator.hasNext()) {

                KeyValue<GsiTrendsKey, GsiTrendsValueInfo> entry = iterator.next();
                GsiTrendsKey key = entry.key;
                if(!Objects.equals(key.containerId(), key.gsiId())){
                    CuDetails cuDetails = entry.value.getContainerDetails();
                    String cuCategory = cuDetails.getCuCategory();
                    String methodType = cuDetails.getMethodType();
                    if(Objects.equals(cuCategory, "UNKNOWN CU")){
                        continue;
                    }
                    reserveCuMap.putIfAbsent(cuCategory, new HashSet<>());
                    if (methodType != null) {
                        reserveCuMap.get(cuCategory).add(methodType);
                    }
                }
            }

            log.info("Success in retrieving data from KTable to fetch unique reservedCu types");
            return reserveCuMap;

        } catch (InvalidStateStoreException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "InvalidStateStoreException occurred while retrieving info from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.INVALID_STATE_STORE_EXCEPTION);
        } catch (SerializationException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "SerializationException occurred while retrieving info from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.SERIALIZATION_EXCEPTION);
        } catch (TimeoutException e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "TimeoutException occurred while retrieving info from KTable.";
            throw new KafkaStoreAccessException(errorMessage, e, KafkaStoreExceptionType.TIMEOUT_EXCEPTION);
        } catch (Exception e) {
            log.error("Error occurred while accessing Kafka store: {}", e.getMessage());
            final String errorMessage = "Exception occurred while retrieving info KTable.";
            throw new RuntimeException(errorMessage, e);
        }
    }


}