package com.nsl.paas.kafkastream.controller;

import com.nsl.paas.kafkastream.dto.NodeDto;
import com.nsl.paas.kafkastream.dto.PathDto;
import com.nsl.paas.kafkastream.service.MemgraphService;

import io.swagger.v3.oas.annotations.Operation;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import static com.nsl.paas.kafkastream.constants.AppConstants.CHANGE_UNIT;
import static com.nsl.paas.kafkastream.constants.AppConstants.GENERAL_ENTITY;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_CHILD_NODES_FOR_CU_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_CHILD_NODES_FOR_GE_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_CU_NODES_FOR_GE_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_CU_NODES_FOR_GSI_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_GE_NODES_FOR_GSI_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_GSI_NODES_FOR_GE_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GET_PARENT_NODES_FOR_CU_ID;
import static com.nsl.paas.kafkastream.constants.AppConstants.GSI;

@Controller
public class GraphViewController {

    private static final Logger log = LoggerFactory.getLogger(GraphViewController.class);

    @Autowired
    private MemgraphService memgraphService;

    @Operation(summary = "Get dependency graph for a given entity id.", description = "Get dependency graph for a given entity Id.")
    @GetMapping("ui/graph/entity/{entityId}")
    public String getDependencyGraphByEntityId(@PathVariable Long entityId, Model model)  {

        log.info("Received request to fetch dependency graph for entityId: {}", entityId);

        List<PathDto> result = memgraphService.getDependencyGraphByBetId(entityId, GENERAL_ENTITY);
        model.addAttribute("graphData", result);

        log.info("Successfully processed request to fetch dependency graph for entityId: {}", entityId);

        return "ComponentGraph";
    }

    @Operation(summary = "Get dependency graph for a given cu id.", description = "Get dependency graph for a given cu Id.")
    @GetMapping("ui/graph/cu/{cuId}")
    public String getDependencyGraphByChangeUnitId(@PathVariable Long cuId, Model model) {

        log.info("Received request to fetch dependency graph for cuId: {}", cuId);

        List<PathDto> result = memgraphService.getDependencyGraphByBetId(cuId, CHANGE_UNIT);
        model.addAttribute("graphData", result);

        log.info("Successfully processed request to fetch dependency graph for cuId: {}", cuId);
        return "ComponentGraph";
    }

    @Operation(summary = "Get dependency graph for a given gsi id.", description = "Get dependency graph for a given gsi Id.")
    @GetMapping("ui/graph/gsi/{gsiId}")
    public String getDependencyGraphByGsiId(@PathVariable Long gsiId, Model model) {

        log.info("Received request to fetch dependency graph for gsiId: {}", gsiId);

        List<PathDto> result = memgraphService.getDependencyGraphByBetId(gsiId, GSI);
        model.addAttribute("graphData", result);

        log.info("Successfully processed request to fetch dependency graph for gsiId: {}", gsiId);
        return "ComponentGraph";
    }

    @Operation(summary = "Get list of gsi nodes in which given cu is present.", description = "Get list of gsi nodes in which given cu is present.")
    @GetMapping("ui/parent/nodes/cu/{cuId}")
    public String getParentNodesForCuId(@PathVariable Long cuId, Model model) {

        log.info("Received request to fetch parent nodes for cuId: {}", cuId);

        List<NodeDto> result = memgraphService.getListOfNodes(cuId, GET_PARENT_NODES_FOR_CU_ID);
        NodeDto root = extractRootNode(cuId, result);
        model.addAttribute("graphData", result);
        model.addAttribute("root", root);

        log.info("Successfully processed request to fetch parent nodes for cuId: {}", cuId);

        return "GraphNodeView";
    }

    @Operation(summary = "Get list of ge nodes present in given cu.", description = "Get list of ge nodes present in given cu.")
    @GetMapping("ui/child/nodes/cu/{cuId}")
    public String getChildNodesForCuId(@PathVariable Long cuId, Model model) {

        log.info("Received request to fetch child nodes for cuId: {}", cuId);

        List<NodeDto> result = memgraphService.getListOfNodes(cuId, GET_CHILD_NODES_FOR_CU_ID);
        NodeDto root = extractRootNode(cuId, result);
        model.addAttribute("graphData", result);
        model.addAttribute("root", root);

        log.info("Successfully processed request to fetch child nodes for cuId: {}", cuId);
        return "GraphNodeView";
    }

    @Operation(summary = "Get list of cu nodes present in given gsi.", description = "Get list of cu nodes present in given gsi.")
    @GetMapping("ui/child/nodes/gsi/{gsiId}/cu")
    public String getCuNodesForGsiId(@PathVariable Long gsiId, Model model) {

        log.info("Received request to fetch cu nodes for gsiId: {}", gsiId);

        List<NodeDto> result = memgraphService.getListOfNodes(gsiId, GET_CU_NODES_FOR_GSI_ID);
        NodeDto root = extractRootNode(gsiId, result);
        model.addAttribute("graphData", result);
        model.addAttribute("root", root);

        log.info("Successfully processed request to fetch cu nodes for gsiId: {}", gsiId);
        return "GraphNodeView";
    }

    @Operation(summary = "Get list of ge nodes present in given gsi.", description = "Get list of ge nodes present in given gsi.")
    @GetMapping("ui/child/nodes/gsi/{gsiId}/ge")
    public String getGeNodesForGsiId(@PathVariable Long gsiId, Model model) {
        log.info("Received request to fetch ge nodes for gsiId: {}", gsiId);

        List<NodeDto> result = memgraphService.getListOfNodes(gsiId, GET_GE_NODES_FOR_GSI_ID);
        NodeDto root = extractRootNode(gsiId, result);
        model.addAttribute("graphData", result);
        model.addAttribute("root", root);

        log.info("Successfully processed request to fetch ge nodes for gsiId: {}", gsiId);
        return "GraphNodeView";

    }

    @Operation(summary = "Get list of gsi nodes in which given ge is present.", description = "Get list of gsi nodes in which given ge is present.")
    @GetMapping("ui/parent/nodes/ge/{geId}/gsi")
    public String getGsiNodesForGeId(@PathVariable Long geId, Model model) {


        log.info("Received request to fetch gsi nodes for geId: {}", geId);

        List<NodeDto> result = memgraphService.getListOfNodes(geId, GET_GSI_NODES_FOR_GE_ID);
        NodeDto root = extractRootNode(geId, result);
        model.addAttribute("graphData", result);
        model.addAttribute("root", root);

        log.info("Successfully processed request to fetch gsi nodes for geId: {}", geId);
        return "GraphNodeView";
    }

    @Operation(summary = "Get list of cu nodes in which given ge is present.", description = "Get list of cu nodes in which given ge is present.")
    @GetMapping("ui/parent/nodes/ge/{geId}/cu")
    public String getCuNodesForGeId(@PathVariable Long geId, Model model) {

        log.info("Received request to fetch cu nodes for geId: {}", geId);

        List<NodeDto> result = memgraphService.getListOfNodes(geId, GET_CU_NODES_FOR_GE_ID);
        NodeDto root = extractRootNode(geId, result);
        model.addAttribute("graphData", result);
        model.addAttribute("root", root);

        log.info("Successfully processed request to fetch cu nodes for geId: {}", geId);
        return "GraphNodeView";
    }

    @Operation(summary = "Get list of attribute nodes present in given general entity.", description = "Get list of attribute nodes present in given general entity.")
    @GetMapping("ui/child/nodes/ge/{geId}/attribute")
    public String getChildNodesForGeId(@PathVariable Long geId, Model model) {

        log.info("Received request to fetch child nodes for geId: {}", geId);

        List<NodeDto> result = memgraphService.getListOfNodes(geId, GET_CHILD_NODES_FOR_GE_ID);
        NodeDto root = extractRootNode(geId, result);
        model.addAttribute("graphData", result);
        model.addAttribute("root", root);

        log.info("Successfully processed request to fetch child nodes for geId: {}", geId);
        return "GraphNodeView";
    }

    private NodeDto extractRootNode(final long betId, final List<NodeDto> nodes) {
        for (NodeDto n: nodes) {
            if (n.id() == betId) {
                return n;
            }
        }
        return null;
    }
}