package com.nsl.paas.kafkastream.dto;

public record NodeDto(String label, long id, String name) {
}
