package com.nsl.paas.kafkastream.controller;

import com.nsl.paas.kafkastream.model.ContainerCuInfo;
import com.nsl.paas.kafkastream.model.GsiTrendsValueInfo;
import com.nsl.paas.kafkastream.model.TenantActivityInfo;
import com.nsl.paas.kafkastream.model.UserActivityInfo;
import com.nsl.paas.kafkastream.service.GsiActivityService;
import com.nsl.paas.kafkastream.service.TenantActivityService;
import com.nsl.paas.kafkastream.service.UserActivityService;
import java.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.nsl.paas.kafkastream.constants.AppConstants.DISPLAY_CONTROLLER;

@Controller
public class TransactionDisplayController {

    private static final Logger log = LoggerFactory.getLogger(TransactionDisplayController.class);

    @Value(value = "${grafana.base.env}")
    private String grafanaEnv;

    @Value(value = "${grafana.base.url}")
    private String grafanaBaseUrl;

    @Value(value = "${history.service.url}")
    private String historyServiceUrl;

    @Value(value = "${history.service.username}")
    private String historyServiceUsername;

    @Value(value = "${history.service.password}")
    private String historyServicePassword;

    @Value(value = "${grafana.base.datasource}")
    private String grafanaDataSource;

    @Value(value = "${grafana.org.id}")
    private String grafanaOrgId;

    @Autowired
    StreamsBuilderFactoryBean factoryBean;

    @Autowired
    private UserActivityService userActivityService;

    @Autowired
    private TenantActivityService tenantActivityService;

    @Autowired
    private GsiActivityService gsiActivityService;

    @GetMapping("/redoc")
    public String redoc() {
        log.info("returning redoc api for API documentation ");
        return "redoc";
    }

    @GetMapping("/ui/gsi/details")
    public String displayGsiExecutionTable(Model model) {
        log.info("returning a page with gsi details table");

        List<Map<String, String>> gsiExecutionDataList = gsiActivityService.getGsiExecutionActivityMapAsList();

        // Pass the GSI execution data list to the Thymeleaf template
        model.addAttribute("gsiExecutionDataList", gsiExecutionDataList);

        // Return the Thymeleaf template name
        return "gsiExecutionTemplate";
    }

    @GetMapping("/ui/cu/details")
    public String displayCuTable(Model model) {
        log.info("returning a page with Failed CU details table");

        List<Map<String, String>> cuDataList = gsiActivityService.getCuExecutionActivityMapAsList();

        // Pass the GSI execution data list to the Thymeleaf template
        model.addAttribute("cuDataList", cuDataList);

        // Return the Thymeleaf template name
        return "cuDetailsTable";
    }

    @GetMapping("/ui/gsi/analytics")
    public String gsiAnalytics(Model model) {

        List<Map<String, Long>> result = gsiActivityService.getGsiAnalyticsMapAsList();

        model.addAttribute("gsiSuccessCountList", result.get(0));
        model.addAttribute("gsiFailureCountList", result.get(1));

        log.info("gsi success vs failure analysis");

        return "gsiCountTreeMap";
    }

    @GetMapping("/ui/user/analytics")
    public String userActivityAnalytics(@RequestParam(defaultValue = "1") int windowSizeInHours, Model model) {

        validateWindowSize(windowSizeInHours);

        log.info("Received request to get user activity table for last {} hours.", windowSizeInHours);

        List<UserActivityInfo> userActivityList = userActivityService.getUserActivityListByTimeWindow(windowSizeInHours);

        log.info("Successfully retrieved user activity table for last {} hours.", windowSizeInHours);

        model.addAttribute("userActivityList", userActivityList);

        return "userActivityTable";
    }

    @GetMapping("/ui/tenant/analytics")
    public String tenantActivityAnalytics(@RequestParam(defaultValue = "1") int windowSizeInHours, Model model) {

        validateWindowSize(windowSizeInHours);

        log.info("Received request to get tenant activity table for last {} hours.", windowSizeInHours);

        List<TenantActivityInfo> result = tenantActivityService.getTenantActivityListByTimeWindow(windowSizeInHours);

        log.info("Successfully retrieved tenant activity table for last {} hours.", windowSizeInHours);

        model.addAttribute("tenantActivityList", result);

        return "tenantActivityTable";
    }

    @GetMapping("ui/user/{userId}/{emailId}")
    public String userActivity(@PathVariable long userId, @PathVariable String emailId,
        @RequestParam (defaultValue = "1") int windowSizeInHours, Model model) {

        validateWindowSize(windowSizeInHours);

        log.info("Received request to get user activity details for last {} hours.", windowSizeInHours);

        UserActivityInfo userActivityInfo = userActivityService.getActivityByUserIdAndTimeWindow(userId, emailId,
            windowSizeInHours, DISPLAY_CONTROLLER);

        log.info("Successfully retrieved user activity details for last {} hours.", windowSizeInHours);

        model.addAttribute("userActivityInfoObj", userActivityInfo);
        model.addAttribute("userId", userId);
        model.addAttribute("emailId", emailId);

        List<Map<String, ContainerCuInfo>> containerCuNames = new ArrayList<>();
        if (userActivityInfo.getContainerCuNames() != null) {
            for (Map.Entry<String, ContainerCuInfo> entry : userActivityInfo.getContainerCuNames().entrySet()) {
                String key = entry.getKey();
                ContainerCuInfo value = entry.getValue();
                Map<String, ContainerCuInfo> map = new HashMap<>();
                map.put(key, value);
                containerCuNames.add(map);
            }
        }

        model.addAttribute("containerCuNames", containerCuNames);

        return "userActivity";
    }

    @GetMapping("ui/tenant/{tenantId}")
    public String tenantActivity(@PathVariable String tenantId,
        @RequestParam (defaultValue = "1") int windowSizeInHours, Model model) {

        validateWindowSize(windowSizeInHours);

        log.info("Received request to get tenant activity details for last {} hours.", windowSizeInHours);

        TenantActivityInfo tenantActivityInfo = tenantActivityService.getActivityByTenantIdAndTimeWindow(tenantId,
            windowSizeInHours, DISPLAY_CONTROLLER);

        log.info("Successfully retrieved tenant activity details for last {} hours.", windowSizeInHours);

        model.addAttribute("tenantId", tenantId);
        model.addAttribute("users", tenantActivityInfo.getUsers());
        model.addAttribute("tenantActivityInfo", tenantActivityInfo);
        model.addAttribute("historyServiceUrl", historyServiceUrl);
        model.addAttribute("historyServiceUsername", historyServiceUsername);
        model.addAttribute("historyServicePassword", historyServicePassword);

        List<Map<String, ContainerCuInfo>> containerCuNames = new ArrayList<>();
        if (tenantActivityInfo.getContainerCuNames() != null) {
            for (Map.Entry<String, ContainerCuInfo> entry : tenantActivityInfo.getContainerCuNames().entrySet()) {
                String key = entry.getKey();
                ContainerCuInfo value = entry.getValue();
                Map<String, ContainerCuInfo> map = new HashMap<>();
                map.put(key, value);
                containerCuNames.add(map);
            }
        }

        model.addAttribute("containerCuNames", containerCuNames);

        return "tenantActivity";
    }

    @GetMapping("/ui/gsi/trends")
    public String displayGsiTrends(Model model) {

        log.info("Returning a page which contains gsi and cu activities in hierarchical manner");

        ConcurrentHashMap<Long, GsiTrendsValueInfo> response = gsiActivityService.getGsiTrendsMap();
        model.addAttribute("gsiTrendsMap", response);
        model.addAttribute("grafanaBaseUrl", grafanaBaseUrl);
        model.addAttribute("grafanaOrgId", grafanaOrgId);
        model.addAttribute("grafanaDatasource", grafanaDataSource);
        model.addAttribute("grafanaBaseEnv", new ArrayList<>(Arrays.asList(grafanaEnv)));

        return "gsiTrendsTable";
    }

    @GetMapping("/ui/gsi/trends/{gsiName}")
    public String displayForGsiTrendsByName(Model model, @PathVariable String gsiName) {

        log.info("Returning a page which contains gsi and cu activities in hierarchical manner" +
                " for the following gsi:{} ",gsiName);

        ConcurrentHashMap<Long, GsiTrendsValueInfo> response = gsiActivityService.getGsiTrendsMapByName(gsiName);
        model.addAttribute("gsiTrendsMap", response);
        model.addAttribute("gsiTrendsMap", response);
        model.addAttribute("grafanaBaseUrl", grafanaBaseUrl);
        model.addAttribute("grafanaOrgId", grafanaOrgId);
        model.addAttribute("grafanaDatasource", grafanaDataSource);
        model.addAttribute("grafanaBaseEnv", new ArrayList<>(Arrays.asList(grafanaEnv)));

        return "gsiTrends";
    }

    private void validateWindowSize(int windowSizeInHours) {
        if (windowSizeInHours != 1 && windowSizeInHours != 3 && windowSizeInHours != 6 &&
            windowSizeInHours != 12 && windowSizeInHours != 24) {
            throw new IllegalArgumentException("Invalid window size specified. Valid values are 1, 3, 6, 12, 24.");
        }
    }
}
