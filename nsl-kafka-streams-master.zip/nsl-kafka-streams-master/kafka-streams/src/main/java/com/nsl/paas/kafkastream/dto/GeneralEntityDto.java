package com.nsl.paas.kafkastream.dto;

import java.util.List;

public record GeneralEntityDto(Long geId,
                               String name,
                               Long geMasterId,
                               List<AttributeDto> listOfAttributes){

}
