package com.nsl.paas.kafkastream.controller;

import static com.nsl.paas.kafkastream.constants.AppConstants.SUCCESS_MSG;
import static com.nsl.paas.kafkastream.constants.AppConstants.TRANSACTION_CONTROLLER;

import com.nsl.paas.kafkastream.dto.APIResponse;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.GsiFinalTransactionValueDto;
import com.nsl.paas.kafkastream.dto.CuTransactionKeyDto;
import com.nsl.paas.kafkastream.dto.CuTransactionValueDto;
import com.nsl.paas.kafkastream.dto.UserKeyDto;
import com.nsl.paas.kafkastream.exceptions.InvalidRequestException;
import com.nsl.paas.kafkastream.exceptions.KafkaStoreAccessException;
import com.nsl.paas.kafkastream.exceptions.NotFoundException;
import com.nsl.paas.kafkastream.model.GsiTrendsValueInfo;
import com.nsl.paas.kafkastream.model.TenantActivityInfo;
import com.nsl.paas.kafkastream.model.UserActivityInfo;
import com.nsl.paas.kafkastream.service.GsiActivityService;
import com.nsl.paas.kafkastream.service.TenantActivityService;
import com.nsl.paas.kafkastream.service.UserActivityService;
import io.swagger.v3.oas.annotations.Operation;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping(value = "/api")
public class TransactionController {

    @Autowired
    StreamsBuilderFactoryBean factoryBean;

    @Autowired
    private UserActivityService userActivityService;

    @Autowired
    private TenantActivityService tenantActivityService;

    @Autowired
    private GsiActivityService gsiActivityService;

    private static final Logger log = LoggerFactory.getLogger(TransactionController.class);

    @Operation(summary = "get Completed GSI Count", description= "This end point will allows the user to retrieve the count of GSIs transactions which are completed.\n gsi Name should be provided as input.")
    @GetMapping("/gsi/completed/count/{gsiName}")
    public ResponseEntity<APIResponse> gsiCompletedCount(@PathVariable String gsiName) {

        APIResponse apiResponse;
        try {
            log.info("Received request to fetch completion count for gsiName: {}", gsiName);

            final Long count = gsiActivityService.getCompletedGsiCountByGsiName(gsiName);
            apiResponse = new APIResponse(SUCCESS_MSG, count, HttpStatus.OK.value());

            log.info("Successfully processed request to fetch completion count for gsiName: {}", gsiName);
            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (NotFoundException e) {
            log.error("Error processing gsiCompletedCount request: {}", e.getMessage(), e);
            apiResponse = new APIResponse(e.getMessage(),
                null, HttpStatus.NOT_FOUND.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing gsiCompletedCount request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing gsiCompletedCount request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing gsiCompletedCount request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing gsiCompletedCount request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "get failed GSI Count", description= "This end point will allows the user to retrieve the count of GSIs transactions failure activity.\n gsi Name should be provided as input.")
    @GetMapping("/gsi/failed/count/{gsiName}")
    public ResponseEntity<APIResponse> gsiFailedCount(@PathVariable String gsiName) {

        APIResponse apiResponse;
        try {
            log.info("Received request to fetch failure count for gsiName: {}", gsiName);

            final Long count = gsiActivityService.getFailedGsiCountByGsiName(gsiName);
            apiResponse = new APIResponse(SUCCESS_MSG, count, HttpStatus.OK.value());

            log.info("Successfully processed request to fetch failure count for gsiName: {}", gsiName);

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (NotFoundException e) {
            log.error("Error processing gsiFailedCount request: {}", e.getMessage(), e);
            apiResponse = new APIResponse(e.getMessage(),
                null, HttpStatus.NOT_FOUND.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing gsiFailedCount request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing gsiFailedCount request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing gsiFailedCount request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing gsiFailedCount request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "get GSI execution duration  ", description= "This end point will allows the user to retrieve the duration of gsi transaction.\n inputs required are [gsiName,transactionId,TenantId].")
    @GetMapping("/duration/{gsiName}/{transactionId}/{tenantId}")
    public ResponseEntity<APIResponse> getGsiDuration(@PathVariable String gsiName, @PathVariable long transactionId, @PathVariable String tenantId) {

        APIResponse apiResponse;
        try {
            log.info("Received request to fetch duration for gsiName '{}', transactionId '{}' and tenantId '{}'", gsiName, transactionId, tenantId);

            final GsiFinalTransactionValueDto values = gsiActivityService.getGsiDurationByTxnIdAndNameAndTenantId(gsiName, transactionId, tenantId);
            apiResponse = new APIResponse(SUCCESS_MSG, values, HttpStatus.OK.value());

            log.info("Successfully processed request to fetch duration.");

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (NotFoundException e) {
            log.error("Error processing getGsiDuration request: {}", e.getMessage(), e);
            apiResponse = new APIResponse(e.getMessage(),
                null, HttpStatus.NOT_FOUND.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing getGsiDuration request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getGsiDuration request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing getGsiDuration request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getGsiDuration request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "get Completed GSI Count list", description= "This end point will allows the user to retrieve the count of GSIs transactions which are completed.")
    @GetMapping("/_facets")
    public ResponseEntity<APIResponse> facets() {

        APIResponse apiResponse;
        try {
            log.info("Received request to fetch success GSI count list");

            final Map<String, Long> result = gsiActivityService.getCompletedGsiCountMap();
            apiResponse = new APIResponse(SUCCESS_MSG, result, HttpStatus.OK.value());

            log.info("Successfully processed request to fetch success Gsi count list.");

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing facets request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing facets request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing facets request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing facets request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "get failed Cu details", description= "This end point will allows the user to check the failed CU level transaction Execution details.")
    @GetMapping("/cu/details")
    public ResponseEntity<APIResponse> cuTable() {

        APIResponse apiResponse;
        try {
            log.info("Received request to fetch cu table.");

            final Map<CuTransactionKeyDto, CuTransactionValueDto> result = gsiActivityService.getCuExecutionActivityMap();
            apiResponse = new APIResponse(SUCCESS_MSG, result, HttpStatus.OK.value());

            log.info("Successfully processed request to fetch cu table.");
            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing cuTable request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing cuTable request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing cuTable request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing cuTable request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "get GSI level execution details", description= "This end point will allows the user to check the GSI level transaction Execution details.")
    @GetMapping("/gsi/details")
    public ResponseEntity<APIResponse> gsiTable() {

        APIResponse apiResponse;
        try {
            log.info("Received request to fetch GSI table.");

            final Map<GsiFinalTransactionKeyDto, GsiFinalTransactionValueDto> result = gsiActivityService.getGsiExecutionActivityMap();
            apiResponse = new APIResponse(SUCCESS_MSG, result, HttpStatus.OK.value());

            log.info("Successfully processed request to fetch Gsi table.");

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing gsiTable request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing gsiTable request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing gsiTable request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing gsiTable request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "Get User level activity details in the provided time window",
        description = "This endpoint allows to get user activity details in the specified time window.")
    @GetMapping("/users/activity")
    public ResponseEntity<APIResponse> getUsersActivityDetailsByTimeWindow(@RequestParam(defaultValue = "1") int page,
        @RequestParam(defaultValue = "10") int pageSize, @RequestParam(defaultValue = "totalTransactions") String sortBy,
        @RequestParam(defaultValue = "desc") String sortOrder, @RequestParam(defaultValue = "1") int windowSizeInHours) {

        APIResponse apiResponse;
        try {
            validateWindowSize(windowSizeInHours);

            log.info("Fetching results from windowed table for all active users.");

            Map<UserKeyDto, UserActivityInfo> result = userActivityService.getUserActivityInfoByTimeWindow(page, pageSize, sortBy, sortOrder, windowSizeInHours);
            apiResponse = new APIResponse(SUCCESS_MSG, result, HttpStatus.OK.value());

            log.info("Successfully fetched result from table for all users.");

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (InvalidRequestException e) {
            log.error("Invalid window size specified: {}. Valid values are 1, 3, 6, 12, 24.", windowSizeInHours);
            apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing getUsersActivityDetailsByTimeWindow request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getUsersActivityDetailsByTimeWindow request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing getUsersActivityDetailsByTimeWindow request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getUsersActivityDetailsByTimeWindow request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "Get tenant level activity details in the provided time window",
        description = "This endpoint allows to get tenant activity details in the specified time window.")
    @GetMapping("/tenants/activity")
    public ResponseEntity<APIResponse> getTenantsActivityDetailsByTimeWindow(@RequestParam(defaultValue = "1") int page,
        @RequestParam(defaultValue = "10") int pageSize, @RequestParam(defaultValue = "totalTransactions") String sortBy,
        @RequestParam(defaultValue = "desc") String sortOrder, @RequestParam(defaultValue = "1") int windowSizeInHours) {

        APIResponse apiResponse;
        try {
            validateWindowSize(windowSizeInHours);

            log.info("Fetching results from windowed table for all active tenants.");

            Map<String, TenantActivityInfo> result = tenantActivityService.getTenantActivityInfoByTimeWindow(page, pageSize, sortBy, sortOrder, windowSizeInHours);
            apiResponse = new APIResponse(SUCCESS_MSG, result, HttpStatus.OK.value());

            log.info("Successfully fetched result from table for all tenants.");

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (InvalidRequestException e) {
            log.error("Invalid window size specified: {}. Valid values are 1, 3, 6, 12, 24.", windowSizeInHours);
            apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing getTenantsActivityDetailsByTimeWindow request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getTenantsActivityDetailsByTimeWindow request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing getTenantsActivityDetailsByTimeWindow request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getTenantsActivityDetailsByTimeWindow request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "Get user activity details by userId & emailId in given time window.",
        description = "This endpoint provides activity details for a given user in the provided time window.")
    @GetMapping("/users/{userId}/{emailId}")
    public ResponseEntity<APIResponse> getUserActivityDetailsByTimeWindow(@PathVariable long userId,
        @PathVariable String emailId, @RequestParam(defaultValue = "1") int windowSizeInHours) {

        APIResponse apiResponse;
        try {
            validateWindowSize(windowSizeInHours);

            log.info("Received request to get user activity details for last {} hours.", windowSizeInHours);

            UserActivityInfo userActivityInfo = userActivityService.getActivityByUserIdAndTimeWindow(userId, emailId,
                windowSizeInHours, TRANSACTION_CONTROLLER);
            Map<UserKeyDto, UserActivityInfo> responseMap = new HashMap<>();
            responseMap.put(new UserKeyDto(userId, emailId), userActivityInfo);
            apiResponse = new APIResponse(SUCCESS_MSG, responseMap, HttpStatus.OK.value());

            log.info("Successfully retrieved user activity details.");

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (InvalidRequestException e) {
            log.error("Invalid window size specified: {}. Valid values are 1, 3, 6, 12, 24.", windowSizeInHours);
            apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
        } catch (NotFoundException e) {
            log.error("Error processing getUserActivityDetailsByTimeWindow request: {}", e.getMessage(), e);
            apiResponse = new APIResponse(e.getMessage(),
                null, HttpStatus.NOT_FOUND.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing getUserActivityDetailsByTimeWindow request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getUserActivityDetailsByTimeWindow request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing getUserActivityDetailsByTimeWindow request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getUserActivityDetailsByTimeWindow request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "Get tenant activity details by tenantId in given time window.",
        description = "This endpoint provides activity details for a given tenant in the provided time window.")
    @GetMapping("/tenants/{tenantId}")
    public ResponseEntity<APIResponse> getTenantActivityDetailsByTimeWindow(@PathVariable String tenantId,
        @RequestParam(defaultValue = "1") int windowSizeInHours) {

        APIResponse apiResponse;
        try {
            validateWindowSize(windowSizeInHours);

            log.info("Received request to get tenant activity details for last {} hours.", windowSizeInHours);

            TenantActivityInfo tenantActivityInfo = tenantActivityService.getActivityByTenantIdAndTimeWindow(tenantId,
                windowSizeInHours, TRANSACTION_CONTROLLER);
            Map<String, TenantActivityInfo> responseMap = new HashMap<>();
            responseMap.put(tenantId, tenantActivityInfo);
            apiResponse = new APIResponse(SUCCESS_MSG, responseMap, HttpStatus.OK.value());

            log.info("Successfully retrieved tenant activity details.");

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (InvalidRequestException e) {
            log.error("Invalid window size specified: {}. Valid values are 1, 3, 6, 12, 24.", windowSizeInHours);
            apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
        } catch (NotFoundException e) {
            log.error("Error processing getTenantActivityDetailsByTimeWindow request: {}", e.getMessage(), e);
            apiResponse = new APIResponse(e.getMessage(),
                null, HttpStatus.NOT_FOUND.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing getTenantActivityDetailsByTimeWindow request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getTenantActivityDetailsByTimeWindow request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing getTenantActivityDetailsByTimeWindow request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getTenantActivityDetailsByTimeWindow request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "Get total number of active users in an environment in given time window.",
        description = "This endpoint provides the count of users who did transactions in the given time window.")
    @GetMapping("/users/active/count")
    public ResponseEntity<APIResponse> getActiveUserCount(@RequestParam(defaultValue = "1") int windowSizeInHours) {

        APIResponse apiResponse;
        try {
            validateWindowSize(windowSizeInHours);

            log.info("Received request to get total active users count for the last {} hours.", windowSizeInHours);

            Long activeUsersCount = userActivityService.getActiveUserCountByTimeWindow(windowSizeInHours);
            apiResponse = new APIResponse(SUCCESS_MSG, activeUsersCount, HttpStatus.OK.value());

            log.info("Successfully retrieved total active users count: {}.", activeUsersCount);

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (InvalidRequestException e) {
            log.error("Invalid window size specified: {}. Valid values are 1, 3, 6, 12, 24.", windowSizeInHours);
            apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing getActiveUserCount request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getActiveUserCount request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing getActiveUserCount request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getActiveUserCount request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "Get total number of active tenants in an environment in given time window.",
        description = "This endpoint provides the count of tenants who did transactions in the given time window.")
    @GetMapping("/tenants/active/count")
    public ResponseEntity<APIResponse> getActiveTenantCount(@RequestParam(defaultValue = "1") int windowSizeInHours) {

        APIResponse apiResponse;
        try {
            validateWindowSize(windowSizeInHours);

            log.info("Received request to get total active tenants count for the last {} hours.", windowSizeInHours);

            Long activeTenantsCount = tenantActivityService.getActiveTenantCountByTimeWindow(windowSizeInHours);
            apiResponse = new APIResponse(SUCCESS_MSG, activeTenantsCount, HttpStatus.OK.value());

            log.info("Successfully retrieved total active tenants count: {}.", activeTenantsCount);

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (InvalidRequestException e) {
            log.error("Invalid window size specified: {}. Valid values are 1, 3, 6, 12, 24.", windowSizeInHours);
            apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing getActiveTenantCount request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getActiveTenantCount request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing getActiveTenantCount request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getActiveTenantCount request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "get GSI and Cu level execution details", description= "This end point will allows the user to" +
            " check the GSI and Cu level activity in a hierarchical structure")
    @GetMapping("/gsi/trends")
    public ResponseEntity<APIResponse> getGsiTrendsAnalysis()  {

        APIResponse apiResponse;
        try {
            log.info("Request received to fetch GSI TRENDS analysis");

            final ConcurrentHashMap<Long, GsiTrendsValueInfo> response = gsiActivityService.getGsiTrendsMap();
            apiResponse = new APIResponse(SUCCESS_MSG, response, HttpStatus.OK.value());

            log.info("Successfully retrieved the GSI TRENDS analysis.");

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing getGsiTrendsAnalysis request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getGsiTrendsAnalysis request: " + e.getMessage(),
                    e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing getGsiTrendsAnalysis request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getGsiTrendsAnalysis request: " + e.getMessage(),
                    null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "get GSI and Cu level execution details of the provided gsi names", description= "This end point" +
        " will allows the user to fetch the GSI and Cu level activity in a hierarchical structure of the given gsi names")
    @GetMapping("/gsi/trends/{gsiName}")
    public ResponseEntity<APIResponse> gsiTrendsAnalysisByName(@PathVariable String gsiName) {

        APIResponse apiResponse;
        try {

            log.info("Request received to fetch GSI TRENDS analysis for following gsi: {}", gsiName);

            ConcurrentHashMap<Long, GsiTrendsValueInfo> response = gsiActivityService.getGsiTrendsMapByName(gsiName);

            apiResponse = new APIResponse(SUCCESS_MSG, response, HttpStatus.OK.value());

            log.info("Successfully retrieved GSI TRENDS analysis.");

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing gsiCuTableList request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing gsiTrendsAnalysisByName request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing gsiCuTableList request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing gsiTrendsAnalysisByName request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "get all the reservedCu types that has been executed", description= "This end point" +
            " will allows the user to fetch all the reservedCu types that has been executed recently")
    @GetMapping("/cu/all/reservedCu")
    public ResponseEntity<APIResponse> allReservedCuTypes() {

        APIResponse apiResponse;
        try {

            log.info("Request received to fetch different reservedCu Types");

            Map<String, Set<String>> response = gsiActivityService.getReservedCuTypes();

            apiResponse = new APIResponse(SUCCESS_MSG, response, HttpStatus.OK.value());

            log.info("Successfully retrieved different reservedCu Types");

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing allReservedCuTypes request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing allReservedCuTypes request: " + e.getMessage(),
                    e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing allReservedCuTypes request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing allReservedCuTypes request: " + e.getMessage(),
                    null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Operation(summary = "get list of all tenants where transactions have happened in specified time window.",
    description = "returns a list of active tenants in provided time window.")
    @GetMapping("/v1/active/tenants")
    public ResponseEntity<APIResponse> getActiveTenants(@RequestParam(defaultValue = "1") int windowSizeInHours) {

        APIResponse apiResponse;
        try {
            validateWindowSize(windowSizeInHours);

            log.info("Received request to get active tenants list for the last {} hours.", windowSizeInHours);

            List<String> activeTenants = tenantActivityService.getActiveTenantsListByTimeWindow(windowSizeInHours);
            apiResponse = new APIResponse(SUCCESS_MSG, activeTenants, HttpStatus.OK.value());

            log.info("Successfully retrieved active tenants list: {}.", activeTenants);

            return new ResponseEntity<>(apiResponse, HttpStatus.OK);
        } catch (InvalidRequestException e) {
            log.error("Invalid window size specified: {}. Valid values are 1, 3, 6, 12, 24.", windowSizeInHours);
            apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.BAD_REQUEST.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
        } catch (KafkaStoreAccessException e) {
            log.error("Error processing getActiveTenants request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getActiveTenants request: " + e.getMessage(),
                e.getExceptionType(), HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Error processing getActiveTenants request: {}", e.getMessage(), e);
            apiResponse = new APIResponse("Error processing getActiveTenants request: " + e.getMessage(),
                null, HttpStatus.INTERNAL_SERVER_ERROR.value());
            return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private void validateWindowSize(int windowSizeInHours) {
        if (windowSizeInHours != 1 && windowSizeInHours != 3 && windowSizeInHours != 6 &&
            windowSizeInHours != 12 && windowSizeInHours != 24) {
            throw new InvalidRequestException("Invalid window size specified. Valid values are 1, 3, 6, 12, 24.");
        }
    }
}