package com.nsl.paas.kafkastream.model;

import java.util.Map;
import java.util.Set;

public class UserActivityInfo implements ActivityInfo {

    private String emailId;
    private long userId;
    private Set<String> tenants;
    private Map<String, ContainerCuInfo> containerCuNames;
    private long avgDuration;
    private long totalDuration;
    private String readableTotalDuration;
    private long totalTransactions;
    private long totalFailedTransactions;
    private long totalCompletedTransactions;
    private long totalIncompleteTransactions;
    private String lastRunContainerCuName;

    // Giving default constructor so that jackson can perform serdes.
    public UserActivityInfo() {}

    private UserActivityInfo(Builder builder) {
        this.emailId = builder.emailId;
        this.userId = builder.userId;
        this.tenants = builder.tenants;
        this.containerCuNames = builder.containerCuNames;
        this.avgDuration = builder.avgDuration;
        this.totalDuration = builder.totalDuration;
        this.readableTotalDuration = builder.readableTotalDuration;
        this.totalTransactions = builder.totalTransactions;
        this.totalFailedTransactions = builder.totalFailedTransactions;
        this.totalCompletedTransactions = builder.totalCompletedTransactions;
        this.totalIncompleteTransactions = builder.totalIncompleteTransactions;
        this.lastRunContainerCuName = builder.lastRunContainerCuName;
    }

    public String getEmailId() {
        return emailId;
    }

    public long getUserId() {
        return userId;
    }

    public Set<String> getTenants() {
        return tenants;
    }

    public Map<String, ContainerCuInfo> getContainerCuNames() {
        return containerCuNames;
    }

    public long getAvgDuration() {
        return avgDuration;
    }

    public long getTotalDuration() {
        return totalDuration;
    }

    public String getReadableTotalDuration() {
        return readableTotalDuration;
    }

    public long getTotalTransactions() {
        return totalTransactions;
    }

    public long getTotalFailedTransactions() {
        return totalFailedTransactions;
    }

    public long getTotalCompletedTransactions() {
        return totalCompletedTransactions;
    }

    public long getTotalIncompleteTransactions() {
        return totalIncompleteTransactions;
    }

    public String getLastRunContainerCuName() {
        return lastRunContainerCuName;
    }

    public static Builder Builder() {
        return new Builder();
    }

    public static class Builder {

        private String emailId;
        private long userId;
        private Set<String> tenants;
        private Map<String, ContainerCuInfo> containerCuNames;
        private long avgDuration;
        private long totalDuration;
        private String readableTotalDuration;
        private long totalTransactions;
        private long totalFailedTransactions;
        private long totalCompletedTransactions;
        private long totalIncompleteTransactions;
        private String lastRunContainerCuName;

        public Builder withEmailId(String emailId) {
            this.emailId = emailId;
            return this;
        }

        public Builder withUserId(long userId) {
            this.userId = userId;
            return this;
        }

        public Builder withTenantIds(Set<String> tenants) {
            this.tenants = tenants;
            return this;
        }

        public Builder withContainerCuNames(Map<String, ContainerCuInfo> containerCuNames) {
            this.containerCuNames = containerCuNames;
            return this;
        }

        public Builder withAvgDuration(long avgDuration) {
            this.avgDuration = avgDuration;
            return this;
        }

        public Builder withTotalDuration(long totalDuration) {
            this.totalDuration = totalDuration;
            return this;
        }

        public Builder withReadableTotalDuration(String readableTotalDuration) {
            this.readableTotalDuration = readableTotalDuration;
            return this;
        }

        public Builder withTotalTransactions(long totalTransactions) {
            this.totalTransactions = totalTransactions;
            return this;
        }

        public Builder withTotalFailedTransactions(long totalFailedTransactions) {
            this.totalFailedTransactions = totalFailedTransactions;
            return this;
        }

        public Builder withTotalCompletedTransactions(long totalCompletedTransactions) {
            this.totalCompletedTransactions = totalCompletedTransactions;
            return this;
        }

        public Builder withLastRunContainerCuName(String name) {
            this.lastRunContainerCuName = name;
            return this;
        }

        public Builder withTotalIncompleteTransactions(long totalIncompleteTransactions) {
            this.totalIncompleteTransactions = totalIncompleteTransactions;
            return this;
        }

        public UserActivityInfo build() {
            return new UserActivityInfo(this);
        }
    }

    @Override
    public String toString() {
        return "UserActivityInfo{" +
            "emailId='" + emailId + '\'' +
            ", userId=" + userId +
            ", tenants=" + tenants +
            ", containerCuNames=" + containerCuNames +
            ", avgDuration=" + avgDuration +
            ", totalDuration=" + totalDuration +
            ", readableTotalDuration='" + readableTotalDuration + '\'' +
            ", totalTransactions=" + totalTransactions +
            ", totalFailedTransactions=" + totalFailedTransactions +
            ", totalCompletedTransactions=" + totalCompletedTransactions +
            ", totalIncompleteTransactions=" + totalIncompleteTransactions +
            ", lastRunContainerCuName='" + lastRunContainerCuName + '\'' +
            '}';
    }
}