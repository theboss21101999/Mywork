package com.nsl.paas.kafkastream.service;

import com.nsl.paas.kafkastream.model.TenantActivityInfo;
import java.util.List;
import java.util.Map;

public interface TenantActivityService {

    List<TenantActivityInfo> getTenantActivityListByTimeWindow(final int windowSizeInHours);

    Long getActiveTenantCountByTimeWindow(final int windowSizeInHours);

    TenantActivityInfo getActivityByTenantIdAndTimeWindow(final String tenantId, final int windowSizeInHours,
                                                          final String controller);

    Map<String, TenantActivityInfo> getTenantActivityInfoByTimeWindow(final int page, final int pageSize,
                                final String sortBy, final String sortOrder, final int windowSizeInHours);

    List<String> getActiveTenantsListByTimeWindow(final int windowSizeInHours);
}
