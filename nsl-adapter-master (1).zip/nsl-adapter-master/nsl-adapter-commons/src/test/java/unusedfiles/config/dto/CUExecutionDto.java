package unusedfiles.config.dto;

import com.nsl.logical.model.ReferenceEntityInfoRequest;
import com.nsl.logical.model.TxnData;

import java.io.Serializable;
import java.util.Map;

public class CUExecutionDto implements Serializable {

    private static final long serialVersionUID = 1335298010542796253L;
    private Long triggerCuId;
    private Long gsiId;
    private TxnData txnData;
    private String transID;
    private String gsiName;

    // changes for Mind CU
    private String baseTransID;
    private String transType;
    private String triggerContextualId;
    private String baseContextualId;
    private String masterTxnId;
    private Map<String, String> masterTransactionIdRecords;

    // Adding as the base contextual ID in the case of Parallel Framework
    private String gsiContextualId;

    private ReferenceEntityInfoRequest referenceEntityInfo;

    public CUExecutionDto() {}

    public CUExecutionDto(Long triggerCuId, Long gsiId, TxnData txnData, String transID,
                          String baseTransID, String transType, String triggerContextualId, String gsiContextualId) {
        this.triggerCuId = triggerCuId;
        this.gsiId = gsiId;
        this.txnData = txnData;
        this.transID = transID;
        this.baseTransID = baseTransID;
        this.transType = transType;
        this.triggerContextualId = triggerContextualId;
        this.gsiContextualId = gsiContextualId;
    }

    public String getGsiContextualId() {
        return gsiContextualId;
    }

    public void setGsiContextualId(String gsiContextualId) {
        this.gsiContextualId = gsiContextualId;
    }

    public String getTriggerContextualId() {
        return triggerContextualId;
    }

    public void setTriggerContextualId(String triggerContextualId) {
        this.triggerContextualId = triggerContextualId;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getBaseTransID() {
        return baseTransID;
    }

    public void setBaseTransID(String baseTransID) {
        this.baseTransID = baseTransID;
    }

    public Long getTriggerCuId() {
        return triggerCuId;
    }

    public void setTriggerCuId(Long triggerCuId) {
        this.triggerCuId = triggerCuId;
    }

    public Long getGsiId() {
        return gsiId;
    }

    public void setGsiId(Long containerCuId) {
        this.gsiId = containerCuId;
    }

    public String getTransID() {
        return transID;
    }

    public void setTransID(String transID) {
        this.transID = transID;
    }

    public TxnData getTxnData() {
        return txnData;
    }

    public void setTxnData(TxnData txnData) {
        this.txnData = txnData;
    }

    public Map<String, String> getMasterTransactionIdRecords() {
        return masterTransactionIdRecords;
    }

    public void setMasterTransactionIdRecords(Map<String, String> masterTransactionIdRecords) {
        this.masterTransactionIdRecords = masterTransactionIdRecords;
    }

    public String getGsiName() {
        return gsiName;
    }

    public String getBaseContextualId() {
        return baseContextualId;
    }

    public void setBaseContextualId(String baseContextualId) {
        this.baseContextualId = baseContextualId;
    }

    public String getMasterTxnId() {
        return masterTxnId;
    }

    public void setMasterTxnId(String masterTxnId) {
        this.masterTxnId = masterTxnId;
    }

    public void setGsiName(String gsiName) {
        this.gsiName = gsiName;
    }

    public ReferenceEntityInfoRequest getReferenceEntityInfo() {
        return referenceEntityInfo;
    }

    public void setReferenceEntityInfo(ReferenceEntityInfoRequest referenceEntityInfo) {
        this.referenceEntityInfo = referenceEntityInfo;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("CUExecutionDto [id=");
        builder.append(gsiId);
        builder.append(", triggerCuId=");
        builder.append(triggerCuId);
        builder.append(", transID=");
        builder.append(transID);
        builder.append(", gsiName=");
        builder.append(gsiName);
        builder.append(", baseTransID=");
        builder.append(baseTransID);
        builder.append(", transType=");
        builder.append(transType);
        builder.append(", triggerContextualId=");
        builder.append(triggerContextualId);
        builder.append(", baseContextualId=");
        builder.append(baseContextualId);
        builder.append(", masterTxnId=");
        builder.append(masterTxnId);
        builder.append(", gsiContextualId=");
        builder.append(gsiContextualId);
        builder.append("]");
        return builder.toString();
    }
}
