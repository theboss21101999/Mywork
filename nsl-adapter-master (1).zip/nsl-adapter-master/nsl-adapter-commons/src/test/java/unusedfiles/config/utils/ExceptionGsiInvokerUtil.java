package unusedfiles.config.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.model.GSI;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import unusedfiles.config.constants.AppConstant;
import unusedfiles.config.service.ExceptionGsiExecutor;

import java.util.Map;

@Service
public class ExceptionGsiInvokerUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionGsiInvokerUtil.class);

    @Autowired
    AuthenticateCommonUser authenticateUser;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    ExceptionExtSolutionUtil exceptionExtSolutionUtil;

    @Autowired
    ExceptionGsiExecutor gsiExecutor;

    public void invokeGsi(Long gsiMasterId, Map<String, String> msg){
        try{
            setAuthorizationBean(msg);
            String tenantId = msg.get(AppConstant.TENANTID);
            String userEmail = msg.get(AppConstant.EMAIL);
            LOGGER.info("Fetching GSI..");
            GSI gsiMaster = changeUnitDao.getGsiByMasterId(gsiMasterId,null,
                    StatusEnum.PUBLISHED, authenticateUser.getAuthenticatedUser(msg));
            Long gsiId = gsiMaster.getId();
            LOGGER.info("GSI with master id {} fetched successfully..", gsiMaster.getName());
            GSI  gsi = changeUnitDao.getGSI(gsiId,authenticateUser.getAuthenticatedUser(msg));
            TriggerCU triggerCu = gsi.getSolutionLogic().get(0);
            GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu,AppConstant.PHYSICAL_LAYER);
            ObjectMapper objectMapper=new ObjectMapper();
            msg.put("subCategory",msg.get("adapterSubCategory"));
            String jsonObject = new ObjectMapper().writeValueAsString(msg);
            JsonNode jsonNode = objectMapper.readTree(jsonObject);
            TxnGeneralEntity txnGeneralEntity = JSONToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, jsonNode);
            TxnData transData = exceptionExtSolutionUtil.setChangeDriverInTxnData(txnGeneralEntity, LayerType.PHYSICAL);
            gsiExecutor.executeGsi(gsiId, tenantId, userEmail, transData);
        }catch(Exception e){
            LOGGER.error("Exception occurred while invoking GSI in thread {} : {}", Thread.currentThread().getName(), e.getMessage());
        }
    }


    private void setAuthorizationBean(Map<String, String> msg) throws JSONException {
        AuthenticatedUserDetailsImpl authenticatedUser = authenticateUser.getAuthenticatedUser(msg);
        exceptionExtSolutionUtil.setRequestScopedAuthenticatedUserBean(authenticatedUser);
    }



}
