package unusedfiles.config;


import unusedfiles.config.constants.KafkaConstants;
import unusedfiles.config.dto.KafkaConnectionDto;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


public class KafkaProducerConnectionUtil {

    private static final Logger logger = LoggerFactory.getLogger(KafkaProducerConnectionUtil.class);

    private KafkaTemplate<String, String> kafkaTemplate;

    public KafkaTemplate<String, String> getKafkaTemplate() {
        return kafkaTemplate;
    }

    public void setKafkaTemplate(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    private ProducerFactory<String, String> producer(KafkaConnectionDto connection) {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, connection.getBootStrapServer().get(0));
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    public KafkaProducerConnectionUtil(KafkaConnectionDto connection) {
        ProducerFactory<String, String> kafkaProducer = producer(connection);
        setKafkaTemplate(new KafkaTemplate<String, String>(kafkaProducer));
    }


    public void sendMessageTokafka(String kafkaMessage, String topic, String key) {
        String value = kafkaMessage;
        ListenableFuture<SendResult<String, String>> listenablefuture = kafkaTemplate.send(topic, key, value);
        listenablefuture.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {
            @Override
            public void onSuccess(SendResult<String, String> stringStringSendResult) {
                KafkaSuccess(topic, key, value, stringStringSendResult);
                logger.info("msg success");
            }

            @Override
            public void onFailure(Throwable ex) {
                KafkaFailure(topic, value, ex);
                logger.error("msg failed");
            }

        });
    }

    private void KafkaSuccess(String topic, String key, String value, SendResult<String, String> stringStringSendResult) {
        logger.info("Message Sent SuccessFully for the Topic: {} key : {} and the value is {} , result is {}", topic, key, value, stringStringSendResult.getRecordMetadata());

    }

    private void KafkaFailure(String Topic, String value, Throwable ex) {
        logger.info("Message Sent SuccessFully for the Topic: {} key : {} and the value is {}", Topic, value);

        logger.error("Error Sending the Message and the exception is {}", ex.getMessage());
        try {
            throw ex;
        } catch (Throwable throwable) {
            logger.error("Error in OnFailure: {}", throwable.getMessage());
        }

    }

    public  KafkaConnectionDto getKafkaConfig() {

        KafkaConnectionDto kafkaConnectionDto = new KafkaConnectionDto();
        Properties config = new Properties();
        config.put(KafkaConstants.TOPIC,"exception_topic");
        kafkaConnectionDto.setBootStrapServer(Collections.singletonList("localhost:9092"));
        kafkaConnectionDto.setAdvancedConfig(config);
        return kafkaConnectionDto;
    }

}
