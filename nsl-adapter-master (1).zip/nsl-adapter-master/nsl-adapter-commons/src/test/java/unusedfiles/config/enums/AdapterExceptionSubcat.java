package unusedfiles.config.enums;

import com.nsl.logical.std.logs.SubCat;

public enum AdapterExceptionSubcat implements SubCat {
    CONNECTION_FAILURE,
    INVALID_INPUT
}
