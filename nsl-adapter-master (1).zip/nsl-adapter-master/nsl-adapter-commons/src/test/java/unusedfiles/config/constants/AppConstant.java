package unusedfiles.config.constants;


public class AppConstant {

    private AppConstant() {
    }

    public static final String PHYSICAL_LAYER = "physical";
    public static final String TRIGGER_CES_LAYER = "triggerces";
    public static final String UTF_8 = "UTF-8";
    public static final String SUCCESS = "Success";
    public static final String ADAPTER = "adapter";
    public static final String CONFIG_ENTITY_KEY = "reservedCuConfigurationEntity";
    public static final String CONFIG_ENTITY_RECORD_ID = "configEntityRecordId";
    public static final String METAINFO_ENTITY_KEY = "reservedCuMetaInfoEntity";

    public static final String FILENAME = "fileName";
    public static final String FILEPATH = "filePath";
    public static final String FILETYPE = "fileType";
    public static final String CONFILICT = "conflict";
    public static final String REMOTEHOST = "host";
    public static final String PORT = "port";
    public static final String PASSWORD = "password";
    public static final String DATEFORMAT = "dateformat";
    public static final String WORKUNDERPROCESS = "work under progress";
    public static final String FAILURE = "Failure";
    public static final String TYPE = "type";
    public static final String ARRAY = "array";
    public static final String OBJECT = "object";
    public static final String LIST = "List";
    public static final String ENTITY = "Entity";
    public static final String ACCEPT_LANGUAGE_EN = "EN";
    public static final String OPERATION = "operation";
    public static final String DELETE_FILE = "deleteFile";
    public static final String TXN_ID = "txnId";
    public static final String TENANTID = "tenantId";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String BEARER = "Bearer ";
    public static final String CONTENTTYPE = "contentType";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String APPLICATION = "application";
    public static final String TOKEN = "Token";
    public static final String SYSTEM_USER_DETAILS = "systemUserDetails";
    public static final String EN = "en";
    public static final String CUNAME = "cuName";
    public static final String USERID = "userId";
    public static final String USEREMAIL = "userEmail";
    public static final String EMAIL = "email";

}
