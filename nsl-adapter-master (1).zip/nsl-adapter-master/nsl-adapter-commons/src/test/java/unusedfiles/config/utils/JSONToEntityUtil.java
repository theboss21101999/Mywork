package unusedfiles.config.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Splitter;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class JSONToEntityUtil {
    private static final Logger logger = LoggerFactory.getLogger(JSONToEntityUtil.class);

    public static TxnGeneralEntity getTriggerTxnGeneralEntityWithData(GeneralEntity generalEntity,
                                                                      JsonNode txnGeneralEntityData) {

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();
        txnGeneralEntity.setGeneralEntityID(generalEntity.getId());
        txnGeneralEntity.setName(generalEntity.getName());
        List<TxnGeneralEntityRecord> txnGeneralEntityRecordList = new ArrayList<>();
        txnGeneralEntity.setTransEntityRecords(txnGeneralEntityRecordList);
        if (txnGeneralEntityData != null && txnGeneralEntityData.isArray() && !txnGeneralEntityData.isEmpty())
            for (JsonNode entityRecordDataNode : txnGeneralEntityData)
                txnGeneralEntityRecordList
                        .add(buildTxnGeneralEntityRecord(generalEntity.getNslAttributes(), entityRecordDataNode));
        else
            txnGeneralEntityRecordList
                    .add(buildTxnGeneralEntityRecord(generalEntity.getNslAttributes(), txnGeneralEntityData));
        return txnGeneralEntity;
    }

    private static TxnGeneralEntityRecord buildTxnGeneralEntityRecord(List<NslAttribute> nslAttributeList,
                                                                      JsonNode entityRecordDataNode) {
        logger.info(entityRecordDataNode != null ? entityRecordDataNode.toString() : null);
        logger.info("++++++++++++++++++++++++");
        List<TxnNslAttribute> txnNslAttributes = new ArrayList<>();
        TxnGeneralEntityRecord txnGeneralEntityRecord = new TxnGeneralEntityRecord();
        if (nslAttributeList != null) {
            for (NslAttribute nslAttribute : nslAttributeList) {
                TxnNslAttribute attribute = new TxnNslAttribute();
                attribute.setNslAttributeID(nslAttribute.getId());
                attribute.setName(nslAttribute.getName());
                String type = nslAttribute.getAttributeType().getType().toString();
                String name = nslAttribute.getName();
                JsonNode attributeDataNode = null;
                if (entityRecordDataNode != null && entityRecordDataNode.get(name) != null)
                    attributeDataNode = entityRecordDataNode.get(name);

                if (attributeDataNode == null && !type.equalsIgnoreCase("entity"))
                    attribute.setValues(new ArrayList<>());
                else if (type.equalsIgnoreCase("entity") && nslAttribute.getGeneralEntity() != null)
                    attribute.setTxnGeneralEntity(
                            getTriggerTxnGeneralEntityWithData(nslAttribute.getGeneralEntity(), attributeDataNode));
                else if (type.equalsIgnoreCase("list")) {
                    if (nslAttribute.getGeneralEntity() == null) {
                        List<String> values = new ArrayList<>();
                        for (JsonNode node : attributeDataNode) {
                            values.add(node.asText());
                        }
                        attribute.setValues(values);
                    } else {
                        attribute.setTxnGeneralEntity(
                                getTriggerTxnGeneralEntityWithData(nslAttribute.getGeneralEntity(), attributeDataNode));
                    }
                } else if (attributeDataNode != null && (type.equalsIgnoreCase("file") || type.equalsIgnoreCase("image") || type.equalsIgnoreCase("video"))) {
                    String values = generateValueFromNode(attributeDataNode);
                    attribute.setValues(Collections.singletonList(values));
                } else if (attributeDataNode != null)
                    attribute.setValues(Collections.singletonList(attributeDataNode.asText()));

                logger.info(attribute.toString());
                txnNslAttributes.add(attribute);
                txnGeneralEntityRecord.setTxnNslAttribute(txnNslAttributes);
            }
        }
        return txnGeneralEntityRecord;
    }

    private static String generateValueFromNode(JsonNode attributeDataNode) {
        String values = attributeDataNode.asText();
        String preProcessed = values.replace("{", "");
        String processed = preProcessed.replace("}", "");
        Map<String, String> result = Splitter.on(',').trimResults().withKeyValueSeparator(Splitter.on('=').limit(2).trimResults()).split(processed);
        try {
            values = new ObjectMapper().writeValueAsString(result);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return values;
    }
}
