package unusedfiles.config.utils;

import com.nsl.dsd.store.models.tenant.io.TenantCUEntityAttributeInput;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.dsd.store.models.tenant.io.TenantCULayerInput;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import com.nsl.dsd.store.models.tenant.io.TenantSlotItemInput;
import com.nsl.logical.model.*;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class GeneralEntityUtils {

    public static TxnGeneralEntity getExpectedTxnGeneralEntity(List<TxnSlotItem> transEntityDetails, String expectedEntity) {

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();

        if (transEntityDetails != null && !transEntityDetails.isEmpty()) {
            for (TxnSlotItem slot : transEntityDetails) {
                if (slot.getItem() instanceof TxnGeneralEntity) {
                    txnGeneralEntity = (TxnGeneralEntity) slot.getItem();
                    if (((TxnGeneralEntity) slot.getItem()).getName().equalsIgnoreCase(expectedEntity)) {
                        txnGeneralEntity = (TxnGeneralEntity) slot.getItem();
                        break;
                    }
                }
            }
        }

        return txnGeneralEntity;
    }

    public static Map<String,TxnGeneralEntity> getTxnGeneralEntitieswithId(List<TxnSlotItem> transEntityDetails) {

        Map<String,TxnGeneralEntity> txnGeneralEntities = new HashMap<>();

        if (transEntityDetails != null && !transEntityDetails.isEmpty()) {
            for (TxnSlotItem slot : transEntityDetails) {
                if (slot.getItem() instanceof TxnGeneralEntity) {
                    TxnGeneralEntity entity = (TxnGeneralEntity) slot.getItem();
                    txnGeneralEntities.put(entity.getGeneralEntityID().toString(),entity);
                }
            }
        }

        return txnGeneralEntities;
    }

    public static TxnGeneralEntity getExpectedTxnGeneralEntity(List<TxnSlotItem> transEntityDetails) {

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();

        if (transEntityDetails != null && !transEntityDetails.isEmpty()) {
            for (TxnSlotItem slot : transEntityDetails) {
                if (slot.getItem() instanceof TxnGeneralEntity) {
                    txnGeneralEntity = (TxnGeneralEntity) slot.getItem();
                    break;
                }
            }
        }

        return txnGeneralEntity;
    }
    public static List<TxnGeneralEntity> getExpectedTxnMultipleGeneralEntities(List<TxnSlotItem> transEntityDetails) {

        List<TxnGeneralEntity> txnGeneralEntity = new LinkedList<TxnGeneralEntity>();

        if (transEntityDetails != null && !transEntityDetails.isEmpty()) {
            for (TxnSlotItem slot : transEntityDetails) {
                if (slot.getItem() instanceof TxnGeneralEntity) {
                    txnGeneralEntity.add( (TxnGeneralEntity) slot.getItem());
                }
            }
        }
        return txnGeneralEntity;
    }
    
    public static TxnGeneralEntityRecord getTxnEntityfromGeneralEntity(GeneralEntity generalEntity) {
        TxnGeneralEntityRecord txnGeneralEntityRecord = new TxnGeneralEntityRecord();
        
        if(generalEntity==null || generalEntity.getNslAttributes()==null || generalEntity.getNslAttributes().isEmpty())
            return txnGeneralEntityRecord;

        List<TxnNslAttribute> txnNslAttributes = new ArrayList<>();
        for(NslAttribute nslAttribute : generalEntity.getNslAttributes()) {
            TxnNslAttribute attribute = new TxnNslAttribute();
            attribute.setName(nslAttribute.getName());
            attribute.setId(nslAttribute.getId());
            attribute.setValues(Collections.singletonList(nslAttribute.getDefaultValue()));
            txnNslAttributes.add(attribute);
        }
        txnGeneralEntityRecord.setTxnNslAttribute(txnNslAttributes);
        
        return txnGeneralEntityRecord;
    }

    public static Map<String,GeneralEntity> getTriggerCUGeneralEntities(TriggerCU triggerCU, String layerName) {

        Map<String,GeneralEntity> generalEntities = new HashMap<>();
        List<CULayer> cuLayers = triggerCU.getLayers();

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : triggerCU.getLayers()) {
                if (null != layer && null != layer.getParticipatingItems()
                        && layer.getType().getLayerType().equalsIgnoreCase(layerName)) {

                    for (SlotItem slotItem : layer.getParticipatingItems()) {
                        if (null != slotItem && null != slotItem.getItem() && slotItem.getItem() instanceof GeneralEntity) {
                            GeneralEntity generalEntity = (GeneralEntity) slotItem.getItem();
                            generalEntities.put(generalEntity.getId().toString(),generalEntity);
                        }
                    }
                }
            }
        }
        return generalEntities;
    }

    public static GeneralEntity getTriggerCUGeneralEntity(TriggerCU triggerCU, String layerName) {

        GeneralEntity generalEntity = null;
        List<CULayer> cuLayers = triggerCU.getLayers();

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : triggerCU.getLayers()) {
                if (null != layer && null != layer.getParticipatingItems()
                        && layer.getType().getLayerType().equalsIgnoreCase(layerName)) {

                    for (SlotItem slotItem : layer.getParticipatingItems()) {
                        if (null != slotItem && null != slotItem.getItem() && slotItem.getItem() instanceof GeneralEntity) {
                            generalEntity = (GeneralEntity) slotItem.getItem();
                            break;
                        }
                    }
                }
            }
        }
        return generalEntity;
    }
    public static List<GeneralEntity> getTriggerCUMultipleGeneralEntities(TriggerCU triggerCU, String layerName) {

        List<GeneralEntity> generalEntity = new LinkedList<GeneralEntity>();
        List<CULayer> cuLayers = triggerCU.getLayers();

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : triggerCU.getLayers()) {
                if (null != layer && null != layer.getParticipatingItems()
                        && layer.getType().getLayerType().equalsIgnoreCase(layerName)) {

                    for (SlotItem slotItem : layer.getParticipatingItems()) {
                        if (null != slotItem && null != slotItem.getItem() && slotItem.getItem() instanceof GeneralEntity) {
                            generalEntity.add( (GeneralEntity) slotItem.getItem());
                        }
                    }
                }
            }
        }
        return generalEntity;
    }

    public static TxnGeneralEntity getTriggerTxnGeneralEntityStructure(GeneralEntity generalEntity) {

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();
        txnGeneralEntity.setGeneralEntityID(generalEntity.getId());
        txnGeneralEntity.setName(generalEntity.getName());
        List<TxnGeneralEntityRecord> txnGeneralEntityRecordList = new ArrayList<>();

        List<NslAttribute> nslAttributeList = generalEntity.getNslAttributes();

        List<TxnNslAttribute> txnNslAttributes = new ArrayList<>();
        TxnGeneralEntityRecord txnGeneralEntityRecord = new TxnGeneralEntityRecord();
        if (nslAttributeList != null) {
            for (NslAttribute nslAttribute : nslAttributeList) {
                TxnNslAttribute attribute = new TxnNslAttribute();
                attribute.setId(nslAttribute.getId());
                attribute.setName(nslAttribute.getName());
                txnNslAttributes.add(attribute);

                txnGeneralEntityRecord.setTxnNslAttribute(txnNslAttributes);
            }
            txnGeneralEntityRecordList.add(txnGeneralEntityRecord);
        }

        txnGeneralEntity.setTransEntityRecords(txnGeneralEntityRecordList);
        return txnGeneralEntity;
    }

    private static boolean isEmpty(Collection<?> coll) {
        return CollectionUtils.isEmpty(coll);
    }

    public static void updateEntityWithAttributes(TxnGeneralEntity txnGeneralEntity,
                                            List<TxnNslAttribute> txnNslAttributeList) {

        for (TxnNslAttribute attribute : txnNslAttributeList) {

            for (TxnNslAttribute txnNslAttribute : txnGeneralEntity.getTransEntityRecords().get(0).getTxnNslAttribute()) {

                if (attribute.getName().equals(txnNslAttribute.getName())) {

                    attribute.setNslAttributeID(txnNslAttribute.getNslAttributeID() == null ? txnNslAttribute.getId()
                            : txnNslAttribute.getNslAttributeID());
                    break;
                }
            }
        }
        txnGeneralEntity.getTransEntityRecords().get(0).getTxnNslAttribute().clear();
        txnGeneralEntity.getTransEntityRecords().get(0).getTxnNslAttribute().addAll(txnNslAttributeList);
    }

    public static List<TxnSlotItem> getTransEntityDetails(List<TxnCULayer> txnCuLayers, String layer) {

        List<TxnSlotItem> transEntityDetails = new ArrayList<>();
        for (TxnCULayer cuLayer : txnCuLayers) {
            if (cuLayer.getType().getLayerType().equalsIgnoreCase(layer)) {
                transEntityDetails = cuLayer.getTxnSlotItems();
                break;
            }
        }
        return transEntityDetails;
    }

    public static void updateEntityAndAttributeId(TenantChangeUnitInput changeUnit, TenantCUEntityInput entity) {

        if (changeUnit == null || entity == null)
            return;
        for (TenantCULayerInput layer : changeUnit.getLayers()) {

            for (TenantSlotItemInput slot : layer.getParticipatingItems()) {

                if (slot.getItem() instanceof TenantCUEntityInput && ((TenantCUEntityInput) slot.getItem()).getName().equals(entity.getName())) {

                    TenantCUEntityInput currEntity = (TenantCUEntityInput) slot.getItem();
                    currEntity.setId(entity.getId());
                    for(TenantCUEntityAttributeInput attribute : currEntity.getNslAttributes()){

                        attribute.setId(getNslAttributeId(entity, attribute.getName()));
                        attribute.setDsdId(getNslAttributeDsdId(entity, attribute.getName()));
                    }
                }
            }
        }
    }

    private static Long getNslAttributeId(TenantCUEntityInput entity, String attributeName) {
        Optional<TenantCUEntityAttributeInput> findnslAttr = entity.getNslAttributes().stream()
                .filter(nslAttribute -> nslAttribute.getName().equalsIgnoreCase(attributeName)).findAny();

        if (findnslAttr.isPresent()) {
            return findnslAttr.get().getId();
        }
        return null;
    }

    private static String getNslAttributeDsdId(TenantCUEntityInput entity, String attributeName) {
        Optional<TenantCUEntityAttributeInput> findnslAttr = entity.getNslAttributes().stream()
                .filter(nslAttribute -> nslAttribute.getName().equalsIgnoreCase(attributeName)).findAny();

        if (findnslAttr.isPresent()) {
            return findnslAttr.get().getDsdId();
        }
        return null;
    }
}
