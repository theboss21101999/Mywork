package unusedfiles.config.service;


import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.model.CUExecutionDto;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import unusedfiles.config.constants.AppConstant;

import java.util.Objects;

import static org.springframework.http.HttpHeaders.ACCEPT_LANGUAGE;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Service
public class ExceptionGsiExecutor {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionGsiExecutor.class);

    @Value("${sftp.adapter.gsi.execution.url}")
    private String executionUrl;

    @Value("${sftp.adapter.system.user.token.url}")
    private String sysUserTokenUrl;

    public void executeGsi(Long gsiId, String tenantId, String userEmail, TxnData txnData) throws JSONException {
        JSONObject transactionObject = getTransactionId(gsiId, tenantId, userEmail);
        ResponseEntity<String> response = executeGsi(transactionObject, txnData, gsiId, tenantId, userEmail);
        LOGGER.info("GSI invoked successfully.. Response received : {} ", response.getBody());
    }

    private ResponseEntity<String> executeGsi(JSONObject initialResponse, TxnData txnData, Long gsiId, String tenantId, String userEmail) throws JSONException {
        JSONObject responseResult = (JSONObject) initialResponse.get("result");
        TriggerCU triggerCu = JacksonUtils.getObjectFromJsonString(responseResult.get("nextTriggerCU").toString(), TriggerCU.class);
        String transactionId = JacksonUtils.getObjectFromJsonString(responseResult.get("transId").toString(), String.class);
        LOGGER.info("Received transaction id : {}", transactionId);
        txnData.setTransactionId(transactionId);
        txnData.setCuContextualId(triggerCu.getContextualId().get(0));
        CUExecutionDto dto = getCuExecutionDto(triggerCu, txnData, transactionId, gsiId);
        HttpEntity<Object> cuHttp1 = new HttpEntity<>(JacksonUtils.toJson(dto), getHeaders(tenantId, userEmail));
        RestTemplate restTemplate = new RestTemplate();
        LOGGER.info("Triggering GSI having transaction id : {}", transactionId);
        return restTemplate.exchange(executionUrl, HttpMethod.POST, cuHttp1, String.class);
    }

    private CUExecutionDto getCuExecutionDto(TriggerCU triggerCu, TxnData txnData, String transactionId, Long gsiId)
    {
        CUExecutionDto dto = new CUExecutionDto();
        dto.setTransID(transactionId);
        dto.setTxnData(txnData);
        dto.setTriggerCuId(triggerCu.getId());
        dto.setGsiId(gsiId);
        return dto;
    }

    private JSONObject getTransactionId(Long gsiId, String tenantId, String userEmail) throws JSONException {
        LOGGER.info("Requesting transaction id..");
        CUExecutionDto dto = new CUExecutionDto();
        dto.setGsiId(gsiId);
        HttpEntity<CUExecutionDto> cuHttp = new HttpEntity<>(dto, getHeaders(tenantId, userEmail));
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> cUResponse = restTemplate.exchange(executionUrl, HttpMethod.POST, cuHttp, String.class);
        return new JSONObject(Objects.requireNonNull(cUResponse.getBody()));
    }

    private HttpHeaders getHeaders(String tenantId, String userEmail) throws JSONException {
        HttpHeaders coreHeaders = new HttpHeaders();
        coreHeaders.add(AUTHORIZATION, AppConstant.BEARER + getAccessToken());
        coreHeaders.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        coreHeaders.add(ACCEPT_LANGUAGE, AppConstant.EN);
        coreHeaders.add(AppConstant.SYSTEM_USER_DETAILS, tenantId+ ":"+ userEmail);
        return coreHeaders;
    }

    private String getAccessToken() throws JSONException {
        HttpEntity<String> tkHttp = new HttpEntity<>("", new HttpHeaders());
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> tokenResp = restTemplate.exchange(sysUserTokenUrl, HttpMethod.GET, tkHttp, String.class);
        JSONObject tkResponseJSON = new JSONObject(Objects.requireNonNull(tokenResp.getBody()));
        return ((JSONObject)tkResponseJSON.get("result")).get("access_token").toString();
    }


}
