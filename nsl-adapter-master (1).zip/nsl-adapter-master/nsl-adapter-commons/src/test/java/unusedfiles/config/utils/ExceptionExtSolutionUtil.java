package unusedfiles.config.utils;


import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.model.ChangeDriverData;
import com.nsl.logical.model.TxnCULayer;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnSlotItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;


@Component
public class ExceptionExtSolutionUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionExtSolutionUtil.class);


    @Resource(name = "requestScopedAuthenticatedUserBean")
    private AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;


    public void setRequestScopedAuthenticatedUserBean(AuthenticatedUserDetailsImpl user) {
        this.requestScopedAuthenticatedUserBean = user;
    }

    public AuthenticatedUserDetailsImpl getRequestScopedAuthenticatedUserBean() {
        return this.requestScopedAuthenticatedUserBean;
    }

    public TxnData setChangeDriverInTxnData(ChangeDriverData changeDriverDataTriggerCES, LayerType layerType) {
        TxnData result = new TxnData();
        List<TxnCULayer> transactionCULayerList = new ArrayList<>();
        TxnCULayer transactionCULayer = new TxnCULayer();
        List<TxnSlotItem> slots = new ArrayList<>();
        TxnSlotItem slot1 = new TxnSlotItem();
        slot1.setItem(changeDriverDataTriggerCES);
        slots.add(slot1);
        transactionCULayer.setTxnSlotItems(slots);
        transactionCULayer.setType(layerType);
        transactionCULayerList.add(transactionCULayer);
        result.setTxnCULayer(transactionCULayerList);
        return result;
    }


}
