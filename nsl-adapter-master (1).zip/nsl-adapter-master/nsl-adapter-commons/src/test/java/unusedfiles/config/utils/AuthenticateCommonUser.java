package unusedfiles.config.utils;


import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import unusedfiles.config.constants.AppConstant;

import java.util.Map;
import java.util.Objects;

@Component
public class AuthenticateCommonUser {

    @Value("${sftp.adapter.system.user.token.url}")
    private String sysUserTokenUrl;

    public AuthenticatedUserDetailsImpl getAuthenticatedUser(Long userId, String tenantId){
        AuthenticatedUserDetailsImpl authenticatedUser = new AuthenticatedUserDetailsImpl();
        authenticatedUser.setTenantId(tenantId);
        authenticatedUser.setUserId(userId);
        return authenticatedUser;
    }
    public AuthenticatedUserDetailsImpl getAuthenticatedUser(Map<String, String> msg) throws JSONException {
            AuthenticatedUserDetailsImpl authenticatedUser = new AuthenticatedUserDetailsImpl();
            authenticatedUser.setEmailId(msg.get(AppConstant.USEREMAIL));
            authenticatedUser.setTenantId(msg.get(AppConstant.TENANTID));
            authenticatedUser.setUserId(Long.valueOf(msg.get(AppConstant.USERID)));
            authenticatedUser.setAuthToken(getAccessToken());
            return authenticatedUser;
    }

    private String getAccessToken() throws JSONException {
        HttpEntity<String> tkHttp = new HttpEntity<String>("", new HttpHeaders());
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> tokenResp = restTemplate.exchange(sysUserTokenUrl, HttpMethod.GET, tkHttp, String.class);
        JSONObject tkResponseJSON = new JSONObject(Objects.requireNonNull(tokenResp.getBody()));
        return ((JSONObject)tkResponseJSON.get("result")).get("access_token").toString();
    }
}
