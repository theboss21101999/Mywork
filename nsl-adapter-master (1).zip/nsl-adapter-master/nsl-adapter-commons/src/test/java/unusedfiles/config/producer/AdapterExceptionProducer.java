package unusedfiles.config.producer;


import com.fasterxml.jackson.databind.ObjectMapper;
import unusedfiles.config.KafkaProducerConnectionUtil;
import unusedfiles.config.constants.KafkaConstants;
import unusedfiles.config.dto.KafkaConnectionDto;
import unusedfiles.config.exception.NSLAdapterException;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.Properties;


public class AdapterExceptionProducer {
    @Autowired
    KafkaProducerConnectionUtil kafkaProducerConnectionUtil;

    public void sendException(NSLAdapterException nslAdapterException) {
        KafkaConnectionDto connectionDto = getKafkaConfig();
        KafkaProducerConnectionUtil kafkaProducerConnectionService = new KafkaProducerConnectionUtil(connectionDto);
        String data=null;
        try {
            data = new ObjectMapper().writeValueAsString(nslAdapterException);
        } catch (Exception e) {

        }
        String key = nslAdapterException.getTenantId();
        kafkaProducerConnectionService.sendMessageTokafka(data, "exception_topic", key);
    }

    public KafkaConnectionDto getKafkaConfig() {

        KafkaConnectionDto kafkaConnectionDto = new KafkaConnectionDto();
        Properties config = new Properties();
        config.put(KafkaConstants.TOPIC, "exception_topic");
        kafkaConnectionDto.setBootStrapServer(Collections.singletonList("localhost:9092"));
        kafkaConnectionDto.setAdvancedConfig(config);
        return kafkaConnectionDto;
    }
}
