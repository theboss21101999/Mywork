package unusedfiles.config.service;


import com.nsl.common.utils.JacksonUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import unusedfiles.config.utils.ExceptionGsiInvokerUtil;

import java.util.Map;

@Service("exceptionInboundKafkaServiceImpl")
public class ExceptionInboundKafkaServiceImpl {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionInboundKafkaServiceImpl.class);


    @Autowired
    ExceptionGsiInvokerUtil exceptionGsiInvokerUtil;

    @Async("sftpInboundKafkaExecutor")
    public void processKafkaMessage(ConsumerRecord<?, ?> consumerRecord) {
        String kafkaMsg = (String) consumerRecord.value();
        Map<String, String> kafkaMsgMap = JacksonUtils.getObjectFromJsonString(kafkaMsg, Map.class);
        exceptionGsiInvokerUtil.invokeGsi(Long.valueOf(kafkaMsgMap.get("exceptionGsiMasterId")), kafkaMsgMap);

    }
}


