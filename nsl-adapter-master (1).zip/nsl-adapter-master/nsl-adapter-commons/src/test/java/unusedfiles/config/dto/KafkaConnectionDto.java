package unusedfiles.config.dto;


import java.util.List;
import java.util.Properties;

public class KafkaConnectionDto {

    String connectionName;
    List<String> bootStrapServer;
    String partition;
    int offset;
    Properties advancedConfig;

    public KafkaConnectionDto() {
    }

    public String getConnectionName() {
        return connectionName;
    }

    public void setConnectionName(String connectionName) {
        this.connectionName = connectionName;
    }

    public List<String> getBootStrapServer() {
        return bootStrapServer;
    }

    public void setBootStrapServer(List<String> bootStrapServer) {
        this.bootStrapServer = bootStrapServer;
    }

    public String getPartition() {
        return partition;
    }

    public void setPartition(String partition) {
        this.partition = partition;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public Properties getAdvancedConfig() {
        return advancedConfig;
    }

    public void setAdvancedConfig(Properties advancedConfig) {
        this.advancedConfig = advancedConfig;
    }
}
