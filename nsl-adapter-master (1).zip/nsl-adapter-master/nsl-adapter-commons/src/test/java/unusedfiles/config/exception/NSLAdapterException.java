package unusedfiles.config.exception;

import unusedfiles.config.enums.AdapterExceptionSubcat;
import unusedfiles.config.producer.AdapterExceptionProducer;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;

public class NSLAdapterException extends NSLException {

    private String exceptionGsiMasterId;
    private String tenantId;
    private String userId;
    private String email;
    private String adapter;
    private String cuName;
    private String severity;

    public String getEmail() {
        return email;
    }

    private String message;
    private String gsiName;
    private String gsiId;
    private String adapterSubCategory;

    @Override
    public String getTenantId() {
        return tenantId;
    }

    public String getAdapterSubCategory() {
        return adapterSubCategory;
    }

    public String getExceptionGsiMasterId() {
        return exceptionGsiMasterId;
    }

    public String getUserId() {
        return userId;
    }



    public String getAdapter() {
        return adapter;
    }

    public String getCuName() {
        return cuName;
    }


    @Override
    public String getMessage() {
        return message;
    }

    public String getGsiName() {
        return gsiName;
    }

    public String getGsiId() {
        return gsiId;
    }



    public NSLAdapterException(String userId, String userEmail, String tenantId, String gsiName, String cuName, String adapter,
                               String exceptionGsiMasterId, ErrorType errorType,
                               ExceptionCategory category, AdapterExceptionSubcat adapterExceptionSubcat,
                               String errorMessage,
                               ExceptionSeverity severity)  {
        super(errorType,category, errorMessage, severity);

        AdapterExceptionProducer report=new AdapterExceptionProducer();
        this.userId=userId;
        this.gsiName=gsiName;
        this.adapter=adapter;
        this.tenantId=tenantId;
        this.email=userEmail;
        this.adapterSubCategory=String.valueOf(adapterExceptionSubcat);
        this.cuName=cuName;
        this.message=errorMessage;
        this.exceptionGsiMasterId=exceptionGsiMasterId;

        report.sendException(this);

    }
}
