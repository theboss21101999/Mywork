package unusedfiles.config.listener;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.logical.dao.ChangeUnitDao;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import unusedfiles.config.service.ExceptionInboundKafkaServiceImpl;


@Service
@ConditionalOnProperty(
        value = "kafka.pipeline.enabled",
        havingValue = "true",
        matchIfMissing = false
)
public class AdapterExceptionListener<V> {

    @Autowired
    ExceptionInboundKafkaServiceImpl exceptionInboundKafkaService;

    @Autowired
    ChangeUnitDao changeUnitDao;

    private static final Logger LOGGER = LoggerFactory.getLogger(AdapterExceptionListener.class);


    @KafkaListener(topics = "exception_topic",
            groupId = "${kafka.topic.adapters.gsi.response.group.id}",
            containerFactory = "adapterGsiContainerFactory")
    public void receiveNotifications(V v, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
                                     @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
                                     @Header(KafkaHeaders.OFFSET) int offset,
                                     @Header(KafkaHeaders.ACKNOWLEDGMENT) Acknowledgment acknowledgment) throws JsonProcessingException {

        ConsumerRecord<?, ?> consumerRecord = ((ConsumerRecord) v);
        System.out.println(consumerRecord.value().toString());
        exceptionInboundKafkaService.processKafkaMessage(consumerRecord);
        acknowledgment.acknowledge();


    }
}

