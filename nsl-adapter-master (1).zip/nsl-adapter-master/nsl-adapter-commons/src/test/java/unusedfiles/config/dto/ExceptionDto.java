package unusedfiles.config.dto;


public class ExceptionDto {
    String exceptionGsiMasterId;
    String tenantId;
    String userId;
    String userEmail;
    String errorType;
    String adapter;
    String cuName;
    String severity;
    String message;
    String gsiName;
    String gsiId;
    String category;
    String subCategory;

    public ExceptionDto() {
    }

    public ExceptionDto(String exceptionGsiMasterId, String tenantId, String userId, String userEmail, String errorType, String adapter, String cuName, String severity, String message, String gsiName, String gsiId, String category, String subCategory) {
        this.exceptionGsiMasterId = exceptionGsiMasterId;
        this.tenantId = tenantId;
        this.userId = userId;
        this.userEmail = userEmail;
        this.errorType = errorType;
        this.adapter = adapter;
        this.cuName = cuName;
        this.severity = severity;
        this.message = message;
        this.gsiName = gsiName;
        this.gsiId = gsiId;
        this.category = category;
        this.subCategory = subCategory;
    }

    public String getExceptionGsiMasterId() {
        return exceptionGsiMasterId;
    }

    public void setExceptionGsiMasterId(String exceptionGsiMasterId) {
        this.exceptionGsiMasterId = exceptionGsiMasterId;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public String getAdapter() {
        return adapter;
    }

    public void setAdapter(String adapter) {
        this.adapter = adapter;
    }

    public String getCuName() {
        return cuName;
    }

    public void setCuName(String cuName) {
        this.cuName = cuName;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getGsiName() {
        return gsiName;
    }

    public void setGsiName(String gsiName) {
        this.gsiName = gsiName;
    }

    public String getGsiId() {
        return gsiId;
    }

    public void setGsiId(String gsiId) {
        this.gsiId = gsiId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }
}
