package unusedfiles.config.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.logical.config.AuthenticatedUserDetails;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.model.GSI;
import com.nsl.logical.model.TxnData;
import org.apache.commons.io.FileUtils;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import unusedfiles.config.constants.AppConstant;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.springframework.http.HttpHeaders.ACCEPT_LANGUAGE;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@Service
public class GsiUtil {

    private String importUrl;
    @Autowired
    ChangeUnitDao changeUnitDao;
    @Autowired
    AuthenticateCommonUser authenticateUser;
    @Autowired
    private RestTemplate restTemplate;
    public  String getGsiName(TxnData transData, AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean) throws JSONException {

        Long gsiId = Long.valueOf(transData.getCuContextualId().substring(2).split("[.]")[0]);
        Map<String, String> msg = new HashMap<>();
        msg.put(AppConstant.USEREMAIL, requestScopedAuthenticatedUserBean.getEmailId());
        msg.put(AppConstant.TENANTID, requestScopedAuthenticatedUserBean.getTenantId());
        msg.put(AppConstant.USERID, String.valueOf(requestScopedAuthenticatedUserBean.getUserId()));
        GSI gsiMaster = changeUnitDao.getGsiByMasterId(gsiId, null,
                StatusEnum.PUBLISHED, authenticateUser.getAuthenticatedUser(msg));
        return gsiMaster.getName();
    }

    public String getGSIByName(String gsiName, AuthenticatedUserDetails userDetails) {
        GSI gsiMaster = changeUnitDao.getGSIByName(gsiName,userDetails);
        if(gsiMaster!=null) {
            return gsiMaster.getMasterId().toString();
        }
        return null;
    }
    public String importGsi(AuthenticatedUserDetails userDetails) throws IOException {
        InputStream CreateEntityConfigStream = new ClassPathResource("adapter_config_entity/ExceptionGsi/" +
                "ExceptionGsi.json").getInputStream();
        File file = File.createTempFile("ExeceptionEmailGsi", "." +"json");
        FileUtils.copyInputStreamToFile(CreateEntityConfigStream, file);
        FileSystemResource fileSystemSource = new FileSystemResource(file);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.add(AUTHORIZATION, "Bearer "+ userDetails.getAuthToken());
        headers.add(ACCEPT_LANGUAGE, AppConstant.ACCEPT_LANGUAGE_EN);
        MultiValueMap<String, Object> map= new LinkedMultiValueMap<>();
        map.add("file", fileSystemSource);
        HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(map, headers);
        ResponseEntity<JsonNode> response = restTemplate.exchange(importUrl, HttpMethod.POST,
                httpEntity, JsonNode.class);
        JsonNode result = response.getBody();
        return result.get("result").get("gsiDetails").get(0).get("masterId").asText();
    }
}
