package com.nsl.adapter.commons.parsers;

import ca.uhn.hl7v2.DefaultHapiContext;
import ca.uhn.hl7v2.HapiContext;
import ca.uhn.hl7v2.parser.CanonicalModelClassFactory;
import ca.uhn.hl7v2.parser.Parser;
import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.adapter.commons.utils.FileUploadUtil;
import com.nsl.adapter.commons.utils.entity.EntityToCSVUtil;
import com.nsl.adapter.commons.utils.entity.EntityToHl7;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.commons.utils.entity.Hl7ToEntity;
import com.nsl.adapter.commons.utils.entity.EntityToXML;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnGeneralEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.configurationprocessor.json.JSONException;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;
import static org.mockito.ArgumentMatchers.any;


@RunWith(MockitoJUnitRunner.class)
public class OutboundParsersTest {

    @InjectMocks
    JSONParserV2 jsonParserV2;

    @InjectMocks
    XMLParserV2 xmlParserV2;

    @InjectMocks
    CSVParserV2 csvParserV2;

    @InjectMocks
    NativeParserV2 nativeParserV2;

    @InjectMocks
    EntityToXML entityToXml;

    @InjectMocks
    EntityToJSONUtil entityToJSONUtil;

    @Mock
    FileUploadUtil fileUploadUtil;

    @Mock
    AdaptorCommonsProperties adaptorCommonsProperties;

    @InjectMocks
    OutboundParserUtils outboundParserUtils;

    @InjectMocks
    EntityToCSVUtil entityToCSVUtil;

    @InjectMocks
    HL7ParserV2 hl7ParserV2;

    @InjectMocks
    EntityToHl7 entityToHl7;

    @InjectMocks
    Hl7ToEntity hl7ToEntity;


    @Test
    public void testJsonOutboundParser() throws NSLException, NoSuchFieldException {

        FieldSetter.setField(jsonParserV2,jsonParserV2.getClass().
                getDeclaredField("entityToJSONUtil"),entityToJSONUtil);

        TxnGeneralEntity txnGeneralEntity = outboundParserUtils.jsonouttxnGeneralEntity();
        GeneralEntity inputGeneralEntity = outboundParserUtils.jsonoutinputGeneralEntity();

        InputStream actualObj = jsonParserV2.outboundParser(txnGeneralEntity, inputGeneralEntity, true,null);
        org.junit.Assert.assertNotNull("resp for jsonOutbound",actualObj);

    }

    @Test
    public void testXmlOutboundParser() throws NSLException, NoSuchFieldException {

//        FieldSetter.setField(xmlParserV2,xmlParserV2.getClass().
//                getDeclaredField(""), entityToXml);

        TxnGeneralEntity txnGeneralEntity = outboundParserUtils.jsonouttxnGeneralEntity();
        GeneralEntity inputGeneralEntity = outboundParserUtils.jsonoutinputGeneralEntity();

        InputStream actualObj = xmlParserV2.outboundParser(txnGeneralEntity, inputGeneralEntity, true,null);
        org.junit.Assert.assertNotNull("resp for xmlOutbound",actualObj);

    }

    @Test
    public void testCsvOutboundParser() throws NSLException, NoSuchFieldException {

        FieldSetter.setField(csvParserV2,csvParserV2.getClass().
                getDeclaredField("entityToCSVUtil"),entityToCSVUtil);

        TxnGeneralEntity txnGeneralEntity = outboundParserUtils.jsonouttxnGeneralEntity();
        GeneralEntity inputGeneralEntity = outboundParserUtils.jsonoutinputGeneralEntity();

        InputStream actualObj = csvParserV2.outboundParser(txnGeneralEntity, inputGeneralEntity, false,null);
        org.junit.Assert.assertNotNull("resp for csvOutbound",actualObj);

    }

    @Test
    public void testHl7OutboundParser() throws NSLException, NoSuchFieldException {

        FieldSetter.setField(hl7ParserV2,hl7ParserV2.getClass().getDeclaredField("entityToHl7"),entityToHl7);
        FieldSetter.setField(hl7ParserV2,hl7ParserV2.getClass().getDeclaredField("entityToJSONUtil"),entityToJSONUtil);

        TxnGeneralEntity txnGeneralEntity = outboundParserUtils.hl7outtxnGeneralEntity();
        GeneralEntity inputGeneralEntity = outboundParserUtils.hl7outinputGeneralEntity();

        Parser parser;
        try (HapiContext context = new DefaultHapiContext(new CanonicalModelClassFactory("2.5"))){
            parser = context.getPipeParser();
        }catch (Exception e){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"failed to parse the message" +
                    e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }
        FieldSetter.setField(entityToHl7,entityToHl7.getClass().getDeclaredField("parser"),parser );

        InputStream actualObj = hl7ParserV2.outboundParser(txnGeneralEntity, inputGeneralEntity, false,null);
        org.junit.Assert.assertNotNull("resp for csvOutbound",actualObj);

    }

    @Test
    public void testNativeOutboundParser() throws NoSuchFieldException, NSLException {

        FieldSetter.setField(nativeParserV2,nativeParserV2.getClass().
                getDeclaredField("entityToJSONUtil"),entityToJSONUtil);

        TxnGeneralEntity txnGeneralEntity = outboundParserUtils.nativeouttxnGeneralEntity();
        GeneralEntity inputGeneralEntity = outboundParserUtils.nativeinputGeneralEntity();

        Mockito.when(fileUploadUtil.getContentFromUrl(ArgumentMatchers.any(),ArgumentMatchers.any())).thenReturn(new ByteArrayInputStream("aa".getBytes()));
//        Mockito.when(adaptorCommonsProperties.getEnvUrl()).thenReturn("https://qa3.nslhub.com");
        InputStream actualObj = nativeParserV2.outboundParser(txnGeneralEntity,inputGeneralEntity,false,null);
        org.junit.Assert.assertNotNull(actualObj );

    }
    @Test
    public void testNativeOutboundExceptionParser() throws NoSuchFieldException, NSLException {

        FieldSetter.setField(nativeParserV2,nativeParserV2.getClass().
                getDeclaredField("entityToJSONUtil"),entityToJSONUtil);
        TxnGeneralEntity txnGeneralEntity = outboundParserUtils.nativeouttxnGeneralEntity();
        GeneralEntity inputGeneralEntity = outboundParserUtils.nativeinputGeneralEntity();

        Mockito.when(fileUploadUtil.getContentFromUrl(ArgumentMatchers.any(),ArgumentMatchers.any())).thenThrow(NSLException.class);
//        Mockito.when(adaptorCommonsProperties.getEnvUrl()).thenReturn("https://qa3.nslhub.com");
        org.junit.Assert.assertThrows(NSLException.class,() -> {nativeParserV2.outboundParser(txnGeneralEntity,inputGeneralEntity,false,null);});

    }



}
