package com.nsl.adapter.commons.service;

import com.nsl.adapter.commons.dto.PaginatedConnectionsListDto;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.dao.SearchCUDAO;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class AdapterConnectionServiceV3Test {

    @InjectMocks
    AdapterConnectionServiceV3 adapterConnectionServiceV3;

    @Mock
    AuthenticatedUserDetailsImpl authBean;

    @Mock
    GeneralEntityDao generalEntityDao;

    @Mock
    SaveBetsService saveBetsService;

    @Mock
    SearchCUDAO searchCUDAO;

    @Test
    public void listConnectionTest(){

        GeneralEntity generalEntity = new GeneralEntity();
        NslAttribute nslAttribute = new NslAttribute();
        nslAttribute.setName("connectionName");
        generalEntity.setNslAttributes(nslAttribute);

        Mockito.when(generalEntityDao.findByName(any(),any())).thenReturn(generalEntity);
        Mockito.when(searchCUDAO.getEntities(any(),any())).thenReturn(getRecord());

        AuthenticatedUserDetailsImpl authenticatedUserDetails = new AuthenticatedUserDetailsImpl();
        authenticatedUserDetails.setAuthToken("aaa");

        PaginatedConnectionsListDto resp = adapterConnectionServiceV3.getConnectionList(1, 10, "NSL_S3_Connection", "conn",authenticatedUserDetails);
        org.junit.Assert.assertEquals("1",resp.getCurrentPageSize().toString());

    }

    private List<TxnGeneralEntityRecord> getRecord() {
        String jsonString = "{\n" +
                "  \"generalEntityId\": 310522596668,\n" +
                "  \"generalEntityMasterId\": 6596117227,\n" +
                "  \"txnNslAttribute\": [\n" +
                "    {\n" +
                "      \"name\": \"accessKey\",\n" +
                "      \"nslAttributeID\": 1869647585384,\n" +
                "      \"values\": [\n" +
                "        \"sads\"\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"secretKey\",\n" +
                "      \"nslAttributeID\": 1150106786518,\n" +
                "      \"values\": [\n" +
                "        \"sdasd\"\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"region\",\n" +
                "      \"nslAttributeID\": 586677963877,\n" +
                "      \"values\": [\n" +
                "        \"us-east-2\"\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"connectionName\",\n" +
                "      \"nslAttributeID\": 2076637920246,\n" +
                "      \"values\": [\n" +
                "        \"asdasdsd\"\n" +
                "      ]\n" +
                "    }\n" +
                "  ],\n" +
                "  \"id\": 601208044166,\n" +
                "  \"guid\": \"fc47bf97-7366-4c54-976d-5626eb66f8ad\",\n" +
                "  \"ownerId\": 814296849840,\n" +
                "  \"createdAt\": 1651225986371,\n" +
                "  \"createdBy\": 814296849840,\n" +
                "  \"updatedAt\": 1651225986371,\n" +
                "  \"updatedBy\": 814296849840,\n" +
                "  \"orgUnitId\": 984891268689\n" +
                "}";
        TxnGeneralEntityRecord record = JacksonUtils.getObjectFromJsonString(jsonString,TxnGeneralEntityRecord.class);
        return Collections.singletonList(record);
    }

}
