package com.nsl.adapter.commons.parsers;

import ca.uhn.hl7v2.DefaultHapiContext;
import ca.uhn.hl7v2.HapiContext;
import ca.uhn.hl7v2.parser.CanonicalModelClassFactory;
import ca.uhn.hl7v2.parser.Parser;
import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.adapter.commons.parsers.service.ParserService;
import com.nsl.adapter.commons.utils.FileUploadUtil;
import com.nsl.adapter.commons.utils.entity.Hl7ToEntity;
import com.nsl.adapter.commons.utils.entity.TxnDataUtils;
import com.nsl.adapter.commons.utils.entity.EntityToXML;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@RunWith(MockitoJUnitRunner.class)
public class InboundParsersTest {

    @InjectMocks
    XMLParserV2 xmlParserV2;

    @InjectMocks
    EntityToXML entityToXml;

    @InjectMocks
    JSONParserV2 jsonParserV2;

    @InjectMocks
    CSVParserV2 csvParserV2;

    @InjectMocks
    HL7ParserV2 hl7ParserV2;

    @InjectMocks
    Hl7ToEntity hl7ToEntity;

    @InjectMocks
    NativeParserV2 nativeParserV2;

    @InjectMocks
    ParserService parserService;

    @InjectMocks
    FileUploadUtil fileUploadUtil;

    @Mock
    AdaptorCommonsProperties adaptorCommonsProperties;

    @Mock
    RestTemplate restTemplate;

    @InjectMocks
    TxnDataUtils txnDataUtils;

    @InjectMocks
    InboundParserUtils inboundParserUtils;

    @Mock
    AuthenticatedUserDetailsImpl authBean;


    @Test
    public void XmlInboundparsers() throws NoSuchFieldException, NSLException, FileNotFoundException {

//        FieldSetter.setField(xmlParserV2,xmlParserV2.getClass().
//                getDeclaredField("xmlValidationUtil"), entityToXml);
        FieldSetter.setField(xmlParserV2,xmlParserV2.getClass().
                getDeclaredField("txnDataUtils"), txnDataUtils);
        File file = ResourceUtils.getFile("classpath:parsers/testxmlparser.xml");
        InputStream inputStream = new FileInputStream(file);

        TxnData expectedObj = inboundParserUtils.getXmlres();
        GeneralEntity tcesGeneralEntity = inboundParserUtils.tcesGeneralEntity();
        List<TxnGeneralEntity> actualObj1 = xmlParserV2.inboundParserV2(inputStream, tcesGeneralEntity, true, null, LayerType.TRIGGERCES, null);
        inputStream =  new FileInputStream(file);
        List<TxnData> actualObj = xmlParserV2.inboundParser(inputStream, tcesGeneralEntity, true, null, LayerType.TRIGGERCES, null);
        org.junit.Assert.assertEquals(actualObj.get(0).getTxnCULayer().get(0).getType(),
                expectedObj.getTxnCULayer().get(0).getType());
    }

    @Test
    public void JsonInboundparsers() throws NoSuchFieldException, NSLException, IOException {

        FieldSetter.setField(jsonParserV2,jsonParserV2.getClass().
                getDeclaredField("txnDataUtils"), txnDataUtils);
        File file = ResourceUtils.getFile("classpath:parsers/testjsonparser.json");
        InputStream inputStream = new FileInputStream(file);

        TxnData expectedObj = inboundParserUtils.getJsonres();
        GeneralEntity tcesGeneralEntity = inboundParserUtils.tcesGeneralEntity();
        List<TxnGeneralEntity> actualObj1 = jsonParserV2.inboundParserV2(inputStream,tcesGeneralEntity,true,null,LayerType.TRIGGERCES,null);
        inputStream =  new FileInputStream(file);
        List<TxnData> actualObj = jsonParserV2.inboundParser(inputStream, tcesGeneralEntity, true, null, LayerType.TRIGGERCES, null);
        org.junit.Assert.assertEquals(actualObj.get(0).getTxnCULayer().get(0).getType(),
                expectedObj.getTxnCULayer().get(0).getType());
    }

    @Test
    public void CsvInboundparsers() throws NoSuchFieldException, NSLException, FileNotFoundException {

        FieldSetter.setField(csvParserV2,csvParserV2.getClass().
                getDeclaredField("txnDataUtils"), txnDataUtils);
        File file = ResourceUtils.getFile("classpath:parsers/testcsvparser.csv");
        InputStream inputStream = new FileInputStream(file);
        TxnData expectedObj = inboundParserUtils.getCsvres();
        GeneralEntity tcesGeneralEntity = inboundParserUtils.tcesGeneralEntity();
        List<TxnGeneralEntity> actualObj1 = csvParserV2.inboundParserV2(inputStream,tcesGeneralEntity,true,null,LayerType.TRIGGERCES,null);
        inputStream =  new FileInputStream(file);
        List<TxnData> actualObj = csvParserV2.inboundParser(inputStream, tcesGeneralEntity, true, null, LayerType.TRIGGERCES, null);
        org.junit.Assert.assertEquals(actualObj.get(0).getTxnCULayer().get(0).getType(),
                expectedObj.getTxnCULayer().get(0).getType());
    }

    @Test
    public void Hl7Inboundparsers() throws NoSuchFieldException, NSLException, FileNotFoundException {

        FieldSetter.setField(hl7ParserV2,hl7ParserV2.getClass().getDeclaredField("txnDataUtils"), txnDataUtils);
        FieldSetter.setField(hl7ParserV2,hl7ParserV2.getClass().getDeclaredField("hl7ToEntity"), hl7ToEntity);
        File file = ResourceUtils.getFile("classpath:parsers/testhl7parser.hl7");
        InputStream inputStream = new FileInputStream(file);
        TxnData expectedObj = inboundParserUtils.getHl7res();

        Parser parser;
        try (HapiContext context = new DefaultHapiContext(new CanonicalModelClassFactory("2.5"))){
            parser = context.getPipeParser();
        }catch (Exception e){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"failed to parse the message" +
                    e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }
        FieldSetter.setField(hl7ToEntity,hl7ToEntity.getClass().getDeclaredField("parser"),parser );

        GeneralEntity tcesGeneralEntity = inboundParserUtils.hl7TcesGeneralEntity();
        List<TxnGeneralEntity> actualObj1 = hl7ParserV2.inboundParserV2(inputStream,tcesGeneralEntity,true,null,LayerType.TRIGGERCES,null);
        inputStream =  new FileInputStream(file);
        List<TxnData> actualObj = hl7ParserV2.inboundParser(inputStream, tcesGeneralEntity, true, null, LayerType.TRIGGERCES, null);
        org.junit.Assert.assertEquals(actualObj.get(0).getTxnCULayer().get(0).getType(),
                expectedObj.getTxnCULayer().get(0).getType());
    }

    @Test
    public void NativeInboundparsers() throws IOException, NSLException, NoSuchFieldException {

        FieldSetter.setField(nativeParserV2,nativeParserV2.getClass().
                getDeclaredField("parserService"), parserService);
        FieldSetter.setField(nativeParserV2,nativeParserV2.getClass().
                getDeclaredField("txnDataUtils"), txnDataUtils);

        FieldSetter.setField(parserService, parserService.getClass().
                getDeclaredField("fileUploadUtil"),fileUploadUtil);

        File file = ResourceUtils.getFile("classpath:parsers/testcsvparser.csv");
        InputStream inputStream = new FileInputStream(file);

        Mockito.when(adaptorCommonsProperties.getAppDsdSingleFileUploadUrl()).thenReturn("https://qa3.nslhub.com/dsd-files-store/upload/file");

        Mockito.when(restTemplate.exchange(eq("https://qa3.nslhub.com/dsd-files-store/upload/file"),eq(HttpMethod.POST),any(),eq(JsonNode.class))).
                                                thenReturn(ResponseEntity.ok(inboundParserUtils.getFileUploadres()));
        GeneralEntity tcesGeneralEntity = inboundParserUtils.nativetcesGeneralEntity();
        Map<String,String> cusystemprops = new HashMap<>();
        cusystemprops.put("fileName","testfile");
        cusystemprops.put("fileType","native");
        TxnData expectedObj = inboundParserUtils.getNativeres();
        List<TxnData> actualObj = nativeParserV2.inboundParser(inputStream, tcesGeneralEntity, true, cusystemprops, LayerType.TRIGGERCES, new AuthenticatedUserDetailsImpl());
        org.junit.Assert.assertEquals(actualObj.get(0).getTxnCULayer().get(0).getType(),
                expectedObj.getTxnCULayer().get(0).getType());
    }
    @Test
    public void NativeInboundExceptionparsers() throws IOException, NSLException, NoSuchFieldException {

        FieldSetter.setField(nativeParserV2,nativeParserV2.getClass().
                getDeclaredField("parserService"), parserService);
        FieldSetter.setField(nativeParserV2,nativeParserV2.getClass().
                getDeclaredField("txnDataUtils"), txnDataUtils);

        FieldSetter.setField(parserService, parserService.getClass().
                getDeclaredField("fileUploadUtil"),fileUploadUtil);

        File file = ResourceUtils.getFile("classpath:parsers/testcsvparser.csv");
        InputStream inputStream = new FileInputStream(file);

        Mockito.when(adaptorCommonsProperties.getAppDsdSingleFileUploadUrl()).thenReturn("https://qa3.nslhub.com/dsd-files-store/upload/file");

        Mockito.when(restTemplate.exchange(eq("https://qa3.nslhub.com/dsd-files-store/upload/file"),eq(HttpMethod.POST),any(),eq(JsonNode.class))).thenThrow(NSLException.class);
        GeneralEntity tcesGeneralEntity = inboundParserUtils.nativetcesGeneralEntity();
        Map<String,String> cusystemprops = new HashMap<>();
        cusystemprops.put("fileName","testfile");
        cusystemprops.put("fileType","native");
        TxnData expectedObj = inboundParserUtils.getNativeres();
        org.junit.Assert.assertThrows(NSLException.class,() -> {nativeParserV2.inboundParser(inputStream, tcesGeneralEntity, true, cusystemprops, LayerType.TRIGGERCES, new AuthenticatedUserDetailsImpl());});
    }
    @Test
    public void NativeInboundException2parsers() throws IOException, NSLException, NoSuchFieldException {

        FieldSetter.setField(nativeParserV2,nativeParserV2.getClass().
                getDeclaredField("parserService"), parserService);
        FieldSetter.setField(nativeParserV2,nativeParserV2.getClass().
                getDeclaredField("txnDataUtils"), txnDataUtils);

        FieldSetter.setField(parserService, parserService.getClass().
                getDeclaredField("fileUploadUtil"),fileUploadUtil);

        File file = ResourceUtils.getFile("classpath:parsers/testcsvparser.csv");
        InputStream inputStream = new FileInputStream(file);

        Mockito.when(adaptorCommonsProperties.getAppDsdSingleFileUploadUrl()).thenReturn("https://qa3.nslhub.com/dsd-files-store/upload/file");

        Mockito.when(restTemplate.exchange(eq("https://qa3.nslhub.com/dsd-files-store/upload/file"),eq(HttpMethod.POST),any(),eq(JsonNode.class))).thenThrow(NSLException.class);
        GeneralEntity tcesGeneralEntity = inboundParserUtils.nativetcesGeneralEntity();
        Map<String,String> cusystemprops = new HashMap<>();
        cusystemprops.put("fileName","testfile");
        cusystemprops.put("fileType","native");
        TxnData expectedObj = inboundParserUtils.getNativeres();
        org.junit.Assert.assertThrows(Exception.class,() -> {nativeParserV2.inboundParser(inputStream, tcesGeneralEntity, true, cusystemprops, LayerType.TRIGGERCES, new AuthenticatedUserDetailsImpl());});
    }
    @Test
    public void NativeInboundV2parsers() throws IOException, NSLException, NoSuchFieldException {

        FieldSetter.setField(nativeParserV2, nativeParserV2.getClass().
                getDeclaredField("parserService"), parserService);
        FieldSetter.setField(nativeParserV2, nativeParserV2.getClass().
                getDeclaredField("txnDataUtils"), txnDataUtils);
        FieldSetter.setField(parserService, parserService.getClass().
                getDeclaredField("fileUploadUtil"),fileUploadUtil);
        File file = ResourceUtils.getFile("classpath:parsers/testcsvparser.csv");
        InputStream inputStream = new FileInputStream(file);

        Mockito.when(adaptorCommonsProperties.getAppDsdSingleFileUploadUrl()).thenReturn("https://qa3.nslhub.com/dsd-files-store/upload/file");

        Mockito.when(restTemplate.exchange(eq("https://qa3.nslhub.com/dsd-files-store/upload/file"),eq(HttpMethod.POST),any(),eq(JsonNode.class))).thenReturn(ResponseEntity.ok(inboundParserUtils.getFileUploadres()));

        GeneralEntity tcesGeneralEntity = inboundParserUtils.nativetcesGeneralEntity();
        Map<String, String> cusystemprops = new HashMap<>();
        cusystemprops.put("fileName", "testfile");
        cusystemprops.put("fileType", "native");
        List<TxnGeneralEntity> actualObj = nativeParserV2.inboundParserV2(inputStream, tcesGeneralEntity, true, cusystemprops, LayerType.TRIGGERCES, new AuthenticatedUserDetailsImpl());
        org.junit.Assert.assertNotNull(actualObj);
    }

}
