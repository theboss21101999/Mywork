package com.nsl.adapter.commons.service;

import ca.uhn.hl7v2.DefaultHapiContext;
import ca.uhn.hl7v2.HapiContext;
import ca.uhn.hl7v2.parser.CanonicalModelClassFactory;
import ca.uhn.hl7v2.parser.Parser;
import com.nsl.adapter.commons.serviceImpl.CreateEntityServiceImpl;
import com.nsl.adapter.commons.utils.IRDRUtils;
import com.nsl.adapter.commons.utils.create_entity.*;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.dao.RoleDao;
import com.nsl.logical.dao.UserDao;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.Role;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class CreateEntityServiceImplTest {

    @InjectMocks
    CreateEntityServiceImpl createEntityService;

    @Mock
    AuthenticatedUserDetailsImpl authBean;

    @InjectMocks
    CreateEntityFactory createEntityFactory;

    @Mock
    GeneralEntityDao generalEntityDao;

    @InjectMocks
    CreateEntityFromJsonSchemaUtil createEntityFromJSONSCHEMAUtil;

    @InjectMocks
    CreateEntityFromJSONUtil createEntityFromJSONUtil;

    @InjectMocks
    CreateEntityFromCSVUtil createEntityFromCSVUtil;

    @InjectMocks
    CreateEntityFromHL7 createEntityFromHL7;

    @InjectMocks
    CreateEntityFromXML createEntityFromXML;

    @Mock
    SaveBetsService saveBetsService;

    @InjectMocks
    IRDRUtils irdrUtils;

    @Mock
    RoleDao roleRdfDao;

    @Mock
    UserDao userDao;


    @Test
    public void convertIntoEntityTest1() throws NoSuchFieldException, IOException, NSLException {

        FieldSetter.setField(createEntityService,createEntityService.getClass().
                                                    getDeclaredField("createEntityFactory"),createEntityFactory );
        FieldSetter.setField(createEntityFactory,createEntityFactory.getClass().
                                            getDeclaredField("createEntityFromJSONUtil"),createEntityFromJSONUtil );
        FieldSetter.setField(createEntityFromJSONUtil ,createEntityFromJSONUtil.getClass().
                                                                    getDeclaredField("irdrUtils"), irdrUtils);

        InputStream inputStream = new ClassPathResource("creatEntity_testFiles/createEntityFromJson.json").getInputStream();
        MultipartFile file = new MockMultipartFile("test.json",inputStream);

        Mockito.when( roleRdfDao.getRoleByName(any(),any())).thenReturn(true);
        Mockito.when(roleRdfDao.getNamedRole(any(),any())).thenReturn(new Role());

        Mockito.when(saveBetsService.saveGeneralEntity(any())).thenAnswer(
                (Answer<TenantCUEntityInput>) invocation -> invocation.getArgument(0));

        createEntityService.convertIntoEntity("json",file,"entity_name",null);

    }

    @Test
    public void convertIntoEntityTest2() throws NoSuchFieldException, IOException, NSLException {

        FieldSetter.setField(createEntityService,createEntityService.getClass().
                getDeclaredField("createEntityFactory"),createEntityFactory );
        FieldSetter.setField(createEntityFactory,createEntityFactory.getClass().
                getDeclaredField("createEntityFromJSONSCHEMAUtil"),createEntityFromJSONSCHEMAUtil);
        FieldSetter.setField(createEntityFromJSONSCHEMAUtil ,createEntityFromJSONSCHEMAUtil.getClass().
                getDeclaredField("irdrUtils"), irdrUtils);

        InputStream inputStream = new ClassPathResource("creatEntity_testFiles/createEntityFromJsonSchema.json").getInputStream();
        MultipartFile file = new MockMultipartFile("test.json",inputStream);

        Mockito.when( roleRdfDao.getRoleByName(any(),any())).thenReturn(true);
        Mockito.when(roleRdfDao.getNamedRole(any(),any())).thenReturn(new Role());

        Mockito.when(saveBetsService.saveGeneralEntity(any())).thenAnswer(
                (Answer<TenantCUEntityInput>) invocation -> invocation.getArgument(0));

        createEntityService.convertIntoEntity("jsonschema",file,"entity_name",null);

    }

    @Test
    public void convertIntoEntityTest3() throws NoSuchFieldException, IOException, NSLException {

        FieldSetter.setField(createEntityService,createEntityService.getClass().
                getDeclaredField("createEntityFactory"),createEntityFactory );
        FieldSetter.setField(createEntityFactory,createEntityFactory.getClass().
                getDeclaredField("createEntityFromCSVUtil"),createEntityFromCSVUtil);
        FieldSetter.setField(createEntityFromCSVUtil ,createEntityFromCSVUtil.getClass().
                getDeclaredField("irdrUtils"), irdrUtils);

        InputStream inputStream = new ClassPathResource("creatEntity_testFiles/createEntityFromCSV.txt").getInputStream();
        MultipartFile file = new MockMultipartFile("test.json",inputStream);

        Mockito.when( roleRdfDao.getRoleByName(any(),any())).thenReturn(true);
        Mockito.when(roleRdfDao.getNamedRole(any(),any())).thenReturn(new Role());

        Mockito.when(saveBetsService.saveGeneralEntity(any())).thenAnswer(
                (Answer<TenantCUEntityInput>) invocation -> invocation.getArgument(0));

        createEntityService.convertIntoEntity("csv",file,"entity_name",null);

    }

    @Test
    public void convertIntoEntityTest4() throws NoSuchFieldException, IOException, NSLException {

        FieldSetter.setField(createEntityService,createEntityService.getClass().
                getDeclaredField("createEntityFactory"),createEntityFactory );
        FieldSetter.setField(createEntityFactory,createEntityFactory.getClass().
                getDeclaredField("createEntityFromHL7"),createEntityFromHL7);
        FieldSetter.setField(createEntityFromHL7 ,createEntityFromHL7.getClass().
                getDeclaredField("irdrUtils"), irdrUtils);

        Parser parser;
        try (HapiContext context = new DefaultHapiContext(new CanonicalModelClassFactory("2.5"))){
            parser = context.getPipeParser();
        }catch (Exception e){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"failed to parse the message" +
                    e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }
        FieldSetter.setField(createEntityFromHL7,createEntityFromHL7.getClass().
                getDeclaredField("parser"),parser );

        InputStream inputStream = new ClassPathResource("creatEntity_testFiles/createEntityFromHL7.txt").getInputStream();
        MultipartFile file = new MockMultipartFile("test.json",inputStream);

        Mockito.when( roleRdfDao.getRoleByName(any(),any())).thenReturn(true);
        Mockito.when(roleRdfDao.getNamedRole(any(),any())).thenReturn(new Role());

        Mockito.when(saveBetsService.saveGeneralEntity(any())).thenAnswer(
                (Answer<TenantCUEntityInput>) invocation -> invocation.getArgument(0));

        createEntityService.convertIntoEntity("hl7",file,"entity_name",null);

    }

    @Test
    public void convertIntoEntityTest5() throws NoSuchFieldException, IOException, NSLException {

        FieldSetter.setField(createEntityService,createEntityService.getClass().
                getDeclaredField("createEntityFactory"),createEntityFactory );
        FieldSetter.setField(createEntityFactory,createEntityFactory.getClass().
                getDeclaredField("createEntityFromXML"),createEntityFromXML);
        FieldSetter.setField(createEntityFromXML ,createEntityFromXML.getClass().
                getDeclaredField("irdrUtils"), irdrUtils);


        InputStream inputStream = new ClassPathResource("creatEntity_testFiles/createEntityFromXML.xml").getInputStream();
        MultipartFile file = new MockMultipartFile("test.xml",inputStream);

        Mockito.when( roleRdfDao.getRoleByName(any(),any())).thenReturn(true);
        Mockito.when(roleRdfDao.getNamedRole(any(),any())).thenReturn(new Role());

        Mockito.when(saveBetsService.saveGeneralEntity(any())).thenAnswer(
                (Answer<TenantCUEntityInput>) invocation -> invocation.getArgument(0));

        createEntityService.convertIntoEntity("xml",file,"entity_name",null);

    }



}
