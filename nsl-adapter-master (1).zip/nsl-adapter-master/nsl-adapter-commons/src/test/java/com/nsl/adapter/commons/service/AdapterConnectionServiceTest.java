package com.nsl.adapter.commons.service;

import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.model.CreateSecretResult;
import com.amazonaws.services.secretsmanager.model.UpdateSecretResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.adapter.commons.dto.connections.S3AdapterConnectionDto;
import com.nsl.adapter.commons.serviceImpl.AWSSecretManagerServiceImpl;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.CreateGeneralEntityCUDao;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.dao.SearchCUDAO;
import com.nsl.logical.dao.SecretManagerDao;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.LinkedList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class AdapterConnectionServiceTest {

    @InjectMocks
    AdapterConnectionServiceV3 adapterConnectionServiceV3;

    @Mock
    GeneralEntityDao generalEntityDao;

    @Mock
    CreateGeneralEntityCUDao createGeneralEntityCUDao;

    @Mock
    SearchCUDAO searchCUDAO;

    @InjectMocks
    ConnectionDataToolsV3 connectionDataToolsV3;

    @InjectMocks
    SaveBetsService saveBetsService;

    @InjectMocks
    AWSSecretManagerServiceImpl awsSecretManagerService;

    @Mock
    SecretManagerDao secretManagerDao;

    @Mock
    AdaptorCommonsProperties adaptorCommonsProperties;

    @Mock
    RestTemplate restTemplate;


    @Test
    public void saveConnectionTest() throws JsonProcessingException, NoSuchFieldException {

        FieldSetter.setField(adapterConnectionServiceV3,adapterConnectionServiceV3.getClass().
                                                        getDeclaredField("saveBetsService"),saveBetsService );
        FieldSetter.setField(adapterConnectionServiceV3,adapterConnectionServiceV3.getClass().
                getDeclaredField("connectionDataToolsV3"),connectionDataToolsV3 );

        FieldSetter.setField(connectionDataToolsV3,connectionDataToolsV3.getClass().
                getDeclaredField("awsSecretManagerService"),awsSecretManagerService );

        ResponseEntity<JsonNode> resp_ent=new ResponseEntity<>(getSeedresponse(), HttpStatus.OK);
        Mockito.doReturn(resp_ent).when(restTemplate).exchange(anyString(),eq(HttpMethod.GET),any(), ArgumentMatchers.eq(JsonNode.class));
        Mockito.when(generalEntityDao.findByName(any(),any())).thenReturn(getGE());
        Mockito.when(searchCUDAO.getEntities(any(),any())).thenReturn(new LinkedList<>());

        Mockito.when(secretManagerDao.saveSecret(anyString(), anyString())).thenReturn("scdc");

        S3AdapterConnectionDto dto = new S3AdapterConnectionDto();
        dto.setConnectionName("aaa");
        dto.setRegion("ap-south-1");
        dto.setAccessKey("aaa");
        dto.setSecretKey("bbbd");
        List<TxnGeneralEntity> txnGeneralEntities = List.of(getTxnGE());
        Mockito.when(createGeneralEntityCUDao.saveEntities(any(),any(),any(),any(),anyBoolean(),any())).thenReturn(txnGeneralEntities);

        TxnGeneralEntityRecord result = adapterConnectionServiceV3.saveConnection("NSL_S3_connection", JacksonUtils.getValueToTree(dto), new AuthenticatedUserDetailsImpl());

        org.junit.Assert.assertEquals("1386425819339",result.getId().toString());
    }

    @Test
    public void updateConnectionTest() throws JsonProcessingException, NoSuchFieldException {

        FieldSetter.setField(adapterConnectionServiceV3,adapterConnectionServiceV3.getClass().
                getDeclaredField("saveBetsService"),saveBetsService );
        FieldSetter.setField(adapterConnectionServiceV3,adapterConnectionServiceV3.getClass().
                getDeclaredField("connectionDataToolsV3"),connectionDataToolsV3 );

        FieldSetter.setField(connectionDataToolsV3,connectionDataToolsV3.getClass().
                getDeclaredField("awsSecretManagerService"),awsSecretManagerService );

        ResponseEntity<JsonNode> resp_ent=new ResponseEntity<>(getSeedresponse(), HttpStatus.OK);
        Mockito.doReturn(resp_ent).when(restTemplate).exchange(eq("null/entity/reserved/name/NSL_S3_connection"),eq(HttpMethod.GET),any(), ArgumentMatchers.eq(JsonNode.class));
        Mockito.when(generalEntityDao.findByName(any(),any())).thenReturn(getGE());
        Mockito.when(searchCUDAO.getEntities(any(),any())).thenReturn(List.of(getRecords()));

        Mockito.when(secretManagerDao.updateSecret(anyString(), anyString())).thenReturn("scdc");

        S3AdapterConnectionDto dto = new S3AdapterConnectionDto();
        dto.setConnectionName("aaa");
        dto.setRegion("ap-south-1");
        dto.setAccessKey("aaa");
        dto.setSecretKey("bbbd");

        List<TxnGeneralEntity> txnGeneralEntities = List.of(getTxnGE());
        Mockito.when(createGeneralEntityCUDao.saveEntities(any(),any(),any(),any(),anyBoolean(),any())).thenReturn(txnGeneralEntities);

        TxnGeneralEntityRecord result = adapterConnectionServiceV3.updateConnection("NSL_S3_connection", JacksonUtils.getValueToTree(dto),615420035493L,new AuthenticatedUserDetailsImpl());

        org.junit.Assert.assertEquals("1386425819339",result.getId().toString());
    }

    @Test
    public void getConnByIdTest() throws NoSuchFieldException, JsonProcessingException {

        FieldSetter.setField(adapterConnectionServiceV3,adapterConnectionServiceV3.getClass().
                getDeclaredField("saveBetsService"),saveBetsService );
        Mockito.when(restTemplate.exchange(eq("null/entity/reserved/name/NSL_S3_connection"),eq(HttpMethod.GET),any(),
                eq(JsonNode.class))).thenReturn(ResponseEntity.ok(getSeedresponse()));
        Mockito.when(searchCUDAO.getEntities(any(),any())).thenReturn(List.of(getRecords()));

        Mockito.when(generalEntityDao.findByName(any(),any())).thenReturn(getGE());

        TxnGeneralEntityRecord result = adapterConnectionServiceV3.getConnById("NSL_S3_connection",615420035493L,new AuthenticatedUserDetailsImpl());

        org.junit.Assert.assertEquals("615420035493",result.getId().toString());
    }




    private JsonNode getSeedresponse() throws JsonProcessingException {
       String jsonString = "{\"status\":200,\"message\":\"Fetched Reserved Entity using Name\",\"result\":{\"dsdId\":\"1607258979889\",\"id\":1607258979889,\"nslAttributes\":[{\"dsdId\":\"1691756105282\",\"id\":1691756105282,\"attributeType\":{\"type\":\"string\",\"uiElement\":{\"name\":\"Text\",\"dataType\":\"string\",\"uiElement\":\"text\",\"isMulti\":false}},\"defaultValue\":\"null\",\"isReserved\":false,\"isInPotentiality\":true,\"triggerConditionalPotentiality\":false,\"ownerId\":1907863430259,\"canDownload\":false,\"exportDesignSystem\":true,\"naqResultsForBET\":{\"hasChildrenErrors\":false},\"name\":\"accessKey\",\"displayName\":\"accessKey\",\"source\":\"CANVAS\",\"status\":\"DRAFT\",\"isNameUpdated\":false,\"attachments\":[],\"minAge\":0,\"maxAge\":0,\"editable\":false,\"approvalStatus\":\"UnAssigned\"},{\"dsdId\":\"842031966821\",\"id\":842031966821,\"attributeType\":{\"type\":\"encryptedtext\",\"uiElement\":{\"name\":\"Encrypt Text\",\"dataType\":\"encryptedtext\",\"uiElement\":\"encrypttext\",\"isMulti\":false}},\"defaultValue\":\"null\",\"isReserved\":false,\"isInPotentiality\":true,\"triggerConditionalPotentiality\":false,\"ownerId\":1907863430259,\"canDownload\":false,\"exportDesignSystem\":true,\"naqResultsForBET\":{\"hasChildrenErrors\":false},\"name\":\"secretKey\",\"displayName\":\"secretKey\",\"source\":\"CANVAS\",\"status\":\"DRAFT\",\"isNameUpdated\":false,\"attachments\":[],\"minAge\":0,\"maxAge\":0,\"editable\":false,\"approvalStatus\":\"UnAssigned\"},{\"dsdId\":\"931388720274\",\"id\":931388720274,\"attributeType\":{\"type\":\"string\",\"uiElement\":{\"name\":\"Text\",\"dataType\":\"string\",\"uiElement\":\"text\",\"isMulti\":false}},\"defaultValue\":\"null\",\"isReserved\":false,\"isInPotentiality\":true,\"triggerConditionalPotentiality\":false,\"ownerId\":1907863430259,\"canDownload\":false,\"exportDesignSystem\":true,\"naqResultsForBET\":{\"hasChildrenErrors\":false},\"name\":\"region\",\"displayName\":\"region\",\"source\":\"CANVAS\",\"status\":\"DRAFT\",\"isNameUpdated\":false,\"attachments\":[],\"minAge\":0,\"maxAge\":0,\"editable\":false,\"approvalStatus\":\"UnAssigned\"},{\"dsdId\":\"1921082764580\",\"id\":1921082764580,\"attributeType\":{\"type\":\"string\",\"uiElement\":{\"name\":\"Text\",\"dataType\":\"string\",\"uiElement\":\"text\",\"isMulti\":false}},\"defaultValue\":\"null\",\"isReserved\":false,\"isInPotentiality\":true,\"triggerConditionalPotentiality\":false,\"ownerId\":1907863430259,\"canDownload\":false,\"exportDesignSystem\":true,\"naqResultsForBET\":{\"hasChildrenErrors\":false},\"name\":\"connectionName\",\"displayName\":\"connectionName\",\"source\":\"CANVAS\",\"status\":\"DRAFT\",\"isNameUpdated\":false,\"attachments\":[],\"minAge\":0,\"maxAge\":0,\"editable\":false,\"approvalStatus\":\"UnAssigned\"}],\"entityProperties\":{\"isConfig\":\"true\",\"subCategory\":\"S3\",\"category\":\"Adapter\"},\"isReserved\":true,\"ownerId\":1907863430259,\"canDownload\":false,\"exportDesignSystem\":true,\"naqResultsForBET\":{\"hasChildrenErrors\":false},\"name\":\"NSL_S3_Connection\",\"displayName\":\"NSL_S3_Connection\",\"description\":\"NSL_S3_Connection\",\"source\":\"CANVAS\",\"masterId\":6596117227,\"version\":\"2.0\",\"status\":\"PUBLISHED\",\"isNameUpdated\":false,\"ontology\":[{\"id\":\"common\",\"name\":\"common\",\"displayName\":\"Common\",\"level\":1,\"isValidated\":false}],\"attachments\":[],\"keywords\":[],\"publisher\":{\"id\":\"nslhub.com\",\"name\":\"nslhub.com\"},\"author\":{\"id\":\"1597730747003\",\"name\":\"mohith.vegi@nslhub.com\",\"email\":[\"mohith.vegi@nslhub.com\"]},\"minAge\":0,\"maxAge\":0,\"editable\":false,\"approvalStatus\":\"UnAssigned\"}}";

        return new ObjectMapper().readTree(jsonString);
    }

    public GeneralEntity getGE(){
        String jsonString = "{\n" +
                "  \"name\": \"NSL_S3_Connection\",\n" +
                "  \"displayName\": \"NSL_S3_Connection\",\n" +
                "  \"entityProperties\": {\n" +
                "    \"isConfig\": \"true\",\n" +
                "    \"subCategory\": \"S3\",\n" +
                "    \"category\": \"Adapter\"\n" +
                "  },\n" +
                "  \"masterId\": 6596117227,\n" +
                "  \"version\": \"2.0\",\n" +
                "  \"status\": \"PUBLISHED\",\n" +
                "  \"nslAttributes\": [\n" +
                "    {\n" +
                "      \"name\": \"accessKey\",\n" +
                "      \"displayName\": \"accessKey\",\n" +
                "      \"attributeType\": {\n" +
                "        \"type\": \"string\"\n" +
                "      },\n" +
                "      \"canDownload\": false,\n" +
                "      \"defaultValue\": \"null\",\n" +
                "      \"isReserved\": false,\n" +
                "      \"isInPotentiality\": true,\n" +
                "      \"triggerConditionalPotentiality\": false,\n" +
                "      \"id\": 1691756105282,\n" +
                "      \"guid\": \"f3c97a30-4dda-4e02-8ff5-a5e22c3bffdc\",\n" +
                "      \"ownerId\": 1907863430259,\n" +
                "      \"createdAt\": 1655442039023,\n" +
                "      \"createdBy\": 1907863430259,\n" +
                "      \"updatedAt\": 1655442039026,\n" +
                "      \"updatedBy\": 1907863430259,\n" +
                "      \"isNameUpdated\": false\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"secretKey\",\n" +
                "      \"displayName\": \"secretKey\",\n" +
                "      \"attributeType\": {\n" +
                "        \"type\": \"encryptedtext\"\n" +
                "      },\n" +
                "      \"canDownload\": false,\n" +
                "      \"defaultValue\": \"null\",\n" +
                "      \"isReserved\": false,\n" +
                "      \"isInPotentiality\": true,\n" +
                "      \"triggerConditionalPotentiality\": false,\n" +
                "      \"id\": 842031966821,\n" +
                "      \"guid\": \"ff1a6e39-2286-41e0-9ee2-f3fc88d37385\",\n" +
                "      \"ownerId\": 1907863430259,\n" +
                "      \"createdAt\": 1655442039023,\n" +
                "      \"createdBy\": 1907863430259,\n" +
                "      \"updatedAt\": 1655442039026,\n" +
                "      \"updatedBy\": 1907863430259,\n" +
                "      \"isNameUpdated\": false\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"region\",\n" +
                "      \"displayName\": \"region\",\n" +
                "      \"attributeType\": {\n" +
                "        \"type\": \"string\"\n" +
                "      },\n" +
                "      \"canDownload\": false,\n" +
                "      \"defaultValue\": \"null\",\n" +
                "      \"isReserved\": false,\n" +
                "      \"isInPotentiality\": true,\n" +
                "      \"triggerConditionalPotentiality\": false,\n" +
                "      \"id\": 931388720274,\n" +
                "      \"guid\": \"83fcffa2-b7a9-4763-ada0-b865b8eeb707\",\n" +
                "      \"ownerId\": 1907863430259,\n" +
                "      \"createdAt\": 1655442039023,\n" +
                "      \"createdBy\": 1907863430259,\n" +
                "      \"updatedAt\": 1655442039026,\n" +
                "      \"updatedBy\": 1907863430259,\n" +
                "      \"isNameUpdated\": false\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"connectionName\",\n" +
                "      \"displayName\": \"connectionName\",\n" +
                "      \"attributeType\": {\n" +
                "        \"type\": \"string\"\n" +
                "      },\n" +
                "      \"canDownload\": false,\n" +
                "      \"defaultValue\": \"null\",\n" +
                "      \"isReserved\": false,\n" +
                "      \"isInPotentiality\": true,\n" +
                "      \"triggerConditionalPotentiality\": false,\n" +
                "      \"id\": 1921082764580,\n" +
                "      \"guid\": \"8736f101-ff90-4b4e-9a09-5806d3be9e99\",\n" +
                "      \"ownerId\": 1907863430259,\n" +
                "      \"createdAt\": 1655442039023,\n" +
                "      \"createdBy\": 1907863430259,\n" +
                "      \"updatedAt\": 1655442039026,\n" +
                "      \"updatedBy\": 1907863430259,\n" +
                "      \"isNameUpdated\": false\n" +
                "    }\n" +
                "  ],\n" +
                "  \"isReserved\": true,\n" +
                "  \"id\": 1607258979889,\n" +
                "  \"guid\": \"fcc4aa86-5b36-4fc4-9818-48e3f53848af\",\n" +
                "  \"ownerId\": 1907863430259,\n" +
                "  \"createdAt\": 1655442039023,\n" +
                "  \"createdBy\": 1907863430259,\n" +
                "  \"updatedAt\": 1655442039026,\n" +
                "  \"updatedBy\": 1907863430259,\n" +
                "  \"isNameUpdated\": false\n" +
                "}";
        return JacksonUtils.getObjectFromJsonString(jsonString,GeneralEntity.class);
    }

    private TxnGeneralEntityRecord getRecords(){
        String jsonString = "{\n" +
                "  \"generalEntityId\": 1607258979889,\n" +
                "  \"generalEntityMasterId\": 6596117227,\n" +
                "  \"txnNslAttribute\": [\n" +
                "    {\n" +
                "      \"name\": \"accessKey\",\n" +
                "      \"nslAttributeID\": 1691756105282,\n" +
                "      \"values\": [\n" +
                "        \"AKIAZTMT7RSFYYJW5VWC\"\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"secretKey\",\n" +
                "      \"nslAttributeID\": 842031966821,\n" +
                "      \"values\": [\n" +
                "        \"AdapterConnection/NSL_S3_Connection/secretKey/adaptertest/s3_connection_satya\"\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"region\",\n" +
                "      \"nslAttributeID\": 931388720274,\n" +
                "      \"values\": [\n" +
                "        \"ap-south-1\"\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"connectionName\",\n" +
                "      \"nslAttributeID\": 1921082764580,\n" +
                "      \"values\": [\n" +
                "        \"s3_connection_satya\"\n" +
                "      ]\n" +
                "    }\n" +
                "  ],\n" +
                "  \"id\": 615420035493,\n" +
                "  \"guid\": \"5a55afac-91c1-4923-94fd-81ef223a9611\",\n" +
                "  \"ownerId\": 1907863430259,\n" +
                "  \"createdAt\": 1655442245323,\n" +
                "  \"createdBy\": 1907863430259,\n" +
                "  \"updatedAt\": 1655442245323,\n" +
                "  \"updatedBy\": 1907863430259,\n" +
                "  \"orgUnitId\": 1507450764610\n" +
                "}";

        return JacksonUtils.getObjectFromJsonString(jsonString, TxnGeneralEntityRecord.class);
    }

    public TxnGeneralEntity getTxnGE(){
        String response = "{\"name\":\"NSL_SFTP_Connection\",\"generalEntityID\":17292291542,\"generalEntityMasterId\":9741578548,\"transEntityRecords\":[{\"generalEntityId\":17292291542,\"generalEntityMasterId\":9741578548,\"txnNslAttribute\":[{\"name\":\"host\",\"nslAttributeID\":1607810315844,\"values\":[\"167.151.156.240\"]},{\"name\":\"port\",\"nslAttributeID\":18405735644,\"values\":[\"22\"]},{\"name\":\"authentication\",\"nslAttributeID\":1984809591953,\"values\":[\"{\\\"type\\\":\\\"KEYPASSWORD\\\",\\\"username\\\":\\\"admin\\\",\\\"password\\\":\\\"AdapterConnection/NSL_SFTP_Connection/password/qa3/apiqa2405/SFTPConnection_2023070710084060841\\\",\\\"sshKey\\\":\\\"12134343\\\"}\"]},{\"name\":\"connectionName\",\"nslAttributeID\":1776470997881,\"values\":[\"SFTPConnection_2023070710084060841\"]}],\"id\":1386425819339,\"ownerId\":82836092627,\"orgUnitId\":1789593988777}],\"isLastBatch\":false,\"isMasterData\":true,\"isBulkImport\":false,\"id\":550571271614,\"ownerId\":82836092627}";
        return JacksonUtils.getObjectFromJsonString(response,TxnGeneralEntity.class);
    }

}
