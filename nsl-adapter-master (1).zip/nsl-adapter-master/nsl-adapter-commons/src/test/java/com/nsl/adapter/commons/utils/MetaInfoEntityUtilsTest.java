package com.nsl.adapter.commons.utils;

import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.MetaInfoEntityDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.impl.AdapterConnectionsDynamoDao;
import com.nsl.adapter.commons.impl.AdapterConnectionsRedisDao;
import com.nsl.adapter.commons.impl.AdapterConnectionsSelectorDao;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Qualifier;

import static org.mockito.ArgumentMatchers.any;


@RunWith(MockitoJUnitRunner.class)
public class MetaInfoEntityUtilsTest {

    @InjectMocks
    MetaInfoEntityUtils metaInfoEntityUtils;

    @InjectMocks
    AdapterConnectionsSelectorDao adapterConnectionsSelectorDao;

    @Mock
    @Qualifier("adapterConnectionsDynamoDao")
    AdapterConnnectionsDao adapterConnectionsDynamoDao;

    @Mock
    AdaptorCommonsProperties adaptorCommonsProperties;

    @Mock
    @Qualifier("adapterConnectionsRedisDao")
    AdapterConnnectionsDao adapterConnectionsRedisDao;

    @Test
    public void saveMetaInfoEntityTest() throws NoSuchFieldException {

        FieldSetter.setField(metaInfoEntityUtils,metaInfoEntityUtils.getClass().
                getDeclaredField("adapterConnnectionsDao"), adapterConnectionsSelectorDao );
        FieldSetter.setField(adapterConnectionsSelectorDao,adapterConnectionsSelectorDao.getClass().
                getDeclaredField("adapterConnnectionsDynamoDao"), adapterConnectionsDynamoDao );
        FieldSetter.setField(adapterConnectionsSelectorDao,adapterConnectionsSelectorDao.getClass().
                getDeclaredField("adapterConnnectionsRedisDao"), adapterConnectionsRedisDao );

        TxnAdapterConnection adapterConnection = getRecord();
        Mockito.when(adapterConnectionsDynamoDao.saveConnection(any(),any())).thenReturn(adapterConnection);
        Mockito.when(adapterConnectionsRedisDao.saveConnection(any(),any())).thenReturn(adapterConnection);
        Mockito.when(adaptorCommonsProperties.getCacheEnabled()).thenReturn(true);

        String resp = metaInfoEntityUtils.createMetaInfoEntity("cuName",new AuthenticatedUserDetailsImpl());

        org.junit.Assert.assertEquals(resp,"cuName");

    }

    @Test
    public void updateMetaInfoEntityTest() throws NoSuchFieldException {

        FieldSetter.setField(metaInfoEntityUtils,metaInfoEntityUtils.getClass().
                getDeclaredField("adapterConnnectionsDao"), adapterConnectionsSelectorDao );
        FieldSetter.setField(adapterConnectionsSelectorDao,adapterConnectionsSelectorDao.getClass().
                getDeclaredField("adapterConnnectionsDynamoDao"), adapterConnectionsDynamoDao );
        FieldSetter.setField(adapterConnectionsSelectorDao,adapterConnectionsSelectorDao.getClass().
                getDeclaredField("adapterConnnectionsRedisDao"), adapterConnectionsRedisDao );

        TxnAdapterConnection adapterConnection = getRecord();
        Mockito.when(adapterConnectionsDynamoDao.getConnectionByRecordId(any(),any(),any())).thenReturn(adapterConnection);
        Mockito.when(adapterConnectionsDynamoDao.saveConnection(any(),any())).thenReturn(adapterConnection);
        Mockito.when(adapterConnectionsRedisDao.saveConnection(any(),any())).thenReturn(adapterConnection);
        Mockito.when(adaptorCommonsProperties.getCacheEnabled()).thenReturn(true);
        MetaInfoEntityDto metaInfoEntityDto = (MetaInfoEntityDto) adapterConnection.getConnection();

        metaInfoEntityUtils.updateMetaInfoEntity(metaInfoEntityDto,new AuthenticatedUserDetailsImpl());

    }

    @Test
    public void saveNslTxnEntitiesTest() throws NoSuchFieldException {

        FieldSetter.setField(metaInfoEntityUtils,metaInfoEntityUtils.getClass().
                getDeclaredField("adapterConnnectionsDao"), adapterConnectionsSelectorDao );
        FieldSetter.setField(adapterConnectionsSelectorDao,adapterConnectionsSelectorDao.getClass().
                getDeclaredField("adapterConnnectionsDynamoDao"), adapterConnectionsDynamoDao );

        TxnAdapterConnection adapterConnection = getRecord();
        Mockito.when(adapterConnectionsDynamoDao.getConnectionByName(any(),any(),any())).thenReturn(adapterConnection);

        metaInfoEntityUtils.getMetaInfoEntityDto("cuName",new AuthenticatedUserDetailsImpl());
    }

    private TxnAdapterConnection getRecord() {

        TxnAdapterConnection connection = new TxnAdapterConnection();
        connection.setRecordId(2001947409547L);
        connection.setConnectionDtoType(ConnectionDtoType.InboundCu);

        String jsonString = "{\"cuMasterId\":836629264711,\"gsiIdList\":[1677682262589],\"additionalProperties\":{\"lastCuId\":\"2024370153087\",\"configEntityRecordId\":\"1677682262589\",\"lastCuVersion\":\"1.0\",\"version\":\"1.0\"},\"connectionName\":\"cuName\",\"metadata\":{},\"connectionStatus\":\"VALID\"}";
        connection.setConnection(JacksonUtils.fromJson(jsonString, MetaInfoEntityDto.class));
        return connection;

    }

}
