package com.nsl.adapter.commons.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.util.ResourceUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.util.ResourceUtils.getFile;

@RunWith(MockitoJUnitRunner.class)
public class FileUploadUtilTest {

    @InjectMocks
    FileUploadUtil fileUploadUtil;

    @Mock
    AuthenticatedUserDetailsImpl authUser;

    @Mock
    AdaptorCommonsProperties adaptorProperties;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetContentFromUrl() {
        //Arrange
        String contentUrl = "http://example.com/upload";
        //Act
        InputStream inputStream = fileUploadUtil.getContentFromUrl(contentUrl, authUser);
        //Assert
        assertNull(inputStream, "failed to read data from url");

    }

    @Test
    public void testGetData() {
        //Arrange
        GSI gsi = new GSI();

        GeneralEntity entity = new GeneralEntity();
        entity.setName("testEntity");
        entity.setId(123L);

        NslAttribute nslAttribute=new NslAttribute();
        nslAttribute.setId(123L);
        nslAttribute.setName("abcd");
        nslAttribute.setDefaultValue("default");
        List<NslAttribute> nslAttributes=new ArrayList<>();
        nslAttributes.add(nslAttribute);
        entity.setNslAttributes(nslAttributes);

        List<TriggerCU> solutionLogic=new ArrayList<>();
        TriggerCU triggerCU1=new AlternativeCU();
        triggerCU1.setName("Aman");
        triggerCU1.setId(1234L);
        solutionLogic.add(triggerCU1);

        gsi.setId(123L);
        gsi.setName("testGSI");
        gsi.setMasterId(123L);
        gsi.setStatus(StatusEnum.PUBLISHED);
        gsi.setSolutionLogic(solutionLogic);
        //Act
        String value = fileUploadUtil.getDsdFolderPath(gsi, entity, 0);
        //Assert
        assertNotNull(value, "Path Data Received");
    }

    @Test
    public void testUploadSingleFile() {
        try {
            String folder = "testFolder";
            File files = null;
            String url = "http://example.com/upload";
            JsonNode jsonNode = fileUploadUtil.uploadSingleFile(files, folder, authUser);
            assertNull(jsonNode, "test message");
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testUploadMultipleFiles() {
        try {
            String folder = "testFolder";
            List<File> files = null;
            String url = "http://example.com/upload";
            JsonNode jsonNode = fileUploadUtil.uploadMultipleFiles(files, folder, authUser);
            assertNull(jsonNode, "test message");
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Test
    public void testUploadMultipleFiles1() {
        try {
            String folder = "testFolder";
            authUser.setSystemUser(true);
            List<File> files = new ArrayList<>() ;
            File file = getFile("classpath:test_files/abc.txt");
            files.add(file);
            String url = "http://example.com/upload";
            when(adaptorProperties.getAppDsdMultiFilesUploadUrl()).thenReturn(url);
            JsonNode jsonNode = fileUploadUtil.uploadMultipleFiles(files, folder, authUser);
            assertNull(jsonNode, "test message");
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testGetContentSize() {
        //Arrange
        String contentUrl = "http://example.com/upload";
        //Act
        long value = fileUploadUtil.getContentSize(contentUrl, authUser);
        //Assert
        assertNotEquals(0, value);

    }

    @Test
    public void testGetContentSize1() {
        //Arrange
        String contentUrl = null;
        //Act
        long value = fileUploadUtil.getContentSize(contentUrl, authUser);
        //Assert
        assertEquals(0, value);

    }
}
