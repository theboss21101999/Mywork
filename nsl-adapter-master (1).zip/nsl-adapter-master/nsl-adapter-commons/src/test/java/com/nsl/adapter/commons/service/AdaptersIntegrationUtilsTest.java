package com.nsl.adapter.commons.service;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.commons.utils.IRDRUtils;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.dao.RoleDao;
import com.nsl.logical.dao.UserDao;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.ChangeUnit;
import com.nsl.logical.model.Role;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;


@RunWith(MockitoJUnitRunner.class)
public class AdaptersIntegrationUtilsTest {

    @InjectMocks
    AdaptersIntegrationUtils adaptersIntegrationUtils;

    @Mock
    ChangeUnitDao changeUnitDao;

    @InjectMocks
    IRDRUtils irdrUtils;

    @InjectMocks
    SaveBetsService saveBetsService;

    @Mock
    RoleDao roleDao;

    @Mock
    UserDao userDao;

    @Mock
    AuthenticatedUserDetailsImpl authenticatedUserDetails;


    @Mock
    RestTemplate restTemplate;

    @Test
    public void GetCUsListTest() throws Exception {

        Page<ChangeUnit> result = adaptersIntegrationUtils.getCUsList(1, 1, "query", "adapter");

        org.junit.Assert.assertNull(result);

    }

    @Test
    public void CheckCUNameTest() {

        adaptersIntegrationUtils.checkCUName("integration");
        Mockito.when(changeUnitDao.getChangeUnitByName(any(),any())).thenReturn(new ChangeUnit());
        adaptersIntegrationUtils.checkCUName("integration");

    }

    @Test
    public void SaveIntegrationTest() throws Exception {

        FieldSetter.setField(adaptersIntegrationUtils , adaptersIntegrationUtils.getClass().
                                getDeclaredField("irdrUtils"), irdrUtils );
        FieldSetter.setField(adaptersIntegrationUtils , adaptersIntegrationUtils.getClass().
                getDeclaredField("saveBetsService"), saveBetsService );

        Mockito.when(roleDao.saveRole(any(),any())).thenReturn(new Role());

        Mockito.when(restTemplate.exchange(eq("null/tenant/change-unit"),eq(HttpMethod.POST),any(),eq(ApiResponse.class))).
                                        thenReturn(ResponseEntity.ok(getCuSaveResponse()));


        TenantChangeUnitInput result = adaptersIntegrationUtils.saveIntegration(getCuPropsDto());
        org.junit.Assert.assertEquals("s3_put_1517",result.getName());

    }

    @Test
    public void GetIntegrationByIdTest() throws NoSuchFieldException, NSLException {

        FieldSetter.setField(adaptersIntegrationUtils , adaptersIntegrationUtils.getClass().
                getDeclaredField("saveBetsService"), saveBetsService );

        Mockito.when(restTemplate.exchange(eq("null/tenant/change-unit/{dsdId}"),eq(HttpMethod.GET),any(),eq(ApiResponse.class), (Map<String, ?>) any())).
                thenReturn(ResponseEntity.ok(getCuSaveResponse()));

        CUPropsDto result = adaptersIntegrationUtils.getIntegrationById("dsdId");

        org.junit.Assert.assertEquals("s3_put_1517",result.getCuName());
    }

    @Test
    public void UpdateIntegrationTest() throws NoSuchFieldException, NSLException {

        FieldSetter.setField(adaptersIntegrationUtils , adaptersIntegrationUtils.getClass().
                getDeclaredField("saveBetsService"), saveBetsService );
        Mockito.when(restTemplate.exchange(eq("null/tenant/change-unit/{dsdId}"),eq(HttpMethod.GET),any(),eq(ApiResponse.class), (Map<String, ?>) any())).
                thenReturn(ResponseEntity.ok(getCuSaveResponse()));

        Mockito.when(restTemplate.exchange(eq("null/tenant/edit/change-unit/{dsdId}"),eq(HttpMethod.POST),any(),eq(ApiResponse.class), (Map<String, ?>) any())).
                thenReturn(ResponseEntity.ok(getCuSaveResponse()));

        Mockito.when(restTemplate.exchange(eq("null/tenant/change-unit"),eq(HttpMethod.POST),any(),eq(ApiResponse.class))).
                thenReturn(ResponseEntity.ok(getCuSaveResponse()));

        TenantChangeUnitInput result = adaptersIntegrationUtils.updateIntegration("dsdId", getCuPropsDto());

        // Verify the results
    }


    private ApiResponse getCuSaveResponse() {
        String jsonString = "{\n" +
                "  \"dsdId\": \"856701967132\",\n" +
                "  \"id\": 856701967132,\n" +
                "  \"layers\": [\n" +
                "    {\n" +
                "      \"id\": 932667824575,\n" +
                "      \"ownerId\": 814296849840,\n" +
                "      \"participatingItems\": [\n" +
                "        {\n" +
                "          \"id\": 697288822016,\n" +
                "          \"ownerId\": 814296849840,\n" +
                "          \"isMultiValue\": false,\n" +
                "          \"item\": {\n" +
                "            \"TYPE\": \"GeneralEntity\",\n" +
                "            \"DATA\": {\n" +
                "              \"dsdId\": \"475657850692\",\n" +
                "              \"id\": 475657850692,\n" +
                "              \"nslAttributes\": [\n" +
                "                {\n" +
                "                  \"dsdId\": \"854489424451\",\n" +
                "                  \"id\": 854489424451,\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"file\",\n" +
                "                    \"uiElement\": {\n" +
                "                      \"name\": \"File\",\n" +
                "                      \"dataType\": \"file\",\n" +
                "                      \"uiElement\": \"file\",\n" +
                "                      \"isMulti\": false\n" +
                "                    }\n" +
                "                  },\n" +
                "                  \"attributeClassification\": \"ESSENTIAL\",\n" +
                "                  \"isReserved\": true,\n" +
                "                  \"isInPotentiality\": true,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"exportDesignSystem\": true,\n" +
                "                  \"naqResultsForBET\": {\n" +
                "                    \"hasChildrenErrors\": false\n" +
                "                  },\n" +
                "                  \"name\": \"File\",\n" +
                "                  \"displayName\": \"File\",\n" +
                "                  \"source\": \"CANVAS\",\n" +
                "                  \"status\": \"DRAFT\",\n" +
                "                  \"isNameUpdated\": false,\n" +
                "                  \"attachments\": [],\n" +
                "                  \"minAge\": 0,\n" +
                "                  \"maxAge\": 0,\n" +
                "                  \"editable\": false,\n" +
                "                  \"approvalStatus\": \"UnAssigned\"\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isReserved\": true,\n" +
                "              \"canDownload\": false,\n" +
                "              \"exportDesignSystem\": true,\n" +
                "              \"naqResultsForBET\": {\n" +
                "                \"hasChildrenErrors\": false\n" +
                "              },\n" +
                "              \"name\": \"NSL_Adapter_Native_File\",\n" +
                "              \"displayName\": \"NSL_Adapter_Native_File\",\n" +
                "              \"description\": \"NSL_Adapter_Native_File\",\n" +
                "              \"source\": \"CANVAS\",\n" +
                "              \"masterId\": 10698260263,\n" +
                "              \"version\": \"1.0\",\n" +
                "              \"status\": \"PUBLISHED\",\n" +
                "              \"isNameUpdated\": false,\n" +
                "              \"ontology\": [\n" +
                "                {\n" +
                "                  \"id\": \"common\",\n" +
                "                  \"name\": \"common\",\n" +
                "                  \"displayName\": \"Common\",\n" +
                "                  \"level\": 1,\n" +
                "                  \"isValidated\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"attachments\": [],\n" +
                "              \"keywords\": [],\n" +
                "              \"publisher\": {\n" +
                "                \"id\": \"nslhub.com\",\n" +
                "                \"name\": \"nslhub.com\"\n" +
                "              },\n" +
                "              \"author\": {\n" +
                "                \"id\": \"1597730747003\",\n" +
                "                \"name\": \"mohith.vegi@nslhub.com\",\n" +
                "                \"email\": [\n" +
                "                  \"mohith.vegi@nslhub.com\"\n" +
                "                ]\n" +
                "              },\n" +
                "              \"minAge\": 0,\n" +
                "              \"maxAge\": 0,\n" +
                "              \"editable\": false,\n" +
                "              \"approvalStatus\": \"UnAssigned\"\n" +
                "            }\n" +
                "          },\n" +
                "          \"isInPotentiality\": false,\n" +
                "          \"triggerConditionalPotentiality\": false,\n" +
                "          \"isPlaceholder\": false\n" +
                "        },\n" +
                "        {\n" +
                "          \"id\": 1387941589935,\n" +
                "          \"ownerId\": 814296849840,\n" +
                "          \"isMultiValue\": false,\n" +
                "          \"item\": {\n" +
                "            \"TYPE\": \"GeneralEntity\",\n" +
                "            \"DATA\": {\n" +
                "              \"dsdId\": \"519254659086\",\n" +
                "              \"id\": 519254659086,\n" +
                "              \"nslAttributes\": [\n" +
                "                {\n" +
                "                  \"dsdId\": \"692353117897\",\n" +
                "                  \"id\": 692353117897,\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"string\",\n" +
                "                    \"uiElement\": {\n" +
                "                      \"name\": \"Text\",\n" +
                "                      \"dataType\": \"string\",\n" +
                "                      \"uiElement\": \"text\",\n" +
                "                      \"isMulti\": false\n" +
                "                    }\n" +
                "                  },\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"nslAttributeMetaData\": {\n" +
                "                    \"changeDriverType\": \"OPTIONAL\",\n" +
                "                    \"transLiterate\": false\n" +
                "                  },\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"exportDesignSystem\": true,\n" +
                "                  \"naqResultsForBET\": {\n" +
                "                    \"hasChildrenErrors\": false\n" +
                "                  },\n" +
                "                  \"name\": \"fileName\",\n" +
                "                  \"source\": \"CANVAS\",\n" +
                "                  \"status\": \"DRAFT\",\n" +
                "                  \"isNameUpdated\": false,\n" +
                "                  \"attachments\": [],\n" +
                "                  \"minAge\": 0,\n" +
                "                  \"maxAge\": 0,\n" +
                "                  \"editable\": false,\n" +
                "                  \"approvalStatus\": \"UnAssigned\"\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isReserved\": true,\n" +
                "              \"designTimeRights\": [\n" +
                "                {\n" +
                "                  \"informationRight\": true,\n" +
                "                  \"decisionRight\": true,\n" +
                "                  \"executionRight\": false,\n" +
                "                  \"rightHolderId\": 312295005996,\n" +
                "                  \"rightHolderType\": \"ROLE\",\n" +
                "                  \"rightHolderName\": \"GlobalIRDR\",\n" +
                "                  \"disableParentRoleAccess\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"txnTimeRights\": [\n" +
                "                {\n" +
                "                  \"informationRight\": true,\n" +
                "                  \"decisionRight\": true,\n" +
                "                  \"executionRight\": true,\n" +
                "                  \"rightHolderId\": 312295005996,\n" +
                "                  \"rightHolderType\": \"ROLE\",\n" +
                "                  \"rightHolderName\": \"GlobalIRDR\",\n" +
                "                  \"disableParentRoleAccess\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"canDownload\": false,\n" +
                "              \"exportDesignSystem\": true,\n" +
                "              \"naqResultsForBET\": {\n" +
                "                \"hasChildrenErrors\": false\n" +
                "              },\n" +
                "              \"name\": \"NSL_S3_Put_Req\",\n" +
                "              \"displayName\": \"NSL_S3_Put_Req\",\n" +
                "              \"description\": \"NSL_S3_Put_Req\",\n" +
                "              \"source\": \"CANVAS\",\n" +
                "              \"version\": \"1.0\",\n" +
                "              \"status\": \"PUBLISHED\",\n" +
                "              \"isNameUpdated\": false,\n" +
                "              \"ontology\": [\n" +
                "                {\n" +
                "                  \"id\": \"common\",\n" +
                "                  \"name\": \"common\",\n" +
                "                  \"displayName\": \"Common\",\n" +
                "                  \"level\": 1,\n" +
                "                  \"isValidated\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"attachments\": [],\n" +
                "              \"keywords\": [],\n" +
                "              \"publisher\": {\n" +
                "                \"id\": \"nslhub.com\",\n" +
                "                \"name\": \"nslhub.com\"\n" +
                "              },\n" +
                "              \"author\": {\n" +
                "                \"id\": \"1597730747003\",\n" +
                "                \"name\": \"mohith.vegi@nslhub.com\",\n" +
                "                \"email\": [\n" +
                "                  \"mohith.vegi@nslhub.com\"\n" +
                "                ]\n" +
                "              },\n" +
                "              \"minAge\": 0,\n" +
                "              \"maxAge\": 0,\n" +
                "              \"editable\": false,\n" +
                "              \"approvalStatus\": \"UnAssigned\"\n" +
                "            }\n" +
                "          },\n" +
                "          \"isInPotentiality\": false,\n" +
                "          \"triggerConditionalPotentiality\": false,\n" +
                "          \"isPlaceholder\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"naqResultsForBET\": {\n" +
                "        \"hasChildrenErrors\": false\n" +
                "      },\n" +
                "      \"type\": \"physical\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"id\": 1755875184492,\n" +
                "      \"ownerId\": 814296849840,\n" +
                "      \"participatingItems\": [\n" +
                "        {\n" +
                "          \"id\": 860195330752,\n" +
                "          \"ownerId\": 814296849840,\n" +
                "          \"isMultiValue\": false,\n" +
                "          \"item\": {\n" +
                "            \"TYPE\": \"GeneralEntity\",\n" +
                "            \"DATA\": {\n" +
                "              \"dsdId\": \"816849876199\",\n" +
                "              \"id\": 816849876199,\n" +
                "              \"nslAttributes\": [\n" +
                "                {\n" +
                "                  \"dsdId\": \"2041664765644\",\n" +
                "                  \"id\": 2041664765644,\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"string\"\n" +
                "                  },\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"exportDesignSystem\": true,\n" +
                "                  \"naqResultsForBET\": {\n" +
                "                    \"hasChildrenErrors\": false\n" +
                "                  },\n" +
                "                  \"name\": \"response\",\n" +
                "                  \"source\": \"CANVAS\",\n" +
                "                  \"status\": \"DRAFT\",\n" +
                "                  \"isNameUpdated\": false,\n" +
                "                  \"attachments\": [],\n" +
                "                  \"minAge\": 0,\n" +
                "                  \"maxAge\": 0,\n" +
                "                  \"editable\": false,\n" +
                "                  \"approvalStatus\": \"UnAssigned\"\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isReserved\": true,\n" +
                "              \"designTimeRights\": [\n" +
                "                {\n" +
                "                  \"informationRight\": true,\n" +
                "                  \"decisionRight\": true,\n" +
                "                  \"executionRight\": false,\n" +
                "                  \"rightHolderId\": 312295005996,\n" +
                "                  \"rightHolderType\": \"ROLE\",\n" +
                "                  \"rightHolderName\": \"GlobalIRDR\",\n" +
                "                  \"disableParentRoleAccess\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"txnTimeRights\": [\n" +
                "                {\n" +
                "                  \"informationRight\": true,\n" +
                "                  \"decisionRight\": true,\n" +
                "                  \"executionRight\": true,\n" +
                "                  \"rightHolderId\": 312295005996,\n" +
                "                  \"rightHolderType\": \"ROLE\",\n" +
                "                  \"rightHolderName\": \"GlobalIRDR\",\n" +
                "                  \"disableParentRoleAccess\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"canDownload\": false,\n" +
                "              \"exportDesignSystem\": true,\n" +
                "              \"naqResultsForBET\": {\n" +
                "                \"hasChildrenErrors\": false\n" +
                "              },\n" +
                "              \"name\": \"NSL_Native_InboundAdapter_Resp\",\n" +
                "              \"displayName\": \"NSL_Native_InboundAdapter_Resp\",\n" +
                "              \"description\": \"NSL_Native_InboundAdapter_Resp\",\n" +
                "              \"source\": \"CANVAS\",\n" +
                "              \"masterId\": 8775081175,\n" +
                "              \"version\": \"1.0\",\n" +
                "              \"status\": \"PUBLISHED\",\n" +
                "              \"isNameUpdated\": false,\n" +
                "              \"ontology\": [\n" +
                "                {\n" +
                "                  \"id\": \"common\",\n" +
                "                  \"name\": \"common\",\n" +
                "                  \"displayName\": \"Common\",\n" +
                "                  \"level\": 1,\n" +
                "                  \"isValidated\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"attachments\": [],\n" +
                "              \"keywords\": [],\n" +
                "              \"publisher\": {\n" +
                "                \"id\": \"cduiqa\",\n" +
                "                \"name\": \"cduiqa\"\n" +
                "              },\n" +
                "              \"author\": {\n" +
                "                \"id\": \"5579112569\",\n" +
                "                \"name\": \"admin@nslhub.com\",\n" +
                "                \"email\": [\n" +
                "                  \"admin@nslhub.com\"\n" +
                "                ]\n" +
                "              },\n" +
                "              \"minAge\": 0,\n" +
                "              \"maxAge\": 0,\n" +
                "              \"editable\": false,\n" +
                "              \"approvalStatus\": \"UnAssigned\"\n" +
                "            }\n" +
                "          },\n" +
                "          \"isInPotentiality\": false,\n" +
                "          \"triggerConditionalPotentiality\": false,\n" +
                "          \"isPlaceholder\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"naqResultsForBET\": {\n" +
                "        \"hasChildrenErrors\": false\n" +
                "      },\n" +
                "      \"type\": \"triggerCES\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"gsiList\": [],\n" +
                "  \"agents\": [\n" +
                "    {\n" +
                "      \"agentType\": \"human\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"isReserved\": true,\n" +
                "  \"reservedCUType\": \"externalSolution:s3_put_1517\",\n" +
                "  \"cuSystemProperties\": {\n" +
                "    \"bucketName\": \"fractal-signature\",\n" +
                "    \"fileName\": \"file\",\n" +
                "    \"adapter\": \"S3\",\n" +
                "    \"configEntityRecordId\": \"1340651931729\",\n" +
                "    \"extSolnsType\": \"Adapter\",\n" +
                "    \"Folder\": \"home/test\",\n" +
                "    \"operation\": \"PUT\",\n" +
                "    \"fileType\": \"native\",\n" +
                "    \"configEntityRecordName\": \"s3conn_2101_v1\"\n" +
                "  },\n" +
                "  \"ownerId\": 814296849840,\n" +
                "  \"designTimeRights\": [\n" +
                "    {\n" +
                "      \"informationRight\": true,\n" +
                "      \"decisionRight\": true,\n" +
                "      \"executionRight\": false,\n" +
                "      \"rightHolderId\": 2042178466464,\n" +
                "      \"rightHolderType\": \"ROLE\",\n" +
                "      \"rightHolderName\": \"adapterDesigner\",\n" +
                "      \"disableParentRoleAccess\": false\n" +
                "    }\n" +
                "  ],\n" +
                "  \"tenant\": {\n" +
                "    \"id\": \"adapterdemo\",\n" +
                "    \"name\": \"adapterdemo\"\n" +
                "  },\n" +
                "  \"dsdMetadataId\": \"c6fd10e8-1386-4c29-b048-4345040fc92d\",\n" +
                "  \"exportDesignSystem\": true,\n" +
                "  \"naqResultsForBET\": {\n" +
                "    \"hasChildrenErrors\": false\n" +
                "  },\n" +
                "  \"name\": \"s3_put_1517\",\n" +
                "  \"displayName\": \"s3_put_1517\",\n" +
                "  \"description\": \"s3_put_1517\",\n" +
                "  \"source\": \"CANVAS\",\n" +
                "  \"masterId\": 856701967132,\n" +
                "  \"version\": \"1.0\",\n" +
                "  \"status\": \"PUBLISHED\",\n" +
                "  \"isNameUpdated\": false,\n" +
                "  \"ontology\": [\n" +
                "    {\n" +
                "      \"id\": \"common\",\n" +
                "      \"name\": \"common\",\n" +
                "      \"displayName\": \"Common\",\n" +
                "      \"level\": 1,\n" +
                "      \"isValidated\": false\n" +
                "    }\n" +
                "  ],\n" +
                "  \"attachments\": [],\n" +
                "  \"keywords\": [],\n" +
                "  \"publisher\": {\n" +
                "    \"id\": \"adapterdemo\",\n" +
                "    \"name\": \"adapterdemo\"\n" +
                "  },\n" +
                "  \"author\": {\n" +
                "    \"id\": \"814296849840\",\n" +
                "    \"name\": \"admin@nslhub.com\",\n" +
                "    \"email\": [\n" +
                "      \"admin@nslhub.com\"\n" +
                "    ]\n" +
                "  },\n" +
                "  \"minAge\": 0,\n" +
                "  \"maxAge\": 0,\n" +
                "  \"editable\": false,\n" +
                "  \"approvalStatus\": \"UnAssigned\"\n" +
                "}";
        ApiResponse response = new ApiResponse();
        response.setMessage("s3_put_1517 is saved");
        response.setStatus(200);
        response.setResult(JacksonUtils.getObjectFromJsonString(jsonString, HashMap.class));

        return response;
    }

    private CUPropsDto getCuPropsDto() {

        String jsonString = "{\n" +
                "  \"cuName\": \"s3_put_1517\",\n" +
                "  \"isMachineCU\": false,\n" +
                "  \"cuSystemProps\": {\n" +
                "    \"bucketName\": \"fractal-signature\",\n" +
                "    \"fileName\": \"file\",\n" +
                "    \"adapter\": \"S3\",\n" +
                "    \"configEntityRecordId\": \"1340651931729\",\n" +
                "    \"extSolnsType\": \"Adapter\",\n" +
                "    \"Folder\": \"home/test\",\n" +
                "    \"operation\": \"PUT\",\n" +
                "    \"fileType\": \"native\",\n" +
                "    \"configEntityRecordName\": \"s3conn_2101_v1\"\n" +
                "  },\n" +
                "  \"physicalLayerItems\": [\n" +
                "    {\n" +
                "      \"dsdId\": \"475657850692\",\n" +
                "      \"id\": 475657850692,\n" +
                "      \"nslAttributes\": [\n" +
                "        {\n" +
                "          \"dsdId\": \"854489424451\",\n" +
                "          \"id\": 854489424451,\n" +
                "          \"attributeType\": {\n" +
                "            \"type\": \"file\",\n" +
                "            \"uiElement\": {\n" +
                "              \"name\": \"File\",\n" +
                "              \"dataType\": \"file\",\n" +
                "              \"uiElement\": \"file\",\n" +
                "              \"isMulti\": false\n" +
                "            }\n" +
                "          },\n" +
                "          \"attributeClassification\": \"ESSENTIAL\",\n" +
                "          \"isReserved\": true,\n" +
                "          \"isInPotentiality\": true,\n" +
                "          \"triggerConditionalPotentiality\": false,\n" +
                "          \"canDownload\": false,\n" +
                "          \"naqResultsForBET\": {\n" +
                "            \"hasChildrenErrors\": false\n" +
                "          },\n" +
                "          \"name\": \"File\",\n" +
                "          \"displayName\": \"File\",\n" +
                "          \"source\": \"CANVAS\",\n" +
                "          \"status\": \"DRAFT\",\n" +
                "          \"isNameUpdated\": false,\n" +
                "          \"ontology\": [],\n" +
                "          \"attachments\": [],\n" +
                "          \"keywords\": [],\n" +
                "          \"minAge\": 0,\n" +
                "          \"maxAge\": 0,\n" +
                "          \"editable\": false,\n" +
                "          \"approvalStatus\": \"UnAssigned\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"isReserved\": true,\n" +
                "      \"canDownload\": false,\n" +
                "      \"naqResultsForBET\": {\n" +
                "        \"hasChildrenErrors\": false\n" +
                "      },\n" +
                "      \"name\": \"NSL_Adapter_Native_File\",\n" +
                "      \"displayName\": \"NSL_Adapter_Native_File\",\n" +
                "      \"description\": \"NSL_Adapter_Native_File\",\n" +
                "      \"source\": \"CANVAS\",\n" +
                "      \"masterId\": 10698260263,\n" +
                "      \"version\": \"1.0\",\n" +
                "      \"status\": \"PUBLISHED\",\n" +
                "      \"isNameUpdated\": false,\n" +
                "      \"ontology\": [\n" +
                "        {\n" +
                "          \"id\": \"common\",\n" +
                "          \"name\": \"common\",\n" +
                "          \"displayName\": \"Common\",\n" +
                "          \"level\": 1,\n" +
                "          \"isValidated\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"attachments\": [],\n" +
                "      \"keywords\": [],\n" +
                "      \"publisher\": {\n" +
                "        \"id\": \"nslhub.com\",\n" +
                "        \"name\": \"nslhub.com\"\n" +
                "      },\n" +
                "      \"author\": {\n" +
                "        \"id\": \"1597730747003\",\n" +
                "        \"name\": \"mohith.vegi@nslhub.com\",\n" +
                "        \"email\": [\n" +
                "          \"mohith.vegi@nslhub.com\"\n" +
                "        ]\n" +
                "      },\n" +
                "      \"minAge\": 0,\n" +
                "      \"maxAge\": 0,\n" +
                "      \"editable\": false,\n" +
                "      \"approvalStatus\": \"UnAssigned\"\n" +
                "    },\n" +
                "    {\n" +
                "      \"dsdId\": \"519254659086\",\n" +
                "      \"id\": 519254659086,\n" +
                "      \"nslAttributes\": [\n" +
                "        {\n" +
                "          \"dsdId\": \"692353117897\",\n" +
                "          \"id\": 692353117897,\n" +
                "          \"attributeType\": {\n" +
                "            \"type\": \"string\",\n" +
                "            \"uiElement\": {\n" +
                "              \"name\": \"Text\",\n" +
                "              \"dataType\": \"string\",\n" +
                "              \"uiElement\": \"text\",\n" +
                "              \"isMulti\": false\n" +
                "            }\n" +
                "          },\n" +
                "          \"isReserved\": false,\n" +
                "          \"isInPotentiality\": false,\n" +
                "          \"triggerConditionalPotentiality\": false,\n" +
                "          \"nslAttributeMetaData\": {\n" +
                "            \"changeDriverType\": \"OPTIONAL\",\n" +
                "            \"transLiterate\": false\n" +
                "          },\n" +
                "          \"canDownload\": false,\n" +
                "          \"naqResultsForBET\": {\n" +
                "            \"hasChildrenErrors\": false\n" +
                "          },\n" +
                "          \"name\": \"fileName\",\n" +
                "          \"source\": \"CANVAS\",\n" +
                "          \"status\": \"DRAFT\",\n" +
                "          \"isNameUpdated\": false,\n" +
                "          \"ontology\": [],\n" +
                "          \"attachments\": [],\n" +
                "          \"keywords\": [],\n" +
                "          \"minAge\": 0,\n" +
                "          \"maxAge\": 0,\n" +
                "          \"editable\": false,\n" +
                "          \"approvalStatus\": \"UnAssigned\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"isReserved\": true,\n" +
                "      \"designTimeRights\": [\n" +
                "        {\n" +
                "          \"informationRight\": true,\n" +
                "          \"decisionRight\": true,\n" +
                "          \"executionRight\": false,\n" +
                "          \"rightHolderId\": 312295005996,\n" +
                "          \"rightHolderType\": \"ROLE\",\n" +
                "          \"rightHolderName\": \"GlobalIRDR\",\n" +
                "          \"disableParentRoleAccess\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"txnTimeRights\": [\n" +
                "        {\n" +
                "          \"informationRight\": true,\n" +
                "          \"decisionRight\": true,\n" +
                "          \"executionRight\": true,\n" +
                "          \"rightHolderId\": 312295005996,\n" +
                "          \"rightHolderType\": \"ROLE\",\n" +
                "          \"rightHolderName\": \"GlobalIRDR\",\n" +
                "          \"disableParentRoleAccess\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"canDownload\": false,\n" +
                "      \"naqResultsForBET\": {\n" +
                "        \"hasChildrenErrors\": false\n" +
                "      },\n" +
                "      \"name\": \"NSL_S3_Put_Req\",\n" +
                "      \"displayName\": \"NSL_S3_Put_Req\",\n" +
                "      \"description\": \"NSL_S3_Put_Req\",\n" +
                "      \"source\": \"CANVAS\",\n" +
                "      \"version\": \"1.0\",\n" +
                "      \"status\": \"PUBLISHED\",\n" +
                "      \"isNameUpdated\": false,\n" +
                "      \"ontology\": [\n" +
                "        {\n" +
                "          \"id\": \"common\",\n" +
                "          \"name\": \"common\",\n" +
                "          \"displayName\": \"Common\",\n" +
                "          \"level\": 1,\n" +
                "          \"isValidated\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"attachments\": [],\n" +
                "      \"keywords\": [],\n" +
                "      \"publisher\": {\n" +
                "        \"id\": \"nslhub.com\",\n" +
                "        \"name\": \"nslhub.com\"\n" +
                "      },\n" +
                "      \"author\": {\n" +
                "        \"id\": \"1597730747003\",\n" +
                "        \"name\": \"mohith.vegi@nslhub.com\",\n" +
                "        \"email\": [\n" +
                "          \"mohith.vegi@nslhub.com\"\n" +
                "        ]\n" +
                "      },\n" +
                "      \"minAge\": 0,\n" +
                "      \"maxAge\": 0,\n" +
                "      \"editable\": false,\n" +
                "      \"approvalStatus\": \"UnAssigned\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"triggerCESLayerItems\": [\n" +
                "    {\n" +
                "      \"dsdId\": \"816849876199\",\n" +
                "      \"id\": 816849876199,\n" +
                "      \"nslAttributes\": [\n" +
                "        {\n" +
                "          \"dsdId\": \"2041664765644\",\n" +
                "          \"id\": 2041664765644,\n" +
                "          \"attributeType\": {\n" +
                "            \"type\": \"string\"\n" +
                "          },\n" +
                "          \"isReserved\": false,\n" +
                "          \"isInPotentiality\": false,\n" +
                "          \"triggerConditionalPotentiality\": false,\n" +
                "          \"canDownload\": false,\n" +
                "          \"naqResultsForBET\": {\n" +
                "            \"hasChildrenErrors\": false\n" +
                "          },\n" +
                "          \"name\": \"response\",\n" +
                "          \"source\": \"CANVAS\",\n" +
                "          \"status\": \"DRAFT\",\n" +
                "          \"isNameUpdated\": false,\n" +
                "          \"ontology\": [],\n" +
                "          \"attachments\": [],\n" +
                "          \"keywords\": [],\n" +
                "          \"minAge\": 0,\n" +
                "          \"maxAge\": 0,\n" +
                "          \"editable\": false,\n" +
                "          \"approvalStatus\": \"UnAssigned\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"isReserved\": true,\n" +
                "      \"designTimeRights\": [\n" +
                "        {\n" +
                "          \"informationRight\": true,\n" +
                "          \"decisionRight\": true,\n" +
                "          \"executionRight\": false,\n" +
                "          \"rightHolderId\": 312295005996,\n" +
                "          \"rightHolderType\": \"ROLE\",\n" +
                "          \"rightHolderName\": \"GlobalIRDR\",\n" +
                "          \"disableParentRoleAccess\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"txnTimeRights\": [\n" +
                "        {\n" +
                "          \"informationRight\": true,\n" +
                "          \"decisionRight\": true,\n" +
                "          \"executionRight\": true,\n" +
                "          \"rightHolderId\": 312295005996,\n" +
                "          \"rightHolderType\": \"ROLE\",\n" +
                "          \"rightHolderName\": \"GlobalIRDR\",\n" +
                "          \"disableParentRoleAccess\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"canDownload\": false,\n" +
                "      \"naqResultsForBET\": {\n" +
                "        \"hasChildrenErrors\": false\n" +
                "      },\n" +
                "      \"name\": \"NSL_Native_InboundAdapter_Resp\",\n" +
                "      \"displayName\": \"NSL_Native_InboundAdapter_Resp\",\n" +
                "      \"description\": \"NSL_Native_InboundAdapter_Resp\",\n" +
                "      \"source\": \"CANVAS\",\n" +
                "      \"masterId\": 8775081175,\n" +
                "      \"version\": \"1.0\",\n" +
                "      \"status\": \"PUBLISHED\",\n" +
                "      \"isNameUpdated\": false,\n" +
                "      \"ontology\": [\n" +
                "        {\n" +
                "          \"id\": \"common\",\n" +
                "          \"name\": \"common\",\n" +
                "          \"displayName\": \"Common\",\n" +
                "          \"level\": 1,\n" +
                "          \"isValidated\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"attachments\": [],\n" +
                "      \"keywords\": [],\n" +
                "      \"publisher\": {\n" +
                "        \"id\": \"cduiqa\",\n" +
                "        \"name\": \"cduiqa\"\n" +
                "      },\n" +
                "      \"author\": {\n" +
                "        \"id\": \"5579112569\",\n" +
                "        \"name\": \"admin@nslhub.com\",\n" +
                "        \"email\": [\n" +
                "          \"admin@nslhub.com\"\n" +
                "        ]\n" +
                "      },\n" +
                "      \"minAge\": 0,\n" +
                "      \"maxAge\": 0,\n" +
                "      \"editable\": false,\n" +
                "      \"approvalStatus\": \"UnAssigned\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"informationLayerItems\": [\n" +
                "    {\n" +
                "      \"dsdId\": \"816849876199\",\n" +
                "      \"id\": 816849876199,\n" +
                "      \"nslAttributes\": [\n" +
                "        {\n" +
                "          \"dsdId\": \"2041664765644\",\n" +
                "          \"id\": 2041664765644,\n" +
                "          \"attributeType\": {\n" +
                "            \"type\": \"string\"\n" +
                "          },\n" +
                "          \"isReserved\": false,\n" +
                "          \"isInPotentiality\": false,\n" +
                "          \"triggerConditionalPotentiality\": false,\n" +
                "          \"canDownload\": false,\n" +
                "          \"naqResultsForBET\": {\n" +
                "            \"hasChildrenErrors\": false\n" +
                "          },\n" +
                "          \"name\": \"response\",\n" +
                "          \"source\": \"CANVAS\",\n" +
                "          \"status\": \"DRAFT\",\n" +
                "          \"isNameUpdated\": false,\n" +
                "          \"ontology\": [],\n" +
                "          \"attachments\": [],\n" +
                "          \"keywords\": [],\n" +
                "          \"minAge\": 0,\n" +
                "          \"maxAge\": 0,\n" +
                "          \"editable\": false,\n" +
                "          \"approvalStatus\": \"UnAssigned\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"isReserved\": true,\n" +
                "      \"designTimeRights\": [\n" +
                "        {\n" +
                "          \"informationRight\": true,\n" +
                "          \"decisionRight\": true,\n" +
                "          \"executionRight\": false,\n" +
                "          \"rightHolderId\": 312295005996,\n" +
                "          \"rightHolderType\": \"ROLE\",\n" +
                "          \"rightHolderName\": \"GlobalIRDR\",\n" +
                "          \"disableParentRoleAccess\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"txnTimeRights\": [\n" +
                "        {\n" +
                "          \"informationRight\": true,\n" +
                "          \"decisionRight\": true,\n" +
                "          \"executionRight\": true,\n" +
                "          \"rightHolderId\": 312295005996,\n" +
                "          \"rightHolderType\": \"ROLE\",\n" +
                "          \"rightHolderName\": \"GlobalIRDR\",\n" +
                "          \"disableParentRoleAccess\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"canDownload\": false,\n" +
                "      \"naqResultsForBET\": {\n" +
                "        \"hasChildrenErrors\": false\n" +
                "      },\n" +
                "      \"name\": \"NSL_Native_InboundAdapter_Resp\",\n" +
                "      \"displayName\": \"NSL_Native_InboundAdapter_Resp\",\n" +
                "      \"description\": \"NSL_Native_InboundAdapter_Resp\",\n" +
                "      \"source\": \"CANVAS\",\n" +
                "      \"masterId\": 8775081175,\n" +
                "      \"version\": \"1.0\",\n" +
                "      \"status\": \"PUBLISHED\",\n" +
                "      \"isNameUpdated\": false,\n" +
                "      \"ontology\": [\n" +
                "        {\n" +
                "          \"id\": \"common\",\n" +
                "          \"name\": \"common\",\n" +
                "          \"displayName\": \"Common\",\n" +
                "          \"level\": 1,\n" +
                "          \"isValidated\": false\n" +
                "        }\n" +
                "      ],\n" +
                "      \"attachments\": [],\n" +
                "      \"keywords\": [],\n" +
                "      \"publisher\": {\n" +
                "        \"id\": \"cduiqa\",\n" +
                "        \"name\": \"cduiqa\"\n" +
                "      },\n" +
                "      \"author\": {\n" +
                "        \"id\": \"5579112569\",\n" +
                "        \"name\": \"admin@nslhub.com\",\n" +
                "        \"email\": [\n" +
                "          \"admin@nslhub.com\"\n" +
                "        ]\n" +
                "      },\n" +
                "      \"minAge\": 0,\n" +
                "      \"maxAge\": 0,\n" +
                "      \"editable\": false,\n" +
                "      \"approvalStatus\": \"UnAssigned\"\n" +
                "    }\n" +
                "  ]\n" +
                "}";
//        return JacksonUtils.getObjectFromJsonString(jsonString, CUPropsDto.class);
        return JacksonUtils.getObjectFromJsonString(jsonString, CUPropsDto.class);
    }

}
