package com.nsl.adapter.commons.parsers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnData;

public class InboundParserUtils {

    public GeneralEntity tcesGeneralEntity() {
        String jsonString = "{\n" +
                "  \"name\": \"gdrive_put_Request\",\n" +
                "  \"displayName\": \"gdrive_put_Request\",\n" +
                "  \"masterId\": 177163449201,\n" +
                "  \"version\": \"1.0\",\n" +
                "  \"status\": \"PUBLISHED\",\n" +
                "  \"nslAttributes\": [\n" +
                "    {\n" +
                "      \"name\": \"name\",\n" +
                "      \"displayName\": \"name\",\n" +
                "      \"attributeType\": {\n" +
                "        \"type\": \"string\"\n" +
                "      },\n" +
                "      \"canDownload\": false,\n" +
                "      \"isReserved\": false,\n" +
                "      \"isInPotentiality\": false,\n" +
                "      \"triggerConditionalPotentiality\": false,\n" +
                "      \"id\": 705859676916,\n" +
                "      \"guid\": \"33a62b5c-d7fc-47a1-bd36-6fbb18632a73\",\n" +
                "      \"ownerId\": 1907863430259,\n" +
                "      \"createdAt\": 1664181322148,\n" +
                "      \"createdBy\": 1907863430259,\n" +
                "      \"updatedAt\": 1664181322152,\n" +
                "      \"updatedBy\": 1907863430259,\n" +
                "      \"isNameUpdated\": false\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"id\",\n" +
                "      \"displayName\": \"id\",\n" +
                "      \"attributeType\": {\n" +
                "        \"type\": \"number\"\n" +
                "      },\n" +
                "      \"canDownload\": false,\n" +
                "      \"isReserved\": false,\n" +
                "      \"isInPotentiality\": false,\n" +
                "      \"triggerConditionalPotentiality\": false,\n" +
                "      \"id\": 2118580369847,\n" +
                "      \"guid\": \"d78951f2-a69f-4d8f-9efc-360439a351d0\",\n" +
                "      \"ownerId\": 1907863430259,\n" +
                "      \"createdAt\": 1664181322148,\n" +
                "      \"createdBy\": 1907863430259,\n" +
                "      \"updatedAt\": 1664181322152,\n" +
                "      \"updatedBy\": 1907863430259,\n" +
                "      \"isNameUpdated\": false\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"contactDetails\",\n" +
                "      \"displayName\": \"contactDetails\",\n" +
                "      \"attributeType\": {\n" +
                "        \"type\": \"entity\",\n" +
                "        \"properties\": {\n" +
                "          \"referencingType\": \"contactDetails\"\n" +
                "        }\n" +
                "      },\n" +
                "      \"canDownload\": false,\n" +
                "      \"isReserved\": false,\n" +
                "      \"generalEntity\": {\n" +
                "        \"name\": \"gdrive_put_Request_contactDetails\",\n" +
                "        \"displayName\": \"gdrive_put_Request_contactDetails\",\n" +
                "        \"masterId\": 1895737678261,\n" +
                "        \"version\": \"1.0\",\n" +
                "        \"status\": \"PUBLISHED\",\n" +
                "        \"nslAttributes\": [\n" +
                "          {\n" +
                "            \"name\": \"address\",\n" +
                "            \"displayName\": \"address\",\n" +
                "            \"attributeType\": {\n" +
                "              \"type\": \"entity\",\n" +
                "              \"properties\": {\n" +
                "                \"referencingType\": \"address\"\n" +
                "              }\n" +
                "            },\n" +
                "            \"canDownload\": false,\n" +
                "            \"isReserved\": false,\n" +
                "            \"generalEntity\": {\n" +
                "              \"name\": \"gdrive_put_Request_contactDetails_address\",\n" +
                "              \"displayName\": \"gdrive_put_Request_contactDetails_address\",\n" +
                "              \"masterId\": 1108142859907,\n" +
                "              \"version\": \"1.0\",\n" +
                "              \"status\": \"PUBLISHED\",\n" +
                "              \"nslAttributes\": [\n" +
                "                {\n" +
                "                  \"name\": \"pinCode\",\n" +
                "                  \"displayName\": \"pinCode\",\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"number\"\n" +
                "                  },\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"id\": 1804078038909,\n" +
                "                  \"guid\": \"1a915aa2-b9a3-473a-a1f3-c1c68f2597e0\",\n" +
                "                  \"ownerId\": 1907863430259,\n" +
                "                  \"createdAt\": 1664181321777,\n" +
                "                  \"createdBy\": 1907863430259,\n" +
                "                  \"updatedAt\": 1664181321780,\n" +
                "                  \"updatedBy\": 1907863430259,\n" +
                "                  \"isNameUpdated\": false\n" +
                "                },\n" +
                "                {\n" +
                "                  \"name\": \"Street\",\n" +
                "                  \"displayName\": \"Street\",\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"string\"\n" +
                "                  },\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"id\": 165540751716,\n" +
                "                  \"guid\": \"92da95fa-08a3-42d2-a8d3-ac404cd0917b\",\n" +
                "                  \"ownerId\": 1907863430259,\n" +
                "                  \"createdAt\": 1664181321777,\n" +
                "                  \"createdBy\": 1907863430259,\n" +
                "                  \"updatedAt\": 1664181321780,\n" +
                "                  \"updatedBy\": 1907863430259,\n" +
                "                  \"isNameUpdated\": false\n" +
                "                },\n" +
                "                {\n" +
                "                  \"name\": \"City\",\n" +
                "                  \"displayName\": \"City\",\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"string\"\n" +
                "                  },\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"id\": 71974458684,\n" +
                "                  \"guid\": \"1f2f9b84-a96e-4f3d-8d13-eb58ab91783a\",\n" +
                "                  \"ownerId\": 1907863430259,\n" +
                "                  \"createdAt\": 1664181321777,\n" +
                "                  \"createdBy\": 1907863430259,\n" +
                "                  \"updatedAt\": 1664181321780,\n" +
                "                  \"updatedBy\": 1907863430259,\n" +
                "                  \"isNameUpdated\": false\n" +
                "                },\n" +
                "                {\n" +
                "                  \"name\": \"email\",\n" +
                "                  \"displayName\": \"email\",\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"string\"\n" +
                "                  },\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"id\": 92646871599,\n" +
                "                  \"guid\": \"4056b9a3-980e-4716-aa51-4a638a1e9b3f\",\n" +
                "                  \"ownerId\": 1907863430259,\n" +
                "                  \"createdAt\": 1664181321777,\n" +
                "                  \"createdBy\": 1907863430259,\n" +
                "                  \"updatedAt\": 1664181321780,\n" +
                "                  \"updatedBy\": 1907863430259,\n" +
                "                  \"isNameUpdated\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isReserved\": false,\n" +
                "              \"id\": 1108142859907,\n" +
                "              \"guid\": \"d878f9fa-c92a-4dc2-9a3b-ad857a881841\",\n" +
                "              \"ownerId\": 1907863430259,\n" +
                "              \"createdAt\": 1664181321777,\n" +
                "              \"createdBy\": 1907863430259,\n" +
                "              \"updatedAt\": 1664181420419,\n" +
                "              \"updatedBy\": 302926936254,\n" +
                "              \"designTimeRights\": [\n" +
                "                {\n" +
                "                  \"informationRight\": true,\n" +
                "                  \"decisionRight\": true,\n" +
                "                  \"executionRight\": false,\n" +
                "                  \"rightHolderId\": 1893442398371,\n" +
                "                  \"rightHolderType\": \"ROLE\",\n" +
                "                  \"rightHolderName\": \"adapterDesigner\",\n" +
                "                  \"disableParentRoleAccess\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isNameUpdated\": false,\n" +
                "              \"dsdMetadataId\": \"727a22c0-14f0-4be0-b2af-5c35a364af39\"\n" +
                "            },\n" +
                "            \"isInPotentiality\": false,\n" +
                "            \"triggerConditionalPotentiality\": false,\n" +
                "            \"id\": 710193827747,\n" +
                "            \"guid\": \"8ce6f129-1ed0-480a-ab65-9c15ccc083a8\",\n" +
                "            \"ownerId\": 1907863430259,\n" +
                "            \"createdAt\": 1664181322022,\n" +
                "            \"createdBy\": 1907863430259,\n" +
                "            \"updatedAt\": 1664181322025,\n" +
                "            \"updatedBy\": 1907863430259,\n" +
                "            \"isNameUpdated\": false\n" +
                "          },\n" +
                "          {\n" +
                "            \"name\": \"mobileNumber\",\n" +
                "            \"displayName\": \"mobileNumber\",\n" +
                "            \"attributeType\": {\n" +
                "              \"type\": \"list\",\n" +
                "              \"nestedNslDataTypeProperties\": {\n" +
                "                \"itemType\": {\n" +
                "                  \"type\": \"number\"\n" +
                "                }\n" +
                "              }\n" +
                "            },\n" +
                "            \"canDownload\": false,\n" +
                "            \"isReserved\": false,\n" +
                "            \"isInPotentiality\": false,\n" +
                "            \"triggerConditionalPotentiality\": false,\n" +
                "            \"id\": 1677597978266,\n" +
                "            \"guid\": \"ac2b1186-486c-48fa-80c9-a5eb7514a1ed\",\n" +
                "            \"ownerId\": 1907863430259,\n" +
                "            \"createdAt\": 1664181322022,\n" +
                "            \"createdBy\": 1907863430259,\n" +
                "            \"updatedAt\": 1664181322025,\n" +
                "            \"updatedBy\": 1907863430259,\n" +
                "            \"isNameUpdated\": false\n" +
                "          },\n" +
                "          {\n" +
                "            \"name\": \"emergencyContacts\",\n" +
                "            \"displayName\": \"emergencyContacts\",\n" +
                "            \"attributeType\": {\n" +
                "              \"type\": \"list\",\n" +
                "              \"nestedNslDataTypeProperties\": {\n" +
                "                \"itemType\": {\n" +
                "                  \"type\": \"entity\"\n" +
                "                }\n" +
                "              },\n" +
                "              \"properties\": {\n" +
                "                \"referencingType\": \"emergencyContacts\"\n" +
                "              }\n" +
                "            },\n" +
                "            \"canDownload\": false,\n" +
                "            \"isReserved\": false,\n" +
                "            \"generalEntity\": {\n" +
                "              \"name\": \"gdrive_put_Request_contactDetails_emergencyContacts\",\n" +
                "              \"displayName\": \"gdrive_put_Request_contactDetails_emergencyContacts\",\n" +
                "              \"masterId\": 1881499165206,\n" +
                "              \"version\": \"1.0\",\n" +
                "              \"status\": \"PUBLISHED\",\n" +
                "              \"nslAttributes\": [\n" +
                "                {\n" +
                "                  \"name\": \"mobileNumber\",\n" +
                "                  \"displayName\": \"mobileNumber\",\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"number\"\n" +
                "                  },\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"id\": 457241716609,\n" +
                "                  \"guid\": \"0c2f56b4-0aa1-40f6-859b-67ec2d8a8671\",\n" +
                "                  \"ownerId\": 1907863430259,\n" +
                "                  \"createdAt\": 1664181321914,\n" +
                "                  \"createdBy\": 1907863430259,\n" +
                "                  \"updatedAt\": 1664181321918,\n" +
                "                  \"updatedBy\": 1907863430259,\n" +
                "                  \"isNameUpdated\": false\n" +
                "                },\n" +
                "                {\n" +
                "                  \"name\": \"name__\",\n" +
                "                  \"displayName\": \"name\",\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"string\"\n" +
                "                  },\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"id\": 132907623673,\n" +
                "                  \"guid\": \"18553c2f-9620-4a8a-928b-c4e99d30dae8\",\n" +
                "                  \"ownerId\": 1907863430259,\n" +
                "                  \"createdAt\": 1664181321914,\n" +
                "                  \"createdBy\": 1907863430259,\n" +
                "                  \"updatedAt\": 1664181321918,\n" +
                "                  \"updatedBy\": 1907863430259,\n" +
                "                  \"isNameUpdated\": false\n" +
                "                },\n" +
                "                {\n" +
                "                  \"name\": \"primary\",\n" +
                "                  \"displayName\": \"primary\",\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"boolean\"\n" +
                "                  },\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"id\": 782873092399,\n" +
                "                  \"guid\": \"0f1d1988-dc1b-4951-8250-68961be29c79\",\n" +
                "                  \"ownerId\": 1907863430259,\n" +
                "                  \"createdAt\": 1664181321914,\n" +
                "                  \"createdBy\": 1907863430259,\n" +
                "                  \"updatedAt\": 1664181321918,\n" +
                "                  \"updatedBy\": 1907863430259,\n" +
                "                  \"isNameUpdated\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isReserved\": false,\n" +
                "              \"id\": 1881499165206,\n" +
                "              \"guid\": \"98f34983-7421-4dde-b298-00ccfc3e6910\",\n" +
                "              \"ownerId\": 1907863430259,\n" +
                "              \"createdAt\": 1664181321914,\n" +
                "              \"createdBy\": 1907863430259,\n" +
                "              \"updatedAt\": 1664181420422,\n" +
                "              \"updatedBy\": 302926936254,\n" +
                "              \"designTimeRights\": [\n" +
                "                {\n" +
                "                  \"informationRight\": true,\n" +
                "                  \"decisionRight\": true,\n" +
                "                  \"executionRight\": false,\n" +
                "                  \"rightHolderId\": 1893442398371,\n" +
                "                  \"rightHolderType\": \"ROLE\",\n" +
                "                  \"rightHolderName\": \"adapterDesigner\",\n" +
                "                  \"disableParentRoleAccess\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isNameUpdated\": false,\n" +
                "              \"dsdMetadataId\": \"3176fda6-a6e0-4691-a553-cacde227e8e4\"\n" +
                "            },\n" +
                "            \"isInPotentiality\": false,\n" +
                "            \"triggerConditionalPotentiality\": false,\n" +
                "            \"id\": 1970026351276,\n" +
                "            \"guid\": \"6e15c459-4df1-4cf0-8730-2591159c4603\",\n" +
                "            \"ownerId\": 1907863430259,\n" +
                "            \"createdAt\": 1664181322022,\n" +
                "            \"createdBy\": 1907863430259,\n" +
                "            \"updatedAt\": 1664181322025,\n" +
                "            \"updatedBy\": 1907863430259,\n" +
                "            \"isNameUpdated\": false\n" +
                "          }\n" +
                "        ],\n" +
                "        \"isReserved\": false,\n" +
                "        \"id\": 1895737678261,\n" +
                "        \"guid\": \"ad20844a-a25a-43de-83dc-22fa59858e8e\",\n" +
                "        \"ownerId\": 1907863430259,\n" +
                "        \"createdAt\": 1664181322022,\n" +
                "        \"createdBy\": 1907863430259,\n" +
                "        \"updatedAt\": 1664181420416,\n" +
                "        \"updatedBy\": 302926936254,\n" +
                "        \"designTimeRights\": [\n" +
                "          {\n" +
                "            \"informationRight\": true,\n" +
                "            \"decisionRight\": true,\n" +
                "            \"executionRight\": false,\n" +
                "            \"rightHolderId\": 1893442398371,\n" +
                "            \"rightHolderType\": \"ROLE\",\n" +
                "            \"rightHolderName\": \"adapterDesigner\",\n" +
                "            \"disableParentRoleAccess\": false\n" +
                "          }\n" +
                "        ],\n" +
                "        \"isNameUpdated\": false,\n" +
                "        \"dsdMetadataId\": \"fea5857d-2012-4514-bc29-e10e813db4e1\"\n" +
                "      },\n" +
                "      \"isInPotentiality\": false,\n" +
                "      \"triggerConditionalPotentiality\": false,\n" +
                "      \"id\": 943881116300,\n" +
                "      \"guid\": \"44c12213-249b-48fa-8702-4750dc3c4553\",\n" +
                "      \"ownerId\": 1907863430259,\n" +
                "      \"createdAt\": 1664181322148,\n" +
                "      \"createdBy\": 1907863430259,\n" +
                "      \"updatedAt\": 1664181322152,\n" +
                "      \"updatedBy\": 1907863430259,\n" +
                "      \"isNameUpdated\": false\n" +
                "    }\n" +
                "  ],\n" +
                "  \"isReserved\": false,\n" +
                "  \"id\": 177163449201,\n" +
                "  \"guid\": \"90b2eeca-2aef-490a-b151-f8cef7a1db4b\",\n" +
                "  \"ownerId\": 1907863430259,\n" +
                "  \"createdAt\": 1664181322148,\n" +
                "  \"createdBy\": 1907863430259,\n" +
                "  \"updatedAt\": 1664181420431,\n" +
                "  \"updatedBy\": 302926936254,\n" +
                "  \"designTimeRights\": [\n" +
                "    {\n" +
                "      \"informationRight\": true,\n" +
                "      \"decisionRight\": true,\n" +
                "      \"executionRight\": false,\n" +
                "      \"rightHolderId\": 1893442398371,\n" +
                "      \"rightHolderType\": \"ROLE\",\n" +
                "      \"rightHolderName\": \"adapterDesigner\",\n" +
                "      \"disableParentRoleAccess\": false\n" +
                "    }\n" +
                "  ],\n" +
                "  \"isNameUpdated\": false,\n" +
                "  \"dsdMetadataId\": \"b709beed-4b5d-45cc-a675-9c3e4ff9cdc7\"\n" +
                "}";

        return JacksonUtils.getObjectFromJsonString(jsonString,GeneralEntity.class);
    }

    public GeneralEntity nativetcesGeneralEntity() {
        String jsonString = "{\n" +
                "  \"name\": \"NSL_Adapter_Native_file\",\n" +
                "  \"masterId\": 8123088003,\n" +
                "  \"version\": \"1.0\",\n" +
                "  \"status\": \"PUBLISHED\",\n" +
                "  \"nslAttributes\": [\n" +
                "    {\n" +
                "      \"name\": \"File\",\n" +
                "      \"attributeType\": {\n" +
                "        \"type\": \"file\"\n" +
                "      },\n" +
                "      \"canDownload\": false,\n" +
                "      \"isReserved\": false,\n" +
                "      \"isInPotentiality\": false,\n" +
                "      \"triggerConditionalPotentiality\": false,\n" +
                "      \"id\": 2067853012918,\n" +
                "      \"guid\": \"c5e05857-f0aa-42f4-922f-96bed15dcfac\",\n" +
                "      \"ownerId\": 1907863430259,\n" +
                "      \"createdAt\": 1646229774470,\n" +
                "      \"createdBy\": 1907863430259,\n" +
                "      \"updatedAt\": 1650018097932,\n" +
                "      \"updatedBy\": 1907863430259\n" +
                "    }\n" +
                "  ],\n" +
                "  \"isReserved\": true,\n" +
                "  \"id\": 2035562528912,\n" +
                "  \"guid\": \"aba2106c-582b-45a4-822d-dfb2a4ebfb34\",\n" +
                "  \"ownerId\": 1907863430259,\n" +
                "  \"createdAt\": 1646229774470,\n" +
                "  \"createdBy\": 1907863430259,\n" +
                "  \"updatedAt\": 1650018097932,\n" +
                "  \"updatedBy\": 1907863430259,\n" +
                "  \"designTimeRights\": [\n" +
                "    {\n" +
                "      \"informationRight\": true,\n" +
                "      \"decisionRight\": true,\n" +
                "      \"executionRight\": false,\n" +
                "      \"rightHolderId\": 78167419163,\n" +
                "      \"rightHolderType\": \"ROLE\",\n" +
                "      \"rightHolderName\": \"GlobalIRDR\",\n" +
                "      \"disableParentRoleAccess\": false\n" +
                "    }\n" +
                "  ],\n" +
                "  \"txnTimeRights\": [\n" +
                "    {\n" +
                "      \"informationRight\": true,\n" +
                "      \"decisionRight\": true,\n" +
                "      \"executionRight\": true,\n" +
                "      \"rightHolderId\": 78167419163,\n" +
                "      \"rightHolderType\": \"ROLE\",\n" +
                "      \"rightHolderName\": \"GlobalIRDR\",\n" +
                "      \"disableParentRoleAccess\": false\n" +
                "    }\n" +
                "  ]\n" +
                "}";
        return JacksonUtils.getObjectFromJsonString(jsonString,GeneralEntity.class);
    }

    public TxnData getNativeres() {
        String jsonString="{\n" +
                "  \"txnCULayer\": [\n" +
                "    {\n" +
                "      \"type\": \"triggerCES\",\n" +
                "      \"txnSlotItems\": [\n" +
                "        {\n" +
                "          \"isMultiValue\": false,\n" +
                "          \"item\": {\n" +
                "            \"TYPE\": \"TxnGeneralEntity\",\n" +
                "            \"DATA\": {\n" +
                "              \"name\": \"NSL_Adapter_Native_file\",\n" +
                "              \"generalEntityID\": 2035562528912,\n" +
                "              \"transEntityRecords\": [\n" +
                "                {\n" +
                "                  \"txnNslAttribute\": [\n" +
                "                    {\n" +
                "                      \"name\": \"File\",\n" +
                "                      \"nslAttributeID\": 2067853012918,\n" +
                "                      \"values\": [\n" +
                "                        \"{\\\"name\\\":\\\"filee51ec44e-7365-4ca0-87cc-a9c6cae80776.txt\\\",\\\"displayName\\\":\\\"filee51ec44e-7365-4ca0-87cc-a9c6cae80776.txt\\\",\\\"description\\\":\\\"filee51ec44e-7365-4ca0-87cc-a9c6cae80776.txt\\\",\\\"dsdId\\\":\\\"633146e247d832246e181f24\\\",\\\"mimeType\\\":\\\"text/plain\\\",\\\"size\\\":\\\"276\\\",\\\"contentUrl\\\":\\\"https://qa3.nslhub.com/dsd-files-store/content/adaptertest/other/filee51ec44e-7365-4ca0-87cc-a9c6cae80776.txt\\\",\\\"originalFileName\\\":\\\"file.txt\\\"}\"\n" +
                "                      ]\n" +
                "                    }\n" +
                "                  ]\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isLastBatch\": false\n" +
                "            }\n" +
                "          }\n" +
                "        }\n" +
                "      ],\n" +
                "      \"recordAdditionalInfo\": false\n" +
                "    }\n" +
                "  ]\n" +
                "}";

        return JacksonUtils.getObjectFromJsonString(jsonString,TxnData.class);
    }

    public TxnData getCsvres() {
        String jsonString ="{\n" +
                "  \"txnCULayer\": [\n" +
                "    {\n" +
                "      \"type\": \"triggerCES\",\n" +
                "      \"txnSlotItems\": [\n" +
                "        {\n" +
                "          \"isMultiValue\": false,\n" +
                "          \"item\": {\n" +
                "            \"TYPE\": \"TxnGeneralEntity\",\n" +
                "            \"DATA\": {\n" +
                "              \"name\": \"gdrive_put_Request\",\n" +
                "              \"generalEntityID\": 177163449201,\n" +
                "              \"transEntityRecords\": [\n" +
                "                {\n" +
                "                  \"txnNslAttribute\": [\n" +
                "                    {\n" +
                "                      \"name\": \"name\",\n" +
                "                      \"nslAttributeID\": 705859676916,\n" +
                "                      \"values\": [\n" +
                "                        \"sriram\"\n" +
                "                      ]\n" +
                "                    },\n" +
                "                    {\n" +
                "                      \"name\": \"id\",\n" +
                "                      \"nslAttributeID\": 2118580369847,\n" +
                "                      \"values\": [\n" +
                "                        \"11111\"\n" +
                "                      ]\n" +
                "                    },\n" +
                "                    {\n" +
                "                      \"name\": \"contactDetails\",\n" +
                "                      \"nslAttributeID\": 943881116300,\n" +
                "                      \"txnGeneralEntity\": {\n" +
                "                        \"name\": \"gdrive_put_Request_contactDetails\",\n" +
                "                        \"generalEntityID\": 1895737678261,\n" +
                "                        \"transEntityRecords\": [\n" +
                "                          {\n" +
                "                            \"txnNslAttribute\": [\n" +
                "                              {\n" +
                "                                \"name\": \"address\",\n" +
                "                                \"nslAttributeID\": 710193827747,\n" +
                "                                \"txnGeneralEntity\": {\n" +
                "                                  \"name\": \"gdrive_put_Request_contactDetails_address\",\n" +
                "                                  \"generalEntityID\": 1108142859907,\n" +
                "                                  \"transEntityRecords\": [\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"pinCode\",\n" +
                "                                          \"nslAttributeID\": 1804078038909,\n" +
                "                                          \"values\": [\n" +
                "                                            \"123\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"Street\",\n" +
                "                                          \"nslAttributeID\": 165540751716,\n" +
                "                                          \"values\": [\n" +
                "                                            \"aaa\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"City\",\n" +
                "                                          \"nslAttributeID\": 71974458684,\n" +
                "                                          \"values\": [\n" +
                "                                            \"aa\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"email\",\n" +
                "                                          \"nslAttributeID\": 92646871599,\n" +
                "                                          \"values\": [\n" +
                "                                            \"adsads\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    }\n" +
                "                                  ],\n" +
                "                                  \"isLastBatch\": false\n" +
                "                                }\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"mobileNumber\",\n" +
                "                                \"nslAttributeID\": 1677597978266,\n" +
                "                                \"values\": [\n" +
                "                                  \"12\"\n" +
                "                                ]\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"emergencyContacts\",\n" +
                "                                \"nslAttributeID\": 1970026351276,\n" +
                "                                \"txnGeneralEntity\": {\n" +
                "                                  \"name\": \"gdrive_put_Request_contactDetails_emergencyContacts\",\n" +
                "                                  \"generalEntityID\": 1881499165206,\n" +
                "                                  \"transEntityRecords\": [\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"mobileNumber\",\n" +
                "                                          \"nslAttributeID\": 457241716609,\n" +
                "                                          \"values\": [\n" +
                "                                            \"1223\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"name\",\n" +
                "                                          \"nslAttributeID\": 132907623673,\n" +
                "                                          \"values\": [\n" +
                "                                            \"pet1\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"primary\",\n" +
                "                                          \"nslAttributeID\": 782873092399,\n" +
                "                                          \"values\": [\n" +
                "                                            \"true\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    }\n" +
                "                                  ],\n" +
                "                                  \"isLastBatch\": false\n" +
                "                                }\n" +
                "                              }\n" +
                "                            ]\n" +
                "                          }\n" +
                "                        ],\n" +
                "                        \"isLastBatch\": false\n" +
                "                      }\n" +
                "                    }\n" +
                "                  ]\n" +
                "                },\n" +
                "                {\n" +
                "                  \"txnNslAttribute\": [\n" +
                "                    {\n" +
                "                      \"name\": \"name\",\n" +
                "                      \"nslAttributeID\": 705859676916,\n" +
                "                      \"values\": [\n" +
                "                        \"sriram\"\n" +
                "                      ]\n" +
                "                    },\n" +
                "                    {\n" +
                "                      \"name\": \"id\",\n" +
                "                      \"nslAttributeID\": 2118580369847,\n" +
                "                      \"values\": [\n" +
                "                        \"111\"\n" +
                "                      ]\n" +
                "                    },\n" +
                "                    {\n" +
                "                      \"name\": \"contactDetails\",\n" +
                "                      \"nslAttributeID\": 943881116300,\n" +
                "                      \"txnGeneralEntity\": {\n" +
                "                        \"name\": \"gdrive_put_Request_contactDetails\",\n" +
                "                        \"generalEntityID\": 1895737678261,\n" +
                "                        \"transEntityRecords\": [\n" +
                "                          {\n" +
                "                            \"txnNslAttribute\": [\n" +
                "                              {\n" +
                "                                \"name\": \"address\",\n" +
                "                                \"nslAttributeID\": 710193827747,\n" +
                "                                \"txnGeneralEntity\": {\n" +
                "                                  \"name\": \"gdrive_put_Request_contactDetails_address\",\n" +
                "                                  \"generalEntityID\": 1108142859907,\n" +
                "                                  \"transEntityRecords\": [\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"pinCode\",\n" +
                "                                          \"nslAttributeID\": 1804078038909,\n" +
                "                                          \"values\": [\n" +
                "                                            \"13\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"Street\",\n" +
                "                                          \"nslAttributeID\": 165540751716,\n" +
                "                                          \"values\": [\n" +
                "                                            \"aa\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"City\",\n" +
                "                                          \"nslAttributeID\": 71974458684,\n" +
                "                                          \"values\": [\n" +
                "                                            \"a\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"email\",\n" +
                "                                          \"nslAttributeID\": 92646871599,\n" +
                "                                          \"values\": [\n" +
                "                                            \"adds\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    }\n" +
                "                                  ],\n" +
                "                                  \"isLastBatch\": false\n" +
                "                                }\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"mobileNumber\",\n" +
                "                                \"nslAttributeID\": 1677597978266,\n" +
                "                                \"values\": [\n" +
                "                                  \"1\"\n" +
                "                                ]\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"emergencyContacts\",\n" +
                "                                \"nslAttributeID\": 1970026351276,\n" +
                "                                \"txnGeneralEntity\": {\n" +
                "                                  \"name\": \"gdrive_put_Request_contactDetails_emergencyContacts\",\n" +
                "                                  \"generalEntityID\": 1881499165206,\n" +
                "                                  \"transEntityRecords\": [\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"mobileNumber\",\n" +
                "                                          \"nslAttributeID\": 457241716609,\n" +
                "                                          \"values\": [\n" +
                "                                            \"13\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"name\",\n" +
                "                                          \"nslAttributeID\": 132907623673,\n" +
                "                                          \"values\": [\n" +
                "                                            \"pet2\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"primary\",\n" +
                "                                          \"nslAttributeID\": 782873092399,\n" +
                "                                          \"values\": [\n" +
                "                                            \"false\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    }\n" +
                "                                  ],\n" +
                "                                  \"isLastBatch\": false\n" +
                "                                }\n" +
                "                              }\n" +
                "                            ]\n" +
                "                          }\n" +
                "                        ],\n" +
                "                        \"isLastBatch\": false\n" +
                "                      }\n" +
                "                    }\n" +
                "                  ]\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isLastBatch\": false\n" +
                "            }\n" +
                "          }\n" +
                "        }\n" +
                "      ],\n" +
                "      \"recordAdditionalInfo\": false\n" +
                "    }\n" +
                "  ]\n" +
                "}";
        return JacksonUtils.getObjectFromJsonString(jsonString,TxnData.class);
    }

    public TxnData getXmlres() {
        String jsonString ="{\n" +
                "  \"txnCULayer\": [\n" +
                "    {\n" +
                "      \"type\": \"triggerCES\",\n" +
                "      \"txnSlotItems\": [\n" +
                "        {\n" +
                "          \"isMultiValue\": false,\n" +
                "          \"item\": {\n" +
                "            \"TYPE\": \"TxnGeneralEntity\",\n" +
                "            \"DATA\": {\n" +
                "              \"name\": \"gdrive_put_Request\",\n" +
                "              \"generalEntityID\": 177163449201,\n" +
                "              \"transEntityRecords\": [\n" +
                "                {\n" +
                "                  \"txnNslAttribute\": [\n" +
                "                    {\n" +
                "                      \"name\": \"name\",\n" +
                "                      \"values\": [\n" +
                "                        \"sriram\"\n" +
                "                      ]\n" +
                "                    },\n" +
                "                    {\n" +
                "                      \"name\": \"id\",\n" +
                "                      \"values\": [\n" +
                "                        \"11111\"\n" +
                "                      ]\n" +
                "                    },\n" +
                "                    {\n" +
                "                      \"name\": \"contactDetails\",\n" +
                "                      \"txnGeneralEntity\": {\n" +
                "                        \"name\": \"contactDetails\",\n" +
                "                        \"transEntityRecords\": [\n" +
                "                          {\n" +
                "                            \"txnNslAttribute\": [\n" +
                "                              {\n" +
                "                                \"name\": \"address\",\n" +
                "                                \"txnGeneralEntity\": {\n" +
                "                                  \"name\": \"address\",\n" +
                "                                  \"transEntityRecords\": [\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"pinCode\",\n" +
                "                                          \"values\": [\n" +
                "                                            \"123\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"Street\",\n" +
                "                                          \"values\": [\n" +
                "                                            \"aaa\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"City\",\n" +
                "                                          \"values\": [\n" +
                "                                            \"aa\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"email\",\n" +
                "                                          \"values\": [\n" +
                "                                            \"adsads\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    }\n" +
                "                                  ],\n" +
                "                                  \"isLastBatch\": false\n" +
                "                                }\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"mobileNumber\",\n" +
                "                                \"values\": [\n" +
                "                                  \"12\"\n" +
                "                                ]\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"emergencyContacts\",\n" +
                "                                \"txnGeneralEntity\": {\n" +
                "                                  \"name\": \"emergencyContacts\",\n" +
                "                                  \"transEntityRecords\": [\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"mobileNumber\",\n" +
                "                                          \"values\": [\n" +
                "                                            \"1223\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"name\",\n" +
                "                                          \"values\": [\n" +
                "                                            \"pet1\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"primary\",\n" +
                "                                          \"values\": [\n" +
                "                                            \"true\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    },\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"mobileNumber\",\n" +
                "                                          \"values\": [\n" +
                "                                            \"12231\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"name\",\n" +
                "                                          \"values\": [\n" +
                "                                            \"name2\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"primary\",\n" +
                "                                          \"values\": [\n" +
                "                                            \"false\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    }\n" +
                "                                  ],\n" +
                "                                  \"isLastBatch\": false\n" +
                "                                }\n" +
                "                              }\n" +
                "                            ]\n" +
                "                          }\n" +
                "                        ],\n" +
                "                        \"isLastBatch\": false\n" +
                "                      }\n" +
                "                    }\n" +
                "                  ]\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isLastBatch\": false\n" +
                "            }\n" +
                "          }\n" +
                "        }\n" +
                "      ],\n" +
                "      \"recordAdditionalInfo\": false\n" +
                "    }\n" +
                "  ]\n" +
                "}";
        return JacksonUtils.getObjectFromJsonString(jsonString,TxnData.class);
    }

    public TxnData getJsonres() {
        String jsonString ="{\n" +
                "  \"txnCULayer\": [\n" +
                "    {\n" +
                "      \"type\": \"triggerCES\",\n" +
                "      \"txnSlotItems\": [\n" +
                "        {\n" +
                "          \"isMultiValue\": false,\n" +
                "          \"item\": {\n" +
                "            \"TYPE\": \"TxnGeneralEntity\",\n" +
                "            \"DATA\": {\n" +
                "              \"name\": \"gdrive_put_Request\",\n" +
                "              \"generalEntityID\": 177163449201,\n" +
                "              \"transEntityRecords\": [\n" +
                "                {\n" +
                "                  \"txnNslAttribute\": [\n" +
                "                    {\n" +
                "                      \"name\": \"name\",\n" +
                "                      \"nslAttributeID\": 705859676916,\n" +
                "                      \"values\": [\n" +
                "                        \"sriram\"\n" +
                "                      ]\n" +
                "                    },\n" +
                "                    {\n" +
                "                      \"name\": \"id\",\n" +
                "                      \"nslAttributeID\": 2118580369847,\n" +
                "                      \"values\": [\n" +
                "                        \"11111\"\n" +
                "                      ]\n" +
                "                    },\n" +
                "                    {\n" +
                "                      \"name\": \"contactDetails\",\n" +
                "                      \"nslAttributeID\": 943881116300,\n" +
                "                      \"txnGeneralEntity\": {\n" +
                "                        \"name\": \"gdrive_put_Request_contactDetails\",\n" +
                "                        \"generalEntityID\": 1895737678261,\n" +
                "                        \"transEntityRecords\": [\n" +
                "                          {\n" +
                "                            \"txnNslAttribute\": [\n" +
                "                              {\n" +
                "                                \"name\": \"address\",\n" +
                "                                \"nslAttributeID\": 710193827747,\n" +
                "                                \"txnGeneralEntity\": {\n" +
                "                                  \"name\": \"gdrive_put_Request_contactDetails_address\",\n" +
                "                                  \"generalEntityID\": 1108142859907,\n" +
                "                                  \"transEntityRecords\": [\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"pinCode\",\n" +
                "                                          \"nslAttributeID\": 1804078038909,\n" +
                "                                          \"values\": [\n" +
                "                                            \"123\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"Street\",\n" +
                "                                          \"nslAttributeID\": 165540751716,\n" +
                "                                          \"values\": [\n" +
                "                                            \"aaa\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"City\",\n" +
                "                                          \"nslAttributeID\": 71974458684,\n" +
                "                                          \"values\": [\n" +
                "                                            \"aa\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"email\",\n" +
                "                                          \"nslAttributeID\": 92646871599,\n" +
                "                                          \"values\": [\n" +
                "                                            \"adsads\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    }\n" +
                "                                  ],\n" +
                "                                  \"isLastBatch\": false\n" +
                "                                }\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"mobileNumber\",\n" +
                "                                \"nslAttributeID\": 1677597978266,\n" +
                "                                \"values\": [\n" +
                "                                  \"12\"\n" +
                "                                ]\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"emergencyContacts\",\n" +
                "                                \"nslAttributeID\": 1970026351276,\n" +
                "                                \"txnGeneralEntity\": {\n" +
                "                                  \"name\": \"gdrive_put_Request_contactDetails_emergencyContacts\",\n" +
                "                                  \"generalEntityID\": 1881499165206,\n" +
                "                                  \"transEntityRecords\": [\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"mobileNumber\",\n" +
                "                                          \"nslAttributeID\": 457241716609,\n" +
                "                                          \"values\": [\n" +
                "                                            \"1223\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"name\",\n" +
                "                                          \"nslAttributeID\": 132907623673,\n" +
                "                                          \"values\": [\n" +
                "                                            \"pet1\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"primary\",\n" +
                "                                          \"nslAttributeID\": 782873092399,\n" +
                "                                          \"values\": [\n" +
                "                                            \"true\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    },\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"mobileNumber\",\n" +
                "                                          \"nslAttributeID\": 457241716609,\n" +
                "                                          \"values\": [\n" +
                "                                            \"12231\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"name\",\n" +
                "                                          \"nslAttributeID\": 132907623673,\n" +
                "                                          \"values\": [\n" +
                "                                            \"name2\"\n" +
                "                                          ]\n" +
                "                                        },\n" +
                "                                        {\n" +
                "                                          \"name\": \"primary\",\n" +
                "                                          \"nslAttributeID\": 782873092399,\n" +
                "                                          \"values\": [\n" +
                "                                            \"false\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    }\n" +
                "                                  ],\n" +
                "                                  \"isLastBatch\": false\n" +
                "                                }\n" +
                "                              }\n" +
                "                            ]\n" +
                "                          }\n" +
                "                        ],\n" +
                "                        \"isLastBatch\": false\n" +
                "                      }\n" +
                "                    }\n" +
                "                  ]\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isLastBatch\": false\n" +
                "            }\n" +
                "          }\n" +
                "        }\n" +
                "      ],\n" +
                "      \"recordAdditionalInfo\": false\n" +
                "    }\n" +
                "  ]\n" +
                "}";
        return JacksonUtils.getObjectFromJsonString(jsonString,TxnData.class);
    }

    public JsonNode getFileUploadres() throws JsonProcessingException {
        String jsonString = "{\"name\":\"filee51ec44e-7365-4ca0-87cc-a9c6cae80776.txt\",\"displayName\":\"filee51ec44e-7365-4ca0-87cc-a9c6cae80776.txt\",\"description\":\"filee51ec44e-7365-4ca0-87cc-a9c6cae80776.txt\",\"dsdId\":\"633146e247d832246e181f24\",\"mimeType\":\"text/plain\",\"size\":\"276\",\"contentUrl\":\"https://qa3.nslhub.com/dsd-files-store/content/adaptertest/other/filee51ec44e-7365-4ca0-87cc-a9c6cae80776.txt\",\"originalFileName\":\"file.txt\"}";
        return new ObjectMapper().readTree(jsonString);
    }

    public TxnData getHl7res() throws NSLException {
        String jsonString = "{\n" +
                "  \"txnCULayer\": [\n" +
                "    {\n" +
                "      \"type\": \"triggerCES\",\n" +
                "      \"txnSlotItems\": [\n" +
                "        {\n" +
                "          \"isMultiValue\": false,\n" +
                "          \"item\": {\n" +
                "            \"TYPE\": \"TxnGeneralEntity\",\n" +
                "            \"DATA\": {\n" +
                "              \"name\": \"hl7_4\",\n" +
                "              \"generalEntityID\": 30405779063,\n" +
                "              \"transEntityRecords\": [\n" +
                "                {\n" +
                "                  \"txnNslAttribute\": [\n" +
                "                    {\n" +
                "                      \"name\": \"MSH\",\n" +
                "                      \"nslAttributeID\": 336908293120,\n" +
                "                      \"txnGeneralEntity\": {\n" +
                "                        \"name\": \"hl7_4_MSH\",\n" +
                "                        \"generalEntityID\": 1003492769824,\n" +
                "                        \"transEntityRecords\": [\n" +
                "                          {\n" +
                "                            \"txnNslAttribute\": [\n" +
                "                              {\n" +
                "                                \"name\": \"Field Separator\",\n" +
                "                                \"nslAttributeID\": 690315810034,\n" +
                "                                \"values\": [\n" +
                "                                  \"|\"\n" +
                "                                ]\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"Encoding Characters\",\n" +
                "                                \"nslAttributeID\": 1284512390217,\n" +
                "                                \"values\": [\n" +
                "                                  \"^~\\\\&\"\n" +
                "                                ]\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"Message Type\",\n" +
                "                                \"nslAttributeID\": 2053195156957,\n" +
                "                                \"txnGeneralEntity\": {\n" +
                "                                  \"name\": \"hl7_4_MSH_Message Type\",\n" +
                "                                  \"generalEntityID\": 1261663788518,\n" +
                "                                  \"transEntityRecords\": [\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"Message Type_1\",\n" +
                "                                          \"nslAttributeID\": 739730818549,\n" +
                "                                          \"values\": [\n" +
                "                                            \"ACK\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    }\n" +
                "                                  ],\n" +
                "                                  \"isLastBatch\": false\n" +
                "                                }\n" +
                "                              },\n" +
                "                              {\n" +
                "                                \"name\": \"Version ID\",\n" +
                "                                \"nslAttributeID\": 1339506576457,\n" +
                "                                \"txnGeneralEntity\": {\n" +
                "                                  \"name\": \"hl7_4_MSH_Version ID\",\n" +
                "                                  \"generalEntityID\": 1845797474326,\n" +
                "                                  \"transEntityRecords\": [\n" +
                "                                    {\n" +
                "                                      \"txnNslAttribute\": [\n" +
                "                                        {\n" +
                "                                          \"name\": \"Version ID_1\",\n" +
                "                                          \"nslAttributeID\": 2122440297467,\n" +
                "                                          \"values\": [\n" +
                "                                            \"2.5\"\n" +
                "                                          ]\n" +
                "                                        }\n" +
                "                                      ]\n" +
                "                                    }\n" +
                "                                  ],\n" +
                "                                  \"isLastBatch\": false\n" +
                "                                }\n" +
                "                              }\n" +
                "                            ]\n" +
                "                          }\n" +
                "                        ],\n" +
                "                        \"isLastBatch\": false\n" +
                "                      }\n" +
                "                    },\n" +
                "                    {\n" +
                "                      \"name\": \"MSA\",\n" +
                "                      \"nslAttributeID\": 1136564738998,\n" +
                "                      \"txnGeneralEntity\": {\n" +
                "                        \"name\": \"hl7_4_MSA\",\n" +
                "                        \"generalEntityID\": 1453244376550,\n" +
                "                        \"transEntityRecords\": [\n" +
                "                          {\n" +
                "                            \"txnNslAttribute\": [\n" +
                "                              {\n" +
                "                                \"name\": \"Text Message\",\n" +
                "                                \"nslAttributeID\": 147353875845,\n" +
                "                                \"values\": [\n" +
                "                                  \"Everything was okay dokay!\"\n" +
                "                                ]\n" +
                "                              }\n" +
                "                            ]\n" +
                "                          }\n" +
                "                        ],\n" +
                "                        \"isLastBatch\": false\n" +
                "                      }\n" +
                "                    }\n" +
                "                  ]\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isLastBatch\": false\n" +
                "            }\n" +
                "          }\n" +
                "        }\n" +
                "      ],\n" +
                "      \"recordAdditionalInfo\": false\n" +
                "    }\n" +
                "  ]\n" +
                "}";
        return JacksonUtils.fromJson(jsonString,TxnData.class);
    }

    public GeneralEntity hl7TcesGeneralEntity() throws NSLException {
        String jsonString = "{\n" +
                "  \"name\": \"hl7_4\",\n" +
                "  \"displayName\": \"hl7_4\",\n" +
                "  \"masterId\": 30405779063,\n" +
                "  \"version\": \"1.0\",\n" +
                "  \"status\": \"PUBLISHED\",\n" +
                "  \"nslAttributes\": [\n" +
                "    {\n" +
                "      \"name\": \"MSH\",\n" +
                "      \"displayName\": \"MSH\",\n" +
                "      \"attributeType\": {\n" +
                "        \"type\": \"entity\",\n" +
                "        \"properties\": {\n" +
                "          \"referencingType\": \"MSH\"\n" +
                "        }\n" +
                "      },\n" +
                "      \"canDownload\": false,\n" +
                "      \"isReserved\": false,\n" +
                "      \"generalEntity\": {\n" +
                "        \"name\": \"hl7_4_MSH\",\n" +
                "        \"displayName\": \"MSH\",\n" +
                "        \"masterId\": 1003492769824,\n" +
                "        \"version\": \"1.0\",\n" +
                "        \"status\": \"PUBLISHED\",\n" +
                "        \"nslAttributes\": [\n" +
                "          {\n" +
                "            \"name\": \"Field Separator\",\n" +
                "            \"displayName\": \"Field Separator\",\n" +
                "            \"attributeType\": {\n" +
                "              \"type\": \"string\"\n" +
                "            },\n" +
                "            \"canDownload\": false,\n" +
                "            \"isReserved\": false,\n" +
                "            \"isInPotentiality\": false,\n" +
                "            \"triggerConditionalPotentiality\": false,\n" +
                "            \"id\": 690315810034,\n" +
                "            \"guid\": \"0503ee19-25ea-491e-9754-dd2d46bdf0ab\",\n" +
                "            \"ownerId\": 1907863430259,\n" +
                "            \"createdAt\": 1671125199883,\n" +
                "            \"createdBy\": 1907863430259,\n" +
                "            \"updatedAt\": 1671125199887,\n" +
                "            \"updatedBy\": 1907863430259,\n" +
                "            \"isNameUpdated\": false\n" +
                "          },\n" +
                "          {\n" +
                "            \"name\": \"Encoding Characters\",\n" +
                "            \"displayName\": \"Encoding Characters\",\n" +
                "            \"attributeType\": {\n" +
                "              \"type\": \"string\"\n" +
                "            },\n" +
                "            \"canDownload\": false,\n" +
                "            \"isReserved\": false,\n" +
                "            \"isInPotentiality\": false,\n" +
                "            \"triggerConditionalPotentiality\": false,\n" +
                "            \"id\": 1284512390217,\n" +
                "            \"guid\": \"27c53aef-dab0-4381-bef6-17d1a4928098\",\n" +
                "            \"ownerId\": 1907863430259,\n" +
                "            \"createdAt\": 1671125199883,\n" +
                "            \"createdBy\": 1907863430259,\n" +
                "            \"updatedAt\": 1671125199887,\n" +
                "            \"updatedBy\": 1907863430259,\n" +
                "            \"isNameUpdated\": false\n" +
                "          },\n" +
                "          {\n" +
                "            \"name\": \"Message Type\",\n" +
                "            \"displayName\": \"Message Type\",\n" +
                "            \"attributeType\": {\n" +
                "              \"type\": \"entity\",\n" +
                "              \"properties\": {\n" +
                "                \"referencingType\": \"Message Type\"\n" +
                "              }\n" +
                "            },\n" +
                "            \"canDownload\": false,\n" +
                "            \"isReserved\": false,\n" +
                "            \"generalEntity\": {\n" +
                "              \"name\": \"hl7_4_MSH_Message Type\",\n" +
                "              \"displayName\": \"Message Type\",\n" +
                "              \"masterId\": 1261663788518,\n" +
                "              \"version\": \"1.0\",\n" +
                "              \"status\": \"PUBLISHED\",\n" +
                "              \"nslAttributes\": [\n" +
                "                {\n" +
                "                  \"name\": \"Message Type_1\",\n" +
                "                  \"displayName\": \"MessageCode\",\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"string\"\n" +
                "                  },\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"id\": 739730818549,\n" +
                "                  \"guid\": \"dd206aa5-9db3-4df8-a609-8832a2021477\",\n" +
                "                  \"ownerId\": 1907863430259,\n" +
                "                  \"createdAt\": 1671125199364,\n" +
                "                  \"createdBy\": 1907863430259,\n" +
                "                  \"updatedAt\": 1671125199366,\n" +
                "                  \"updatedBy\": 1907863430259,\n" +
                "                  \"isNameUpdated\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isReserved\": false,\n" +
                "              \"id\": 1261663788518,\n" +
                "              \"guid\": \"c5d631f4-c936-4a0b-a606-50bdbd6de5ba\",\n" +
                "              \"ownerId\": 1907863430259,\n" +
                "              \"createdAt\": 1671125199364,\n" +
                "              \"createdBy\": 1907863430259,\n" +
                "              \"updatedAt\": 1671125323244,\n" +
                "              \"updatedBy\": 302926936254,\n" +
                "              \"designTimeRights\": [\n" +
                "                {\n" +
                "                  \"informationRight\": true,\n" +
                "                  \"decisionRight\": true,\n" +
                "                  \"executionRight\": false,\n" +
                "                  \"rightHolderId\": 1893442398371,\n" +
                "                  \"rightHolderType\": \"ROLE\",\n" +
                "                  \"rightHolderName\": \"adapterDesigner\",\n" +
                "                  \"disableParentRoleAccess\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isNameUpdated\": false,\n" +
                "              \"dsdMetadataId\": \"fd92e348-a5c0-4a52-80a3-fee50d22fd9b\"\n" +
                "            },\n" +
                "            \"isInPotentiality\": false,\n" +
                "            \"triggerConditionalPotentiality\": false,\n" +
                "            \"id\": 2053195156957,\n" +
                "            \"guid\": \"fe75ca33-9a5a-482e-a768-755e8a123445\",\n" +
                "            \"ownerId\": 1907863430259,\n" +
                "            \"createdAt\": 1671125199883,\n" +
                "            \"createdBy\": 1907863430259,\n" +
                "            \"updatedAt\": 1671125199887,\n" +
                "            \"updatedBy\": 1907863430259,\n" +
                "            \"isNameUpdated\": false\n" +
                "          },\n" +
                "          {\n" +
                "            \"name\": \"Version ID\",\n" +
                "            \"displayName\": \"Version ID\",\n" +
                "            \"attributeType\": {\n" +
                "              \"type\": \"entity\",\n" +
                "              \"properties\": {\n" +
                "                \"referencingType\": \"Version ID\"\n" +
                "              }\n" +
                "            },\n" +
                "            \"canDownload\": false,\n" +
                "            \"isReserved\": false,\n" +
                "            \"generalEntity\": {\n" +
                "              \"name\": \"hl7_4_MSH_Version ID\",\n" +
                "              \"displayName\": \"Version ID\",\n" +
                "              \"masterId\": 1845797474326,\n" +
                "              \"version\": \"1.0\",\n" +
                "              \"status\": \"PUBLISHED\",\n" +
                "              \"nslAttributes\": [\n" +
                "                {\n" +
                "                  \"name\": \"Version ID_1\",\n" +
                "                  \"displayName\": \"VersionID\",\n" +
                "                  \"attributeType\": {\n" +
                "                    \"type\": \"string\"\n" +
                "                  },\n" +
                "                  \"canDownload\": false,\n" +
                "                  \"isReserved\": false,\n" +
                "                  \"isInPotentiality\": false,\n" +
                "                  \"triggerConditionalPotentiality\": false,\n" +
                "                  \"id\": 2122440297467,\n" +
                "                  \"guid\": \"0331df0b-b1d0-4056-9c19-9ee73b75f03f\",\n" +
                "                  \"ownerId\": 1907863430259,\n" +
                "                  \"createdAt\": 1671125199633,\n" +
                "                  \"createdBy\": 1907863430259,\n" +
                "                  \"updatedAt\": 1671125199635,\n" +
                "                  \"updatedBy\": 1907863430259,\n" +
                "                  \"isNameUpdated\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isReserved\": false,\n" +
                "              \"id\": 1845797474326,\n" +
                "              \"guid\": \"3aed8498-6e39-4329-b6a9-6f499f153a8a\",\n" +
                "              \"ownerId\": 1907863430259,\n" +
                "              \"createdAt\": 1671125199633,\n" +
                "              \"createdBy\": 1907863430259,\n" +
                "              \"updatedAt\": 1671125323246,\n" +
                "              \"updatedBy\": 302926936254,\n" +
                "              \"designTimeRights\": [\n" +
                "                {\n" +
                "                  \"informationRight\": true,\n" +
                "                  \"decisionRight\": true,\n" +
                "                  \"executionRight\": false,\n" +
                "                  \"rightHolderId\": 1893442398371,\n" +
                "                  \"rightHolderType\": \"ROLE\",\n" +
                "                  \"rightHolderName\": \"adapterDesigner\",\n" +
                "                  \"disableParentRoleAccess\": false\n" +
                "                }\n" +
                "              ],\n" +
                "              \"isNameUpdated\": false,\n" +
                "              \"dsdMetadataId\": \"25165560-ab65-48dc-85db-b8e117d0e1dc\"\n" +
                "            },\n" +
                "            \"isInPotentiality\": false,\n" +
                "            \"triggerConditionalPotentiality\": false,\n" +
                "            \"id\": 1339506576457,\n" +
                "            \"guid\": \"7d828b72-4710-4004-bf28-d4d002355b86\",\n" +
                "            \"ownerId\": 1907863430259,\n" +
                "            \"createdAt\": 1671125199883,\n" +
                "            \"createdBy\": 1907863430259,\n" +
                "            \"updatedAt\": 1671125199887,\n" +
                "            \"updatedBy\": 1907863430259,\n" +
                "            \"isNameUpdated\": false\n" +
                "          }\n" +
                "        ],\n" +
                "        \"isReserved\": false,\n" +
                "        \"id\": 1003492769824,\n" +
                "        \"guid\": \"404d7ce3-2243-47a2-8852-c80a4ad889ff\",\n" +
                "        \"ownerId\": 1907863430259,\n" +
                "        \"createdAt\": 1671125199883,\n" +
                "        \"createdBy\": 1907863430259,\n" +
                "        \"updatedAt\": 1671125323241,\n" +
                "        \"updatedBy\": 302926936254,\n" +
                "        \"designTimeRights\": [\n" +
                "          {\n" +
                "            \"informationRight\": true,\n" +
                "            \"decisionRight\": true,\n" +
                "            \"executionRight\": false,\n" +
                "            \"rightHolderId\": 1893442398371,\n" +
                "            \"rightHolderType\": \"ROLE\",\n" +
                "            \"rightHolderName\": \"adapterDesigner\",\n" +
                "            \"disableParentRoleAccess\": false\n" +
                "          }\n" +
                "        ],\n" +
                "        \"isNameUpdated\": false,\n" +
                "        \"dsdMetadataId\": \"3adc6c95-be25-4da3-bb83-23ea68b7565c\"\n" +
                "      },\n" +
                "      \"isInPotentiality\": false,\n" +
                "      \"triggerConditionalPotentiality\": false,\n" +
                "      \"id\": 336908293120,\n" +
                "      \"guid\": \"83b55ce2-d7b5-491f-8ca0-d2a536f53f41\",\n" +
                "      \"ownerId\": 1907863430259,\n" +
                "      \"createdAt\": 1671125200432,\n" +
                "      \"createdBy\": 1907863430259,\n" +
                "      \"updatedAt\": 1671125200435,\n" +
                "      \"updatedBy\": 1907863430259,\n" +
                "      \"isNameUpdated\": false\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"MSA\",\n" +
                "      \"displayName\": \"MSA\",\n" +
                "      \"attributeType\": {\n" +
                "        \"type\": \"entity\",\n" +
                "        \"properties\": {\n" +
                "          \"referencingType\": \"MSA\"\n" +
                "        }\n" +
                "      },\n" +
                "      \"canDownload\": false,\n" +
                "      \"isReserved\": false,\n" +
                "      \"generalEntity\": {\n" +
                "        \"name\": \"hl7_4_MSA\",\n" +
                "        \"displayName\": \"MSA\",\n" +
                "        \"masterId\": 1453244376550,\n" +
                "        \"version\": \"1.0\",\n" +
                "        \"status\": \"PUBLISHED\",\n" +
                "        \"nslAttributes\": [\n" +
                "          {\n" +
                "            \"name\": \"Text Message\",\n" +
                "            \"displayName\": \"Text Message\",\n" +
                "            \"attributeType\": {\n" +
                "              \"type\": \"string\"\n" +
                "            },\n" +
                "            \"canDownload\": false,\n" +
                "            \"isReserved\": false,\n" +
                "            \"isInPotentiality\": false,\n" +
                "            \"triggerConditionalPotentiality\": false,\n" +
                "            \"id\": 147353875845,\n" +
                "            \"guid\": \"561f27a5-08ee-4df1-91aa-7906588cff85\",\n" +
                "            \"ownerId\": 1907863430259,\n" +
                "            \"createdAt\": 1671125200090,\n" +
                "            \"createdBy\": 1907863430259,\n" +
                "            \"updatedAt\": 1671125200092,\n" +
                "            \"updatedBy\": 1907863430259,\n" +
                "            \"isNameUpdated\": false\n" +
                "          }\n" +
                "        ],\n" +
                "        \"isReserved\": false,\n" +
                "        \"id\": 1453244376550,\n" +
                "        \"guid\": \"b1b92703-b0b0-4d08-b2f4-908cf83a39d2\",\n" +
                "        \"ownerId\": 1907863430259,\n" +
                "        \"createdAt\": 1671125200089,\n" +
                "        \"createdBy\": 1907863430259,\n" +
                "        \"updatedAt\": 1671125323243,\n" +
                "        \"updatedBy\": 302926936254,\n" +
                "        \"designTimeRights\": [\n" +
                "          {\n" +
                "            \"informationRight\": true,\n" +
                "            \"decisionRight\": true,\n" +
                "            \"executionRight\": false,\n" +
                "            \"rightHolderId\": 1893442398371,\n" +
                "            \"rightHolderType\": \"ROLE\",\n" +
                "            \"rightHolderName\": \"adapterDesigner\",\n" +
                "            \"disableParentRoleAccess\": false\n" +
                "          }\n" +
                "        ],\n" +
                "        \"isNameUpdated\": false,\n" +
                "        \"dsdMetadataId\": \"3ef7a920-3dc3-4053-be5a-8fe7f7ae80f5\"\n" +
                "      },\n" +
                "      \"isInPotentiality\": false,\n" +
                "      \"triggerConditionalPotentiality\": false,\n" +
                "      \"id\": 1136564738998,\n" +
                "      \"guid\": \"90698ad5-e0ea-473e-a122-76357e1f0c40\",\n" +
                "      \"ownerId\": 1907863430259,\n" +
                "      \"createdAt\": 1671125200432,\n" +
                "      \"createdBy\": 1907863430259,\n" +
                "      \"updatedAt\": 1671125200435,\n" +
                "      \"updatedBy\": 1907863430259,\n" +
                "      \"isNameUpdated\": false\n" +
                "    }\n" +
                "  ],\n" +
                "  \"isReserved\": false,\n" +
                "  \"id\": 30405779063,\n" +
                "  \"guid\": \"f718668e-9d6a-478a-89f2-4d49a3c73bf0\",\n" +
                "  \"ownerId\": 1907863430259,\n" +
                "  \"createdAt\": 1671125200432,\n" +
                "  \"createdBy\": 1907863430259,\n" +
                "  \"updatedAt\": 1671125323251,\n" +
                "  \"updatedBy\": 302926936254,\n" +
                "  \"isNameUpdated\": false,\n" +
                "  \"dsdMetadataId\": \"51c2a29b-070f-4a4e-a9c3-024e9dc2be5a\"\n" +
                "}";
        return JacksonUtils.fromJson(jsonString,GeneralEntity.class);
    }
}
