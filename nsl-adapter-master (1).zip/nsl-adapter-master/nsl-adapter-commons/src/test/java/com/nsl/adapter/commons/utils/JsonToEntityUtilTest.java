package com.nsl.adapter.commons.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.logical.enums.DataType;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.NslDataType;
import com.nsl.logical.model.TxnGeneralEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(MockitoJUnitRunner.class)
public class JsonToEntityUtilTest {

//    @Test
//    public void testGetDateTimeFormat() throws JsonProcessingException {
//        //Arrange
//        GeneralEntity generalEntity = new GeneralEntity();
//        generalEntity.setId(1234l);
//        generalEntity.setName("datetime");
//        NslAttribute attribute = new NslAttribute();
//        NslDataType type = new NslDataType();
//        type.setType(DataType.DATE_TIME);
//        attribute.setName("dateTime12hrs");
//        Map<String, String> properties = new HashMap<>();
//        properties.put("timeFormat", "12-hr");
//        properties.put("format", "MM/dd/yyyy");
//        type.setProperties(properties);
//        attribute.setAttributeType(type);
//        generalEntity.setNslAttributes(attribute);
//        Map<String, String> mapper = new HashMap<>();
//        String str = "{\"dateTime12hrs\":\"06/02/2023 02:40:00 PM\"}";
//        ObjectMapper objectMapper = new ObjectMapper();
//        JsonNode jsonNode = objectMapper.readTree(str);
//        //Act
//        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(generalEntity, jsonNode, "", mapper );
//        assertNotNull(txnGeneralEntity, "txn General Entity is not null");
//        assertNotNull(txnGeneralEntity.getGeneralEntityID(), "general entity id is not null");
//    }

    @Test
    public void testGetDateTimeFormat1() throws JsonProcessingException {
        //Arrange
        GeneralEntity generalEntity = new GeneralEntity();
        generalEntity.setId(1234l);
        generalEntity.setName("datetime");
        NslAttribute attribute = new NslAttribute();
        NslDataType type = new NslDataType();
        type.setType(DataType.DATE_TIME);
        attribute.setName("dateTime24hrs");
        Map<String, String> properties = new HashMap<>();
        properties.put("timeFormat", "24-hr");
        properties.put("format", "dd/MM/yyyy");
        type.setProperties(properties);
        attribute.setAttributeType(type);
        generalEntity.setNslAttributes(attribute);
        Map<String, String> mapper = new HashMap<>();
        String str = "{\"dateTime24hrs\":\"02/06/2023 11:40:00\"}";
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = objectMapper.readTree(str);
        //Act
        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(generalEntity, jsonNode, "", mapper );
        assertNotNull(txnGeneralEntity, "txn General Entity is not null");
        assertNotNull(txnGeneralEntity.getGeneralEntityID(), "general entity id is not null");
    }

    @Test
    public void testGetDateTimeFormat2() throws JsonProcessingException {
        //Arrange
        GeneralEntity generalEntity = new GeneralEntity();
        generalEntity.setId(1234l);
        generalEntity.setName("currentDatetime");
        NslAttribute attribute = new NslAttribute();
        NslDataType type = new NslDataType();
        type.setType(DataType.CURRENT_DATE_TIME);
        attribute.setName("currentDateTime");
        Map<String, String> properties = new HashMap<>();
        type.setProperties(properties);
        attribute.setAttributeType(type);
        generalEntity.setNslAttributes(attribute);
        Map<String, String> mapper = new HashMap<>();
        String str = "{\"currentDateTime\":\"06/20/2023 11:40\"}";
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = objectMapper.readTree(str);
        //Act
        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(generalEntity, jsonNode, "", mapper );
        assertNotNull(txnGeneralEntity, "txn General Entity is not null");
        assertNotNull(txnGeneralEntity.getGeneralEntityID(), "general entity id is not null");
    }

//    @Test
//    public void testGetDateTimeFormat3() throws JsonProcessingException {
//        //Arrange
//        GeneralEntity generalEntity = new GeneralEntity();
//        generalEntity.setId(1234l);
//        generalEntity.setName("currentDatetime");
//        NslAttribute attribute = new NslAttribute();
//        NslDataType type = new NslDataType();
//        type.setType(DataType.CURRENT_DATE_TIME);
//        attribute.setName("currentDateTime");
//        Map<String, String> properties = new HashMap<>();
//        properties.put("timeFormat", "12-hr");
//        properties.put("format", "MM/dd/yyyy");
//        type.setProperties(properties);
//        attribute.setAttributeType(type);
//        generalEntity.setNslAttributes(attribute);
//        Map<String, String> mapper = new HashMap<>();
//        String str = "{\"currentDateTime\":\"06/02/2023 02:40 AM\"}";
//        ObjectMapper objectMapper = new ObjectMapper();
//        JsonNode jsonNode = objectMapper.readTree(str);
//        //Act
//        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(generalEntity, jsonNode, "", mapper );
//        assertNotNull(txnGeneralEntity, "txn General Entity is not null");
//        assertNotNull(txnGeneralEntity.getGeneralEntityID(), "general entity id is not null");
//    }

    @Test
    public void testGetDateTimeFormat4() throws JsonProcessingException {
        //Arrange
        GeneralEntity generalEntity = new GeneralEntity();
        generalEntity.setId(1234l);
        generalEntity.setName("currentDatetime");
        NslAttribute attribute = new NslAttribute();
        NslDataType type = new NslDataType();
        type.setType(DataType.CURRENT_DATE_TIME);
        attribute.setName("currentDateTime");
        Map<String, String> properties = new HashMap<>();
        properties.put("timeFormat", "24-hr");
        properties.put("format", "dd/MM/yyyy");
        type.setProperties(properties);
        attribute.setAttributeType(type);
        generalEntity.setNslAttributes(attribute);
        Map<String, String> mapper = new HashMap<>();
        String str = "{\"currentDateTime\":\"06/02/2023 11:40\"}";
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = objectMapper.readTree(str);
        //Act
        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(generalEntity, jsonNode, "", mapper );
        assertNotNull(txnGeneralEntity, "txn General Entity is not null");
        assertNotNull(txnGeneralEntity.getGeneralEntityID(), "general entity id is not null");
    }
}
