package com.nsl.adapter.commons.serviceImpl;

import com.nsl.logical.dao.SecretManagerDao;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.exception.SecretExistsException;
import com.nsl.logical.exception.SecretNotFoundException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class AWSSecretManagerServiceImplTest {
    @InjectMocks
    AWSSecretManagerServiceImpl awsSecretManagerService;
    @Mock
    SecretManagerDao secretManagerDao;

    @Test
    public void createNewSecretTest() throws NoSuchFieldException{
        Mockito.when(secretManagerDao.saveSecret(any(),any())).thenReturn("ok");
        String value=awsSecretManagerService.createNewSecret(any(),any());
        org.junit.Assert.assertEquals(value,"ok");
    }
    @Test
    public void createNewSecretExceptionTest() throws NSLException,SecretExistsException {
        Mockito.when(secretManagerDao.saveSecret(any(),any())).thenThrow(SecretExistsException.class);
        org.junit.Assert.assertThrows(NSLException.class,() -> {awsSecretManagerService.createNewSecret(any(),any());});


    }
    @Test
    public void createNewSecretException1Test() throws NSLException,SecretExistsException {
        Mockito.when(secretManagerDao.saveSecret(any(),any())).thenThrow(NSLException.class);
        org.junit.Assert.assertThrows(NSLException.class,() -> {awsSecretManagerService.createNewSecret(any(),any());});


    }

    @Test
    public void updateSecretTest() throws NoSuchFieldException{
        Mockito.when(secretManagerDao.updateSecret(any(),any())).thenReturn("ok");
        String value=awsSecretManagerService.updateSecret(any(),any());
        org.junit.Assert.assertEquals(value,"ok");

    }
//    @Test
//    public void updateSecretExceptionTest() throws NSLException, SecretNotFoundException {
//        Mockito.when(secretManagerDao.updateSecret(any(),any())).thenThrow(SecretNotFoundException.class);
//        org.junit.Assert.assertThrows(SecretNotFoundException.class,() -> {awsSecretManagerService.updateSecret(any(),any());});
//    }
    @Test
    public void updateSecretException1Test() throws NSLException,SecretExistsException {
        Mockito.when(secretManagerDao.updateSecret(any(),any())).thenThrow(NSLException.class);
        org.junit.Assert.assertThrows(NSLException.class,() -> {awsSecretManagerService.updateSecret(any(),any());});


    }
    @Test
    public void checkForSecretTest() throws NoSuchFieldException{
        Mockito.when(secretManagerDao.checkForSecret(any())).thenReturn(true);
        boolean value=awsSecretManagerService.checkForSecret(any());
        Assert.assertTrue(value);

    }
    @Test
    public void checkForSecretException1Test() throws NSLException,SecretExistsException {
        Mockito.when(secretManagerDao.checkForSecret(any())).thenThrow(NSLException.class);
        org.junit.Assert.assertThrows(NSLException.class,() -> {awsSecretManagerService.checkForSecret(any());});


    }
    @Test
    public void getSecretTest() throws NoSuchFieldException{
        Mockito.when(secretManagerDao.getSecret(any())).thenReturn("ok");
        String value=awsSecretManagerService.getSecret(any());
        org.junit.Assert.assertEquals(value,"ok");
    }
    @Test
    public void getSecretExceptionTest() throws SecretExistsException {
        Mockito.when(secretManagerDao.getSecret(any())).thenThrow(SecretExistsException.class);
        org.junit.Assert.assertThrows(SecretExistsException.class,() -> {awsSecretManagerService.getSecret(any());});


    }
    @Test
    public void getSecretException1Test() throws NSLException,SecretExistsException {
        Mockito.when(secretManagerDao.getSecret(any())).thenThrow(NSLException.class);
        org.junit.Assert.assertThrows(NSLException.class,() -> {awsSecretManagerService.getSecret(any());});


    }

}
