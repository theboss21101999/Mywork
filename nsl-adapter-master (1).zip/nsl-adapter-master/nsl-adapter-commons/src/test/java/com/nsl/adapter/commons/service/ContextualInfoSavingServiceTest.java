package com.nsl.adapter.commons.service;

import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.service.ContextualInfoSavingService;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.SearchCUDAO;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.FieldSetter;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.configurationprocessor.json.JSONException;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;

@RunWith(MockitoJUnitRunner.class)
public class ContextualInfoSavingServiceTest {
    @Mock
    AdapterConnectionServiceV3 adapterConnectionServiceV3;
    @InjectMocks
    ContextualInfoSavingService contextualInfoSavingService;

    @Mock
    AuthenticatedUserDetailsImpl authBean;

    @Mock
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Mock
    SearchCUDAO searchCUDAO;


    @Test
    public void SaveRecords() throws NoSuchFieldException {
        Mockito.when(adapterConnectionServiceV3.getGEByName("NSL_ContextualRecord_Info",authBean)).thenReturn(new GeneralEntity());
        Mockito.when(connectionDataToolsV3.JsonToAttributeList(any(),any(),any(),anyBoolean())).thenReturn(Collections.singletonList(new TxnNslAttribute()));
//        Mockito.when(adapterConnectionServiceV3.saveEntityRecord(Collections.singletonList(new TxnGeneralEntityRecord()),new GeneralEntity(),authBean,"create")).thenReturn(new TxnGeneralEntityRecord());
        contextualInfoSavingService.saveRecords(0,3,authBean, AdapterType.SFTP,"test.csv");
    }

    @Test
    public void SaveRecordsExceptionCase() throws NoSuchFieldException {
        Mockito.when(adapterConnectionServiceV3.getGEByName("NSL_ContextualRecord_Info",authBean)).thenThrow(new RuntimeException());
        contextualInfoSavingService.saveRecords(0,3,authBean, AdapterType.SFTP,"test.csv");
    }

    @Test
    public void getContextualInfoTest(){
        AdapterConnectionServiceTest adapterConnectionServiceTest = new AdapterConnectionServiceTest();
        Mockito.when(adapterConnectionServiceV3.getGEByName("NSL_ContextualRecord_Info",authBean)).thenReturn(adapterConnectionServiceTest.getGE());
        Mockito.when(searchCUDAO.getEntities(any(),any())).thenReturn(List.of(getRecords()));
        Mockito.when(adapterConnectionServiceV3.getSubList(List.of(getRecords()),1,1)).thenReturn(List.of(getRecords()));
        contextualInfoSavingService.getContextualInfoList(1,1,"NSL_ContextualRecord_Info","",authBean);
    }

    private TxnGeneralEntityRecord getRecords(){
        String jsonString = "{\n" +
                "  \"generalEntityId\": 1607258979889,\n" +
                "  \"generalEntityMasterId\": 6596117227,\n" +
                "  \"txnNslAttribute\": [\n" +
                "   {\n" +
                "      \"name\": \"Adapter\",\n" +
                "      \"nslAttributeID\": 1691756105282,\n" +
                "      \"values\": [\n" +
                "        \"SFTP\"\n" +
                "      ]\n" +
                "    },\n"+
                "    {\n" +
                "      \"name\": \"TimeStamp\",\n" +
                "      \"nslAttributeID\": 1691756105282,\n" +
                "      \"values\": [\n" +
                "        \"11/08/2023\"\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"FileName\",\n" +
                "      \"nslAttributeID\": 842031966821,\n" +
                "      \"values\": [\n" +
                "        \"test.csv\"\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"SuccessFullRecords\",\n" +
                "      \"nslAttributeID\": 931388720274,\n" +
                "      \"values\": [\n" +
                "        \"0\"\n" +
                "      ]\n" +
                "    },\n" +
                "    {\n" +
                "      \"name\": \"ErrorRecords\",\n" +
                "      \"nslAttributeID\": 1921082764580,\n" +
                "      \"values\": [\n" +
                "        \"1\"\n" +
                "      ]\n" +
                "    }\n" +
                "  ],\n" +
                "  \"id\": 615420035493,\n" +
                "  \"guid\": \"5a55afac-91c1-4923-94fd-81ef223a9611\",\n" +
                "  \"ownerId\": 1907863430259,\n" +
                "  \"createdAt\": 1655442245323,\n" +
                "  \"createdBy\": 1907863430259,\n" +
                "  \"updatedAt\": 1655442245323,\n" +
                "  \"updatedBy\": 1907863430259,\n" +
                "  \"orgUnitId\": 1507450764610\n" +
                "}";

        return JacksonUtils.getObjectFromJsonString(jsonString, TxnGeneralEntityRecord.class);
    }

}
