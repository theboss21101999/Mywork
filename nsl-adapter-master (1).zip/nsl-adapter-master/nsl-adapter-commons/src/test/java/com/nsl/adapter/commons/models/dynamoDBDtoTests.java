package com.nsl.adapter.commons.models;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)

public class dynamoDBDtoTests {
    @InjectMocks
    DynamoDBDto dynamoDBDto;
    @Test
    public void setAndGetDynamoDBDtoTest() throws NoSuchFieldException {
        dynamoDBDto.setConnectionName("bbh");
        dynamoDBDto.setInsertTime(298689L);
        dynamoDBDto.setPayload("hjkjhhj");
        dynamoDBDto.setParentId("sdfdsdf");
        dynamoDBDto.setRecordId(298689L);
        dynamoDBDto.setConnectionNameLower("sdf");
        org.junit.Assert.assertEquals(dynamoDBDto.getConnectionName(),"bbh");
        org.junit.Assert.assertNotNull(dynamoDBDto.getInsertTime());
        org.junit.Assert.assertEquals(dynamoDBDto.getPayload(),"hjkjhhj");
        org.junit.Assert.assertEquals(dynamoDBDto.getParentId(),"sdfdsdf");
        org.junit.Assert.assertNotNull(dynamoDBDto.getRecordId());
        org.junit.Assert.assertEquals(dynamoDBDto.getConnectionNameLower(),"sdf");

    }


}
