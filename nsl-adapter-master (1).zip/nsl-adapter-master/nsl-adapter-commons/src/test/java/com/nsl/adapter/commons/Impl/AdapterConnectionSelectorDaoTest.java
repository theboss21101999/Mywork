package com.nsl.adapter.commons.Impl;

import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.PaginatedConnectionsListDto;
import com.nsl.adapter.commons.dto.connections.BasicAdapterConnection;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.impl.AdapterConnectionsSelectorDao;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Qualifier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;

@RunWith(MockitoJUnitRunner.class)
public class AdapterConnectionSelectorDaoTest {
    @InjectMocks
    AdapterConnectionsSelectorDao adapterConnectionsSelectorDao;
    @Mock
    @Qualifier("adapterConnectionsDynamoDao")
    AdapterConnnectionsDao adapterConnnectionsDynamoDao;
    @Mock
    @Qualifier("adapterConnectionsRedisDao")
    AdapterConnnectionsDao adapterConnnectionsRedisDao;
    @Mock
    AdaptorCommonsProperties adaptorCommonsProperties;
    @Mock
    BasicAdapterConnection basicAdapterConnection;
    @Test
    public void fetchAllConnectionsTest(){

        Mockito.when(adapterConnnectionsDynamoDao.fetchAllConnections(any(),any(),anyInt(),anyInt(),any())).thenReturn(new PaginatedConnectionsListDto());
        PaginatedConnectionsListDto value=adapterConnectionsSelectorDao.fetchAllConnections(ConnectionDtoType.SFTP,"df",3,3,new AuthenticatedUserDetailsImpl());
        org.junit.Assert.assertNotNull(value);
    }
    @Test
    public void fetchAllConnectionsExceptionTest(){
        org.junit.Assert.assertThrows(NSLException.class,() -> {adapterConnectionsSelectorDao.fetchAllConnections(ConnectionDtoType.SFTP,"df",0,0,new AuthenticatedUserDetailsImpl());});
         }

    @Test
    public void saveConnectionTest(){
        TxnAdapterConnection abc= new TxnAdapterConnection();
        abc.setConnectionDtoType(ConnectionDtoType.SFTP);
        abc.setConnection(basicAdapterConnection);
        Mockito.when(adapterConnnectionsDynamoDao.saveConnection(any(),any())).thenReturn(abc);
        Mockito.when(adaptorCommonsProperties.getCacheEnabled()).thenReturn(true);
        Mockito.when(adapterConnnectionsRedisDao.saveConnection(any(),any())).thenReturn(abc);
        TxnAdapterConnection value=adapterConnectionsSelectorDao.saveConnection(abc,new AuthenticatedUserDetailsImpl());
        org.junit.Assert.assertNotNull(value);
    }
    @Test
    public void saveConnectionExceptionTest(){
        TxnAdapterConnection abc= new TxnAdapterConnection();
        org.junit.Assert.assertThrows(NSLException.class,() -> {adapterConnectionsSelectorDao.saveConnection(abc,new AuthenticatedUserDetailsImpl());});

    }

    @Test
    public void getConnectionByRecordIdTest(){
        TxnAdapterConnection abc= new TxnAdapterConnection();
        abc.setConnectionDtoType(ConnectionDtoType.SFTP);
        abc.setConnection(basicAdapterConnection);
        Mockito.when(adaptorCommonsProperties.getCacheEnabled()).thenReturn(true);
        TxnAdapterConnection value=adapterConnectionsSelectorDao.getConnectionByRecordId(ConnectionDtoType.AIML, 888788L,new AuthenticatedUserDetailsImpl());
        org.junit.Assert.assertNull(value);
    }
    @Test
    public void getConnectionByRecordIdExceptionTest(){

        org.junit.Assert.assertThrows(NSLException.class,() -> {adapterConnectionsSelectorDao.getConnectionByRecordId(null, null,new AuthenticatedUserDetailsImpl());
        });
    }

    @Test
    public void getRawConnectionTest(){
        TxnAdapterConnection abc= new TxnAdapterConnection();
        abc.setConnectionDtoType(ConnectionDtoType.SFTP);
        abc.setConnection(basicAdapterConnection);
        Mockito.when(adaptorCommonsProperties.getCacheEnabled()).thenReturn(true);
        String value=adapterConnectionsSelectorDao.getRawConnection(ConnectionDtoType.AIML, 888788L,new AuthenticatedUserDetailsImpl());
        org.junit.Assert.assertNull(value);
    }
    @Test
    public void getRawConnectionExceptionTest(){
        org.junit.Assert.assertThrows(NSLException.class,() -> {adapterConnectionsSelectorDao.getRawConnection(null, null,new AuthenticatedUserDetailsImpl());
        });
    }
    @Test
    public void deleteConnectionByIdTest(){
        boolean value=adapterConnectionsSelectorDao.deleteConnectionById(ConnectionDtoType.AIML, 888788L,new AuthenticatedUserDetailsImpl());
        org.junit.Assert.assertEquals(true,value);
    }

    @Test
    public void saveRawConnectionTest(){
        String value=adapterConnectionsSelectorDao.saveRawConnection("weewe",ConnectionDtoType.AIML, 888788L,new AuthenticatedUserDetailsImpl());
        org.junit.Assert.assertNull(value);
    }
}
