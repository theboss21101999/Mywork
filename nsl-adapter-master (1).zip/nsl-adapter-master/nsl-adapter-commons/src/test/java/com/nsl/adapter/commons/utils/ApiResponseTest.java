package com.nsl.adapter.commons.utils;

import com.sun.net.httpserver.Authenticator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)

public class ApiResponseTest {

    @Test
    public void ApiResponse1Test() throws NoSuchFieldException{
        ApiResponse apiResponse= new ApiResponse(HttpStatus.OK,"ok","wsd");
        //apiResponse.setStatus(st);
        org.junit.Assert.assertEquals(apiResponse.getMessage(),"ok");
        org.junit.Assert.assertEquals(apiResponse.getResult(),"wsd");
        org.junit.Assert.assertEquals(apiResponse.getStatus(),200);
        org.junit.Assert.assertNotNull(apiResponse.toString());
        apiResponse.setStatus(200);
        apiResponse.setResult("wsd");
        apiResponse.setMessage("ok");
        ApiResponse apiResponse1=new ApiResponse();
        ApiResponse apiResponse2= new ApiResponse(HttpStatus.OK,"ok");

    }

}
