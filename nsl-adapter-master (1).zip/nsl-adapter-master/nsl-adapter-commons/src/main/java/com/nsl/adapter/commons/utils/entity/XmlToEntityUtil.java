package com.nsl.adapter.commons.utils.entity;

import com.nsl.logical.enums.DataType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

public class XmlToEntityUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(XmlToEntityUtil.class);

    public static TxnGeneralEntity convertXMLToTxnEntity(GeneralEntity generalEntity, InputStream input) {
        try {
            DocumentBuilderFactory instance = DocumentBuilderFactory.newInstance(); //NOSONAR
            instance.setNamespaceAware(true);
            DocumentBuilder documentBuilder = instance.newDocumentBuilder(); //NOSONAR
            Document doc = documentBuilder.parse(input); //NOSONAR
            return convertXMLToTxnEntity(generalEntity, Collections.singletonList(doc.getDocumentElement()));
        } catch (SAXException | ParserConfigurationException | IOException e) {
            LOGGER.error("error while converting to xml : ", e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "error while converting to xml : " + e.getMessage(),
                    ExceptionSeverity.MAJOR, e);
        }

    }

    private static TxnGeneralEntity convertXMLToTxnEntity(GeneralEntity generalEntity, List<Node> childs) {

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();
        txnGeneralEntity.setGeneralEntityID(generalEntity.getId());
        txnGeneralEntity.setName(generalEntity.getName());
        List<TxnGeneralEntityRecord> txnGeneralEntityRecordList = new ArrayList<>();

        childs.forEach(child -> txnGeneralEntityRecordList.add(buildTxnGeneralEntityRecord(generalEntity, child)));
        txnGeneralEntity.setTransEntityRecords(txnGeneralEntityRecordList);
        return txnGeneralEntity;
    }

    private static TxnGeneralEntityRecord buildTxnGeneralEntityRecord(GeneralEntity generalEntity, Node node) {

        NodeList childs = node.getChildNodes();
        HashMap<String, LinkedList<Node>> map = new HashMap<>();

        for (int i = 0; i < childs.getLength(); i++) {
            Node child = childs.item(i);
            String childName = child.getLocalName()+":"+child.getNamespaceURI();
            if (child.getNodeType() == Node.TEXT_NODE)
                map.put("#text",new LinkedList<>(List.of(node)));
            else if (map.containsKey(childName))
                map.get(childName).add(childs.item(i));
            else
                map.put(childName, new LinkedList<>(List.of(childs.item(i))));
        }

        NamedNodeMap attributes = node.getAttributes();
        for (int i = 0; i < attributes.getLength(); i++) {
            Node child = attributes.item(i);
            String childName = child.getLocalName()+":"+child.getNamespaceURI();
            if (map.containsKey(childName))
                map.get(childName).add(attributes.item(i));
            else
                map.put(childName, new LinkedList<>(List.of(attributes.item(i))));
        }

        TxnGeneralEntityRecord txnGeneralEntityRecord = new TxnGeneralEntityRecord();

        List<TxnNslAttribute> txnNslAttributeList = new ArrayList<>();
        for (NslAttribute attribute : generalEntity.getNslAttributes()) {

            TxnNslAttribute txnNslAttribute = new TxnNslAttribute();
            DataType type = attribute.getAttributeType().getType();
            txnNslAttribute.setName(attribute.getName());
            txnNslAttribute.setNslAttributeID(attribute.getId());

            String key;
            if (attribute.getNslAttributeProperties()!= null && attribute.getNslAttributeProperties().containsKey("XML"))
                key = attribute.getNslAttributeProperties().get("XML");
            else
                key = attribute.getName()+ ":null";
            if (!map.containsKey(key)) {
                txnNslAttribute.setValues(new ArrayList<>());
                continue;
            }
            if (DataType.ENTITY == type && attribute.getGeneralEntity() != null) {
                txnNslAttribute.setTxnGeneralEntity(convertXMLToTxnEntity(attribute.getGeneralEntity(), map.get(key)));
            } else if (DataType.LIST == type) {
                if (attribute.getGeneralEntity() != null)
                    txnNslAttribute.setTxnGeneralEntity(convertXMLToTxnEntity(attribute.getGeneralEntity(), map.get(key)));
                else {
                    List<String> value = new ArrayList<>();
                    map.get(key).forEach(child -> value.add(child.getTextContent().trim()));
                    txnNslAttribute.setValues(value);
                }
            } else {
                txnNslAttribute.setValues(List.of(map.get(key).get(0).getTextContent()));
            }

            txnNslAttributeList.add(txnNslAttribute);
        }

        txnGeneralEntityRecord.setTxnNslAttribute(txnNslAttributeList);
        LOGGER.info(txnGeneralEntityRecord.toString());
        return txnGeneralEntityRecord;
    }

}
