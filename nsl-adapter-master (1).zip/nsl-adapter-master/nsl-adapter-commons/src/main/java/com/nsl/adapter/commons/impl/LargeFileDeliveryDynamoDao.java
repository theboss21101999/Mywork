package com.nsl.adapter.commons.impl;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.*;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.adapter.commons.dao.LargeFileDeliveryDao;
import com.nsl.adapter.commons.enums.TransferStatus;
import com.nsl.adapter.commons.models.LargeFileDto;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.HashCodeIdGenerator;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@Service("largeFileDeliveryDynamoDao")
public class LargeFileDeliveryDynamoDao implements LargeFileDeliveryDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(LargeFileDeliveryDynamoDao.class);

    @Autowired
    DynamoDB dynamoDB;

    @Autowired
    AmazonDynamoDB amazonDynamoDB;

    @Autowired
    DynamoDBMapper dynamoDBMapper;

    @Value("${app.dynamo.table.name.prefix:null}")
    private String tableNamePrefix;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;


    public boolean checkForNotNullValues(LargeFileDto largeFileDto) throws NSLException {
        if(largeFileDto.getCuName()==null) {
            throw new NSLException(ExceptionCategory.VALIDATION, "CuName cannot be null",
                    ExceptionSeverity.MAJOR);
        } else if(largeFileDto.getFilePath() == null) {
            throw new NSLException(ExceptionCategory.VALIDATION, "File path cannot be null",
                    ExceptionSeverity.MAJOR);
        } else if(largeFileDto.getActualSize() == null ||
                largeFileDto.getActualSize() == 0) {
            throw new NSLException(ExceptionCategory.VALIDATION,
                    "Actual Size cannot be null or zero",
                    ExceptionSeverity.MAJOR);
        } else if(largeFileDto.getTransactionId() == null) {
            throw new NSLException(ExceptionCategory.VALIDATION,
                    "Transaction Id cannot be null",
                    ExceptionSeverity.MAJOR);
        } else if(largeFileDto.getParentId() == null) {
            throw new NSLException(ExceptionCategory.VALIDATION,
                    "Parent Id cannot be null",
                    ExceptionSeverity.MAJOR);
        } else if(largeFileDto.getDsdFileLocation() == null) {
            throw new NSLException(ExceptionCategory.VALIDATION,
                    "DSD File Location cannot be null",
                    ExceptionSeverity.MAJOR);
        }
        return true;
    }

    @Override
    public String save(LargeFileDto largeFileDto) throws NSLException {
        checkForNotNullValues(largeFileDto);
        LargeFileDto largeFileDto1 = new LargeFileDto();

        largeFileDto1.setFilePath(largeFileDto.getFilePath());
        largeFileDto1.setCuName(largeFileDto.getCuName());
        largeFileDto1.setActualSize(largeFileDto.getActualSize());
        largeFileDto1.setOwner(largeFileDto.getOwner());
        largeFileDto1.setTransferStatus(TransferStatus.ACTIVE);
        largeFileDto1.setLastModifiedBy(authBean.getUserName());
        largeFileDto1.setCreatedDate(new Date());
        largeFileDto1.setLastModifiedDate(new Date());
        largeFileDto1.setCurrentSize(0L);
        largeFileDto1.setParentId(largeFileDto.getParentId());
        largeFileDto1.setTransactionId(largeFileDto.getTransactionId());
        largeFileDto1.setDsdFileLocation(largeFileDto.getDsdFileLocation());
        String randomUUID = String.valueOf(HashCodeIdGenerator.getId());
        largeFileDto1.setTransferId(randomUUID);
        dynamoDBMapper.save(largeFileDto1);
        return randomUUID;
    }

    @Override
    public LargeFileDto fetchByTransferId(String transferId, String parentId) {
        LargeFileDto largeFileDto = new LargeFileDto();
        Table table = dynamoDB.getTable(tableNamePrefix.concat("_").concat(AppConstants.LARGE_FILE_DELIVERY_TABLE_NAME));

        QuerySpec spec = new QuerySpec()
                .withKeyConditionExpression("parentId = :v_parentid AND transferId = :v_transferid")
                .withValueMap(new ValueMap()
                        .withString(":v_parentid", parentId)
                        .withString(":v_transferid", transferId));

        ItemCollection<QueryOutcome> items = table.query(spec);

        Iterator<Item> iterator = items.iterator();

        while (iterator.hasNext()) {
            Item item = iterator.next();
            largeFileDto = JacksonUtils.fromJson(item.toJSON(), LargeFileDto.class);
            break;
        }
        return largeFileDto;

    }


    @Override
    public List<LargeFileDto> fetchByTransferStatus
            (TransferStatus transferStatus, String parentId) {
        List<LargeFileDto> largeFileDtos = new ArrayList<>();
        Table table = dynamoDB.getTable(tableNamePrefix.concat("_").concat(AppConstants.LARGE_FILE_DELIVERY_TABLE_NAME));
        Index index = table.getIndex("TransferStatusIndex");

        QuerySpec spec = new QuerySpec()
                .withKeyConditionExpression("parentId = :v_parentid AND transferStatus = :v_transferStatus")
                .withValueMap(new ValueMap()
                        .withString(":v_parentid", parentId)
                        .withString(":v_transferStatus", transferStatus.toString()));

        ItemCollection<QueryOutcome> items = index.query(spec);

        Iterator<Item> iterator = items.iterator();
        while (iterator.hasNext()) {
            Item item = iterator.next();
            LargeFileDto largeFileDto =  JacksonUtils.fromJson(item.toJSON(), LargeFileDto.class);
            largeFileDtos.add(largeFileDto);
        }

        return largeFileDtos;

    }

    @Override
    public LargeFileDto updateCurrentSize(String transferId, String parentId, Long newSize) throws NSLException {
        LargeFileDto largeFileDto = new LargeFileDto();
        Table table = dynamoDB.getTable(tableNamePrefix.concat("_").concat(AppConstants.LARGE_FILE_DELIVERY_TABLE_NAME));


        QuerySpec spec = new QuerySpec()
                .withKeyConditionExpression("parentId = :v_parentid AND transferId = :v_transferid")
                .withValueMap(new ValueMap()
                        .withString(":v_parentid", parentId)
                        .withString(":v_transferid", transferId));

        ItemCollection<QueryOutcome> items = table.query(spec);

        Iterator<Item> iterator = items.iterator();

        while (iterator.hasNext()) {
            Item item = iterator.next();
            largeFileDto = JacksonUtils.fromJson(item.toJSON(), LargeFileDto.class);
            break;
        }
        if(newSize > largeFileDto.getActualSize()) {
            throw new NSLException(ExceptionCategory.VALIDATION, "Current Size " +
                    "cannot be greater than actual size", ExceptionSeverity.MAJOR);
        }
        largeFileDto.setCurrentSize(newSize);
        dynamoDBMapper.save(largeFileDto);
        return largeFileDto;

    }

    @Override
    public LargeFileDto updateTransferStatus(String transferId, String parentId, TransferStatus transferStatus) {
        LargeFileDto largeFileDto = new LargeFileDto();
        Table table = dynamoDB.getTable(tableNamePrefix.concat("_").concat(AppConstants.LARGE_FILE_DELIVERY_TABLE_NAME));

        QuerySpec spec = new QuerySpec()
                .withKeyConditionExpression("parentId = :v_parentid AND transferId = :v_transferid")
                .withValueMap(new ValueMap()
                        .withString(":v_parentid", parentId)
                        .withString(":v_transferid", transferId));

        ItemCollection<QueryOutcome> items = table.query(spec);

        Iterator<Item> iterator = items.iterator();


        while (iterator.hasNext()) {
            Item item = iterator.next();
            largeFileDto = JacksonUtils.fromJson(item.toJSON(), LargeFileDto.class);
            break;
        }

        largeFileDto.setTransferStatus(transferStatus);
        dynamoDBMapper.save(largeFileDto);
        return largeFileDto;

    }

}
