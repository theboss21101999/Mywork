package com.nsl.adapter.commons.dto;

import com.nsl.adapter.commons.enums.AdapterType;

import java.io.Serializable;

public class SchedulerRequestDto implements Serializable {


    private static final long serialVersionUID = 1L;

    private String tenantId;

    private String userEmail;

    private Long userId;

    private Long changeUnitId;

    private String name;

    private String fileName;

    private AdapterType adapter;

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getChangeUnitId() {
        return changeUnitId;
    }

    public void setChangeUnitId(Long changeUnitId) {
        this.changeUnitId = changeUnitId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public AdapterType getAdapter() {
        return adapter;
    }

    public void setAdapter(AdapterType adapter) {
        this.adapter = adapter;
    }
}
