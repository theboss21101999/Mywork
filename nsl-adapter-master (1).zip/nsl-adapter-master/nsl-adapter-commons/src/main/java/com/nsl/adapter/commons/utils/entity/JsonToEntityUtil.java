package com.nsl.adapter.commons.utils.entity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.logical.enums.DataType;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.NslDataType;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class JsonToEntityUtil {

    private static final Logger logger = LoggerFactory.getLogger(JsonToEntityUtil.class);

    private static final List<DataType> dateTimeTypesList = new ArrayList<>(
            Arrays.asList(DataType.DATE, DataType.DATE_ONLY, DataType.DATE_TIME,
                    DataType.CURRENT_DATE, DataType.CURRENT_DATE_TIME));

    private static final List<DataType> dateTypesList = new ArrayList<>(
            Arrays.asList(DataType.DATE, DataType.DATE_ONLY, DataType.CURRENT_DATE));

    public static TxnGeneralEntity getTriggerTxnGeneralEntityWithData(GeneralEntity generalEntity,
                                                                      JsonNode txnGeneralEntityData) {
        return getTriggerTxnGeneralEntityWithData(generalEntity, txnGeneralEntityData, "", new HashMap<>());
    }

    public static TxnGeneralEntity getTriggerTxnGeneralEntityWithData(GeneralEntity generalEntity, JsonNode txnGeneralEntityData,
                                                                      String prefixString, Map<String, String> mapper) {

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();
        txnGeneralEntity.setGeneralEntityID(generalEntity.getId());
        txnGeneralEntity.setName(generalEntity.getName());
        List<TxnGeneralEntityRecord> txnGeneralEntityRecordList = new ArrayList<>();
        txnGeneralEntity.setTransEntityRecords(txnGeneralEntityRecordList);
        if (txnGeneralEntityData != null && txnGeneralEntityData.isArray() && !txnGeneralEntityData.isEmpty())
            for (JsonNode entityRecordDataNode : txnGeneralEntityData)
                txnGeneralEntityRecordList
                        .add(buildTxnGeneralEntityRecord(generalEntity.getNslAttributes(), entityRecordDataNode, prefixString, mapper));
        else
            txnGeneralEntityRecordList
                    .add(buildTxnGeneralEntityRecord(generalEntity.getNslAttributes(), txnGeneralEntityData, prefixString, mapper));
        return txnGeneralEntity;
    }

    private static TxnGeneralEntityRecord buildTxnGeneralEntityRecord(List<NslAttribute> nslAttributeList, JsonNode entityRecordDataNode,
                                                                      String prefixString, Map<String, String> mapper) {
        logger.info(entityRecordDataNode != null ? entityRecordDataNode.toString(): null);
        logger.info("++++++++++++++++++++++++");
        ObjectMapper mapper_obj = new ObjectMapper();
        List<TxnNslAttribute> txnNslAttributes = new ArrayList<>();
        TxnGeneralEntityRecord txnGeneralEntityRecord = new TxnGeneralEntityRecord();
        if (nslAttributeList != null) {
            for (NslAttribute nslAttribute : nslAttributeList) {
                TxnNslAttribute attribute = new TxnNslAttribute();
                attribute.setNslAttributeID(nslAttribute.getId());
                attribute.setName(nslAttribute.getName());
                String type = nslAttribute.getAttributeType().getType().toString();
                String attributeName;
                if(prefixString.equalsIgnoreCase(""))
                    attributeName=nslAttribute.getName();
                else
                    attributeName=prefixString+"."+nslAttribute.getName();
                logger.info(attributeName);
//                String nameWithoutMapping = name.replace("__","");
                String nameWithoutMapping = mapper.getOrDefault(attributeName, nslAttribute.getName());
                JsonNode attributeDataNode = null;
                if (entityRecordDataNode != null && entityRecordDataNode.get(nameWithoutMapping) != null)
                    attributeDataNode = entityRecordDataNode.get(nameWithoutMapping);

                if (attributeDataNode == null && !type.equalsIgnoreCase("entity"))
                    attribute.setValues(new ArrayList<>());
                else if (type.equalsIgnoreCase("entity") && nslAttribute.getGeneralEntity() != null)
                    attribute.setTxnGeneralEntity(
                            getTriggerTxnGeneralEntityWithData(nslAttribute.getGeneralEntity(), attributeDataNode, attributeName, mapper));
                else if (type.equalsIgnoreCase("list")) {
                    if (nslAttribute.getGeneralEntity() == null) {
                        List<String> values = new ArrayList<>();
                        for (JsonNode node : attributeDataNode) {
                            values.add(node.asText());
                        }
                        attribute.setValues(values);
                    } else {
                        attribute.setTxnGeneralEntity(
                                getTriggerTxnGeneralEntityWithData(nslAttribute.getGeneralEntity(), attributeDataNode, attributeName, mapper));
                    }
                } else if (attributeDataNode != null && (type.equalsIgnoreCase("file") || type.equalsIgnoreCase("image") || type.equalsIgnoreCase("video"))) {
                    attribute.setValues(getValuesFromNode(attributeDataNode));
                    /*String values = generateValueFromNode(attributeDataNode);
                    attribute.setValues(Collections.singletonList(values));*/
                }
                else if(attributeDataNode!=null)
                    if (dateTimeTypesList.contains(nslAttribute.getAttributeType().getType())){  //NOSONAR
                        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
                        ZonedDateTime dateTime;
                        if (dateTypesList.contains(nslAttribute.getAttributeType().getType())){//NOSONAR
                            dateTime = LocalDate.parse(attributeDataNode.asText(),
                                    DateTimeFormatter.ofPattern(
                                            nslAttribute.getAttributeType().getProperties().get("format")))
                                    .atStartOfDay(ZoneId.of("Asia/Kolkata"))
                                    .withZoneSameInstant(ZoneId.of("UTC"));

                        }else {
                            dateTime = LocalDateTime.parse(attributeDataNode.asText(),
                                            DateTimeFormatter.ofPattern(
                                                    getDateTimeFormat(nslAttribute.getAttributeType())))
                                    .atZone(ZoneId.of("Asia/Kolkata"))
                                    .withZoneSameInstant(ZoneId.of("UTC"));
                        }
                        attribute.setValues(Collections.singletonList(dateTime.format(dateFormatter)));
                    }else{
                        attribute.setValues(formatData(attributeDataNode));
                    }

                logger.info(attribute.toString());
                txnNslAttributes.add(attribute);
            }
            txnGeneralEntityRecord.setTxnNslAttribute(txnNslAttributes);
        }
        return txnGeneralEntityRecord;
    }

    private static List<String> formatData(JsonNode attributeNode){
        List<String> result = new ArrayList<>();
        try{
            if(attributeNode.isArray()){
                for(JsonNode node:attributeNode){
                    result.add(node.asText());
                }
            }
            else if(attributeNode.isObject()){
                result.add(new ObjectMapper().writeValueAsString(attributeNode));
            }else{
                result.add(attributeNode.asText());
            }
        }catch (JsonProcessingException e){
            throw new RuntimeException(e);
        }
        return result;
    }

    private static String getDateTimeFormat(NslDataType dataType){
        Map<String, String> properties = dataType.getProperties();
        String attributeType = dataType.getType().getName();
        String format = properties.get("format");
        switch (properties.getOrDefault("timeFormat","")){
            case "12-hr":
                if(format==null) format = "MM/dd/yyyy";
                if(attributeType.equals("datetime")) format+=" hh:mm:ss a";
                else format+=" hh:mm a";//NOSONAR
                break;
            case "24-hr":
                if(format==null) format = "dd/MM/yyyy";
                if(attributeType.equals("datetime")) format+=" HH:mm:ss";
                else format+=" HH:mm";//NOSONAR
                break;
            default:
                format="MM/dd/yyyy HH:mm";
                break;
        }
        return format;
    }

    private static List<String> getValuesFromNode(JsonNode attributeDataNode) {
        List<String> values = new ArrayList<>();
        if (attributeDataNode.isArray()){
            attributeDataNode.forEach(x -> values.add(x.asText()));
        }else
            values.add(attributeDataNode.asText());
        return values;
    }

    /*private static String generateValueFromNode(JsonNode attributeDataNode) {
        String values = attributeDataNode.asText();
        String preProcessed = values.replace("{","");
        String processed = preProcessed.replace("}","");
        Map<String, String> result = Splitter.on(',').trimResults().withKeyValueSeparator(Splitter.on('=').limit(2).trimResults()).split(processed);
        try {
            values = new ObjectMapper().writeValueAsString(result);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return values;
    }

    public static void addToAttributeList(String attrName, JSONObject value, List<TxnNslAttribute> txnNslAttributeList)
            throws JSONException {

        // Assumption: All result attribute are part of the same entity and
        TxnNslAttribute txnAttribute = new TxnNslAttribute();
        txnAttribute.setName(attrName);
        List<String> values = new ArrayList<>();
        values.add(value.getString(AppConstant.VALUE));
        txnAttribute.setValues(values);
        txnNslAttributeList.add(txnAttribute);
        logger.info("Adding attribute to general Entity: {}", value.getString(AppConstant.VALUE));
    }*/

}
