package com.nsl.adapter.commons.parsers.service;


import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

public interface ParserV2 {

      InputStream outboundParser(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity, Boolean isFileExists , Map<String,String> cuSystemProps) throws NSLException;

      List<TxnData> inboundParser(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued, Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException;

      List<TxnGeneralEntity> inboundParserV2(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued, Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException;
}