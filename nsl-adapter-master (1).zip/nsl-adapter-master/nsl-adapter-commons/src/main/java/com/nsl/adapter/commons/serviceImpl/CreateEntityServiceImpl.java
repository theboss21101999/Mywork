package com.nsl.adapter.commons.serviceImpl;

import com.nsl.adapter.commons.enums.EntityCreationFileType;
import com.nsl.adapter.commons.service.CreateEntityService;
import com.nsl.adapter.commons.utils.create_entity.CreateEntityFactory;
import com.nsl.adapter.commons.utils.create_entity.CreateEntityFromFile;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;

import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import org.elasticsearch.client.ResponseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.Map;

@Service
public class CreateEntityServiceImpl implements CreateEntityService{

    private static final Logger logger = LoggerFactory.getLogger(CreateEntityServiceImpl.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    CreateEntityFactory createEntityFactory;

    @Autowired
    GeneralEntityDao generalEntityDao;
    
    /**
     * method to parse it according to file type and send it to corresponding functions
 
     * @param fileType   Uploaded File Type
     * @param file       Uploaded File
     */
    @Override 
    public TenantCUEntityInput convertIntoEntity(String fileType, MultipartFile file, String entityName, Map<String,Object> PropertyMap) throws NSLException {

        EntityCreationFileType creationFileType= EntityCreationFileType.fromValue(fileType);
        if (creationFileType == null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "invalid fileType ", null);
        GeneralEntity generalEntity = generalEntityDao.findByName(entityName,authBean);
        if (generalEntity != null && generalEntity.getId()!=null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "ValidationErrors: [Error]: Entity already exists in the system with name: " + entityName, null);

        logger.info(creationFileType.toString());
        CreateEntityFromFile createEntityFromFile = createEntityFactory.createEntity(creationFileType);
        return createEntityFromFile.convertFileIntoEntity(file, entityName,PropertyMap);
    }
    
}