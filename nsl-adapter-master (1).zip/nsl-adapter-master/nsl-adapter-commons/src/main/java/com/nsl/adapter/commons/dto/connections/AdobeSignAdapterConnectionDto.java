package com.nsl.adapter.commons.dto.connections;

import java.util.List;

public class AdobeSignAdapterConnectionDto extends BasicAdapterConnection{
    String appId;
    String appSecret;
    String refreshToken;
    List<String> scope;

    public AdobeSignAdapterConnectionDto() {
    }

    public AdobeSignAdapterConnectionDto(String appId, String appSecret, String refreshToken, List<String> scope) {
        this.appId = appId;
        this.appSecret = appSecret;
        this.refreshToken = refreshToken;
        this.scope = scope;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public List<String> getScope() {
        return scope;
    }

    public void setScope(List<String> scope) {
        this.scope = scope;
    }
}
