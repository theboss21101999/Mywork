package com.nsl.adapter.commons.dto;

public class GsiDto {
    String gsiName;
    Long gsiId;

    public String getGsiName() {
        return gsiName;
    }

    public void setGsiName(String gsiName) {
        this.gsiName = gsiName;
    }

    public Long getGsiId() {
        return gsiId;
    }

    public void setGsiId(Long gsiId) {
        this.gsiId = gsiId;
    }
}
