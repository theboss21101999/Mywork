package com.nsl.adapter.commons.dto.connections;


public class IBMMQAdapterConnectionDto extends BasicAdapterConnection{
    private String hostname;
    private String port;
    private String channel;
    private String queueManager;
    MQCredential authentication;

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getQueueManager() {
        return queueManager;
    }

    public void setQueueManager(String queueManager) {
        this.queueManager = queueManager;
    }

    public MQCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(MQCredential authentication) {
        this.authentication = authentication;
    }
}
