package com.nsl.adapter.commons.utils;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.MetaInfoEntityDto;
import com.nsl.adapter.commons.dto.connections.RestInboundDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionStatus;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class MetaInfoEntityUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(MetaInfoEntityUtils.class);

    private static final ConnectionDtoType connType = ConnectionDtoType.InboundCu;


    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    public String createMetaInfoEntity(String integrationName, AuthenticatedUserDetailsImpl authBean){

        TxnAdapterConnection connection = new TxnAdapterConnection();
        connection.setConnectionDtoType(connType);

        MetaInfoEntityDto dto = new MetaInfoEntityDto();
        dto.setConnectionName(integrationName);
        dto.setConnectionStatus(ConnectionStatus.INVALID);

        connection.setConnection(dto);

        LOGGER.info("saving metaInfoEntity {}", JacksonUtils.toJson(connection));

        return adapterConnnectionsDao.saveConnection(connection,authBean).getConnection().getConnectionName();
    }
    public MetaInfoEntityDto getMetaInfoEntityDto(String connName, AuthenticatedUserDetailsImpl authBean){

        TxnAdapterConnection conn = adapterConnnectionsDao.getConnectionByName(connType, connName, authBean);
        MetaInfoEntityDto dto = (MetaInfoEntityDto) conn.getConnection();
        dto.getAdditionalProperties().put(AppConstants.CONFIG_ENTITY_RECORD_ID, conn.getRecordId().toString());

        LOGGER.info("fetched metaInfoEntity {}", JacksonUtils.toJson(conn));
        return dto;
    }

    public void updateMetaInfoEntity(MetaInfoEntityDto metaInfoEntityDto, AuthenticatedUserDetailsImpl authBean){

        String recordId = metaInfoEntityDto.getAdditionalProperties().remove(AppConstants.CONFIG_ENTITY_RECORD_ID);
        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(connType, Long.valueOf(recordId), authBean);
        previousConnection.setConnection(metaInfoEntityDto);

        LOGGER.info("updating metaInfoEntity {}", JacksonUtils.toJson(previousConnection));
        adapterConnnectionsDao.saveConnection(previousConnection, authBean );
    }
    public String createGsiMetaInfoEntity(String gsiName, RestInboundDto restInboundDto, AuthenticatedUserDetailsImpl authBean){

        TxnAdapterConnection connection = new TxnAdapterConnection();
        connection.setConnectionDtoType(connType);
        ObjectMapper objectMapper= new ObjectMapper();
        MetaInfoEntityDto dto = new MetaInfoEntityDto();
        dto.setConnectionName(gsiName);
        dto.setAdditionalProperties(objectMapper.convertValue(restInboundDto, Map.class));
        dto.setConnectionStatus(ConnectionStatus.INVALID);

        connection.setConnection(dto);

        LOGGER.info("saving metaGsiInfoEntity {}", JacksonUtils.toJson(connection));

        return adapterConnnectionsDao.saveConnection(connection,authBean).getConnection().getConnectionName();
    }
    public RestInboundDto getGsiMetaInfoEntityDto(String connName, AuthenticatedUserDetailsImpl authBean){

        TxnAdapterConnection conn = adapterConnnectionsDao.getConnectionByName(connType, connName, authBean);
        MetaInfoEntityDto dto = (MetaInfoEntityDto) conn.getConnection();
        dto.getAdditionalProperties().put(AppConstants.CONFIG_ENTITY_RECORD_ID, conn.getRecordId().toString());
        RestInboundDto restInboundDto= new ObjectMapper().convertValue(dto.getAdditionalProperties(),RestInboundDto.class);
        LOGGER.info("fetched metaInfoEntity {}", JacksonUtils.toJson(conn));
        return restInboundDto;
    }
    public void updateGsiMetaInfoEntity(String gsiName,RestInboundDto restInboundDto, AuthenticatedUserDetailsImpl authBean){

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByName(connType, gsiName, authBean);
        ObjectMapper objectMapper= new ObjectMapper();
        MetaInfoEntityDto metaInfoEntityDto= getMetaInfoEntityDto(gsiName,authBean);
        metaInfoEntityDto.setAdditionalProperties(objectMapper.convertValue(restInboundDto, Map.class));
        previousConnection.setConnection(metaInfoEntityDto);

        LOGGER.info("updating metaInfoEntity {}", JacksonUtils.toJson(previousConnection));
        adapterConnnectionsDao.saveConnection(previousConnection, authBean );
    }
}
