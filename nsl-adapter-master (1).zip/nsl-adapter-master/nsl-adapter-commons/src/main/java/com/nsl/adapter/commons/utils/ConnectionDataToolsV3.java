package com.nsl.adapter.commons.utils;

import com.amazonaws.services.secretsmanager.model.CreateSecretResult;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.amazonaws.services.secretsmanager.model.UpdateSecretResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.service.AWSSecretManagerService;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.DataType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import static com.nsl.adapter.commons.utils.AppConstants.CONNECTION_NAME;

@Service
public class ConnectionDataToolsV3 {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConnectionDataToolsV3.class);

    public static final String prefix = "AdapterConnection/";

    @Autowired
    AWSSecretManagerService awsSecretManagerService;

    @Autowired
    AdaptorCommonsProperties adaptorCommonsProperties;
    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    MessageSource messageSource;

    public List<TxnNslAttribute> JsonToAttributeList(JsonNode jsonNode, GeneralEntity generalEntity , String tenantId , boolean isSave ) {


        List<TxnNslAttribute> attributesList = new ArrayList<>();
        for (NslAttribute nslAttribute : generalEntity.getNslAttributes()) {

//            JsonElement element = jsonElement.getAsJsonObject().get(nslAttribute.getName());
            JsonNode element = jsonNode.get(nslAttribute.getName());
            if (element == null && nslAttribute.getAttributeType().getType() != DataType.ENCRYPTEDTEXT) continue;

            TxnNslAttribute dataAttribute;
            if (nslAttribute.getAttributeType().getType() == DataType.ENCRYPTEDTEXT){
//                String connectionName = jsonElement.getAsJsonObject().get(CONNECTION_NAME).getAsString();
                String connectionName = jsonNode.get(CONNECTION_NAME).asText();
                String secretName;
                if (isSave)
                    secretName= SaveSecret(generalEntity.getName(),nslAttribute.getName(),connectionName,tenantId,element);
                else
                    secretName= updateSecret(generalEntity.getName(),nslAttribute.getName(),connectionName,tenantId,element);
                if (secretName == null) {
                    LOGGER.info("skipping the attribute {}",nslAttribute.getName());
                    continue;
                }
                dataAttribute = createNslAttribute(nslAttribute, secretName);
            } else {
                dataAttribute = createNslAttribute(nslAttribute, element);  //NOSONAR
            }

            attributesList.add(dataAttribute);

        }
        return attributesList;
    }

    public String SaveSecret(String entityName, String attributeName,String connectionName ,
                             String tenantId , JsonNode secretValue){

        if (secretValue == null)
            return null;

        String value;
        if (secretValue.isObject() || secretValue.isArray())
            value = JacksonUtils.toJson(secretValue);
        else
            value = secretValue.asText();

        String secretName = prefix + entityName + "/"+ attributeName + "/" + adaptorCommonsProperties.getEnvKey() + "/"
                + tenantId + "/" + connectionName ;
        try {
            String secret = awsSecretManagerService.createNewSecret(secretName, value);
            LOGGER.info("secret Saved with the name: " + secret);
        }catch (Exception e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "failed to save the secret",e);
        }
        return secretName;

    }

    public String updateSecret(String entityName, String attributeName,String connectionName , String tenantId, JsonNode secretValue) {

        String secretName = prefix + entityName + "/"+ attributeName + "/"+ adaptorCommonsProperties.getEnvKey() + "/"
                + tenantId + "/" + connectionName ;

        try {
            if (secretValue == null) {
                if (awsSecretManagerService.checkForSecret(secretName))
                    return secretName;
                else
                    return null;
            }

            String value;
            if (secretValue.isObject() || secretValue.isArray())
                value = JacksonUtils.toJson(secretValue);
            else
                value = secretValue.asText();

            if (value.startsWith(prefix + entityName))
                return value;

            String secret = awsSecretManagerService.updateSecret(secretName, value);
            LOGGER.info("updated the secret with name: "+secret);
            return secret;
        }catch (NSLException e){
            /** temporary coed to create secrets for old records*/
            LOGGER.info("creating a secret for the old Record");
            return SaveSecret(entityName, attributeName, connectionName, tenantId, secretValue);
//            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "failed to update the secret",e);
        }
    }

    public String saveSecret(ConnectionDtoType type, String attributeName, String connectionName ,
                             String tenantId , String secretValue){

        if (secretValue == null)
            return null;
        var isSecretEnabled = adaptorCommonsProperties.getSecretEnabled();

        if(isSecretEnabled){

            String secretName = prefix + adaptorCommonsProperties.getEnvKey() + "/" + tenantId + "/" + type.toString() + "/"
                    + encode(connectionName) + "/" + attributeName;
            try {
                String secret = awsSecretManagerService.createNewSecret(secretName, secretValue);
                LOGGER.info("secret Saved with the name: " + secret);
            } catch (Exception e) {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "failed to save the secret", e);
            }
            return secretName;
        }
        return secretValue;
    }

    public String updateSecret(ConnectionDtoType type, String attributeName,String connectionName ,
                               String tenantId, String secretValue) {

        String secretName = prefix + adaptorCommonsProperties.getEnvKey() + "/" + tenantId + "/"+ type.toString() + "/"
                + encode(connectionName) + "/" + attributeName;

        try {
            if (secretValue == null) {
                if (awsSecretManagerService.checkForSecret(secretName))
                    return secretName;
                else
                    return null;
            }

            if (secretValue.equals(secretName))
                return secretValue;

            String secret = awsSecretManagerService.updateSecret(secretName, secretValue);
            LOGGER.info("updated the secret with name: "+secret);
            return secret;
        }catch (NSLException e){
            /** temporary coed to create secrets for old records*/
            LOGGER.info("creating a secret for the old Record");
            return saveSecret(type, attributeName, connectionName, tenantId, secretValue);
//            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "failed to update the secret",e);
        }
    }

    public String getSecret(String secretName) {
        if (secretName==null){
            return null;
        }

        if (!secretName.startsWith(prefix))
            return secretName;

        try {
            String response = awsSecretManagerService.getSecret(secretName);
            return response;
        }catch (NSLException e){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,"unable to get the Secret",e);
        }
    }

    public final TxnNslAttribute createNslAttribute(NslAttribute nslAttribute, String value){
        TxnNslAttribute txnNslAttribute = new TxnNslAttribute();
        txnNslAttribute.setName(nslAttribute.getName());
        txnNslAttribute.setNslAttributeID(nslAttribute.getId());
        List<String> valueList= new ArrayList<>();
        valueList.add(value);
        txnNslAttribute.setValues(valueList);
        return txnNslAttribute;
    }

    private String encode(String val){
        if (val.contains(" ")){
            return Base64.getEncoder().encodeToString(val.getBytes(StandardCharsets.UTF_8));
        }
        return val;
    }

    public final TxnNslAttribute createNslAttribute(NslAttribute nslAttribute, JsonNode value){
        try {
            TxnNslAttribute txnNslAttribute = new TxnNslAttribute();
            txnNslAttribute.setName(nslAttribute.getName());
            txnNslAttribute.setNslAttributeID(nslAttribute.getId());
            List<String> valueList;
            if (value.isArray())
                valueList = new ObjectMapper().readValue(value.toString(), List.class);
            else if (value.isObject())
                valueList = Collections.singletonList(JacksonUtils.toJson(value));
            else
                valueList = Collections.singletonList(value.asText());

            txnNslAttribute.setValues(valueList);
            return txnNslAttribute;
        }catch (JsonProcessingException ignore){
            return null;
        }
    }


    /** dynamo helper methods*/

    public void connectionNameCheck(TxnAdapterConnection previousConnection, String connectionName){

        if (previousConnection==null || !previousConnection.getConnection().getConnectionName().
                equals(connectionName)){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,
                    messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }
    }
    public void connectionCheck(ConnectionDtoType adapterType, String connectionName, AuthenticatedUserDetailsImpl authenticatedUserDetails){

        if ( adapterConnnectionsDao.getConnectionByName(adapterType, connectionName, authenticatedUserDetails)!=null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_9", null, Locale.ENGLISH) , null);
        }
    }

}
