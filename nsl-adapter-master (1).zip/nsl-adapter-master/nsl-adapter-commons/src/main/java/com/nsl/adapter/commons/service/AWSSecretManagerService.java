package com.nsl.adapter.commons.service;

import com.amazonaws.services.secretsmanager.model.CreateSecretResult;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.amazonaws.services.secretsmanager.model.UpdateSecretResult;
import com.nsl.logical.exception.NSLException;

/** 
* The interface AWS secret service.
*/
public interface AWSSecretManagerService {

    String createNewSecret(String secretName, String secretValue) throws NSLException;

    String updateSecret(String secretId, String secretValue) throws NSLException;

    boolean checkForSecret(String secretId) throws NSLException;

    String getSecret(String secretId) throws NSLException;

}
