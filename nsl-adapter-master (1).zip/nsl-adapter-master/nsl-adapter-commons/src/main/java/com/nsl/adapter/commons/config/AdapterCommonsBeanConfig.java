package com.nsl.adapter.commons.config;

import com.nsl.adapter.commons.utils.ThreadBeanUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

/**
 * This class is for : AdapterCommonsBeanConfig.
 */
@Configuration
@EnableAsync
public class AdapterCommonsBeanConfig {

    /**
     * This Object is : ThreadBeanUtil.
     */
    @Autowired
    ThreadBeanUtil beanUtil;


    @Bean(name = "commonGsiExecutor")
    public Executor getGsiExecutor()
    {
        return beanUtil.getThread("GsiExecutor-");
    }

    @Bean("dsdRestTemplate")
    public RestTemplate getRestTemplate(@Autowired MappingJackson2HttpMessageConverter jacksonHttpMessageConverter) {
        RestTemplate restTemplate = new RestTemplate();
        List<MediaType> mediaTypes = new ArrayList<>();
        mediaTypes.add(MediaType.APPLICATION_JSON);
        jacksonHttpMessageConverter.setSupportedMediaTypes(mediaTypes);
        restTemplate.getMessageConverters().add(jacksonHttpMessageConverter);
        return restTemplate;
    }

}
