package com.nsl.adapter.commons.dto.connections;

import java.util.Properties;

public class SmtpAdapterConnectionDto extends BasicAdapterConnection {
    //host
    private String host;
    //port
    private int port;
    //from-email
    private String from;
    //authentication
    private String username;
    private String password;
    Properties advancedConfig;
    //connection name

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Properties getAdvancedConfig() {
        return advancedConfig;
    }

    public void setAdvancedConfig(Properties advancedConfig) {
        this.advancedConfig = advancedConfig;
    }
}
