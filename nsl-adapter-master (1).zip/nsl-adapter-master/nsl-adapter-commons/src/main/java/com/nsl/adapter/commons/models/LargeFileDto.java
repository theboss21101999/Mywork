package com.nsl.adapter.commons.models;

import com.amazonaws.services.dynamodbv2.datamodeling.*;
import com.nsl.adapter.commons.enums.TransferStatus;
import com.nsl.adapter.commons.utils.AppConstants;

import java.util.Date;

@DynamoDBTable(tableName = AppConstants.LARGE_FILE_DELIVERY_TABLE_NAME)
public class LargeFileDto {

    private String transferId;

    private String cuName;

    private String filePath;
    private Long currentSize;

    private Long actualSize;
    private Date createdDate;

    private TransferStatus transferStatus;

    private Date lastModifiedDate;

    private String owner;

    private String lastModifiedBy;

    private String comments;

    private String parentId;

    private Long gsiId;

    public String transactionId;

    public String dsdFileLocation;

    public LargeFileDto() {

    }

    public LargeFileDto(String cuName, String filePath, long actualSize, String transactionId, String parentId, Long gsiId,String dsdFileLocation){
        this.cuName=cuName;
        this.filePath=filePath;
        this.actualSize=actualSize;
        this.transactionId=transactionId;
        this.parentId=parentId;
        this.gsiId = gsiId;
        this.dsdFileLocation=dsdFileLocation;
    }

    @DynamoDBAttribute(attributeName = "dsdFileLocation")
    public String getDsdFileLocation() {
        return dsdFileLocation;
    }

    public void setDsdFileLocation(String dsdFileLocation) {
        this.dsdFileLocation = dsdFileLocation;
    }

    @DynamoDBRangeKey(attributeName = "transferId")
    public String getTransferId() {
        return transferId;
    }

    public void setTransferId(String transferId) {
        this.transferId = transferId;
    }

    @DynamoDBAttribute(attributeName = "cuName")
    public String getCuName() {
        return cuName;
    }

    public void setCuName(String cuName) {
        this.cuName = cuName;
    }


    @DynamoDBAttribute(attributeName = "filePath")
    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }


    @DynamoDBHashKey(attributeName = "parentId")
    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }


    @DynamoDBAttribute(attributeName = "currentSize")
    public Long getCurrentSize() {
        return currentSize;
    }

    public void setCurrentSize(Long currentSize) {
        this.currentSize = currentSize;
    }


    @DynamoDBAttribute(attributeName = "actualSize")
    public Long getActualSize() {
        return actualSize;
    }

    public void setActualSize(Long actualSize) {
        this.actualSize = actualSize;
    }


    @DynamoDBAttribute(attributeName = "createdDate")
    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    @DynamoDBAttribute(attributeName = "owner")
    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    @DynamoDBAttribute(attributeName = "lastModifiedBy")
    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    @DynamoDBAttribute(attributeName = "lastModifiedDate")
    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    @DynamoDBAttribute(attributeName = "comments")
    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @DynamoDBAttribute(attributeName = "gsiId")
    public Long getGsiId() {
        return gsiId;
    }

    public void setGsiId(Long gsiId) {
        this.gsiId = gsiId;
    }

    @DynamoDBTypeConvertedEnum
    @DynamoDBIndexRangeKey(attributeName = "transferStatus", localSecondaryIndexName = "TransferStatusIndex")
    @DynamoDBAttribute(attributeName = "transferStatus")
    public TransferStatus getTransferStatus() {
        return transferStatus;
    }

    public void setTransferStatus(TransferStatus transferStatus) {
        this.transferStatus = transferStatus;
    }

    @DynamoDBAttribute(attributeName = "transactionId")
    public String getTransactionId() { return transactionId; }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }


}
