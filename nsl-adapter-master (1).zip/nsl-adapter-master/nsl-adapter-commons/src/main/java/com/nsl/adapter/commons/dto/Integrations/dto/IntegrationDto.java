package com.nsl.adapter.commons.dto.Integrations.dto;

import com.nsl.adapter.commons.dto.AdapterScheduleReq;
import com.nsl.adapter.commons.dto.DynamicGsiRouteDto;
import com.nsl.adapter.commons.dto.Integrations.model.ImapIntegration;
import com.nsl.adapter.commons.enums.AdapterType;

import java.util.HashMap;
import java.util.Map;

public class IntegrationDto {


    private String integrationName;
    private AdapterType adapterType;
    private String operation;

    private String cloudId;
    private Long configEntityRecordId;
    private String configEntityRecordName;
    private String inputEntityId;
    private String outputEntityId;
    private String infoEntityId;
    private Map<String,String> propertiesMap = new HashMap<>();
    private ImapIntegration imapIntegration;
    private AdapterScheduleReq scheduleReq;
    private DynamicGsiRouteDto dynamicGsiReq;

    private boolean isPersonalConnection = false;

    public IntegrationDto() {
    }

    public String getIntegrationName() {
        return integrationName;
    }

    public void setIntegrationName(String integrationName) {
        this.integrationName = integrationName;
    }

    public AdapterType getAdapterType() {
        return adapterType;
    }

    public void setAdapterType(AdapterType adapterType) {
        this.adapterType = adapterType;
    }

    public String getCloudId() {
        return cloudId;
    }

    public void setCloudId(String cloudId) {
        this.cloudId = cloudId;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public Long getConfigEntityRecordId() {
        return configEntityRecordId;
    }

    public void setConfigEntityRecordId(Long configEntityRecordId) {
        this.configEntityRecordId = configEntityRecordId;
    }

    public String getConfigEntityRecordName() {
        return configEntityRecordName;
    }

    public void setConfigEntityRecordName(String configEntityRecordName) {
        this.configEntityRecordName = configEntityRecordName;
    }

    public String getInputEntityId() {
        return inputEntityId;
    }

    public void setInputEntityId(String inputEntityId) {
        this.inputEntityId = inputEntityId;
    }

    public String getOutputEntityId() {
        return outputEntityId;
    }

    public void setOutputEntityId(String outputEntityId) {
        this.outputEntityId = outputEntityId;
    }

    public String getInfoEntityId() {
        return infoEntityId;
    }

    public void setInfoEntityId(String infoEntityId) {
        this.infoEntityId = infoEntityId;
    }

    public Map<String, String> getPropertiesMap() {
        return propertiesMap;
    }

    public void setPropertiesMap(Map<String, String> propertiesMap) {
        this.propertiesMap = propertiesMap;
    }

    public ImapIntegration getImapIntegration() {
        return imapIntegration;
    }

    public void setImapIntegration(ImapIntegration imapIntegration) {
        this.imapIntegration = imapIntegration;
    }

    public AdapterScheduleReq getScheduleReq() {
        return scheduleReq;
    }

    public void setScheduleReq(AdapterScheduleReq scheduleReq) {
        this.scheduleReq = scheduleReq;
    }

    public DynamicGsiRouteDto getDynamicGsiReq() {
        return dynamicGsiReq;
    }

    public void setDynamicGsiReq(DynamicGsiRouteDto dynamicGsiReq) {
        this.dynamicGsiReq = dynamicGsiReq;
    }

    public boolean isPersonalConnection() {
        return isPersonalConnection;
    }

    public void setPersonalConnection(boolean personalConnection) {
        isPersonalConnection = personalConnection;
    }
}
