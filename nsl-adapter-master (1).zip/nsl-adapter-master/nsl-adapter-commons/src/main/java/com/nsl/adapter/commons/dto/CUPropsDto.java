package com.nsl.adapter.commons.dto;

import com.nsl.dsd.store.models.tenant.io.TenantSlotItemInput;
import java.util.List;
import java.util.Map;

public class CUPropsDto {

    private String cuName;
    private Boolean isMachineCU;
    private Map<String ,String> cuSystemProps;
    private List<TenantSlotItemInput> physicalLayerItems;
    private List<TenantSlotItemInput> triggerCESLayerItems;
    private List<TenantSlotItemInput> informationLayerItems;

    public CUPropsDto() {
    }

    public String getCuName() {
        return cuName;
    }

    public void setCuName(String cuName) {
        this.cuName = cuName;
    }

    public Boolean getIsMachineCU() {
        return isMachineCU;
    }

    public void setIsMachineCU(Boolean machineCU) {
        isMachineCU = machineCU;
    }

    public Map<String, String> getCuSystemProps() {
        return cuSystemProps;
    }

    public void setCuSystemProps(Map<String, String> cuSystemProps) {
        this.cuSystemProps = cuSystemProps;
    }

    public List<TenantSlotItemInput> getPhysicalLayerItems() {
        return physicalLayerItems;
    }

    public void setPhysicalLayerItems(List<TenantSlotItemInput> physicalLayerItems) {
        this.physicalLayerItems = physicalLayerItems;
    }

    public List<TenantSlotItemInput> getTriggerCESLayerItems() {
        return triggerCESLayerItems;
    }

    public void setTriggerCESLayerItems(List<TenantSlotItemInput> triggerCESLayerItems) {
        this.triggerCESLayerItems = triggerCESLayerItems;
    }

    public List<TenantSlotItemInput> getInformationLayerItems() {
        return informationLayerItems;
    }

    public void setInformationLayerItems(List<TenantSlotItemInput> informationLayerItems) {
        this.informationLayerItems = informationLayerItems;
    }
}
