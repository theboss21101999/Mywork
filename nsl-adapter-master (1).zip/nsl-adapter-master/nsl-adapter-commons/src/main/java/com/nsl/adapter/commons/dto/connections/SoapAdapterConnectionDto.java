package com.nsl.adapter.commons.dto.connections;

public class SoapAdapterConnectionDto extends BasicAdapterConnection {
    private String baseUrl;
    private SoapCredential authentication;

    public SoapAdapterConnectionDto() {
    }

    public SoapAdapterConnectionDto(String baseUrl, SoapCredential authentication) {
        this.baseUrl = baseUrl;
        this.authentication = authentication;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public SoapCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(SoapCredential authentication) {
        this.authentication = authentication;
    }
}
