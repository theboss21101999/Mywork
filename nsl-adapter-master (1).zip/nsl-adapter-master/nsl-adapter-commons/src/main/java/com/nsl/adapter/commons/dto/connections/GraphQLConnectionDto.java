package com.nsl.adapter.commons.dto.connections;



public class GraphQLConnectionDto extends BasicAdapterConnection {

    private String host;
    private GraphQLCredential authentication;

    public GraphQLConnectionDto() {
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public GraphQLCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(GraphQLCredential authentication) {
        this.authentication = authentication;
    }
}
