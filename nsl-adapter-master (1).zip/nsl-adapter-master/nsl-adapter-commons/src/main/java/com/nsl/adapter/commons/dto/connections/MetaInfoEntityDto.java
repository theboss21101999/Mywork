package com.nsl.adapter.commons.dto.connections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MetaInfoEntityDto extends BasicAdapterConnection {

    Long cuMasterId;
    List<Long> gsiIdList = new ArrayList<>();
    String jobId;
    Map<String,String> additionalProperties = new HashMap<>();
    Long LastRunStartTime;

    public MetaInfoEntityDto() {
    }

    public Long getCuMasterId() {
        return cuMasterId;
    }

    public void setCuMasterId(Long cuMasterId) {
        this.cuMasterId = cuMasterId;
    }

    public List<Long> getGsiIdList() {
        return gsiIdList;
    }

    public void setGsiIdList(List<Long> gsiIdList) {
        this.gsiIdList = gsiIdList;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public Map<String, String> getAdditionalProperties() {
        return additionalProperties;
    }

    public void setAdditionalProperties(Map<String, String> additionalProperties) {
        this.additionalProperties = additionalProperties;
    }

    public Long getLastRunStartTime() {
        return LastRunStartTime;
    }

    public void setLastRunStartTime(Long lastRunStartTime) {
        LastRunStartTime = lastRunStartTime;
    }
}
