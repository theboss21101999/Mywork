package com.nsl.adapter.commons.dto.Integrations.dto;


import java.io.Serializable;
public class RestInboundAdapterDTO implements Serializable {
    private String inputEntityName;
    private Long inputEntityId;
    private String contentType;
    private boolean fileSupport;
    private boolean formData;
    private String headerEntityName;
    private Long headerEntityId;
    private String queryEntityName;
    private Long queryEntityId;

    public RestInboundAdapterDTO() {
    }

    public String getInputEntityName() {
        return inputEntityName;
    }

    public void setInputEntityName(String inputEntityName) {
        this.inputEntityName = inputEntityName;
    }

    public Long getInputEntityId() {
        return inputEntityId;
    }

    public void setInputEntityId(Long inputEntityId) {
        this.inputEntityId = inputEntityId;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public boolean isFileSupport() {
        return fileSupport;
    }

    public void setFileSupport(boolean fileSupport) {
        this.fileSupport = fileSupport;
    }

    public boolean isFormData() {
        return formData;
    }

    public void setFormData(boolean formData) {
        this.formData = formData;
    }

    public String getHeaderEntityName() {
        return headerEntityName;
    }

    public void setHeaderEntityName(String headerEntityName) {
        this.headerEntityName = headerEntityName;
    }

    public Long getHeaderEntityId() {
        return headerEntityId;
    }

    public void setHeaderEntityId(Long headerEntityId) {
        this.headerEntityId = headerEntityId;
    }

    public String getQueryEntityName() {
        return queryEntityName;
    }

    public void setQueryEntityName(String queryEntityName) {
        this.queryEntityName = queryEntityName;
    }

    public Long getQueryEntityId() {
        return queryEntityId;
    }

    public void setQueryEntityId(Long queryEntityId) {
        this.queryEntityId = queryEntityId;
    }
}
