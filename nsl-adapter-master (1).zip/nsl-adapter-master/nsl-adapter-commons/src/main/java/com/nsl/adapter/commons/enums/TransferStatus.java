package com.nsl.adapter.commons.enums;

public enum TransferStatus {
    COMPLETED,
    ACTIVE,
    FAILED,
    CANCELLED,
    PAUSED
}
