package com.nsl.adapter.commons.dto.connections;

import java.util.List;

public class CiscoOauthconnectionDto extends BasicAdapterConnection{

    private String clientId;
    private String clientSecret;
    private List<String> scope;
    private String refreshToken;
    private String applicationName;

    public CiscoOauthconnectionDto() {
    }

    public CiscoOauthconnectionDto(String clientId, String clientSecret, List<String> scope, String refreshToken, String applicationName) {
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.scope = scope;
        this.refreshToken = refreshToken;
        this.applicationName = applicationName;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public List<String> getScope() {
        return scope;
    }

    public void setScope(List<String> scope) {
        this.scope = scope;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }
}
