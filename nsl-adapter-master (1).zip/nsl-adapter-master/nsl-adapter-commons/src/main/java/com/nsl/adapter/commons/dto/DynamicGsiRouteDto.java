package com.nsl.adapter.commons.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DynamicGsiRouteDto {
    Long aimlConnectionId;
    String aimlConnectionName;
    Map<String, ArrayList<GsiDto>> gsiIdMap;
    List<GsiDto> defaultGsi;

    public Long getAimlConnectionId() {
        return aimlConnectionId;
    }

    public void setAimlConnectionId(Long aimlConnectionId) {
        this.aimlConnectionId = aimlConnectionId;
    }

    public String getAimlConnectionName() {
        return aimlConnectionName;
    }

    public void setAimlConnectionName(String aimlConnectionName) {
        this.aimlConnectionName = aimlConnectionName;
    }

    public Map<String, ArrayList<GsiDto>> getGsiIdMap() {
        return gsiIdMap;
    }

    public void setGsiIdMap(Map<String, ArrayList<GsiDto>> gsiIdMap) {
        this.gsiIdMap = gsiIdMap;
    }

    public List<GsiDto> getDefaultGsi() {
        return defaultGsi;
    }

    public void setDefaultGsi(List<GsiDto> defaultGsi) {
        this.defaultGsi = defaultGsi;
    }
}
