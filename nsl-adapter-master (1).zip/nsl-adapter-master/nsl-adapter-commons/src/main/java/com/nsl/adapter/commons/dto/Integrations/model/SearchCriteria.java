package com.nsl.adapter.commons.dto.Integrations.model;

import com.nsl.common.utils.JacksonUtils;

import java.util.List;

public class SearchCriteria {

    String readFromFolder = ImapConstant.DEFAULT_FOLDER;
    String subjectFilter;
    String fromFilter;
    Boolean markAsRead = Boolean.TRUE;

    public String getReadFromFolder() {
        return readFromFolder;
    }

    public void setReadFromFolder(String readFromFolder) {
        this.readFromFolder = readFromFolder;
    }

    public String getSubjectFilter() {
        return subjectFilter;
    }

    public void setSubjectFilter(String subjectFilter) {
        this.subjectFilter = subjectFilter;
    }

    public String getFromFilter() {
        return fromFilter;
    }

    public void setFromFilter(String fromFilter) {
        this.fromFilter = fromFilter;
    }

    public Boolean getMarkAsRead() {
        return markAsRead;
    }

    public void setMarkAsRead(Boolean markAsRead) {
        this.markAsRead = markAsRead;
    }

    public static String buildString(List<SearchCriteria> searchCriteria) {

        if(searchCriteria==null || searchCriteria.isEmpty())
            return "";


        return JacksonUtils.toJson(searchCriteria.get(0));
    }

    public static SearchCriteria buildCriteria(String searchCriteriaString) {

        SearchCriteria searchCriteria = new SearchCriteria();

        if(searchCriteriaString==null || searchCriteriaString.isEmpty())
            return searchCriteria;

        searchCriteria = JacksonUtils.fromJson(searchCriteriaString, SearchCriteria.class);

        return searchCriteria;

    }
}
