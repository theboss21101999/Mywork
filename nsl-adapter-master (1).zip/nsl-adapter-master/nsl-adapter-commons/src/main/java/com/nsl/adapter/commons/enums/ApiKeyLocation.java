package com.nsl.adapter.commons.enums;

public enum ApiKeyLocation {
    QUERY("query"),
    HEADER("header"),
    COOKIE("cookie"),
    PARAM("param");

    private String value;

    private ApiKeyLocation(String value) {
        this.value = value;
    }
    private String getCarrier() {return this.value;}

    public static ApiKeyLocation fromValue(String val) {
        for (ApiKeyLocation at : ApiKeyLocation.values()) {
            if (at.getCarrier().equalsIgnoreCase(val)) {
                return at;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
}
