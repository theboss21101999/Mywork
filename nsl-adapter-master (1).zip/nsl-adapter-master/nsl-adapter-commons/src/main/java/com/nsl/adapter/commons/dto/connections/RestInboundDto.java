package com.nsl.adapter.commons.dto.connections;

import java.util.Map;

public class RestInboundDto {
    private String headerEntityName;
    private String bodyEntityName;
    private String queryEntityName;
    private String outputEntityName;
    private String gsiVersion;
    private Map<String,String> statusMap;
    private boolean syncFlow;
    private boolean formData;
    private String gsiId;
    private String contextualCuId;
    private String contentType;
    private String configEntityRecordId;

    public String getHeaderEntityName() {
        return headerEntityName;
    }

    public void setHeaderEntityName(String headerEntityName) {
        this.headerEntityName = headerEntityName;
    }

    public String getBodyEntityName() {
        return bodyEntityName;
    }

    public void setBodyEntityName(String bodyEntityName) {
        this.bodyEntityName = bodyEntityName;
    }

    public String getQueryEntityName() {
        return queryEntityName;
    }

    public void setQueryEntityName(String queryEntityName) {
        this.queryEntityName = queryEntityName;
    }

    public String getOutputEntityName() {
        return outputEntityName;
    }

    public void setOutputEntityName(String outputEntityName) {
        this.outputEntityName = outputEntityName;
    }

    public String getGsiVersion() {
        return gsiVersion;
    }

    public void setGsiVersion(String gsiVersion) {
        this.gsiVersion = gsiVersion;
    }

    public Map<String, String> getStatusMap() {
        return statusMap;
    }

    public void setStatusMap(Map<String, String> statusMap) {
        this.statusMap = statusMap;
    }

    public boolean isSyncFlow() {
        return syncFlow;
    }

    public void setSyncFlow(boolean syncFlow) {
        this.syncFlow = syncFlow;
    }

    public boolean isFormData() {
        return formData;
    }

    public void setFormData(boolean formData) {
        this.formData = formData;
    }

    public String getGsiId() {
        return gsiId;
    }

    public void setGsiId(String gsiId) {
        this.gsiId = gsiId;
    }

    public String getContextualCuId() {
        return contextualCuId;
    }

    public void setContextualCuId(String contextualCuId) {
        this.contextualCuId = contextualCuId;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getConfigEntityRecordId() {
        return configEntityRecordId;
    }

    public void setConfigEntityRecordId(String configEntityRecordId) {
        this.configEntityRecordId = configEntityRecordId;
    }
}
