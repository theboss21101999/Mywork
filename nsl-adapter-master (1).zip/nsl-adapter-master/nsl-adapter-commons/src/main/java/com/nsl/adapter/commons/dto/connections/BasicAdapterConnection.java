package com.nsl.adapter.commons.dto.connections;

import com.nsl.adapter.commons.enums.ConnectionStatus;

import java.util.HashMap;
import java.util.Map;

public abstract class BasicAdapterConnection {

    protected String connectionName;
    protected Long createdTime;
    protected Long updatedTime;
    protected Map<String, String> metadata = new HashMap<>();
    protected ConnectionStatus connectionStatus = ConnectionStatus.VALID;

    public Map<String, String> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, String> metadata) {
        this.metadata = metadata;
    }

    public ConnectionStatus getConnectionStatus() {
        return connectionStatus;
    }

    public void setConnectionStatus(ConnectionStatus connectionStatus) {
        this.connectionStatus = connectionStatus;
    }

    public String getConnectionName() {
        return connectionName;
    }

    public void setConnectionName(String connectionName) {
        this.connectionName = connectionName;
    }

    public Long getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Long createdTime) {
        this.createdTime = createdTime;
    }

    public Long getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Long updatedTime) {
        this.updatedTime = updatedTime;
    }
}
