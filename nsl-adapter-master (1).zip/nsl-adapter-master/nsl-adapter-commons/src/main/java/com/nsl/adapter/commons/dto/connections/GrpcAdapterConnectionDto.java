package com.nsl.adapter.commons.dto.connections;

public class GrpcAdapterConnectionDto extends BasicAdapterConnection {
    private String host;
    private String port;
    private GrpcCredential authentication;

    public GrpcAdapterConnectionDto() {
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public GrpcCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(GrpcCredential authentication) {
        this.authentication = authentication;
    }
}
