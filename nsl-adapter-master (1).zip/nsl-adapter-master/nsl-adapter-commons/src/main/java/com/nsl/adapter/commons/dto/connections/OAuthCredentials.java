package com.nsl.adapter.commons.dto.connections;

import com.nsl.adapter.commons.enums.ApiKeyLocation;

import java.util.List;

public class OAuthCredentials {
    private String accessTokenUri;
    private String refreshToken;
    private String authorizationUri;
    private OAuthGrantType grantType;
    private String clientId;
    private String clientSecret;
    private List<String> scope;
    private ApiKeyLocation location;

    public OAuthCredentials() {
    }

    public OAuthCredentials(String accessTokenUri, String refreshToken, String authorizationUri, OAuthGrantType grantType, String clientId, ApiKeyLocation location, List<String> scope, String clientSecret) {
        this.accessTokenUri = accessTokenUri;
        this.refreshToken = refreshToken;
        this.authorizationUri = authorizationUri;
        this.grantType = grantType;
        this.clientId = clientId;
        this.location = location;
        this.scope = scope;
        this.clientSecret = clientSecret;
    }

    public String getAccessTokenUri() {
        return accessTokenUri;
    }

    public void setAccessTokenUri(String accessTokenUri) {
        this.accessTokenUri = accessTokenUri;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getAuthorizationUri() {
        return authorizationUri;
    }

    public void setAuthorizationUri(String authorizationUri) {
        this.authorizationUri = authorizationUri;
    }

    public OAuthGrantType getGrantType() {
        return grantType;
    }

    public void setGrantType(OAuthGrantType grantType) {
        this.grantType = grantType;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public ApiKeyLocation getLocation() {
        return location;
    }

    public void setLocation(ApiKeyLocation location) {
        this.location = location;
    }

    public List<String> getScope() {
        return scope;
    }

    public void setScope(List<String> scope) {
        this.scope = scope;
    }
}
