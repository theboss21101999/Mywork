package com.nsl.adapter.commons.dto.connections;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RESTCredential {

         private String username;
         private String password;
         private RESTAuthorizationType authorizationType;
         private OAuthCredentials oAuthCredentials;
         private ApiKeyCredentials apiKeyCredentials;
         private HawkCredentials hawkCredentials;

    public RESTCredential() {
    }

    public RESTCredential(String username, String password, RESTAuthorizationType authorizationType, OAuthCredentials oAuthCredentials, ApiKeyCredentials apiKeyCredentials, HawkCredentials hawkCredentials) {
        this.username = username;
        this.password = password;
        this.authorizationType = authorizationType;
        this.oAuthCredentials = oAuthCredentials;
        this.apiKeyCredentials = apiKeyCredentials;
        this.hawkCredentials = hawkCredentials;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public RESTAuthorizationType getAuthorizationType() {
        return authorizationType;
    }

    public void setAuthorizationType(RESTAuthorizationType authorizationType) {
        this.authorizationType = authorizationType;
    }
    @JsonProperty("oAuthCredentials")
    public OAuthCredentials getOAuthCredentials() {
        return oAuthCredentials;
    }

    public void setOAuthCredentials(OAuthCredentials oAuthCredentials) {
        this.oAuthCredentials = oAuthCredentials;
    }

    public ApiKeyCredentials getApiKeyCredentials() {
        return apiKeyCredentials;
    }

    public void setApiKeyCredentials(ApiKeyCredentials apiKeyCredentials) {
        this.apiKeyCredentials = apiKeyCredentials;
    }

    public HawkCredentials getHawkCredentials() {
        return hawkCredentials;
    }

    public void setHawkCredentials(HawkCredentials hawkCredentials) {
        this.hawkCredentials = hawkCredentials;
    }
}
