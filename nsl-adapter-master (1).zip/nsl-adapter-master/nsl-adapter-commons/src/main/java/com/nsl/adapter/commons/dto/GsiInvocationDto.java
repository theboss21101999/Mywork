package com.nsl.adapter.commons.dto;

import java.util.HashMap;
import java.util.Map;

public class GsiInvocationDto{

    private Long gsiId;
    private Map<String, String> physicalLayer = new HashMap<>();
    private Map<String, String> informationLayer = new HashMap<>();

    public GsiInvocationDto() {
    }

    public GsiInvocationDto(Long gsiId, Map<String, String> physicalLayer, Map<String, String> informationLayer) {
        this.gsiId = gsiId;
        this.physicalLayer = physicalLayer;
        this.informationLayer = informationLayer;
    }

    public Long getGsiId() {
        return gsiId;
    }

    public void setGsiId(Long gsiId) {
        this.gsiId = gsiId;
    }

    public Map<String, String> getPhysicalLayer() {
        return physicalLayer;
    }

    public void setPhysicalLayer(Map<String, String> physicalLayer) {
        this.physicalLayer = physicalLayer;
    }

    public Map<String, String> getInformationLayer() {
        return informationLayer;
    }

    public void setInformationLayer(Map<String, String> informationLayer) {
        this.informationLayer = informationLayer;
    }
}
