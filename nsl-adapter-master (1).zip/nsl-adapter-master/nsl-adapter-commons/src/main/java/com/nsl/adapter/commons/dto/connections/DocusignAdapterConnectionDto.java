package com.nsl.adapter.commons.dto.connections;

import java.util.List;

public class DocusignAdapterConnectionDto extends BasicAdapterConnection{
    String appId;
    String appSecret;
    String refreshToken;
    String encodedKey;
    String accountId;
    String envelopeid;
    List<String> scope;

    public DocusignAdapterConnectionDto() {
    }

    public DocusignAdapterConnectionDto(String appId, String appSecret, String refreshToken, String encodedKey, String accountId, String envelopeid, List<String> scope) {
        this.appId = appId;
        this.appSecret = appSecret;
        this.refreshToken = refreshToken;
        this.encodedKey = encodedKey;
        this.accountId = accountId;
        this.envelopeid = envelopeid;
        this.scope = scope;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getEncodedKey() {
        return encodedKey;
    }

    public void setEncodedKey(String encodedKey) {
        this.encodedKey = encodedKey;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public List<String> getScope() {
        return scope;
    }

    public void setScope(List<String> scope) {
        this.scope = scope;
    }

    public String getEnvelopeid() {
        return envelopeid;
    }

    public void setEnvelopeid(String envelopeid) {
        this.envelopeid = envelopeid;
    }
}
