package com.nsl.adapter.commons.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.dto.ConnectionListDto;
import com.nsl.adapter.commons.dto.PaginatedConnectionsListDto;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.CreateGeneralEntityCUDao;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.dao.SearchCUDAO;
import com.nsl.logical.dto.search.TxnGeneralEntitySearchRequest;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import static com.nsl.adapter.commons.utils.AppConstants.CONNECTION_NAME;

@Service
public class AdapterConnectionServiceV3 {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdapterConnectionServiceV3.class);
    private static final ResponseStatusException GENotFoundResponse = new ResponseStatusException(HttpStatus.
                                                     INTERNAL_SERVER_ERROR , "general entity doesn't exist" , null);

    @Autowired
    GeneralEntityDao generalEntityDao;

    @Autowired
    CreateGeneralEntityCUDao createGeneralEntityCUDao;

    @Autowired
    SearchCUDAO searchCUDAO;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    MessageSource messageSource;

    @Autowired
    SaveBetsService saveBetsService;

    public TxnGeneralEntityRecord saveConnection(String geName, JsonNode connectionDto, AuthenticatedUserDetailsImpl authBean) {

        LOGGER.info("saving" + geName + "connection ..");
        GeneralEntity generalEntity = getGEByName(geName, authBean);


        String searchQuery = "=" + connectionDto.get(CONNECTION_NAME).asText();
        if (!getConnByName(generalEntity, searchQuery,authBean).isEmpty())
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_9", null, Locale.ENGLISH), null);

        List<TxnNslAttribute> attributesList = connectionDataToolsV3.JsonToAttributeList(connectionDto, generalEntity,authBean.getTenantId() ,true);

        TxnGeneralEntityRecord entityRecord = new TxnGeneralEntityRecord();
        entityRecord.setTxnNslAttribute(attributesList);
        List<TxnGeneralEntityRecord> entityRecordList = new ArrayList<>();
        entityRecordList.add(entityRecord);

        return saveEntityRecord(entityRecordList, generalEntity , authBean,"create");
    }

    public TxnGeneralEntityRecord updateConnection(String geName, JsonNode connectionDto, Long connId, AuthenticatedUserDetailsImpl authBean) {

        LOGGER.info("updating" + geName + "connection ..");
        GeneralEntity generalEntity = getGEByName(geName, authBean);

        String searchQuery = "=" + connectionDto.get(CONNECTION_NAME).asText();
        List<TxnGeneralEntityRecord> entityRecords = getConnByName(generalEntity, searchQuery, authBean);
        if (entityRecords.isEmpty())
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,messageSource.getMessage("Paas_Adapter_12", null, Locale.ENGLISH)
                                                                , null);
        TxnGeneralEntityRecord fetchedEntityRecord = entityRecords.get(0);
        if(!Objects.equals(fetchedEntityRecord.getId(), connId))
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,messageSource.getMessage("Paas_Adapter_12", null, Locale.ENGLISH), null);

        List<TxnNslAttribute> attributesList = connectionDataToolsV3.JsonToAttributeList(connectionDto, generalEntity,authBean.getTenantId() ,false);

        TxnGeneralEntityRecord entityRecord = new TxnGeneralEntityRecord();
        entityRecord.setTxnNslAttribute(attributesList);
        entityRecord.setId(connId);
        entityRecord.setGuid(fetchedEntityRecord.getGuid());
        List<TxnGeneralEntityRecord> entityRecordList = new ArrayList<>();
        entityRecordList.add(entityRecord);

        return saveEntityRecord(entityRecordList, generalEntity, authBean,"update");
    }

    public TxnGeneralEntityRecord saveEntityRecord(List<TxnGeneralEntityRecord> entityRecordList,
                                                   GeneralEntity generalEntity, AuthenticatedUserDetailsImpl authBean,String createOrUpdate) {
//        General Entity
        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity(); //General Entity --> Entity Record --> Attributes
        txnGeneralEntity.setTransEntityRecords(entityRecordList);
        txnGeneralEntity.setName(generalEntity.getName());
        txnGeneralEntity.setGeneralEntityID(generalEntity.getId());
//        Saving
        List<TxnGeneralEntity> generalEntityList = new ArrayList<>();
        generalEntityList.add(txnGeneralEntity);
        LOGGER.info("calling dao layer to save connection -> {}",txnGeneralEntity);
        List<TxnGeneralEntity> result = createGeneralEntityCUDao.saveEntities(generalEntityList,null,null,createOrUpdate,false,authBean);
        LOGGER.info("result {}:",result);
        return result.get(0).getTransEntityRecords().get(0);
    }

    public TxnGeneralEntityRecord getConnById(String geName, Long connId, AuthenticatedUserDetailsImpl authBean) {
        TxnGeneralEntitySearchRequest dto1= new TxnGeneralEntitySearchRequest();
        dto1.setGeneralEntity(getGEByName(geName, authBean));
        List<TxnGeneralEntitySearchRequest> generalEntityList = new ArrayList<>();
        generalEntityList.add(dto1);
        List<TxnGeneralEntityRecord> resultList = searchCUDAO.getEntities(generalEntityList, authBean);
        LOGGER.info("fetched {},{} records ",resultList.size(), geName);
        for (TxnGeneralEntityRecord txnGeneralEntityRecord : resultList){
            if (txnGeneralEntityRecord.getId().equals(connId)){
                return txnGeneralEntityRecord;
            }
        }
        return null;

    }

    public List<TxnGeneralEntityRecord> getConnByName(GeneralEntity generalEntity, String searchQuery, AuthenticatedUserDetailsImpl authBean)  {
        List<NslAttribute> attributes = generalEntity.getNslAttributes();
        for(NslAttribute attribute:attributes){
            if(attribute.getName().equalsIgnoreCase("connectionName") && !searchQuery.isEmpty()){
                attribute.setMemberShip(searchQuery);
            }
        }

        TxnGeneralEntitySearchRequest dto1= new TxnGeneralEntitySearchRequest();
        dto1.setGeneralEntity(generalEntity);
        List<TxnGeneralEntitySearchRequest> generalEntityList = new ArrayList<>();
        generalEntityList.add(dto1);
        LOGGER.info("calling searchCuDao -> {}",searchCUDAO.getClass().getName());
        List<TxnGeneralEntityRecord> entityRecords = searchCUDAO.getEntities(generalEntityList, authBean);
        LOGGER.info("found {} records",entityRecords.size());
        return entityRecords;
    }

    public List<TxnGeneralEntityRecord> getRecordsByMap(String geName, Map<String, String> regexMap, AuthenticatedUserDetailsImpl authBean) throws NSLException {
        LOGGER.info("GET total records call.");
        GeneralEntity generalEntity =getGEByName(geName,authBean);
        if (generalEntity==null){
            throw new NSLException(ExceptionCategory.GENERAL_ENTITY,"Config Entity not exist in this tenant.",
                    ExceptionSeverity.BLOCKER);
        }
        if (!regexMap.isEmpty()){
            List<NslAttribute> attributes = generalEntity.getNslAttributes();
            for(NslAttribute attribute:attributes){
                if(regexMap.containsKey(attribute.getName())){
                    attribute.setMemberShip(regexMap.get(attribute.getName()));
                }
            }
        }
        TxnGeneralEntitySearchRequest dto1= new TxnGeneralEntitySearchRequest();
        dto1.setGeneralEntity(generalEntity);
        List<TxnGeneralEntitySearchRequest> generalEntityList = new ArrayList<>();
        generalEntityList.add(dto1);
        return searchCUDAO.getEntities(generalEntityList,authBean);

    }

    public PaginatedConnectionsListDto getConnectionList(Integer pageNumber, Integer pageSize, String geName, String query,AuthenticatedUserDetailsImpl authBean) {

        StringBuilder result = new StringBuilder();
        if (query!=null){
            String[] list = query.split("");
            for (String ch: list)
                result.append("[").append(ch.toUpperCase(Locale.ROOT)).append(ch.toLowerCase(Locale.ROOT)).append("]");
        }

        String searchQuery;
        if (query==null || query.isEmpty())
            searchQuery = "";
        else
            searchQuery = "REGEX.*"+ result +".*";

        GeneralEntity generalEntity = getGEByName(geName, authBean);
        List<TxnGeneralEntityRecord> response = getConnByName(generalEntity, searchQuery, authBean);

        List<TxnGeneralEntityRecord> paginatedList = getSubList(response,pageSize,pageNumber);

        List<ConnectionListDto> connList = new ArrayList<>();
        paginatedList.forEach(x -> {
            ConnectionListDto dto = new ConnectionListDto();
            List<TxnNslAttribute> attributeList = x.getTxnNslAttribute();
            for (TxnNslAttribute attribute : attributeList){
                if (attribute.getName().equals("connectionName")){
                    dto.setConnectionName(attribute.getValues().get(0));
                }
            }
            dto.setConnId(x.getId());
            connList.add(dto);
        });

        PaginatedConnectionsListDto paginatedConnectionsListDto = new PaginatedConnectionsListDto();
        paginatedConnectionsListDto.setConnectionsList(connList);
        paginatedConnectionsListDto.setPageNumber(pageNumber);
        paginatedConnectionsListDto.setPageSize(pageSize);
        paginatedConnectionsListDto.setCurrentPageSize(connList.size());
        paginatedConnectionsListDto.setTotalHits((long) response.size());
        float noOfPages;
        if (connList.isEmpty())
            noOfPages = 0;
        else
            noOfPages = (float) response.size() / pageSize;  //NOSONAR
        paginatedConnectionsListDto.setTotalPages((long) Math.ceil(noOfPages));

        return paginatedConnectionsListDto;
    }

    public List<TxnGeneralEntityRecord> getSubList(List<TxnGeneralEntityRecord> list, int pageSize, int pageNumber){
        List<TxnGeneralEntityRecord> result = new ArrayList<>();
        try {
            int startIndex = (pageNumber-1)*pageSize;
            int currentSize = Math.min(list.size(), pageSize);
            int endIndex = Math.min(list.size(),startIndex+currentSize);
            result = list.subList(startIndex,endIndex);
        }catch (IndexOutOfBoundsException | IllegalArgumentException e){
            LOGGER.info("Exception:"+e);
        }
        return result;
    }

    public GeneralEntity getGEByName(String geName,AuthenticatedUserDetailsImpl authBean){
        try {
            saveBetsService.getEntityByName(geName,authBean);
            GeneralEntity generalEntity = generalEntityDao.findByName(geName, authBean);
            if (generalEntity == null) throw GENotFoundResponse;
            return generalEntity;
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "failed to fetch the entity" , e);
        }
    }

}
