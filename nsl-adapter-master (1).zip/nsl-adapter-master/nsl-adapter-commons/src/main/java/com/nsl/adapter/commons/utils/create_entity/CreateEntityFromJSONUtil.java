package com.nsl.adapter.commons.utils.create_entity;

import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.IRDRUtils;
import com.nsl.dsd.store.models.base.NslDataType;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityAttributeInput;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class CreateEntityFromJSONUtil extends CreateEntityUtil implements CreateEntityFromFile {

    @Autowired
    SaveBetsService saveBetsService;

    @Autowired
    IRDRUtils irdrUtils;

    /**
     * method to convert JSONSchema into NSL_Entity.It Converts File into JSONObject and calls createEntityFromJSON
     * for conversion into Entity
     *
     * @param file Uploaded File
     * @return TenantCUEntityInput
     */
    public TenantCUEntityInput convertFileIntoEntity(MultipartFile file, String entityName,Map<String,Object> PropertyMap) throws NSLException {
        try {
            InputStream CreateEntityConfigStream = file.getInputStream();
            BufferedReader streamReader = new BufferedReader(new InputStreamReader(CreateEntityConfigStream, StandardCharsets.UTF_8));
            StringBuilder responseStrBuilder = new StringBuilder();
            String inputStr;
            while ((inputStr = streamReader.readLine()) != null)
                responseStrBuilder.append(inputStr);

            JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
            return createEntityFromJSON(jsonObject, entityName);
        }catch (NSLException e) {
            throw e;
        }catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"Exception while creating Entity: " +
                    e, ExceptionSeverity.MAJOR, e);
        }
    }

    /*
     *Method to convert JSONObject into NSL_Entity.It parses JOSNObject save it in General Entity

     * @param JsonObject           JSONOBject
     * @return                     TenantCUEntityInput
     */

    private TenantCUEntityInput createEntityFromJSON(JSONObject jsonObject, String entityName) throws NSLException {
        TenantCUEntityInput generalEntity = new TenantCUEntityInput();
        generalEntity.setName(entityName);
        generalEntity.setDisplayName(entityName);
        List<TenantCUEntityAttributeInput> nslAttributeList = new ArrayList<>();
        for (String keyStr : jsonObject.keySet()) {
            Object keyvalue = jsonObject.get(keyStr);
            if (keyvalue != null) {
                String objectType = keyvalue.getClass().toString();
                TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();
                nslAttribute.setName(keyStr);
                nslAttribute.setDisplayName(keyStr);
                if (objectType.equals(AppConstants.JSONOBJECT_CLASS)) {

                    TenantCUEntityInput subentity = createEntityFromJSON((JSONObject) keyvalue, entityName+"_"+keyStr);
                    NslDataType attributeType = getNslDataType(AppConstants.ENTITY);
                    Map<String, String> attributeTypeProperties = new HashMap<>();
                    attributeTypeProperties.put(AppConstants.REFERENCINGTYPE, keyStr);
                    attributeType.setProperties(attributeTypeProperties);

                    nslAttribute.setAttributeType(attributeType);
                    nslAttribute.setGeneralEntity(subentity);
                } else if (objectType.equals(AppConstants.JSONARRAY_CLASS) && !jsonObject.getJSONArray(keyStr).isEmpty()) {

                    JSONArray jsonArray = jsonObject.getJSONArray(keyStr);
                    NslDataType attributeType = getNslDataType(AppConstants.LIST);
                    if (jsonArray.get(0).getClass().toString().equals(AppConstants.JSONOBJECT_CLASS)) {
                        JSONObject objectInArray = jsonArray.getJSONObject(0);
                        TenantCUEntityInput subentity = createEntityFromJSON(objectInArray, entityName+"_"+keyStr);
                        nslAttribute.setGeneralEntity(subentity);


                        /*populate attribute type element*/
                        Map<String, String> properties = new HashMap<>();
                        properties.put(AppConstants.REFERENCINGTYPE, keyStr);
                        attributeType.setProperties(properties);
                        Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                        nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE, getNslDataType(AppConstants.ENTITY));
                        attributeType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);

                    }else {

                        Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                        nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE, getNslDataType(jsonArray.get(0).getClass().toString()));
                        attributeType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);
                        attributeType.setUiElement(getUiElementInfo(jsonArray.get(0).getClass().toString()));

                    }
                    nslAttribute.setAttributeType(attributeType);
                } else {

                    NslDataType attributeType = getNslDataType(keyvalue.getClass().toString());
                    attributeType.setUiElement(getUiElementInfo(keyvalue.getClass().toString()));
                    nslAttribute.setAttributeType(attributeType);
                }
                nslAttributeList.add(nslAttribute);
            }
        }

        generalEntity.setNslAttributes(nslAttributeList);
        generalEntity.setStatus(StatusEnum.DRAFT);
        irdrUtils.setGeIRDR(generalEntity);
        return saveBetsService.saveGeneralEntity(generalEntity);

    }

}
