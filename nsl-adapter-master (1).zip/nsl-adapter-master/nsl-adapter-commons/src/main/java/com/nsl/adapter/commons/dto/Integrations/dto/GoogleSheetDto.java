package com.nsl.adapter.commons.dto.Integrations.dto;

public class GoogleSheetDto {
    private String inputEntityDsdId;
    private String outputEntityDsdId;
    private String operation ;
    private String apiName;
    private String extSolnsType;
    private String dataFormat;
    private String ValueInputOption;
    private String spreadsheetId;
    private String range;
    private String methodName;

    public String getInputEntityDsdId() {
        return inputEntityDsdId;
    }

    public void setInputEntityDsdId(String inputEntityDsdId) {
        this.inputEntityDsdId = inputEntityDsdId;
    }

    public String getOutputEntityDsdId() {
        return outputEntityDsdId;
    }

    public void setOutputEntityDsdId(String outputEntityDsdId) {
        this.outputEntityDsdId = outputEntityDsdId;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getApiName() {
        return apiName;
    }

    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    public String getExtSolnsType() {
        return extSolnsType;
    }

    public void setExtSolnsType(String extSolnsType) {
        this.extSolnsType = extSolnsType;
    }

    public String getDataFormat() {
        return dataFormat;
    }

    public void setDataFormat(String dataFormat) {
        this.dataFormat = dataFormat;
    }

    public String getValueInputOption() {
        return ValueInputOption;
    }

    public void setValueInputOption(String valueInputOption) {
        ValueInputOption = valueInputOption;
    }

    public String getSpreadsheetId() {
        return spreadsheetId;
    }

    public void setSpreadsheetId(String spreadsheetId) {
        this.spreadsheetId = spreadsheetId;
    }

    public String getRange() {
        return range;
    }

    public void setRange(String range) {
        this.range = range;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }
}
