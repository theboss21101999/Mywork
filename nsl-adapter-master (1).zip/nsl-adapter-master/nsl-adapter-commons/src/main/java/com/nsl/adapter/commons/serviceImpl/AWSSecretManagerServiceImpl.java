package com.nsl.adapter.commons.serviceImpl;

import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.model.*;
import com.nsl.adapter.commons.service.AWSSecretManagerService;
import com.nsl.logical.dao.SecretManagerDao;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.exception.SecretExistsException;
import com.nsl.logical.exception.SecretNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class AWSSecretManagerServiceImpl implements AWSSecretManagerService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(AWSSecretManagerServiceImpl.class);


    @Autowired
    SecretManagerDao secretManagerDao;

    @Override
    public String createNewSecret(String secretName, String secretValue) throws NSLException {
        try {

            LOGGER.info("saving a secret with name: "+ secretName);

            return secretManagerDao.saveSecret(secretName, secretValue);

        } catch (SecretExistsException e) {
            LOGGER.error("AWS Exception in secret creation : ", e);
            throw new NSLException(ErrorType.INTERNAL_SERVER, ExceptionCategory.PROCESS,e.getLocalizedMessage(),
                    ExceptionSeverity.MAJOR);
        }catch (NSLException e){
            LOGGER.error("Exception in secret creation : ", e);
            throw e;
        }
    }

    @Override
    public String updateSecret(String secretName, String secretValue) throws NSLException {
        try {

            LOGGER.info("updating a secret with name: "+ secretName);
            return secretManagerDao.updateSecret(secretName, secretValue);
        } catch (SecretNotFoundException e) {
            LOGGER.error("Exception in secret update : ", e);
            return createNewSecret(secretName,secretValue);
        }catch (NSLException e){
            LOGGER.error("Exception in secret update : ", e);
            throw e;
        }
    }

    @Override
    public boolean checkForSecret(String secretName) throws NSLException {

        try {
            LOGGER.info("listing secrets with name "+ secretName);
            return secretManagerDao.checkForSecret(secretName);
        } catch (NSLException e) {
            LOGGER.error("Exception while checking the secret existance : ", e);
            throw e;
        }
    }

    @Override
    public String getSecret(String secretName) throws NSLException {
        try {
            LOGGER.info("fetching a secret with name: "+ secretName);
            return secretManagerDao.getSecret(secretName);
        } catch (SecretNotFoundException e) {
            LOGGER.error("Exception in aws secret Fetching : ", e);
            throw new NSLException(ErrorType.INTERNAL_SERVER, ExceptionCategory.PROCESS,
                    e.getMessage(), ExceptionSeverity.MAJOR);
        }catch (NSLException e) {
            LOGGER.error("Exception while checking the secret existance : ", e);
            throw e;
        }
    }


}
 
