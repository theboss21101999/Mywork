package com.nsl.adapter.commons.dto.Integrations.dto;

public class MQIntegrationDTO {
    private String inputEntityDsdId;
    private String outputEntityDsdId;
    private String type;
    private String name;
    private String operation;
    private String messageType;
    private String extSolnsType;

    public MQIntegrationDTO() {
    }

    public String getInputEntityDsdId() {
        return inputEntityDsdId;
    }

    public void setInputEntityDsdId(String inputEntityDsdId) {
        this.inputEntityDsdId = inputEntityDsdId;
    }

    public String getOutputEntityDsdId() {
        return outputEntityDsdId;
    }

    public void setOutputEntityDsdId(String outputEntityDsdId) {
        this.outputEntityDsdId = outputEntityDsdId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getExtSolnsType() {
        return extSolnsType;
    }

    public void setExtSolnsType(String extSolnsType) {
        this.extSolnsType = extSolnsType;
    }
}
