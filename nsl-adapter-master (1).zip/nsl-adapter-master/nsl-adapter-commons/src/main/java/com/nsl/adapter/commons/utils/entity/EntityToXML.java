package com.nsl.adapter.commons.utils.entity;


import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EntityToXML {

    private static final Logger LOGGER = LoggerFactory.getLogger(EntityToXML.class);

    public static ByteArrayOutputStream getXml(TxnGeneralEntity txnEntity, GeneralEntity inputGE) throws ParserConfigurationException,
            TransformerException {

        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        System.setProperty("javax.xml.transform.TransformerFactory","com.sun.org.apache.xalan.internal.xsltc.trax.TransformerFactoryImpl");
        if (LOGGER.isDebugEnabled()) LOGGER.debug(txnEntity.toString());
        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document document = documentBuilder.newDocument();
        convertToXml(txnEntity,inputGE, document).forEach(element -> document.appendChild(element));
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        transformerFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        transformerFactory.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource domSource = new DOMSource(document);
        StreamResult streamResult = new StreamResult(baos);

        transformer.transform(domSource, streamResult);
        return baos;

    }

    private static List<Element> convertToXml(TxnGeneralEntity txnEntity,GeneralEntity inputGE, Document document) {
        List<Element> elementList = new ArrayList<>();
        List<TxnGeneralEntityRecord> entityRecords = txnEntity.getTransEntityRecords();

        HashMap<String, NslAttribute> attributeMap = new HashMap<>();
        inputGE.getNslAttributes().forEach(attribute -> attributeMap.put(attribute.getName(),attribute));


        entityRecords.forEach(record -> {

            Element element = document.createElement(inputGE.getDisplayName());
            elementList.add(element);
            record.getTxnNslAttribute().forEach(attr -> {

                NslAttribute nslAttribute = attributeMap.get(attr.getName());
                String displayName = nslAttribute.getDisplayName();

                boolean isAttribute = displayName.startsWith("@");

                TxnGeneralEntity ge = attr.getTxnGeneralEntity();
                if (ge != null) {
                    convertToXml(ge,nslAttribute.getGeneralEntity(),document).forEach(elem -> element.appendChild(elem));
                } else {
                    List<String> valueList = attr.getValues();
                    if (valueList != null && !valueList.isEmpty()) {
                        for (Object value : valueList) {

                            if (displayName.equals("#text")){
                                element.setTextContent(value.toString());
                            }else if (isAttribute) {
                                Attr attr1 = document.createAttribute(displayName.substring(1));
                                attr1.setTextContent(value.toString());
                                element.setAttributeNode(attr1);
                            }else {
                                Element child = document.createElement(displayName);
                                child.setTextContent(value.toString());
                                element.appendChild(child);
                            }

                        }
                    }
                }
            });
        });
        return elementList;
    }

}




// Currently not using
    /*
    public TxnGeneralEntity convertXMLToTxnEntity(GeneralEntity generalEntity , MultipartFile file) {
        try {
            String xmlString = new String(file.getBytes(), StandardCharsets.UTF_8);
            xmlString = xmlString.replaceAll("\n", "").replaceAll("(?:>)(\\s*)<", "><");
            logger.error(xmlString);
            return convertXMLToTxnEntity(generalEntity,
                    new ByteArrayInputStream(xmlString.getBytes(StandardCharsets.UTF_8)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public TxnGeneralEntity convertXMLToTxnEntity(GeneralEntity generalEntity , File file) {
        try {
            InputStream input = new FileInputStream(file);
            return convertXMLToTxnEntity(generalEntity,input);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }*/

   /* public TxnGeneralEntity convertXMLToTxnEntity(GeneralEntity generalEntity, InputStream input) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            DocumentBuilder db = dbf.newDocumentBuilder();  //NOSONAR
            Document doc = db.parse(input);
           *//* SAXReader xmlReader = new SAXReader();
            xmlReader.setFeature("http://apache.org/xml/features/disallow-doctype-decl", Boolean.TRUE);
            Document doc = (Document) xmlReader.read(input);*//*
            return convertXMLToTxnEntity(generalEntity, doc);
        } catch (SAXException  | NSLException | ParserConfigurationException | IOException e) {
            LOGGER.error("error while converting to xml : ", e);
        }
        return null;
    }

    public TxnGeneralEntity convertXMLToTxnEntity(GeneralEntity generalEntity, Document doc) throws NSLException {
        Element element = doc.getDocumentElement();
        HashMap<String, Object> hm = new HashMap<>();
        hm.put(element.getNodeName(), elementToTxnRecord(element));

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("element.getNodeName(): {} ", element.getNodeName());
            LOGGER.debug("hashmap generated from xmlfile {}", hm);
        }
        if (generalEntity == null || hm.get(element.getNodeName()) == null)
            LOGGER.warn("No xml schema provided. Proceeding without schema.");
        else if (hm.get(element.getNodeName()) instanceof Map)
            isValidDocument(generalEntity, (Map<String, Object>) hm.get(element.getNodeName()));
        else
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "incompatible xml file ", ExceptionSeverity.BLOCKER);

        TxnGeneralEntity entity = convertMapToObject(hm, true, generalEntity);
        LOGGER.info("Converted Entity::::: {}", entity);
        return entity;
    }

    public void isValidDocument(GeneralEntity generalEntity, Map<String, Object> hm) throws NSLException {
        for (Map.Entry<String, Object> keys : hm.entrySet()) {
            boolean keyMatch = false;
            if (LOGGER.isDebugEnabled()) LOGGER.debug("KEY: {}", keys.getKey());
            for (NslAttribute nslAttr : generalEntity.getNslAttributes()) {
                if (LOGGER.isDebugEnabled()) LOGGER.debug("NSL Attr name: {}", nslAttr.getName());
                if (nslAttr.getName().equals(keys.getKey())) {
                    keyMatch = true;
                    Object value = keys.getValue();
                    if (LOGGER.isDebugEnabled()) LOGGER.debug("Value class name:{}", value.getClass().getName());
                    if (value instanceof List) {
                        if (nslAttr.getAttributeType().getType() != DataType.LIST) {
                            keyMatch = false;
                            break;
                        }
                        for (Object item : (List) value) {
                            if (nslAttr.getGeneralEntity() != null)
                                isValidDocument(nslAttr.getGeneralEntity(), (Map<String, Object>) item);
                        }
                    } else if (value instanceof HashMap) {
                        if (nslAttr.getGeneralEntity() == null ||
                                (nslAttr.getAttributeType().getType() != DataType.ENTITY &&
                                        nslAttr.getAttributeType().getType() != (DataType.LIST))) {
                            keyMatch = false;
                            break;
                        }
                        isValidDocument(nslAttr.getGeneralEntity(), (Map<String, Object>) value);
                    }
                    break;
                }
            }
            if (!keyMatch)
                throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                        "invalid document ", ExceptionSeverity.BLOCKER);
        }
    }

    private static Object elementToTxnRecord(Node node) {
        HashMap<String, Object> hm = new HashMap<>();
        Object returnType = hm;
        if (node.hasChildNodes()) {
            NodeList nodeList = node.getChildNodes();
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node attr = nodeList.item(i);
                if (attr.getNodeType() == Node.ELEMENT_NODE) {
                    String nodeName = attr.getNodeName();
                    if (hm.containsKey(nodeName)) {
                        List<Object> list = new ArrayList<>();
                        if (hm.get(nodeName) instanceof List)
                            list = (List<Object>) hm.get(nodeName);
                        else
                            list.add(hm.get(nodeName));
                        Object childObject = elementToTxnRecord(attr);
                        list.add(childObject);
                        hm.put(nodeName, list);
                    } else {
                        Object childObject = elementToTxnRecord(attr);
                        hm.put(nodeName, childObject);
                    }
                } else if (attr.getNodeType() == Node.TEXT_NODE)
                    return attr.getTextContent().trim();
            }
        }
        return returnType;
    }

    private TxnGeneralEntity convertMapToObject(HashMap<String, Object> hm, boolean isRoot, GeneralEntity generalEntity) {
        TxnGeneralEntity entity = new TxnGeneralEntity();
        entity.setTransEntityRecords(new ArrayList<>());

        for (Map.Entry<String, Object> entry : hm.entrySet()) {
            Object node = entry.getValue();
            if (isRoot) {
                entity.setName(entry.getKey());
                entity.setGeneralEntityID(generalEntity.getId());
            }
            if (node instanceof HashMap) {
                TxnGeneralEntityRecord record = new TxnGeneralEntityRecord();
                record.setTxnNslAttribute(new ArrayList<>());
                entity.getTransEntityRecords().add(record);
                convertMapToObject((Map) node, record);
            }
        }
        return entity;
    }

    private static void convertMapToObject(Map<String, Object> hm, TxnGeneralEntityRecord record) {
        hm.forEach((k, v) -> {
            TxnNslAttribute attribute = new TxnNslAttribute();
            String attributeName = k;
            attribute.setName(attributeName);
            record.getTxnNslAttribute().add(attribute);
            if (v instanceof HashMap) {
                TxnGeneralEntity childEntity = new TxnGeneralEntity();
                attribute.setTxnGeneralEntity(childEntity);
                childEntity.setName(attributeName);
                childEntity.setTransEntityRecords(new ArrayList<>());
                TxnGeneralEntityRecord childRecord = new TxnGeneralEntityRecord();
                childRecord.setTxnNslAttribute(new ArrayList<>());
                childEntity.getTransEntityRecords().add(childRecord);
                convertMapToObject((HashMap) v, childRecord);
            } else if (v instanceof List && ((ArrayList) v).get(0) instanceof HashMap) {
                TxnGeneralEntity childEntity = new TxnGeneralEntity();
                attribute.setTxnGeneralEntity(childEntity);
                childEntity.setName(k);
                childEntity.setTransEntityRecords(new ArrayList<>());
                for (Object item : (List) v) {
                    TxnGeneralEntityRecord childRecord = new TxnGeneralEntityRecord();
                    childRecord.setTxnNslAttribute(new ArrayList<>());
                    childEntity.getTransEntityRecords().add(childRecord);
                    if (item instanceof HashMap) {
                        convertMapToObject((HashMap) item, childRecord);
                    }
                }
            } else {
                if (v instanceof List) {
                    attribute.setValues((List<String>) v);
                } else {
                    attribute.setValues(Collections.singletonList(v.toString()));
                }
            }
        });
    }
*/

    /*public static boolean validateXMLSchema(String xsdPath, String xmlPath){
        try {
            SchemaFactory factory =
                    SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = factory.newSchema(new File(xsdPath));
            Validator validator = schema.newValidator();
            validator.validate(new StreamSource(new File(xmlPath)));
        } catch (IOException e){
            System.out.println("Exception: "+e.getMessage());
            return false;
        }catch(SAXException e1){
            System.out.println("SAX Exception: "+e1.getMessage());
            return false;
        }

        return true;

    }*/
