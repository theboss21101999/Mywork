package com.nsl.adapter.commons.enums;

public enum ConnectionsType {

    REST ("NSL_Rest_Connection"),
    SFTP ("NSL_SFTP_Connection"),
    S3 ("NSL_S3_Connection"),
    Google ("NSL_Google_Connection"),
    SMTP ("NSL_SMTP_Connection"),
    ZOOM ("NSL_Zoom_Connection"),
    DB ("NSL_DB_Connection"),
    Cisco ("NSL_Webex_Connection"),
    IMAP ("NSL_Imap_Connection"),
    POP3 ("NSL_POP3_Connection"),
    Kafka ("NSL_Kafka_Connection"),
    Graph ("NSL_Graph_Connection"),
    AIML("NSL_AIML_Connection"),
    MQTT("NSL_Mqtt_Connection"),
    FACEBOOK("NSL_Facebook_Connection"),
    JIRA("NSL_Jira_Connection"),
    SES ("NSL_SES_Connection"),
    SOAP("NSL_SOAP_Connection"),
    ActiveMQ("NSL_Activemq_Connection"),
    IBMMQ("NSL_Ibmmq_Connection"),
    RabbitMQ("NSL_Rabbitmq_Connection"),
    AS2("NSL_AS2_Connection"),
    OPENAPI("NSL_OPENAPI_Connection"),
    GRAPHQL("NSL_GRAPHQL_Connection"),
    ADOBESIGN(null),
    DOCUSIGN(null),

    LINKEDIN(null),
    FHIR(null),
    TWITTER(null),
    GRPC(null),
    FTP(null),
    JDBC("NSL_JDBC_Connection");

    ConnectionsType(String rest) { this.entityName = rest; }

    public String getEntityName() { return entityName; }
    
    private String entityName;
}
