package com.nsl.adapter.commons.utils.create_entity;

import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.exception.NSLException;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;


public interface CreateEntityFromFile {

    TenantCUEntityInput convertFileIntoEntity(MultipartFile file, String entityName, Map<String,Object> PropertyMap) throws NSLException;
}
