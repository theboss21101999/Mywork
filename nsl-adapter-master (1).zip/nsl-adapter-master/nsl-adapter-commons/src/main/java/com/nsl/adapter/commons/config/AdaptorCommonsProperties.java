package com.nsl.adapter.commons.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import java.util.Map;

@Configuration
@ConfigurationProperties
public class AdaptorCommonsProperties {

    @Value("${app.adapter.redis.cache.enabled:false}")
    private boolean cacheEnabled;

    @Value("${app.adapter.secret.enabled:false}")
    private boolean secretEnabled;

    private Map<String, String> app;

    public void setApp(Map<String, String> app) {
        this.app = app;
    }

    public String getAppDsdSingleFileUploadUrl() {
        return app.get("dsd-files-store-url-single");
    }

    public String getAppDsdMultiFilesUploadUrl() {
        return app.get("dsd-files-store-url-multi");
    }

    public String getEnvKey() {
        return app.get("EnvKey");
    }
    public String getlongDrawnUrl() {
        return app.get("longdrawn.url");
    }
    public long getlongDrawnTime() {
        return Long.parseLong(app.get("longdrawn.time"));
    }

    public boolean getCacheEnabled(){
        return cacheEnabled;
    }

    public Boolean getSecretEnabled() {
        return secretEnabled;
    }

    public String getAimlDynamicUrl(){
        return app.get("aiml.dynamic.url");
    }
    public String getEnvUrl() {return app.get("env.url");}
    public String getFacebookS3Region() {
        return app.get("facebook.s3.region");
    }
    public String getFacebookS3AccessKey() {
        return app.get("facebook.s3.access.key");
    }

    public String getFacebookS3SecretKey() {
        return app.get("facebook.s3.secret.key");
    }

    public String getFacebookS3BucketName() {
        return app.get("facebook.s3.bucket.name");
    }
    public String getwitelistUrls(){
        return  app.get("url.WhiteListUrl");
    }
    public String getblacklistUrls(){
        return  app.get("url.BlackListUrl");
    }



}
