package com.nsl.adapter.commons.config;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.model.*;
import com.nsl.adapter.commons.models.LargeFileDto;
import com.nsl.adapter.commons.utils.AppConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;

@Component
public class LargeFileTableCreator {

    private static final Logger LOGGER = LoggerFactory.getLogger(LargeFileTableCreator.class);

    @Autowired
    private DynamoDBMapper dynamoDBMapper;

    @Autowired
    private AmazonDynamoDB amazonDynamoDB;

    @Autowired
    DynamoDB dynamoDB;

    @Value("${app.dynamo.table.name.prefix:null}")
    private String tableNamePrefix;

    @Value("${app.dynamo.auto.create.tables:false}")
    private boolean createTable;

    @PostConstruct
    public void init() {
        if (createTable) {
            try {
                DescribeTableResult tableDescription = amazonDynamoDB.describeTable(tableNamePrefix.concat("_").concat(AppConstants.LARGE_FILE_DELIVERY_TABLE_NAME));
                LOGGER.info(tableDescription.toString());
            } catch (ResourceNotFoundException e) {

                LOGGER.info("Creating Table : {}", tableNamePrefix.concat("_").concat(AppConstants.LARGE_FILE_DELIVERY_TABLE_NAME));
                CreateTableRequest tableRequest = dynamoDBMapper.generateCreateTableRequest(LargeFileDto.class);
                tableRequest.setProvisionedThroughput(new ProvisionedThroughput(1L, 1L));
                LocalSecondaryIndex secondaryIndex = new LocalSecondaryIndex()
                        .withIndexName("TransferStatusIndex")
                        .withKeySchema(new KeySchemaElement("parentId", KeyType.HASH))
                        .withKeySchema(new KeySchemaElement("transferStatus", KeyType.RANGE))
                        .withProjection(new Projection().withProjectionType(ProjectionType.ALL));

                ArrayList<LocalSecondaryIndex> indexes = new ArrayList<>();
                indexes.add(secondaryIndex);
                tableRequest.setLocalSecondaryIndexes(indexes);
                amazonDynamoDB.createTable(tableRequest);
                LOGGER.info("Successfully Created Table : {}", tableNamePrefix.concat("_").concat(AppConstants.LARGE_FILE_DELIVERY_TABLE_NAME));
            }
        }
    }
}
