package com.nsl.adapter.commons.dto;

import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;

import java.util.List;

public class PaginatedChangeUnit {

    List<TenantChangeUnitInput> data;
    Integer page;
    Integer limit;
    Long totalPages;
    Long totalResults;

    public List<TenantChangeUnitInput> getData() {
        return data;
    }

    public void setData(List<TenantChangeUnitInput> data) {
        this.data = data;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Long getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(Long totalPages) {
        this.totalPages = totalPages;
    }

    public Long getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(Long totalResults) {
        this.totalResults = totalResults;
    }
}
