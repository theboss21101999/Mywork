package com.nsl.adapter.commons.dto.connections;

public class GrpcCredential {
    private GrpcAuthType authType;
    private NegotiationType negotiationType;
    // certificate file
    private String keyCertChainResource;
    // key file
    private String keyResource;
    private String serviceAccountResource;
    private JWTAlgorithm jwtAlgorithm;
    private String jwtSecret;

    public NegotiationType getNegotiationType() {
        return negotiationType;
    }

    public void setNegotiationType(NegotiationType negotiationType) {
        this.negotiationType = negotiationType;
    }

    public String getKeyCertChainResource() {
        return keyCertChainResource;
    }

    public void setKeyCertChainResource(String keyCertChainResource) {
        this.keyCertChainResource = keyCertChainResource;
    }

    public String getKeyResource() {
        return keyResource;
    }

    public void setKeyResource(String keyResource) {
        this.keyResource = keyResource;
    }

    public String getServiceAccountResource() {
        return serviceAccountResource;
    }

    public void setServiceAccountResource(String serviceAccountResource) {
        this.serviceAccountResource = serviceAccountResource;
    }

    public JWTAlgorithm getJwtAlgorithm() {
        return jwtAlgorithm;
    }

    public void setJwtAlgorithm(JWTAlgorithm jwtAlgorithm) {
        this.jwtAlgorithm = jwtAlgorithm;
    }

    public String getJwtSecret() {
        return jwtSecret;
    }

    public void setJwtSecret(String jwtSecret) {
        this.jwtSecret = jwtSecret;
    }

    public GrpcAuthType getAuthType() {
        return authType;
    }

    public void setAuthType(GrpcAuthType authType) {
        this.authType = authType;
    }
}
