package com.nsl.adapter.commons.utils.create_entity;

import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.IRDRUtils;
import com.nsl.dsd.store.models.base.NslDataType;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityAttributeInput;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

/** Author @Kankatala Satya Sriram*/
@Service
public class CreateEntityFromXML extends CreateEntityUtil implements CreateEntityFromFile {

    @Autowired
    SaveBetsService saveBetsService;

    @Autowired
    IRDRUtils irdrUtils;

    public TenantCUEntityInput convertFileIntoEntity(MultipartFile file, String entityName,Map<String,Object> PropertyMap) throws NSLException {
        try {
            InputStream inputStream = file.getInputStream();
            String data = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))
                    .lines().collect(Collectors.joining("\n"));

            /**removing extra spaces,new lines and tab spaces */
            String cleanString = data.replaceAll(AppConstants.XMLRegex, "");

            DocumentBuilderFactory instance = DocumentBuilderFactory.newInstance(); //NOSONAR
            instance.setNamespaceAware(true);
            DocumentBuilder documentBuilder = instance.newDocumentBuilder(); //NOSONAR
            Document doc = documentBuilder.parse(new ByteArrayInputStream(cleanString.getBytes(StandardCharsets.UTF_8))); //NOSONAR

            return createEntityFromXML(doc.getDocumentElement(), entityName);
        } catch (NSLException e) {
            throw e;
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "Exception while creating Entity: " +
                    e, ExceptionSeverity.MAJOR, e);
        }
    }

    /**
     *Method to convert XMLDocument into NSL_Entity.It parses XMLNode and save it in General Entity

     * @param element          XML Node
     * @return                 TenantCUEntityInput
     */

    private TenantCUEntityInput createEntityFromXML(Node element, String entityName) throws NSLException {
        TenantCUEntityInput generalEntity = new TenantCUEntityInput();
        generalEntity.setName(entityName);
        generalEntity.setDisplayName(element.getNodeName());
        List<TenantCUEntityAttributeInput> nslAttributeList = new ArrayList<>();

        HashMap<String , LinkedList<Node>> elementsMap = new HashMap<>();

        /** adding all the child elements to a map for handling multivalued elements.
         * iterate over the ma for populating the NSL attributes. in case of namespacing replacing the
         * ':' with '_' in the name and maintaining the actual name through displayName*/

        NodeList childElements = element.getChildNodes();
        for (int i=0;i<childElements.getLength();i++){
            String childName = childElements.item(i).getNodeName();
            if (elementsMap.containsKey(childName))
                elementsMap.get(childName).add(childElements.item(i));
            else
                elementsMap.put(childName,new LinkedList<>(List.of(childElements.item(i))));
        }

        for (Map.Entry<String,LinkedList<Node>> map: elementsMap.entrySet()) {

            TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();

            String attrName = map.getKey();
            String name;
            if(attrName.contains(":"))
                name = attrName.replace(":","_");
            else
                name = attrName;

            nslAttribute.setName(name);
            nslAttribute.setDisplayName(attrName);

            LinkedList<Node> childs = map.getValue();

            Node child = childs.get(0);

            if (child.getNodeType() == Node.COMMENT_NODE)
                continue;

            HashMap<String,String> attributeProperties= new HashMap<>();
            attributeProperties.put("XML",child.getLocalName()+":"+child.getNamespaceURI());
            nslAttribute.setNslAttributeProperties(attributeProperties);

            if (childs.size() > 1){

                NslDataType attributeType = getNslDataType(AppConstants.LIST);
                if (child.getFirstChild().getNodeType() == Node.TEXT_NODE && child.getAttributes().getLength()==0){
                    String value = child.getFirstChild().getTextContent();
                    Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                    nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE, getNslDataType(value.getClass().toString()));
                    attributeType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);
                    attributeType.setUiElement(getUiElementInfo(value.getClass().toString()));
                }else {
                    TenantCUEntityInput subEntity;
                    if (child.getFirstChild().getNodeType() == Node.TEXT_NODE)
                        subEntity = createEntityFromXML2(child, entityName + "_" + name);
                    else
                        subEntity = createEntityFromXML(child, entityName + "_" + name);
                    nslAttribute.setGeneralEntity(subEntity);

                    Map<String, String> properties = new HashMap<>();
                    properties.put(AppConstants.REFERENCINGTYPE, name);
                    attributeType.setProperties(properties);
                    Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                    nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE, getNslDataType(AppConstants.ENTITY));
                    attributeType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);
                }
                nslAttribute.setAttributeType(attributeType);
            }else if (child.getFirstChild().getNodeType() == Node.TEXT_NODE  && child.getAttributes().getLength()==0){

                String value = child.getFirstChild().getTextContent();
                NslDataType attributeType = getNslDataType(value.getClass().toString());
                attributeType.setUiElement(getUiElementInfo(value.getClass().toString()));
                nslAttribute.setAttributeType(attributeType);
            }else{

                TenantCUEntityInput subEntity;
                if (child.getFirstChild().getNodeType() == Node.TEXT_NODE)
                    subEntity = createEntityFromXML2(child, entityName + "_" + name);
                else
                    subEntity = createEntityFromXML(child, entityName + "_" + name);

                NslDataType attributeType = getNslDataType(AppConstants.ENTITY);
                Map<String, String> properties = new HashMap<>();
                properties.put(AppConstants.REFERENCINGTYPE, name);
                attributeType.setProperties(properties);
                nslAttribute.setAttributeType(attributeType);
                nslAttribute.setGeneralEntity(subEntity);
            }

            nslAttributeList.add(nslAttribute);
        }


        /** Adding xml attributes to the entity. '@' was being added to the display name of the attribute to
         *  identity it as an xml attribute from child element*/
        NamedNodeMap attributes = element.getAttributes();
        for (int i=0;i<attributes.getLength();i++) {

            TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();
            Node child =attributes.item(i);
            String attrName = child.getNodeName();

            String name;
            if(attrName.contains(":"))
                name = attrName.replace(":","_");
            else
                name = attrName;

            nslAttribute.setName(name);
            nslAttribute.setDisplayName("@"+attrName);

            HashMap<String,String> attributeProperties= new HashMap<>();
            attributeProperties.put("XML",child.getLocalName()+":"+child.getNamespaceURI());
            nslAttribute.setNslAttributeProperties(attributeProperties);

            String value = child.getFirstChild().getTextContent();
            NslDataType attributeType = getNslDataType(value.getClass().toString());
            attributeType.setUiElement(getUiElementInfo(value.getClass().toString()));
            nslAttribute.setAttributeType(attributeType);

            nslAttributeList.add(nslAttribute);
        }

        generalEntity.setNslAttributes(nslAttributeList);
        generalEntity.setStatus(StatusEnum.DRAFT);
        irdrUtils.setGeIRDR(generalEntity);
        return saveBetsService.saveGeneralEntity(generalEntity);

    }

    private TenantCUEntityInput createEntityFromXML2(Node element, String entityName) {
        TenantCUEntityInput generalEntity = new TenantCUEntityInput();
        generalEntity.setName(entityName);
        generalEntity.setDisplayName(element.getNodeName());
        List<TenantCUEntityAttributeInput> nslAttributeList = new ArrayList<>();


        NamedNodeMap attributes = element.getAttributes();
        for (int i=0;i<attributes.getLength();i++) {
            TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();
            Node child =attributes.item(i);
            String attrName = child.getNodeName();

            String name;
            if(attrName.contains(":"))
                name = attrName.replace(":","_");
            else
                name = attrName;

            nslAttribute.setName(name);
            nslAttribute.setDisplayName("@"+attrName);

            HashMap<String,String> attributeProperties= new HashMap<>();
            attributeProperties.put("XML",child.getLocalName()+":"+child.getNamespaceURI());
            nslAttribute.setNslAttributeProperties(attributeProperties);

            String value = child.getFirstChild().getTextContent();
            NslDataType attributeType = getNslDataType(value.getClass().toString());
            attributeType.setUiElement(getUiElementInfo(value.getClass().toString()));
            nslAttribute.setAttributeType(attributeType);

            nslAttributeList.add(nslAttribute);
        }

        TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();

        String attrName = element.getNodeName().replace(":","_")+"_"+"text";
        nslAttribute.setName(attrName);
        nslAttribute.setDisplayName("#text");

        HashMap<String,String> attributeProperties= new HashMap<>();
        attributeProperties.put("XML", "#text");
        nslAttribute.setNslAttributeProperties(attributeProperties);

        String value = element.getTextContent();
        NslDataType attributeType = getNslDataType(value.getClass().toString());
        attributeType.setUiElement(getUiElementInfo(value.getClass().toString()));
        nslAttribute.setAttributeType(attributeType);

        nslAttributeList.add(nslAttribute);

        generalEntity.setNslAttributes(nslAttributeList);
        generalEntity.setStatus(StatusEnum.DRAFT);
        irdrUtils.setGeIRDR(generalEntity);
        return saveBetsService.saveGeneralEntity(generalEntity);

    }

}
