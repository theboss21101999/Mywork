package com.nsl.adapter.commons.impl;

import com.nsl.common.utils.JacksonUtils;
import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dao.FetchConnectionService;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;
import static org.springframework.http.HttpHeaders.ACCEPT_LANGUAGE;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Service
@Primary
public class FetchConnectionServiceImpl implements FetchConnectionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FetchConnectionServiceImpl.class);

    private static final String CALLRECEIVED = "Call received to save CU";
    public static final String CU_SAVED_SUCCESSFULLY = "CU saved successfully";

    @Value("${adapter.url:http://nsl-adapter:8203/adapter}")
    String adapterUrl;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    AdaptorCommonsProperties adaptorCommonsProperties;

    @Autowired
    @Qualifier("adapterConnectionsRedisDao")
    private AdapterConnnectionsDao adapterConnnectionsRedisDao;


    @Override
    public <T> T getConnection(ConnectionDtoType connectionType, Long recordId, AuthenticatedUserDetailsImpl authBean) throws NSLException {
        LOGGER.info(CALLRECEIVED);

        try {
            String json = null;
            //Fetching from redis
            if (adaptorCommonsProperties.getCacheEnabled()){
                json = adapterConnnectionsRedisDao.getRawConnection(connectionType, recordId, authBean);
            }
            if (json==null){
                String changeUnitUrl = adapterUrl + "/api/v1/connect/globalconnection?type="
                        + connectionType.toString() + "&recordId=" + recordId;
                Map<String, Object> uriVariables = new HashMap<>();
                HttpHeaders headers = getHeaders(authBean);
                HttpEntity<Object> httpEntity = new HttpEntity(new JSONObject(), headers);
                ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.GET,
                        httpEntity, ApiResponse.class, uriVariables);
                LOGGER.info(CU_SAVED_SUCCESSFULLY);
                ApiResponse apiResponse = response.getBody(); //NOSONAR
                json = (String) apiResponse.getResult(); //NOSONAR
            }
            return JacksonUtils.fromJson(json, connectionType.getClassType()); //NOSONAR
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while fetching CU: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }

    private HttpHeaders getHeaders(AuthenticatedUserDetailsImpl authBean){
        HttpHeaders headers = new HttpHeaders();

        if (authBean.isSystemUser() && authBean.getTenantId()!= null && authBean.getEmailId()!= null)
            headers.add(AppConstants.SYSTEM_USER_DETAILS,authBean.getTenantId()+ ":"+ authBean.getEmailId());
        headers.add(AUTHORIZATION, AppConstants.BEARER+ authBean.getAuthToken());
        headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        headers.add(ACCEPT_LANGUAGE, AppConstants.ACCEPT_LANGUAGE_EN);
        return headers;
    }

}
