package com.nsl.adapter.commons.config;

import ca.uhn.hl7v2.DefaultHapiContext;
import ca.uhn.hl7v2.HapiContext;
import ca.uhn.hl7v2.parser.CanonicalModelClassFactory;
import ca.uhn.hl7v2.parser.Parser;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.auth.WebIdentityTokenCredentialsProvider;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Configuration
public class SecretManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(SecretManager.class);

    @Bean("hapiParser")
    public Parser hapiparser() throws NSLException {

        Parser parser;
        try (HapiContext context = new DefaultHapiContext(new CanonicalModelClassFactory("2.5"))){
            parser = context.getPipeParser();
        }catch (Exception e){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"failed to parse the message" +
                    e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }

        return parser;
    }



}