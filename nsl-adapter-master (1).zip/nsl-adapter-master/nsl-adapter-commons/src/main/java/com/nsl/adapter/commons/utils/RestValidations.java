package com.nsl.adapter.commons.utils;

import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Locale;

@Component
public class RestValidations {
    @Autowired
    MessageSource messageSource;
    @Autowired
    AdaptorCommonsProperties adaptorCommonsProperties;
    public boolean validateBaseUrl(String baseUrl) {
        boolean isValid = true;
        String[] whitelistUrls= adaptorCommonsProperties.getwitelistUrls().split(",");
        String[] blackListUrls= adaptorCommonsProperties.getblacklistUrls().split(",");

        String ipAddress;
        URL url;
        try {
            url = new URL(baseUrl);
            if (url.getPort() == -1 && baseUrl.contains("https")){
                return true;
            }
            ipAddress = url.getHost();
            if (ipAddress.contains(".svc") || ipAddress.contains(".cluster") || ipAddress.contains(".local")) {
                return false;
            }
            if (!ipAddress.matches("^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
                    "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
                    "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." +
                    "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$")) {
                try {
                    InetAddress address = InetAddress.getByName(ipAddress);
                    ipAddress = address.getHostAddress();

                } catch (UnknownHostException e) {
                    throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, messageSource.getMessage("Paas_Adapter_212", null, Locale.ENGLISH), null);
                }
            }

        } catch (MalformedURLException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_212", null, Locale.ENGLISH) , null);
        }

        if(Arrays.asList(whitelistUrls).contains(url.getHost())){
            return true;
        }
        String binaryIpAddress = getBinaryIpAddress(ipAddress);
        for (int i = 0; i < Arrays.asList(whitelistUrls).size(); i++) {
            String first16Bits = binaryIpAddress.substring(0, 16);
            String wlBits=getBinaryIpAddress(Arrays.asList(whitelistUrls).get(i));
            if (wlBits.equals(binaryIpAddress) || wlBits.equals(first16Bits)) {
                return true;
            }
        }
        if(Arrays.asList(blackListUrls).contains(url.getHost())){
            return false;
        }

        for (int i = 0; i < Arrays.asList(blackListUrls).size(); i++) {
            String first16Bits = binaryIpAddress.substring(0, 16);
            String blBits=getBinaryIpAddress(Arrays.asList(blackListUrls).get(i));
            if (blBits.equals(binaryIpAddress) || blBits.equals(first16Bits)) {
                return false;
            }
        }
        if (ipAddress != null && !ipAddress.isEmpty()) {
            try {
                String[] ip = ipAddress.split("\\.");
                short[] ipNumber = new short[]{
                        Short.parseShort(ip[0]),
                        Short.parseShort(ip[1]),
                        Short.parseShort(ip[2]),
                        Short.parseShort(ip[3])
                };

                if (ipNumber[0] == 10) {
                    isValid = false;
                } else if (ipNumber[0] == 172 && (ipNumber[1] >= 16 && ipNumber[1] <= 31)) {
                    isValid = false;
                } else if (ipNumber[0] == 192 && ipNumber[1] == 168) {
                    isValid = false;
                }
            } catch (Exception e) {
                return true;
            }
        }
        return isValid;
    }
    public static String getBinaryIpAddress(String ipAddress) {
        // Split IP address into octets
        try {
            String[] octets = ipAddress.split("\\.");

            // Convert each octet to binary representation
            StringBuilder binaryIpAddress = new StringBuilder();
            for (String octet : octets) {
                int decimal = Integer.parseInt(octet);
                String binary = String.format("%8s", Integer.toBinaryString(decimal)).replace(' ', '0');
                binaryIpAddress.append(binary);
            }

            return binaryIpAddress.toString();
        }
        catch (Exception e){
            return ipAddress;
        }
    }
}
