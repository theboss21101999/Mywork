package com.nsl.adapter.commons.dto.Integrations.dto;

import com.nsl.adapter.commons.dto.Integrations.dto.ViewCUDto;


import java.util.List;

public class PaginatedCUsDto {

    List<ViewCUDto> cuDtoList;
    Integer pageNo;
    Integer pageSize;
    Long totalHits;

    public List<ViewCUDto> getCuDtoList() {
        return cuDtoList;
    }

    public void setCuDtoList(List<ViewCUDto> cuDtoList) {
        this.cuDtoList = cuDtoList;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Long getTotalHits() {
        return totalHits;
    }

    public void setTotalHits(Long totalHits) {
        this.totalHits = totalHits;
    }
}
