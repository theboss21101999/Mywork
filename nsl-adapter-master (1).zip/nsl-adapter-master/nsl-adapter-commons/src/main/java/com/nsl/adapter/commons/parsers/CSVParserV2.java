package com.nsl.adapter.commons.parsers;

import com.nsl.adapter.commons.parsers.service.ParserV2;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.entity.CSVToEntityUtil;
import com.nsl.adapter.commons.utils.entity.EntityToCSVUtil;
import com.nsl.adapter.commons.utils.entity.TxnDataUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class CSVParserV2 implements ParserV2 {

    private static final Logger LOGGER = LoggerFactory.getLogger(CSVParserV2.class);

    @Autowired
    EntityToCSVUtil entityToCSVUtil;

    @Autowired
    TxnDataUtils txnDataUtils;

    @Override
    public InputStream outboundParser(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity, Boolean isFileExists,Map<String,String> cuSystemProps) throws NSLException {

        String conflictAction = "replace";
        if(isFileExists) conflictAction ="append";
        String delimeter = null;
        if(cuSystemProps==null){
            delimeter = "|";
        }else{
            delimeter=cuSystemProps.getOrDefault(AppConstants.DELIMETER,"|");
        }
        LOGGER.info("The delimeter : {}",delimeter);
        String transObject;
        try {
            transObject = entityToCSVUtil.createRequestForSftpAdapter(txnGeneralEntity, inputGeneralEntity, conflictAction,delimeter);
            return new ByteArrayInputStream(transObject.getBytes(StandardCharsets.UTF_8));

        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "failed during csv parsing ", ExceptionSeverity.BLOCKER,e);

        }
    }

    @Override
    public List<TxnData> inboundParser(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued,
                       Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) {

        List<TxnData> transDatas = new ArrayList<>();
        List<TxnGeneralEntity> txnGeneralEntityList = inboundParserV2(inputStream,tcesGeneralEntity,isMultivalued,cuSystemProp,LayerType.PHYSICAL,authBean);
        for (TxnGeneralEntity txnGeneralEntity:txnGeneralEntityList){
            transDatas.add(txnDataUtils.setChangeDriverInTxnData(txnGeneralEntity,layerType));
        }
        return transDatas;
    }

    @Override
    public List<TxnGeneralEntity> inboundParserV2(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued, Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {
        List<TxnGeneralEntity> txnGeneralEntityList = new ArrayList<>();
        String data = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))
                .lines().collect(Collectors.joining("\n"));
        if (data.isEmpty())
            return txnGeneralEntityList;
        String delimeter;
        if(cuSystemProp==null){
            delimeter = "|";
        }else{
            delimeter = cuSystemProp.getOrDefault(AppConstants.DELIMETER,"\\|");
        }
        if(delimeter.equals("|")){
            delimeter="\\|";
        }
        String regexsperator = delimeter+AppConstants.CSVRegex;

        Map<String, Integer> headersMap = new HashMap<>();
        List<String> dataList = new ArrayList<>(Arrays.asList(data.split("\n")));

        List<String> headers = Arrays.asList(dataList.get(0).split(regexsperator,-1));
        for (int i=0; i<headers.size(); i++)
            headersMap.put(headers.get(i),i);
        dataList.remove(0);
        LOGGER.info("The Delimeter : {}",delimeter);
        LOGGER.info("The headers : {}",headers);
        LOGGER.info("The values : {}",dataList);
        List<List<String>> dataMap = FilterBlankRecords(dataList,regexsperator);

        if (isMultivalued) {
            txnGeneralEntityList.add(CSVToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity,
                    headersMap,dataMap,""));
        } else {
            dataMap.forEach(x -> {
                txnGeneralEntityList.add(CSVToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity,
                        headersMap, Collections.singletonList(x),""));
            });
        }
        return txnGeneralEntityList;
    }

    public List<List<String>> FilterBlankRecords(List<String> data,String regex){
        List<List<String>> result = new ArrayList<>();
        int c=0;
        for(String x:data){
            LOGGER.info("The data {} :{}",c++,x);
            List<String> splitData = Arrays.asList(x.split(regex));
            if(CheckRowData(splitData)){
                result.add(splitData);
            }
        }
        return result;
    }
    public boolean CheckRowData(List<String> data){
        for(String x:data){
            if(x.matches("^.*[^ ]+.*$")){
                return true;
            }
        }
        return false;
    }
}
