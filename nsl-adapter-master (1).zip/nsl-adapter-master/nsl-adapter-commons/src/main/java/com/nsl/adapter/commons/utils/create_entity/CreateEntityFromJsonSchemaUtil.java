package com.nsl.adapter.commons.utils.create_entity;


import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.IRDRUtils;
import com.nsl.adapter.commons.utils.UUIDGenerator;
import com.nsl.dsd.store.models.base.NslDataType;
import com.nsl.dsd.store.models.base.UIElementInfo;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityAttributeInput;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.enums.ChangeDriverType;
import com.nsl.logical.enums.DataType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.NSLAttributeMetaData;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class CreateEntityFromJsonSchemaUtil extends CreateEntityUtil implements CreateEntityFromFile{
   
    private static final Logger LOGGER = LoggerFactory.getLogger(CreateEntityFromJsonSchemaUtil.class);

    public String mainEntityName = "";

    @Autowired
    IRDRUtils irdrUtils;

    @Autowired
    SaveBetsService saveBetsService;

   /**
    * method to convert JSONSchema into NSL_Entity.It Converts File into JSONObject and calls createEntityFromSchema 
      for conversion into Entity

    * @param file                 Uploaded File
    * @return                     GeneralEntity
    * @exception IOException      
    */ 
   @Override 
   public TenantCUEntityInput convertFileIntoEntity(MultipartFile file, String entityName,Map<String,Object> PropertyMap) throws NSLException {
       TenantCUEntityInput generalEntity = null;
      try{
         InputStream createEntityConfigStream = file.getInputStream();
         BufferedReader streamReader = new BufferedReader(new InputStreamReader(createEntityConfigStream,
                 StandardCharsets.UTF_8));
         StringBuilder responseStrBuilder = new StringBuilder();
         String inputStr;
         while((inputStr = streamReader.readLine()) != null)
            responseStrBuilder.append(inputStr);
         JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
         return createEntityFromSchema(jsonObject, entityName);
      }catch (NSLException e) {
          throw e;
      }catch (Exception e) {
          throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"Exception while creating Entity: " +
                  e, ExceptionSeverity.MAJOR, e);
      }
   }


   /**
    * Method to convert JSONSchemaObject into NSL_Entity.It recevies Attribute List from mainJsonObject
    * and save it in General Entity
    *
    * @param mainJsonObject       MainJSONOBject 
    * @return                     GeneralEntity
    */
   public TenantCUEntityInput createEntityFromSchema(JSONObject mainJsonObject, String entityName) throws NSLException {
       TenantCUEntityInput generalEntity = new TenantCUEntityInput();
       JSONObject subJsonObject = (JSONObject) mainJsonObject.get(AppConstants.SCHEMA_PROPERTIES);
       this.mainEntityName = entityName;
       List<TenantCUEntityAttributeInput> nslAttributeList = createAttributeListFromSchema(subJsonObject,mainJsonObject);

     if(entityName == null) {
         generalEntity.setName("Entity" + UUIDGenerator.generateType1UUID());
     }
     else
        generalEntity.setName(entityName);
     generalEntity.setNslAttributes(nslAttributeList);
     generalEntity.setStatus(StatusEnum.DRAFT);
     if (LOGGER.isDebugEnabled()){
         LOGGER.info(generalEntity.toString());
     }
     irdrUtils.setGeIRDR(generalEntity);
     generalEntity=saveBetsService.saveGeneralEntity(generalEntity);
     return generalEntity;
   }


   /**
    * Method to convert mainJsonObject into List Of NSL_attributes, It send subJsonObject and gets nslAttribute from 
      createAttributeFromSchema

    * @param subJsonObject         AttributeListJSONObject
    * @param mainJsonObject        MainJsonObject
    * @return                      List NslAttribute
    */
   private List<TenantCUEntityAttributeInput> createAttributeListFromSchema(JSONObject subJsonObject,
                                                                            JSONObject mainJsonObject) throws NSLException {
    List<TenantCUEntityAttributeInput> nslAttributeList= new ArrayList<>();
       for (String keyStr : subJsonObject.keySet()) {
           createEachAttribute(subJsonObject, mainJsonObject, keyStr, nslAttributeList);
       }
       return nslAttributeList;
   }

   private void createEachAttribute(JSONObject subJsonObject, JSONObject mainJsonObject, String keyStr,
                                    List<TenantCUEntityAttributeInput> nslAttributeList) throws NSLException {
       if(!subJsonObject.opt(keyStr).getClass().equals(JSONArray.class)) {
           JSONObject subJsonObjectInfo = (JSONObject) subJsonObject.opt(keyStr);
           TenantCUEntityAttributeInput nslAttribute = createAttributeFromSchema(subJsonObjectInfo,
                   mainJsonObject,keyStr);

           if (mainJsonObject.has("required") &&
                   !mainJsonObject.get("required").toString().contains("\""+keyStr+"\"")){
               NSLAttributeMetaData metaData = new NSLAttributeMetaData();
               metaData.setChangeDriverTypes(List.of(ChangeDriverType.OPTIONAL));
               nslAttribute.setNslAttributeMetaData(metaData);
           }
           nslAttributeList.add(nslAttribute);
       }
   }
    
   /**
    * Method to convert SubJsonObject into NSL_Attribute.If the attribute is EntityType Calls
    * createAttributeListFromSchema and creates NestedEntity .Gets NSL_DataType for Attribute from
    * getNslDataTypeFromSchema2
    *
    * @param subJsonObjectInfo      AttributeJSONObject
    * @param mainJsonObject         MainJsonObject
    * @param attributeName          Attribute Name
    * @return                       NslAttribute
    */
   private TenantCUEntityAttributeInput createAttributeFromSchema(JSONObject subJsonObjectInfo,
                                                                  JSONObject mainJsonObject, String attributeName) throws NSLException {
    TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();
    NslDataType nslDataType;
    nslAttribute.setName(attributeName);
        if (AppConstants.OBJECT.equals(subJsonObjectInfo.opt(AppConstants.TYPE).toString())) {
            nslDataType = getNslDataTypeFromSchema(AppConstants.ENTITY);
            List<TenantCUEntityAttributeInput> subNslAttributes = createAttributeListFromSchema(
                    (JSONObject) subJsonObjectInfo.opt(AppConstants.SCHEMA_PROPERTIES), subJsonObjectInfo);
            TenantCUEntityInput subEntity = new TenantCUEntityInput();

            subEntity.setName(attributeName +"_"+ mainEntityName);
            subEntity.setDisplayName(attributeName);
            subEntity.setStatus(StatusEnum.DRAFT);
            subEntity.setNslAttributes(subNslAttributes);
            irdrUtils.setGeIRDR(subEntity);
            subEntity = saveBetsService.saveGeneralEntity(subEntity);
            nslAttribute.setGeneralEntity(subEntity);
            Map<String, String> subEntityRefProperties = new HashMap<>();
            subEntityRefProperties.put(AppConstants.REFERENCINGTYPE, subEntity.getName());
            nslDataType.setProperties(subEntityRefProperties);
            nslAttribute.setAttributeType(nslDataType);
        } else if (AppConstants.ARRAY.equals(subJsonObjectInfo.opt(AppConstants.TYPE).toString())) {
            nslDataType = getNslDataTypeFromSchema(AppConstants.ARRAY);
            JSONObject jsonObject4;
            jsonObject4 = subJsonObjectInfo.optJSONObject(AppConstants.SCHEMA_ITEMS);
            if (jsonObject4 == null) {
                jsonObject4 = subJsonObjectInfo.optJSONArray(AppConstants.SCHEMA_ITEMS).getJSONObject(0);
            }
            if (!jsonObject4.has(AppConstants.TYPE)) {
                JSONObject extractObject = extractJsonObject(mainJsonObject,
                        jsonObject4.get(AppConstants.SCHEMA_REFFERENCE).toString());
                LOGGER.info("exracted object - {} ", extractObject);
                TenantCUEntityInput subEntity = createEntityFromSchema(extractObject, null);
                Map<String, String> subEntityRefProperties = new HashMap<>();
                subEntityRefProperties.put(AppConstants.REFERENCINGTYPE, subEntity.getName());
                nslAttribute.setGeneralEntity(subEntity);
                nslDataType.setProperties(subEntityRefProperties);
                nslAttribute.setAttributeType(nslDataType);
            } else if (AppConstants.OBJECT.equals(jsonObject4.opt(AppConstants.TYPE).toString())) {
                List<TenantCUEntityAttributeInput> subNslAttributes = createAttributeListFromSchema(
                        (JSONObject) jsonObject4.opt(AppConstants.SCHEMA_PROPERTIES), jsonObject4);
                TenantCUEntityInput subEntity = new TenantCUEntityInput();
                subEntity.setName(attributeName +"_"+ mainEntityName);
                subEntity.setDisplayName(attributeName);
                subEntity.setNslAttributes(subNslAttributes);
                subEntity.setStatus(StatusEnum.DRAFT);
                irdrUtils.setGeIRDR(subEntity);
                subEntity = saveBetsService.saveGeneralEntity(subEntity);
                nslAttribute.setGeneralEntity(subEntity);
                Map<String, String> subEntityRefProperties = new HashMap<>();
                subEntityRefProperties.put(AppConstants.REFERENCINGTYPE, subEntity.getName());
                nslDataType.setProperties(subEntityRefProperties);
                Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE, getNslDataTypeFromSchema(AppConstants.ENTITY));
                nslDataType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);
                nslAttribute.setAttributeType(nslDataType);
            } else {
                Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                NslDataType actualDataType = getNslDataTypeFromSchema(jsonObject4.opt(AppConstants.TYPE).toString());
                nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE, actualDataType);
                nslDataType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);
                nslDataType.setUiElement(getUiElementInfo(jsonObject4.opt(AppConstants.TYPE).toString()));
                nslAttribute.setAttributeType(nslDataType);
            }

        } else {
            if (!subJsonObjectInfo.has(AppConstants.TYPE)) {
                JSONObject extractObject = extractJsonObject(mainJsonObject,
                        subJsonObjectInfo.get(AppConstants.SCHEMA_REFFERENCE).toString());
                TenantCUEntityInput subEntity = createEntityFromSchema(extractObject, null);
                Map<String, String> subEntityRefProperties = new HashMap<>();
                nslAttribute.setGeneralEntity(subEntity);
                subEntityRefProperties.put(AppConstants.REFERENCINGTYPE, subEntity.getName());
                nslDataType = getNslDataTypeFromSchema(AppConstants.ENTITY);
                nslDataType.setProperties(subEntityRefProperties);
                nslAttribute.setAttributeType(nslDataType);
            } else {
                nslDataType = getNslDataTypeFromSchema(subJsonObjectInfo.opt(AppConstants.TYPE).toString());
                nslDataType.setUiElement(getUiElementInfo(subJsonObjectInfo.opt(AppConstants.TYPE).toString()));
                if (subJsonObjectInfo.has(AppConstants.SUB_TYPE) &&
                        subJsonObjectInfo.get(AppConstants.SUB_TYPE).equals(AppConstants.MULTI_LINE)){
                    UIElementInfo uiElementInfo = new UIElementInfo(AppConstants.MULTI_LINE,
                            DataType.STRING.toString().toLowerCase(Locale.ENGLISH),
                            "textarea", Boolean.FALSE);
                    nslDataType.setUiElement(uiElementInfo);

                }
                nslAttribute.setAttributeType(nslDataType);
            }
        }
    return nslAttribute;
   }

   /**
    * Method to Extract Ref Object 

    * @param mainJsonObject    MainJsonObject
    * @param extractString     Object To be Exatrected
    * @return                  JSONObject
    */
  // Need to handle execption when it is null
   private JSONObject extractJsonObject(JSONObject mainJsonObject, String extractString){
    String[] extractStringList = extractString.split("/");  
    JSONObject exatractedObject=null;
    for (String item: extractStringList) { 
        if(!"#".equals(item)){
            exatractedObject=(JSONObject) mainJsonObject.get(item);
        }
    }
    return exatractedObject;
   }

   /**
    * Method to convert dataTypeInfo into DataType
    *
    * @param dataType   DataTypeInfo
    * @return           NslDataType
    */ 
    private static NslDataType getNslDataTypeFromSchema(String dataType) {
        NslDataType nslDataType = new NslDataType();
          if("Entity".equals(dataType)){
            nslDataType.setType(DataType.ENTITY);
          } else if("array".equals(dataType)){
            nslDataType.setType(DataType.LIST);
          } else if("string".equals(dataType)){
            nslDataType.setType(DataType.STRING);
          } else if("integer".equals(dataType)  || "number".equals(dataType)){
            nslDataType.setType(DataType.NUMBER);
          } else if ("boolean".equals(dataType)) {
            nslDataType.setType(DataType.BOOLEAN);
          } else if ("double".equals(dataType)) {
              nslDataType.setType(DataType.FLOAT);
          } else {
            nslDataType.setType(DataType.STRING);
          }
           return nslDataType;
    }
}
