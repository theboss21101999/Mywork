package com.nsl.adapter.commons.utils.entity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.dto.GsiInvocationDto;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityAttributeInput;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class GeneralEntityUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(GeneralEntityUtils.class);

    public static TxnGeneralEntity getExpectedTxnGeneralEntity(List<TxnSlotItem> transEntityDetails,
                                                               String expectedEntity) {

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();

        if (transEntityDetails != null && !transEntityDetails.isEmpty()) {
            for (TxnSlotItem slot : transEntityDetails) {
                if (slot.getItem() instanceof TxnGeneralEntity) {
                    txnGeneralEntity = (TxnGeneralEntity) slot.getItem();
                    if (((TxnGeneralEntity) slot.getItem()).getName().equalsIgnoreCase(expectedEntity)) {
                        txnGeneralEntity = (TxnGeneralEntity) slot.getItem();
                        break;
                    }
                }
            }
        }

        return txnGeneralEntity;
    }

    public static Map<String,TxnGeneralEntity> getTxnGeneralEntitieswithId(List<TxnSlotItem> transEntityDetails,
                                                                           Map<String,TxnGeneralEntity> txnGeneralEntities,
                                                                           Map<String, Boolean> isMultivalueMap) {

        if (transEntityDetails != null && !transEntityDetails.isEmpty()) {
            for (TxnSlotItem slot : transEntityDetails) {
                if (slot.getItem() instanceof TxnGeneralEntity) {
                    TxnGeneralEntity entity = (TxnGeneralEntity) slot.getItem();
                    txnGeneralEntities.put(entity.getName(),entity);
                    isMultivalueMap.put(entity.getName(), slot.getIsMultiValue());
                }
            }
        }

        return txnGeneralEntities;
    }

    public static TxnGeneralEntity getExpectedTxnGeneralEntity(List<TxnSlotItem> transEntityDetails) {

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();

        if (transEntityDetails != null && !transEntityDetails.isEmpty()) {
            for (TxnSlotItem slot : transEntityDetails) {
                if (slot.getItem() instanceof TxnGeneralEntity) {
                    txnGeneralEntity = (TxnGeneralEntity) slot.getItem();
                    break;
                }
            }
        }

        return txnGeneralEntity;
    }

    public static GeneralEntity getExpectedGeneralEntityByName(TriggerCU triggerCU, String name) {

        GeneralEntity generalEntity = null;
        List<CULayer> cuLayers = triggerCU.getLayers();

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : triggerCU.getLayers()) {
                if (null != layer && null != layer.getParticipatingItems()
                        && layer.getType().getLayerType().equalsIgnoreCase(AppConstants.INFORMATION_LAYER)) {

                    for (SlotItem slotItem : layer.getParticipatingItems()) {
                        if (null != slotItem && null != slotItem.getItem()
                                && slotItem.getItem() instanceof GeneralEntity) {
                            generalEntity = (GeneralEntity) slotItem.getItem();
                            if (generalEntity.getName().equals(name))
                                break;
                        }
                    }
                }
            }
        }
        return generalEntity;
    }

    public static List<TxnGeneralEntity> getExpectedTxnMultipleGeneralEntities(List<TxnSlotItem> transEntityDetails) {

        List<TxnGeneralEntity> txnGeneralEntity = new LinkedList<TxnGeneralEntity>();

        if (transEntityDetails != null && !transEntityDetails.isEmpty()) {
            for (TxnSlotItem slot : transEntityDetails) {
                if (slot.getItem() instanceof TxnGeneralEntity) {
                    txnGeneralEntity.add( (TxnGeneralEntity) slot.getItem());
                }
            }
        }
        return txnGeneralEntity;
    }
    
    public static TxnGeneralEntityRecord getTxnEntityfromGeneralEntity(GeneralEntity generalEntity) {
        TxnGeneralEntityRecord txnGeneralEntityRecord = new TxnGeneralEntityRecord();
        
        if(generalEntity==null || generalEntity.getNslAttributes()==null || generalEntity.getNslAttributes().isEmpty())
            return txnGeneralEntityRecord;

        List<TxnNslAttribute> txnNslAttributes = new ArrayList<>();
        for(NslAttribute nslAttribute : generalEntity.getNslAttributes()) {
            TxnNslAttribute attribute = new TxnNslAttribute();
            attribute.setName(nslAttribute.getName());
            attribute.setId(nslAttribute.getId());
            attribute.setValues(Collections.singletonList(nslAttribute.getDefaultValue()));
            txnNslAttributes.add(attribute);
        }
        txnGeneralEntityRecord.setTxnNslAttribute(txnNslAttributes);
        
        return txnGeneralEntityRecord;
    }

    public static void getTriggerCUGeneralEntities(TriggerCU triggerCU, String layerName, Map<String,GeneralEntity> generalEntities) {

        List<CULayer> cuLayers = triggerCU.getLayers();

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : triggerCU.getLayers()) {
                if (null != layer && null != layer.getParticipatingItems()
                        && layer.getType().getLayerType().equalsIgnoreCase(layerName)) {

                    for (SlotItem slotItem : layer.getParticipatingItems()) {
                        if (null != slotItem && null != slotItem.getItem()
                                && slotItem.getItem() instanceof GeneralEntity) {
                            GeneralEntity generalEntity = (GeneralEntity) slotItem.getItem();
                            generalEntities.put(generalEntity.getName(),generalEntity);
                        }
                    }
                }
            }
        }
    }

    public static GeneralEntity getTriggerCUGeneralEntity(TriggerCU triggerCU, String layerName) {

        GeneralEntity generalEntity = null;
        List<CULayer> cuLayers = triggerCU.getLayers();

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : triggerCU.getLayers()) {
                if (null != layer && null != layer.getParticipatingItems()
                        && layer.getType().getLayerType().equalsIgnoreCase(layerName)) {

                    for (SlotItem slotItem : layer.getParticipatingItems()) {
                        if (null != slotItem && null != slotItem.getItem()
                                && slotItem.getItem() instanceof GeneralEntity) {
                            generalEntity = (GeneralEntity) slotItem.getItem();
                            break;
                        }
                    }
                }
            }
        }
        return generalEntity;
    }
    public static GeneralEntity getTriggerCUGeneralEntity(TriggerCU triggerCU, String layerName, int index) {

        GeneralEntity generalEntity = null;
        List<CULayer> cuLayers = triggerCU.getLayers();

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : triggerCU.getLayers()) {
                if (null != layer && null != layer.getParticipatingItems()
                        && layer.getType().getLayerType().equalsIgnoreCase(layerName)) {

                    generalEntity = (GeneralEntity) layer.getParticipatingItems().get(index).getItem();
                }
            }
        }
        return generalEntity;
    }
    public static GeneralEntity getTriggerCUGeneralEntity(List<CULayer> cuLayers, String layerName) {

        GeneralEntity generalEntity = null;

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : cuLayers) {
                if (null != layer && null != layer.getParticipatingItems()
                        && layer.getType().getLayerType().equalsIgnoreCase(layerName)) {

                    for (SlotItem slotItem : layer.getParticipatingItems()) {
                        if (null != slotItem && null != slotItem.getItem()
                                && slotItem.getItem() instanceof GeneralEntity) {
                            generalEntity = (GeneralEntity) slotItem.getItem();
                            break;
                        }
                    }
                }
            }
        }
        return generalEntity;
    }

    public static List<SlotItem> getTriggerCUSlotItemsList(List<CULayer> cuLayers, String layerName) {

        List<SlotItem> slotItems = new ArrayList<>();

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : cuLayers) {
                if (null != layer && null != layer.getParticipatingItems()
                        && layer.getType().getLayerType().equalsIgnoreCase(layerName)) {

                    for (SlotItem slotItem : layer.getParticipatingItems()) {
                        if (null != slotItem && null != slotItem.getItem()
                                && slotItem.getItem() instanceof GeneralEntity) {
                            slotItems.add(slotItem);
                        }
                    }
                }
            }
        }
        return slotItems;
    }
    public static List<GeneralEntity> getTriggerCUMultipleGeneralEntities(TriggerCU triggerCU, String layerName) {

        List<GeneralEntity> generalEntity = new LinkedList<GeneralEntity>();
        List<CULayer> cuLayers = triggerCU.getLayers();

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : triggerCU.getLayers()) {
                if (null != layer && null != layer.getParticipatingItems()
                        && layer.getType().getLayerType().equalsIgnoreCase(layerName)) {

                    for (SlotItem slotItem : layer.getParticipatingItems()) {
                        if (null != slotItem && null != slotItem.getItem()
                                && slotItem.getItem() instanceof GeneralEntity) {
                            generalEntity.add( (GeneralEntity) slotItem.getItem());
                        }
                    }
                }
            }
        }
        return generalEntity;
    }

    public static TxnGeneralEntity getTriggerTxnGeneralEntityStructure(GeneralEntity generalEntity) {

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();
        txnGeneralEntity.setGeneralEntityID(generalEntity.getId());
        txnGeneralEntity.setName(generalEntity.getName());
        List<TxnGeneralEntityRecord> txnGeneralEntityRecordList = new ArrayList<>();

        List<NslAttribute> nslAttributeList = generalEntity.getNslAttributes();

        List<TxnNslAttribute> txnNslAttributes = new ArrayList<>();
        TxnGeneralEntityRecord txnGeneralEntityRecord = new TxnGeneralEntityRecord();
        if (nslAttributeList != null) {
            for (NslAttribute nslAttribute : nslAttributeList) {
                TxnNslAttribute attribute = new TxnNslAttribute();
                attribute.setId(nslAttribute.getId());
                attribute.setName(nslAttribute.getName());
                txnNslAttributes.add(attribute);

                txnGeneralEntityRecord.setTxnNslAttribute(txnNslAttributes);
            }
            txnGeneralEntityRecordList.add(txnGeneralEntityRecord);
        }

        txnGeneralEntity.setTransEntityRecords(txnGeneralEntityRecordList);
        return txnGeneralEntity;
    }

    private static boolean isEmpty(Collection<?> coll) {
        return CollectionUtils.isEmpty(coll);
    }



    public static List<TxnSlotItem> getTransEntityDetails(List<TxnCULayer> txnCuLayers, String layer) {

        List<TxnSlotItem> transEntityDetails = new ArrayList<>();
        for (TxnCULayer cuLayer : txnCuLayers) {
            if (cuLayer.getType().getLayerType().equalsIgnoreCase(layer)) {
                transEntityDetails = cuLayer.getTxnSlotItems();
                break;
            }
        }
        return transEntityDetails;
    }



    private static Long getNslAttributeId(TenantCUEntityInput entity, String attributeName) {
        Optional<TenantCUEntityAttributeInput> findnslAttr = entity.getNslAttributes().stream()
                .filter(nslAttribute -> nslAttribute.getName().equalsIgnoreCase(attributeName)).findAny();

        if (findnslAttr.isPresent()) {
            return findnslAttr.get().getId();
        }
        return null;
    }

    private static String getNslAttributeDsdId(TenantCUEntityInput entity, String attributeName) {
        Optional<TenantCUEntityAttributeInput> findnslAttr = entity.getNslAttributes().stream()
                .filter(nslAttribute -> nslAttribute.getName().equalsIgnoreCase(attributeName)).findAny();

        if (findnslAttr.isPresent()) {
            return findnslAttr.get().getDsdId();
        }
        return null;
    }

    public static String urlEncodedData(String value){

        try{
            value = URLEncoder.encode(value, StandardCharsets.UTF_8);
        }catch (Exception e){
            LOGGER.error("Error in encoding url ", e);
        }
        return value;
    }

    public static String encodeMap(Map<String, Object> valueMap) throws NSLException {
        try {
            return Base64.getEncoder().encodeToString(JacksonUtils.toJson(valueMap).getBytes(StandardCharsets.UTF_8));
        }catch (Exception e){
            LOGGER.error("Exception while encoding string - ",e);
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.SOLUTION_LOGIC,
                    e.getMessage(), null, e);
        }
    }

    public static HashMap decodeString(String code) throws NSLException {
        try {
            byte[] decodedBytes = Base64.getDecoder().decode(code);
            final String decodedString = new String(decodedBytes, StandardCharsets.UTF_8);
            return new ObjectMapper().readValue(decodedString, HashMap.class);
        } catch (JsonProcessingException e) {
            LOGGER.error("Exception while decoding string - ",e);
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.SOLUTION_LOGIC,
                    e.getMessage(), null, e);
        }
    }

    public static TxnData getTxnDataFromGsiInvocationDto(TriggerCU triggerCU, GsiInvocationDto gsiInvocationDto) throws JsonProcessingException {

        TxnData result = new TxnData();
        List<TxnCULayer> transactionCULayerList = new ArrayList<>();
        List<CULayer> cuLayers = triggerCU.getLayers();
        ObjectMapper objectMapper = new ObjectMapper();

        if (!isEmpty(cuLayers)) {

            for (CULayer layer : triggerCU.getLayers()) {
                if (null != layer && null != layer.getParticipatingItems()) {
                    Map<String, String> layerData = null;
                    if (layer.getType().getLayerType().equalsIgnoreCase(AppConstants.PHYSICAL_LAYER)){
                        layerData = gsiInvocationDto.getPhysicalLayer();
                    }else if(layer.getType().getLayerType().equalsIgnoreCase(AppConstants.INFORMATION_LAYER)){
                        layerData = gsiInvocationDto.getInformationLayer();
                    }else {
                        continue;
                    }

                    TxnCULayer transactionCULayer = new TxnCULayer();
                    List<TxnSlotItem> slots = new ArrayList<>();

                    for (SlotItem slotItem : layer.getParticipatingItems()) {
                        if (null != slotItem && null != slotItem.getItem()
                                && slotItem.getItem() instanceof GeneralEntity) {
                            GeneralEntity generalEntity = (GeneralEntity) slotItem.getItem();
                            TxnSlotItem slot = new TxnSlotItem();
                            TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(generalEntity,
                                    objectMapper.readTree(layerData.getOrDefault(generalEntity.getName(), "{}")));
                            slot.setItem(txnGeneralEntity);
                            slots.add(slot);
                        }
                    }

                    transactionCULayer.setTxnSlotItems(slots);
                    transactionCULayer.setType(layer.getType());
                    transactionCULayerList.add(transactionCULayer);
                }
            }
        }
        result.setTxnCULayer(transactionCULayerList);
        return result;
    }

}
