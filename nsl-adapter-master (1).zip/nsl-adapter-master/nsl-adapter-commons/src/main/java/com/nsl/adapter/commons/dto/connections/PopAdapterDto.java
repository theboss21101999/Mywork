package com.nsl.adapter.commons.dto.connections;

public class PopAdapterDto extends BasicAdapterConnection {
    String host;
    int port;
    String storeType;
    String username;
    String password;

    public PopAdapterDto() {
    }

    public PopAdapterDto(String host, int port, String storeType, String username, String password) {
        this.host = host;
        this.port = port;
        this.storeType = storeType;
        this.username = username;
        this.password = password;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getStoreType() {
        return storeType;
    }

    public void setStoreType(String storeType) {
        this.storeType = storeType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
