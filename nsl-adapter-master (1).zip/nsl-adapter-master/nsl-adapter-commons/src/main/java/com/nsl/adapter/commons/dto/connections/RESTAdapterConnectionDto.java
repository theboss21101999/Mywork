package com.nsl.adapter.commons.dto.connections;

import com.nsl.adapter.commons.dto.connections.RESTCredential;

import java.util.Properties;

public class RESTAdapterConnectionDto  extends BasicAdapterConnection{
    private String baseUrl;
    private RESTCredential authentication;
    private Properties advancedConfig;

    public RESTAdapterConnectionDto() {
    }

    public RESTAdapterConnectionDto(String baseUrl, RESTCredential authentication, Properties advancedConfig) {
        this.baseUrl = baseUrl;
        this.authentication = authentication;
        this.advancedConfig = advancedConfig;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public RESTCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(RESTCredential authentication) {
        this.authentication = authentication;
    }

    public Properties getAdvancedConfig() {
        return advancedConfig;
    }

    public void setAdvancedConfig(Properties advancedConfig) {
        this.advancedConfig = advancedConfig;
    }
}
