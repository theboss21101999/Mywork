package com.nsl.adapter.commons.dto.connections;

import java.util.List;

/*
 *GraphOauth connection Dto
 */

public class GraphOauthConnectionDto extends BasicAdapterConnection{

    private String clientId;
    private String clientSecret;
    private List<String> scope;
    private String refreshToken;
    private String tenantId;

    public GraphOauthConnectionDto() {
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public List<String> getScope() {
        return scope;
    }

    public void setScope(List<String> scope) {
        this.scope = scope;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }
}

