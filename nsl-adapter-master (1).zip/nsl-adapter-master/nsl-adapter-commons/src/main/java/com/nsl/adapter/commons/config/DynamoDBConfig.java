package com.nsl.adapter.commons.config;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.auth.WebIdentityTokenCredentialsProvider;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DynamoDBConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(DynamoDBConfig.class);

    @Value("${app.dynamo.aws.accesskey:null}")
    private String awsAccesskey;

    @Value("${app.dynamo.aws.secretkey:null}")
    private String awsSecretkey;

    @Value("${app.dynamo.aws.sessionkey:null}")
    private String awsSessionKey;

    @Value("${app.dynamo.aws.region:ap-south-1}")
    private Regions region;

    @Value("${app.connections.scylla.url:null}")
    private String scyllaUrl;

    @Bean
    @ConditionalOnProperty(value = "app.connections.datasource", havingValue = "AWS", matchIfMissing = true)
    public AmazonDynamoDB dynamoDBClient() {

        AWSCredentialsProvider provider;
        if (awsAccesskey.equals("null") && awsSecretkey.equals("null")){
            LOGGER.info("aws arn : {}", System.getenv("AWS_ROLE_ARN"));
            provider = WebIdentityTokenCredentialsProvider.builder()
                    .roleArn(System.getenv("AWS_ROLE_ARN"))
                    .roleSessionName(System.getenv("AWS_ROLE_SESSION_NAME"))
                    .webIdentityTokenFile(System.getenv("AWS_WEB_IDENTITY_TOKEN_FILE"))
                    .build();
        }else {
            provider = new AWSStaticCredentialsProvider(
                    awsSessionKey.equals("null")?new BasicAWSCredentials(awsAccesskey, awsSecretkey)
                            :new BasicSessionCredentials(
                            awsAccesskey,
                            awsSecretkey,
                            awsSessionKey));
        }

        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
                .withCredentials(provider)
                .withRegion(region)
                .build();

        return client;
    }

    @Bean
    @ConditionalOnProperty(value = "app.connections.datasource", havingValue = "SCYLLA")
    public AmazonDynamoDB dynamoDBClientScylla() {

        AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
                .withEndpointConfiguration(
                        new AwsClientBuilder.EndpointConfiguration(
                                scyllaUrl, region.toString()))
                .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(awsAccesskey, awsSecretkey)))
                .build();

        return client;
    }

    @Bean
    public DynamoDB dynamoDB(@Autowired AmazonDynamoDB client) {
        return new DynamoDB(client);
    }

    @Bean
    public DynamoDBMapper dynamoDBMapper(@Autowired AmazonDynamoDB client, @Autowired TableNameResolver tableNameResolver) {
        return new DynamoDBMapper(client, new DynamoDBMapperConfig.Builder()
                .withTableNameResolver(tableNameResolver).build());
    }
}
