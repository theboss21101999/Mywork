package com.nsl.adapter.commons.dto.Integrations.dto;

import com.nsl.adapter.commons.dto.AdapterScheduleReq;
import com.nsl.adapter.commons.enums.AdapterType;

import java.util.HashMap;
import java.util.Map;

public class IntegrationDtoV3 {

    private String integrationName ;
    private AdapterType adapterType;
    private String operation;
    private Long configEntityRecordId;
    private String configEntityRecordName;
    private String inputEntityDsdId;
    private String outputEntityDsdId;
    private String infoEntityDsdId;
    private Map<String,String> propertiesMap = new HashMap<>();
    private AdapterScheduleReq scheduleReq;
    private Map<String,Map<String,String>> mapper;

    public IntegrationDtoV3() {
    }

    public String getIntegrationName() {
        return integrationName;
    }

    public void setIntegrationName(String integrationName) {
        this.integrationName = integrationName;
    }

    public AdapterType getAdapterType() {
        return adapterType;
    }

    public void setAdapterType(AdapterType adapterType) {
        this.adapterType = adapterType;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public Long getConfigEntityRecordId() {
        return configEntityRecordId;
    }

    public void setConfigEntityRecordId(Long configEntityRecordId) {
        this.configEntityRecordId = configEntityRecordId;
    }

    public String getConfigEntityRecordName() {
        return configEntityRecordName;
    }

    public void setConfigEntityRecordName(String configEntityRecordName) {
        this.configEntityRecordName = configEntityRecordName;
    }

    public String getInputEntityDsdId() {
        return inputEntityDsdId;
    }

    public void setInputEntityDsdId(String inputEntityDsdId) {
        this.inputEntityDsdId = inputEntityDsdId;
    }

    public String getOutputEntityDsdId() {
        return outputEntityDsdId;
    }

    public void setOutputEntityDsdId(String outputEntityDsdId) {
        this.outputEntityDsdId = outputEntityDsdId;
    }

    public String getInfoEntityDsdId() {
        return infoEntityDsdId;
    }

    public void setInfoEntityDsdId(String infoEntityDsdId) {
        this.infoEntityDsdId = infoEntityDsdId;
    }

    public Map<String, String> getPropertiesMap() {
        return propertiesMap;
    }

    public void setPropertiesMap(Map<String, String> propertiesMap) {
        this.propertiesMap = propertiesMap;
    }

    public AdapterScheduleReq getScheduleReq() {
        return scheduleReq;
    }

    public void setScheduleReq(AdapterScheduleReq scheduleReq) {
        this.scheduleReq = scheduleReq;
    }

    public Map<String, Map<String, String>> getMapper() {
        return mapper;
    }

    public void setMapper(Map<String, Map<String, String>> mapper) {
        this.mapper = mapper;
    }
}
