package com.nsl.adapter.commons.parsers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.adapter.commons.parsers.service.ParserService;
import com.nsl.adapter.commons.parsers.service.ParserV2;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.FileUploadUtil;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.adapter.commons.utils.entity.TxnDataUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.DataType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslDataType;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.InputStream;
import java.util.*;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class NativeParserV2 implements ParserV2 {

    private static final Logger LOGGER = LoggerFactory.getLogger(NativeParserV2.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    TxnDataUtils txnDataUtils;

    @Autowired
    EntityToJSONUtil entityToJSONUtil;

    @Autowired
    FileUploadUtil fileUploadUtil;

    @Autowired
    private ParserService parserService;
    @Autowired
    AdaptorCommonsProperties adaptorCommonsProperties;

    @Override
    public InputStream outboundParser(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity, Boolean isFileExists,Map<String,String> cuSystemProps) throws NSLException {

        try {

            HashMap<String ,String> map = (HashMap<String,String>) entityToJSONUtil.getDataFromGE(txnGeneralEntity,
                                                                                    inputGeneralEntity).get("File");
            String url =map.get(AppConstants.CONTENT_URL);
            if(url!=null && !url.contains("https")) {
                url = adaptorCommonsProperties.getEnvUrl() + url;
            }
            return fileUploadUtil.getContentFromUrl(url, authBean); //NOSONAR

        } catch (JSONException e) {
            LOGGER.error("failed during native parsing {}", e.getMessage());
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "failed during native parsing ", ExceptionSeverity.BLOCKER, e);
        }

    }

    @Override
    public List<TxnData> inboundParser(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued,
                                       Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {
        List<TxnData> transDatas = new ArrayList<>();
        try {

            String wrappedResponse = parserService.uploadToDsd(inputStream, cuSystemProp, authBean);

            JSONObject jsonObject = new JSONObject().put("File", wrappedResponse);
            JsonNode response = new ObjectMapper().readTree(jsonObject.toString());
            TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity,
                    response);
            TxnData transData = txnDataUtils.setChangeDriverInTxnData(txnGeneralEntity, layerType);
            transDatas.add(transData);
        }catch (NSLException e) {
            throw e;
        }catch (Exception e) {
            LOGGER.info("error occured");
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "failed during native parsing ", ExceptionSeverity.BLOCKER, e);
        }
        return transDatas;
    }


    public List<TxnGeneralEntity> inboundParserV2(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued,
                                                  Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {

        try {

            String wrappedResponse = parserService.uploadToDsd(inputStream, cuSystemProp, authBean);
            JSONObject jsonObject;

            if(tcesGeneralEntity.getNslAttributes().get(0).getAttributeType().getType()== DataType.LIST){
                jsonObject=new JSONObject().put("File",new JSONArray().put(wrappedResponse));
            }else{
                jsonObject = new JSONObject().put("File", wrappedResponse);
            }
            JsonNode response = new ObjectMapper().readTree(jsonObject.toString());
            TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity,
                    response);

            return Collections.singletonList(txnGeneralEntity);
        }catch (NSLException e) {
            throw e;
        }catch (Exception e) {
            LOGGER.info("error occured");
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "failed during native parsing ", ExceptionSeverity.BLOCKER, e);
        }

    }


}