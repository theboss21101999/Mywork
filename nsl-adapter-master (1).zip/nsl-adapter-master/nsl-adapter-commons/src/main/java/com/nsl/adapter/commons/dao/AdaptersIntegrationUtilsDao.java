package com.nsl.adapter.commons.dao;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.ChangeUnit;
import org.springframework.data.domain.Page;

public interface AdaptersIntegrationUtilsDao {

    Page<ChangeUnit> getCUsList(Integer pageNumber, Integer pageSize, String query, String adapter) throws Exception;

    void checkCUName(String integration);

    TenantChangeUnitInput saveIntegration(CUPropsDto cuPropsDto) throws NSLException;

    CUPropsDto getIntegrationById(String dsdId) throws NSLException;

    TenantChangeUnitInput updateIntegration(String dsdId, CUPropsDto newCuPropsDto) throws NSLException;
}
