package com.nsl.adapter.commons.dto.connections;

public class TelegramConnectionDto extends BasicAdapterConnection{

    public String botToken;

    public TelegramConnectionDto() {
    }

    public TelegramConnectionDto(String botToken) {
        this.botToken = botToken;
    }

    public String getBotToken() {
        return botToken;
    }

    public void setBotToken(String botToken) {
        this.botToken = botToken;
    }
}
