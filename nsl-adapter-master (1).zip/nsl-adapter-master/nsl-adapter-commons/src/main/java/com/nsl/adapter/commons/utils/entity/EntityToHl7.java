package com.nsl.adapter.commons.utils.entity;

import ca.uhn.hl7v2.DefaultHapiContext;
import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.HapiContext;
import ca.uhn.hl7v2.model.AbstractGroup;
import ca.uhn.hl7v2.model.AbstractSegment;
import ca.uhn.hl7v2.model.Composite;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.model.Primitive;
import ca.uhn.hl7v2.model.Structure;
import ca.uhn.hl7v2.model.Type;
import ca.uhn.hl7v2.model.Varies;
import ca.uhn.hl7v2.model.v25.datatype.TX;
import ca.uhn.hl7v2.parser.CanonicalModelClassFactory;
import ca.uhn.hl7v2.parser.Parser;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Component
public class EntityToHl7 {

    public final Logger LOGGER = LoggerFactory.getLogger(EntityToHl7.class);

    @Qualifier("hapiParser")
    @Autowired
    Parser parser;

    public String getHl7Message(JSONObject jsonObject, String message_Type) throws NSLException {

        Message resp;
        try (HapiContext context = new DefaultHapiContext()) {
            context.setModelClassFactory(new CanonicalModelClassFactory("2.5"));

            Class classObj = Class.forName("ca.uhn.hl7v2.model.v25.message." + message_Type);
            resp = context.newMessage(classObj);
            populateGroup((AbstractGroup) resp,jsonObject);
            LOGGER.info("parsing message ...");
            return parser.encode(resp);
        }catch (Exception e){
            LOGGER.error("error while building HL7 message",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "error while building HL7 message "+ e.getMessage(), ExceptionSeverity.BLOCKER,e);
        }
        
    }

    private void populateGroup(AbstractGroup group, JSONObject jsonObject) throws HL7Exception, JSONException {


        for (String name :group.getNames()){


            if (!jsonObject.has(name))
                continue;

            if (group.isRepeating(name) && jsonObject.get(name) instanceof JSONArray){

                JSONArray array = jsonObject.getJSONArray(name);
                for( int i=0 ;i<array.length();i++)
                    populateStructure(group.insertRepetition(name,i) ,array.getJSONObject(i));

            }else
                populateStructure(group.insertRepetition(name,0) ,jsonObject.getJSONObject(name));
        }

    }

    private void populateStructure(Structure structure, JSONObject jsonObject) throws HL7Exception, JSONException {

        if (structure instanceof AbstractGroup)
            populateGroup((AbstractGroup) structure,jsonObject);
        else if(structure instanceof AbstractSegment){
            populateSegment((AbstractSegment) structure,jsonObject);
        }

    }

    private void populateSegment(AbstractSegment segment, JSONObject jsonObject) throws HL7Exception, JSONException {

        String[] names = segment.getNames();
        for (int i=1 ; i<= names.length; i++) {

            String name = names[i-1].replaceAll("[^a-zA-Z0-9 ]"," ");

            if (!jsonObject.has(name))
                continue;

            if (repeatableCheckForField(segment.getClass(),name)){
                JSONArray array = jsonObject.getJSONArray(name);
                for (int j=0 ; j<array.length(); j++){
                    Type type = segment.getField(i,j);
                    populateType(type,array.get(j),name);
                }
            }else {
                Type type = segment.getField(i,0);
                populateType(type,jsonObject.get(name),name);
            }
        }
    }

    private void populateType(Type type , Object object , String name) throws HL7Exception, JSONException {

        if (type instanceof Primitive) {
            Primitive primitiveType = (Primitive) type;
            primitiveType.setValue(String.valueOf(object));
        } else if (type instanceof Composite && object instanceof JSONObject) {
            Composite compositeType = (Composite) type;
            Type[] types = compositeType.getComponents();
            for (int i=0; i<types.length; i++){
                String subTypeName = name +"_"+ (i+1);
                if (((JSONObject) object).has(subTypeName))
                    populateType(types[i], ((JSONObject) object).get(subTypeName), subTypeName);
            }
        } else if (type instanceof Varies) {
            Varies varies = (Varies) type;
            TX newType = new TX(type.getMessage());
            newType.setValue(String.valueOf(object));
            varies.setData(newType);
        }

    }
    
    public boolean repeatableCheckForField(Class classObj , String fieldName){

        try {
            Class[] inputParams = new Class[1];
            inputParams[0] = int.class;
            String methodName = "get"+ fieldName.replaceAll(" ","");
            Method method = classObj.getDeclaredMethod(methodName, inputParams);
            return true;
        }catch (Exception e){
            return false;
        }
    }
    
}
