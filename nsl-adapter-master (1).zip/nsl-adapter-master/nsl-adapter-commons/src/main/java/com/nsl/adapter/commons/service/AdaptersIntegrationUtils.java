package com.nsl.adapter.commons.service;

import com.nsl.adapter.commons.dao.AdaptersIntegrationUtilsDao;
import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.IRDRUtils;
import com.nsl.dsd.store.models.tenant.io.TenantCULayerInput;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.Agent;
import com.nsl.logical.model.ChangeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import static com.nsl.adapter.commons.utils.AppConstants.EXTERNAL_SOLUTION_PREFIX;
import static com.nsl.logical.enums.StatusEnum.PUBLISHED;

@Service
public class AdaptersIntegrationUtils implements AdaptersIntegrationUtilsDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdaptersIntegrationUtils.class);

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    IRDRUtils irdrUtils;

    @Autowired
    SaveBetsService saveBetsService;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;


    @Override
    public Page<ChangeUnit> getCUsList(Integer pageNumber, Integer pageSize, String query, String adapter) throws Exception {

        HashMap<String , String> cuSystemProps = new HashMap<>();
        if(adapter!=null){
            cuSystemProps.put(AppConstants.ADAPTER, adapter.toUpperCase(Locale.ROOT));
        }
        else{
            cuSystemProps.put(AppConstants.EXTERNAL_SOLUTION_TYPE, "Adapter");
        }
        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        return changeUnitDao.getAllCUs(cuSystemProps, query, pageable, authBean);

    }

    public void checkCUName(String integration) {
        ChangeUnit changeUnit = changeUnitDao.getChangeUnitByName(integration, authBean);
        if(changeUnit!=null && changeUnit.getId()!=null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "ValidationErrors: [Error]: Adapter already exists in the system with name: " + integration, null);
     
    }

    public TenantChangeUnitInput saveIntegration(CUPropsDto cuPropsDto) throws NSLException {

        String cuName = cuPropsDto.getCuName();

        Agent agent = new Agent();
        if (cuPropsDto.getIsMachineCU())
            agent.setAgentType("machine");
        else agent.setAgentType("human");

        TenantChangeUnitInput changeUnit = new TenantChangeUnitInput();
        changeUnit.setName(cuName);
        changeUnit.setDisplayName(cuName);
        changeUnit.setReserved(true);
        changeUnit.setReservedCUType(EXTERNAL_SOLUTION_PREFIX + cuName);
        changeUnit.setStatus(StatusEnum.DRAFT);
        changeUnit.setAgents(Collections.singletonList(agent));
        changeUnit.setLayers(buildLayers(cuPropsDto));
        changeUnit.setCuSystemProperties(cuPropsDto.getCuSystemProps());

        LOGGER.info("Adding IRDR rights ");
        irdrUtils.setIRDR(changeUnit);
        LOGGER.info("calling dsd-bets-store to save cu");
        return saveBetsService.saveChangeUnit(changeUnit);

    }

    public CUPropsDto getIntegrationById(String dsdId) throws NSLException {
        TenantChangeUnitInput changeUnit = saveBetsService.findChangeUnitById(dsdId);
        return buildCuProps(changeUnit);
    }

    public TenantChangeUnitInput updateIntegration(String dsdId, CUPropsDto newCuPropsDto) throws NSLException {

        TenantChangeUnitInput changeUnit = saveBetsService.findChangeUnitById(dsdId);
        if (changeUnit.getStatus() == PUBLISHED)
            changeUnit = saveBetsService.getEditChangeUnit(dsdId);

        changeUnit.setLayers(buildLayers(newCuPropsDto));
        changeUnit.setCuSystemProperties(newCuPropsDto.getCuSystemProps());

        return saveBetsService.saveChangeUnit(changeUnit);

    }

    private List<TenantCULayerInput> buildLayers(CUPropsDto cuPropsDto){

        List<TenantCULayerInput> layers = new ArrayList<>();

        if (cuPropsDto.getPhysicalLayerItems() != null) {
            TenantCULayerInput physicalLayer = new TenantCULayerInput();
            physicalLayer.setType(LayerType.PHYSICAL);
            physicalLayer.setParticipatingItems(cuPropsDto.getPhysicalLayerItems());
            layers.add(physicalLayer);
        }

        if (cuPropsDto.getTriggerCESLayerItems() != null) {
            TenantCULayerInput triggerCESLayer = new TenantCULayerInput();
            triggerCESLayer.setType(LayerType.TRIGGERCES);
            triggerCESLayer.setParticipatingItems(cuPropsDto.getTriggerCESLayerItems());
            layers.add(triggerCESLayer);
        }

        if (cuPropsDto.getInformationLayerItems() != null) {
            TenantCULayerInput informationLayer = new TenantCULayerInput();
            informationLayer.setType(LayerType.INFORMATION);
            informationLayer.setParticipatingItems(cuPropsDto.getInformationLayerItems());
            layers.add(informationLayer);
        }


        return layers;

    }

    private CUPropsDto buildCuProps(TenantChangeUnitInput changeUnit) {

        CUPropsDto cuPropsDto = new CUPropsDto();
        cuPropsDto.setCuName(changeUnit.getName());
        cuPropsDto.setCuSystemProps(changeUnit.getCuSystemProperties());
        List<TenantCULayerInput> layers = changeUnit.getLayers();
        for (TenantCULayerInput layer:layers){
            switch (layer.getType()){
                case PHYSICAL:
                    cuPropsDto.setPhysicalLayerItems(layer.getParticipatingItems());
                    break;
                case TRIGGERCES:
                    cuPropsDto.setTriggerCESLayerItems(layer.getParticipatingItems());
                    break;
                case INFORMATION:
                    cuPropsDto.setInformationLayerItems(layer.getParticipatingItems());
                    break;
                default:
            }
        }
        return cuPropsDto;
    }

}
