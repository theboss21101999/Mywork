package com.nsl.adapter.commons.dto.connections;

public class ActiveMQAdapterConnectionDto extends BasicAdapterConnection {

    String brokerURL;
    MQCredential authentication;

    public String getBrokerURL() {
        return brokerURL;
    }

    public void setBrokerURL(String brokerURL) {
        this.brokerURL = brokerURL;
    }

    public MQCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(MQCredential authentication) {
        this.authentication = authentication;
    }

}

