package com.nsl.adapter.commons.utils.create_entity;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.Composite;
import ca.uhn.hl7v2.model.Group;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.model.Segment;
import ca.uhn.hl7v2.model.Structure;
import ca.uhn.hl7v2.model.Type;
import ca.uhn.hl7v2.parser.Parser;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.IRDRUtils;
import com.nsl.dsd.store.models.base.NslDataType;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityAttributeInput;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class CreateEntityFromHL7 extends CreateEntityUtil implements CreateEntityFromFile{

    public final Logger LOGGER = LoggerFactory.getLogger(CreateEntityFromHL7.class);

    @Autowired
    IRDRUtils irdrUtils;

    @Autowired
    SaveBetsService saveBetsService;

    @Qualifier("hapiParser")
    @Autowired
    Parser parser;

    @Override
    public TenantCUEntityInput convertFileIntoEntity(MultipartFile file, String entityName,Map<String,Object> PropertyMap) throws NSLException {

        LOGGER.info("fetching content from file");
        StringBuilder responseStrBuilder = new StringBuilder();
        try (BufferedReader streamReader = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
            String inputStr;
            while ((inputStr = streamReader.readLine()) != null)
                responseStrBuilder.append(inputStr).append("\r");
        }catch (Exception e){
            LOGGER.error("failed to read content from file",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"failed to read content from file"+
                    e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }

        LOGGER.info("parsing message");
        Message msg;
        try{
            msg = parser.parseForSpecificPackage(responseStrBuilder.toString(),"ca.uhn.hl7v2.model.v25.message");
        }catch (Exception e){
            LOGGER.error("failed to parse the message : ",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"failed to parse the message" +
                    e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }

        LOGGER.info("converting data to object");
        try {
            return createHl7Message(msg , entityName, entityName);
        }catch (Exception e){
            LOGGER.error("failed to create entity",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"failed to create entity" +
                    e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }
    }

    public TenantCUEntityInput createHl7Message(Group msg, String entityName,String displayName) throws HL7Exception, NSLException {

        TenantCUEntityInput generalEntity = new TenantCUEntityInput();
        generalEntity.setName(entityName);
        generalEntity.setDisplayName(displayName);
        List<TenantCUEntityAttributeInput> nslAttributeList = new ArrayList<>();

        for (String name: msg.getNames()){

            Structure structure = msg.get(name);
            if (structure.isEmpty()) continue;

            TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();
            nslAttribute.setName(name);
            nslAttribute.setDisplayName(name);

            Map<String, String> properties = new HashMap<>();
            properties.put(AppConstants.REFERENCINGTYPE, name);
            NslDataType attributeType;
            if (msg.isRepeating(name)) {
                attributeType = getNslDataType(AppConstants.LIST);
                Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE, getNslDataType(AppConstants.ENTITY));
                attributeType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);
            }
            else
                attributeType = getNslDataType(AppConstants.ENTITY);

            attributeType.setProperties(properties);
            nslAttribute.setAttributeType(attributeType);
            /**Create GE call*/
            nslAttribute.setGeneralEntity(createStructure(structure, entityName+"_"+name, name));


            nslAttributeList.add(nslAttribute);
        }
        generalEntity.setNslAttributes(nslAttributeList);
        generalEntity.setStatus(StatusEnum.DRAFT);
        irdrUtils.setGeIRDR(generalEntity);
        return saveBetsService.saveGeneralEntity(generalEntity);
    }

    private TenantCUEntityInput createStructure(Structure structure , String entityName , String displayName)throws HL7Exception, NSLException {

        if (structure instanceof Group)
            return createHl7Message((Group) structure, entityName, displayName);
        else if (structure instanceof Segment)
            return createSegment((Segment) structure, entityName, displayName);

        return null;
    }

    private TenantCUEntityInput createSegment(Segment segment, String entityName, String displayName ) throws HL7Exception,NSLException {

        TenantCUEntityInput generalEntity = new TenantCUEntityInput();
        generalEntity.setName(entityName);
        generalEntity.setDisplayName(displayName);
        List<TenantCUEntityAttributeInput> nslAttributeList = new ArrayList<>();

        String[] names = segment.getNames();
        for (int i=1 ; i<= names.length; i++) {

            String name = names[i-1].replaceAll("[^a-zA-Z0-9 ]"," ").trim();

            TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();
            nslAttribute.setName(name);
            nslAttribute.setDisplayName(name);

            boolean isRepeatable = repeatableCheckForField(segment.getClass(), name);
            Type type = segment.getField(i,0);

            if (type.isEmpty()) continue;

            NslDataType attributeType;
            if (type instanceof Composite){

                TenantCUEntityInput entity = createTypes((Composite) type, entityName+"_"+name,name, "");
                if(entity == null) continue;
                nslAttribute.setGeneralEntity(entity);

                Map<String, String> properties = new HashMap<>();
                properties.put(AppConstants.REFERENCINGTYPE, name);
                if (isRepeatable){
                    attributeType = getNslDataType(AppConstants.LIST);
                    Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                    nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE, getNslDataType(AppConstants.ENTITY));
                    attributeType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);
                }else
                    attributeType = getNslDataType(AppConstants.ENTITY);

                attributeType.setProperties(properties);

            } else if (isRepeatable){
                attributeType = getNslDataType(AppConstants.LIST);
                Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE, getNslDataType("String"));
                attributeType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);
                attributeType.setUiElement(getUiElementInfo("String"));

            }else {
                attributeType = getNslDataType("String");
                attributeType.setUiElement(getUiElementInfo("String"));
            }
            nslAttribute.setAttributeType(attributeType);
            nslAttributeList.add(nslAttribute);
        }
        generalEntity.setNslAttributes(nslAttributeList);
        generalEntity.setStatus(StatusEnum.DRAFT);
        irdrUtils.setGeIRDR(generalEntity);
        return saveBetsService.saveGeneralEntity(generalEntity);
    }

    private TenantCUEntityInput createTypes(Composite compositeType , String entityName, String displayName, String name) throws HL7Exception,NSLException {

        if (compositeType.isEmpty())
            return null;
        TenantCUEntityInput generalEntity = new TenantCUEntityInput();
        generalEntity.setName(entityName);
        generalEntity.setDisplayName(displayName);
        List<TenantCUEntityAttributeInput> nslAttributeList = new ArrayList<>();

        Type[] subTypes = compositeType.getComponents();
        HashMap<Integer, String> namesMap = getFieldNames(compositeType.getClass());

        for (int i=1; i < subTypes.length; i++){

            Type type = subTypes[i-1];
            if (type.isEmpty()) continue;

            String attributeName;
            if (name.isEmpty())
                attributeName = displayName+"_"+i;
            else
                attributeName = name+"_"+i;

            TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();
            nslAttribute.setName(attributeName);
            nslAttribute.setDisplayName(namesMap.get(i));


            NslDataType attributeType;
            if (type instanceof Composite){
                TenantCUEntityInput entity = createTypes((Composite) type, entityName +"_"+ i,namesMap.get(i),attributeName);
                if (entity == null) continue;
                nslAttribute.setGeneralEntity(entity);
                attributeType = getNslDataType(AppConstants.ENTITY);
                Map<String, String> attributeTypeProperties = new HashMap<>();
                attributeTypeProperties.put(AppConstants.REFERENCINGTYPE, displayName +"_"+ i);
                attributeType.setProperties(attributeTypeProperties);
            }else {
                attributeType = getNslDataType("String");
                attributeType.setUiElement(getUiElementInfo("String"));
            }

            nslAttribute.setAttributeType(attributeType);
            nslAttributeList.add(nslAttribute);
        }

        generalEntity.setNslAttributes(nslAttributeList);
        generalEntity.setStatus(StatusEnum.DRAFT);
        irdrUtils.setGeIRDR(generalEntity);
        return saveBetsService.saveGeneralEntity(generalEntity);

    }

    /*******************************************************/

    private HashMap<Integer, String> getFieldNames(Class<? extends Composite> composite) {

        HashMap<Integer,String> hm = new HashMap<>();

        int nameLength = composite.getSimpleName().length();

        Method[] methods = composite.getDeclaredMethods();
        for (Method method: methods){

            String methodName =method.getName();

            if (methodName.contains("_")){
                int pos =methodName.indexOf('_');
                hm.put(Integer.valueOf(methodName.substring(3+nameLength,pos)), methodName.substring(pos+1));
            }
        }
        return hm;
    }

    public boolean repeatableCheckForField(Class<? extends Segment> classObj , String fieldName){

        try {
            Class<?>[] inputParams = new Class[1];
            inputParams[0] = int.class;
            String methodName = "get"+ fieldName.replaceAll(" ","");
            classObj.getDeclaredMethod(methodName, inputParams);
            return true;
        }catch (Exception e){
            return false;
        }
    }

}
