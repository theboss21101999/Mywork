package com.nsl.adapter.commons.dto.connections;

import com.nsl.adapter.commons.enums.ApiKeyLocation;

public class ApiKeyCredentials {

    private String key;
    private String value;
    private ApiKeyLocation location;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public ApiKeyLocation getLocation() {
        return location;
    }

    public void setLocation(ApiKeyLocation location) {
        this.location = location;
    }
}
