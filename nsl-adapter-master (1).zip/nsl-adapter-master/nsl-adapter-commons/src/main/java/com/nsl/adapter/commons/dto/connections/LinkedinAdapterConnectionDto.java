package com.nsl.adapter.commons.dto.connections;

import java.util.List;

public class LinkedinAdapterConnectionDto extends BasicAdapterConnection{
    String appId;
    String appSecret;
    String accessToken;
    List<String> scope;

    public LinkedinAdapterConnectionDto() {
    }

    public LinkedinAdapterConnectionDto(String appId, String appSecret, String accessToken, List<String> scope) {
        this.appId = appId;
        this.appSecret = appSecret;
        this.accessToken = accessToken;
        this.scope = scope;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public List<String> getScope() {
        return scope;
    }

    public void setScope(List<String> scope) {
        this.scope = scope;
    }
}
