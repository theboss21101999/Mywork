package com.nsl.adapter.commons.dto.Integrations.dto;

import com.nsl.adapter.commons.dto.AdapterScheduleReq;
import com.nsl.adapter.commons.dto.DynamicGsiRouteDto;
import com.nsl.adapter.commons.dto.Integrations.model.ImapIntegration;


public class POP3AdapterDTO {
    private Long configEntityRecordId;
    private String configEntityRecordName;
    private AdapterScheduleReq scheduleReq;
    public Long getConfigEntityRecordId() {
        return configEntityRecordId;
    }

    public void setConfigEntityRecordId(Long configEntityRecordId) {
        this.configEntityRecordId = configEntityRecordId;
    }

    public String getConfigEntityRecordName() {
        return configEntityRecordName;
    }

    public void setConfigEntityRecordName(String configEntityRecordName) {
        this.configEntityRecordName = configEntityRecordName;
    }

    public AdapterScheduleReq getScheduleReq() {
        return scheduleReq;
    }

    public void setScheduleReq(AdapterScheduleReq scheduleReq) {
        this.scheduleReq = scheduleReq;
    }


}
