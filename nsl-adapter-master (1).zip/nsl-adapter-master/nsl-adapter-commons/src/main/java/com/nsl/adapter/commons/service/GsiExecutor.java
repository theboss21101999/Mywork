package com.nsl.adapter.commons.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.model.CUExecutionDto;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Objects;
import static org.springframework.http.HttpHeaders.ACCEPT_LANGUAGE;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpHeaders.REFERER;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Service
public class GsiExecutor {

    private static final Logger LOGGER = LoggerFactory.getLogger(GsiExecutor.class);

    @Value("${sftp.adapter.gsi.execution.url}")
    String executionUrl;

    @Value("${app.env.url}")
    String refererUrl;

    @Value("${sftp.adapter.system.user.token.url}")
    String sysUserTokenUrl;


    @Autowired
    RestTemplate restTemplate;

    public void executeGsiSync(Long gsiId, String tenantId, String userEmail, TxnData txnData){
        HttpHeaders headers = getHeaders(tenantId , userEmail);
        JSONObject transactionObject = getTransactionId(gsiId, headers);
        ResponseEntity<String> response = executeGsi(transactionObject, txnData, gsiId, headers);
        LOGGER.info("GSI invoked successfully.. Response received : {} ", response.getBody());
    }

    public String executeGsiAsync(Long gsiId, String tenantId, String userEmail, TxnData txnData){
        HttpHeaders headers = getHeaders(tenantId , userEmail);
        JSONObject transactionObject = getTransactionId(gsiId, headers);
        JSONObject responseResult = (JSONObject) transactionObject.get("result");
        String transactionId = JacksonUtils.getObjectFromJsonString(responseResult.get("transId").toString(), String.class);
        LOGGER.info("Transaction id : {}", transactionId);
        executeGsiPostTransactionId(gsiId, headers, txnData, transactionObject);
        return transactionId;
    }
    @Async("commonGsiExecutor")
    public void executeGsi(Long gsiId, String tenantId, String userEmail, TxnData txnData){
        HttpHeaders headers = getHeaders(tenantId , userEmail);
        JSONObject transactionObject = getTransactionId(gsiId, headers);
        ResponseEntity<String> response = executeGsi(transactionObject, txnData, gsiId, headers);
        LOGGER.info("GSI invoked successfully.. Response received : {} ", response.getBody());
    }

    @Async("commonGsiExecutionInitiator")
    public void executeGsiPostTransactionId(Long gsiId, HttpHeaders headers, TxnData txnData, JSONObject transactionObject){
        ResponseEntity<String> response = executeGsi(transactionObject, txnData, gsiId, headers);
        LOGGER.info("GSI invoked successfully.. Response received : {} ", response.getBody());
    }

    public JsonNode executeGsiResponse(Long gsiId, AuthenticatedUserDetailsImpl authBean, TxnData txnData)
            throws JsonProcessingException {
        HttpHeaders headers = getHeaders(authBean);
        JSONObject transactionObject = getTransactionId(gsiId, headers);
        ResponseEntity<String> response = executeGsi(transactionObject, txnData, gsiId,headers);
        LOGGER.info("GSI invoked successfully.. Response received : {} ", response.getBody());
        JsonNode result = new ObjectMapper().readTree(response.getBody());
        return result.get("result");
    }

    private ResponseEntity<String> executeGsi(JSONObject initialResponse, TxnData txnData, Long gsiId,
                                                                                            HttpHeaders headers) {
        JSONObject responseResult = (JSONObject) initialResponse.get("result");
        TriggerCU triggerCu = JacksonUtils.readTypeWrappedTCuJsonString(responseResult.get("nextTriggerCU").toString());
        String transactionId = responseResult.get("transId").toString();
        LOGGER.info("Received transaction id : {}", transactionId);
        txnData.setTransactionId(transactionId);
        txnData.setCuContextualId(triggerCu.getContextualId().get(0));
        CUExecutionDto dto = getCuExecutionDto(triggerCu, txnData, transactionId, gsiId);
        HttpEntity<Object> cuHttp1 = new HttpEntity<>(JacksonUtils.toJson(dto), headers);
        LOGGER.info("Triggering GSI having transaction id : {}", transactionId);
        return restTemplate.exchange(executionUrl, HttpMethod.POST, cuHttp1, String.class);
    }

    private CUExecutionDto getCuExecutionDto(TriggerCU triggerCu, TxnData txnData, String transactionId, Long gsiId) {
        CUExecutionDto dto = new CUExecutionDto();
        dto.setTransID(transactionId);
        dto.setTxnData(txnData);
        dto.setTriggerCuId(triggerCu.getId());
        dto.setGsiId(gsiId);
        return dto;
    }

    public JSONObject getTransactionId(Long gsiId, HttpHeaders headers) {
        LOGGER.info("Requesting transaction id..");
        CUExecutionDto dto = new CUExecutionDto();
        dto.setGsiId(gsiId);
        HttpEntity<CUExecutionDto> cuHttp = new HttpEntity<>(dto,headers);
        ResponseEntity<String> cUResponse = restTemplate.exchange(executionUrl, HttpMethod.POST, cuHttp, String.class);
        return new JSONObject(Objects.requireNonNull(cUResponse.getBody()));
    }

    public HttpHeaders getHeaders(String tenantId, String userEmail){
        HttpHeaders coreHeaders = new HttpHeaders();
        coreHeaders.add(AUTHORIZATION, AppConstants.BEARER + getAccessToken());
        coreHeaders.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        coreHeaders.add(ACCEPT_LANGUAGE, AppConstants.ACCEPT_LANGUAGE_EN);
        coreHeaders.add(REFERER, refererUrl);
        coreHeaders.add(AppConstants.SYSTEM_USER_DETAILS, tenantId+ ":"+ userEmail);
        return coreHeaders;
    }

    private String getAccessToken() {
        HttpEntity<String> tkHttp = new HttpEntity<>("", new HttpHeaders());
        ResponseEntity<String> tokenResp = restTemplate.exchange(sysUserTokenUrl, HttpMethod.GET, tkHttp, String.class);
        JSONObject tkResponseJSON = new JSONObject(Objects.requireNonNull(tokenResp.getBody()));
        return ((JSONObject) tkResponseJSON.get("result")).get("access_token").toString();
    }

    private HttpHeaders getHeaders(AuthenticatedUserDetailsImpl authBean){
        HttpHeaders coreHeaders = new HttpHeaders();
        coreHeaders.add(AUTHORIZATION, AppConstants.BEARER + authBean.getAuthToken());
        coreHeaders.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        coreHeaders.add(ACCEPT_LANGUAGE, AppConstants.ACCEPT_LANGUAGE_EN);
        coreHeaders.add(REFERER, refererUrl);
        if (authBean.isSystemUser() && authBean.getTenantId()!= null && authBean.getEmailId()!= null)
            coreHeaders.add(AppConstants.SYSTEM_USER_DETAILS,authBean.getTenantId()+ ":"+ authBean.getEmailId());

        return coreHeaders;
    }

}
