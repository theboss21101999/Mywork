package com.nsl.adapter.commons.dto;

public class ContextualInfoDto {
    String TimeStamp;
    String FileName;
    String SuccessFullRecords;
    String ErrorRecords;
    String Adapter;

    public String getTimeStamp() {
        return TimeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        TimeStamp = timeStamp;
    }

    public String getFileName() {
        return FileName;
    }

    public void setFileName(String fileName) {
        FileName = fileName;
    }

    public String getSuccessFullRecords() {
        return SuccessFullRecords;
    }

    public void setSuccessFullRecords(String successFullRecords) {
        SuccessFullRecords = successFullRecords;
    }

    public String getErrorRecords() {
        return ErrorRecords;
    }

    public void setErrorRecords(String errorRecords) {
        ErrorRecords = errorRecords;
    }

    public String getAdapter() {
        return Adapter;
    }

    public void setAdapter(String adapter) {
        Adapter = adapter;
    }
}
