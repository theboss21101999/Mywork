package com.nsl.adapter.commons.utils.entity;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.Composite;
import ca.uhn.hl7v2.model.Group;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.model.Primitive;
import ca.uhn.hl7v2.model.Segment;
import ca.uhn.hl7v2.model.Structure;
import ca.uhn.hl7v2.model.Type;
import ca.uhn.hl7v2.parser.Parser;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Component
public class Hl7ToEntity {

    public final Logger LOGGER = LoggerFactory.getLogger(Hl7ToEntity.class);

    @Qualifier("hapiParser")
    @Autowired
    Parser parser;

    public JSONObject readHl7Message(String orr_002) throws HL7Exception, JSONException, NSLException {

        Message msg;
        try {
            msg = parser.parse(orr_002);
        }catch (Exception e){
            LOGGER.error("failed to parse the message : ",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"failed to parse the message",
                    ExceptionSeverity.BLOCKER, e);
        }

        return readGroup(msg);
    }

    private JSONObject readGroup(Group msg) throws HL7Exception, JSONException {

        JSONObject orrObject = new JSONObject();
        for (String name: msg.getNames()){

            if (msg.isRepeating(name)) {
                Structure[] structures = msg.getAll(name);
                JSONArray array = new JSONArray();
                for (Structure structure:structures){
                    array.put(readStructure(structure));
                }
                orrObject.put(name,array);
            }else {
                Structure structure = msg.get(name);
                if (structure.isEmpty()) continue;
                orrObject.put(name, readStructure(structure));
            }
        }

        return orrObject;
    }

    private JSONObject readStructure(Structure structure )throws HL7Exception, JSONException {


        if (structure instanceof Group)
            return readGroup((Group) structure);
        else if (structure instanceof Segment)
            return readSegment((Segment) structure);

        return new JSONObject();
    }

    private JSONObject readSegment(Segment segment ) throws HL7Exception, JSONException {

        JSONObject object = new JSONObject();
        String[] names = segment.getNames();
        for (int i=1 ; i<= names.length; i++){
            String name = names[i-1].replaceAll("[^a-zA-Z0-9 ]"," ");

            if (repeatableCheckForField(segment.getClass(),name)){
                JSONArray array = new JSONArray();
                for (Type type :segment.getField(i)) {
                    array.put(readTypes(type, name));
                }
                if (array.length()!=0)
                    object.put(name,array);
            }else
                object.put(name, readTypes(segment.getField(i,0), name));
        }
        return object;
    }


    private Object readTypes(Type type , String name) throws HL7Exception, JSONException {


        if (type instanceof Primitive) {
            Primitive primitiveType = (Primitive) type;
            return primitiveType.getValue();
        } else if (type instanceof Composite) {
            Composite compositeType = (Composite) type;

            if (compositeType.isEmpty())
                return null;

            Type[] subTypes = compositeType.getComponents();
            JSONObject object= new JSONObject();
            for (int i=0; i < subTypes.length; i++){
                String subTypeName = name +"_"+ (i+1);
                object.put(subTypeName, readTypes(subTypes[i],subTypeName));
            }
            return object;
        }

        return type.encode();
    }


    public boolean repeatableCheckForField(Class classObj , String fieldName){

        try {
            Class[] inputParams = new Class[1];
            inputParams[0] = int.class;
            String methodName = "get"+ fieldName.replaceAll(" ","");
            Method method = classObj.getDeclaredMethod(methodName, inputParams);
            return true;
        }catch (Exception e){
            return false;
        }
    }
}
