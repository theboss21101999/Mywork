package com.nsl.adapter.commons.dto.Integrations.dto;

import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.logical.enums.StatusEnum;

import java.util.Date;

public class ViewCUDto {

    String name;
    String dsdId;
    StatusEnum statusEnum;
    AdapterType adapterType;
    Date createdAt;
    Date updatedAt;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDsdId() {
        return dsdId;
    }

    public void setDsdId(String dsdId) {
        this.dsdId = dsdId;
    }

    public StatusEnum getStatusEnum() {
        return statusEnum;
    }

    public void setStatusEnum(StatusEnum statusEnum) {
        this.statusEnum = statusEnum;
    }

    public AdapterType getAdapterType() {
        return adapterType;
    }

    public void setAdapterType(AdapterType adapterType) {
        this.adapterType = adapterType;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
}
