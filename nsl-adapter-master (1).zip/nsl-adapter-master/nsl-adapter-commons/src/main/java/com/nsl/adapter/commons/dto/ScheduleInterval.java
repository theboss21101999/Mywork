package com.nsl.adapter.commons.dto;

public enum ScheduleInterval {
    SECOND, MINUTE, HOUR, DAY, WEEK, MONTH, WEEKLY, MONTHLY, DAILY, YEARLY
}
