package com.nsl.adapter.commons.dto.Integrations.dto;

public class RestOutputAdapterDto {
    private Long infoEntityId;

    public RestOutputAdapterDto() {
    }

    public Long getInfoEntityId() {
        return infoEntityId;
    }

    public void setInfoEntityId(Long infoEntityId) {
        this.infoEntityId = infoEntityId;
    }
}
