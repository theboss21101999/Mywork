package com.nsl.adapter.commons.enums;

public enum ConnectionStatus {
    VALID,
    INVALID;
}
