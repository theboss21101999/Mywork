package com.nsl.adapter.commons.dto.Integrations.model;

public class ImapConstant {

    public static final String DEFAULT_FOLDER = "INBOX";
    public static final String SEARCH_CRITERIA = "searchCriteria";
    public static final String POST_READ_ACTIONS = "postReadActions";




}
