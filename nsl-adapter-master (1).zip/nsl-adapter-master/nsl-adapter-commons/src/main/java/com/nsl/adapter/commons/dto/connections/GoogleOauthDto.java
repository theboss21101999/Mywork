package com.nsl.adapter.commons.dto.connections;

import java.util.List;

public class GoogleOauthDto extends BasicAdapterConnection {

    private String clientId;
    private String clientSecret;
    private List<String> scope;
    private String applicationName;
    private String refreshToken;
    private String Jobid;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public List<String> getScope() {
        return scope;
    }

    public void setScope(List<String> scope) {
        this.scope = scope;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getJobid() {
        return Jobid;
    }

    public void setJobid(String jobid) {
        Jobid = jobid;
    }
}
