package com.nsl.adapter.commons.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.model.GSI;
import com.nsl.logical.model.GeneralEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Collections;
import java.util.List;

import static org.springframework.http.HttpHeaders.ACCEPT_LANGUAGE;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@Component
public class FileUploadUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileUploadUtil.class);

    @Autowired
    AdaptorCommonsProperties adaptorProperties;

    @Autowired
    RestTemplate restTemplate;

    public InputStream getContentFromUrl(String contentUrl, AuthenticatedUserDetailsImpl authBean) {
        try {
            LOGGER.info("fetching data from DSD Url");
            URLConnection connection = new URL(contentUrl).openConnection();  //NOSONAR
            connection.setRequestProperty(AUTHORIZATION, AppConstants.BEARER + authBean.getAuthToken());
            return connection.getInputStream(); //NOSONAR
        } catch (IOException ignore) {
            LOGGER.error("failed to read data from url");
            return null;
        }
    }

    public String getDsdFolderPath(GSI gsi, GeneralEntity fileEntity, int attributeIndex){

        return String.join(",", "txn", gsi.getName(), gsi.getSolutionLogic().get(0).getName(),
                    fileEntity.getId().toString(),fileEntity.getNslAttributes().get(attributeIndex).getId().toString());
    }

    public JsonNode uploadSingleFile(File file, String folder, AuthenticatedUserDetailsImpl authUser) {

        if (file == null) {
            LOGGER.error("No file received to upload");
            return null;
        }

        JsonNode result;

        String url = adaptorProperties.getAppDsdSingleFileUploadUrl();
        HttpHeaders headers = generateHeaderForFileUpload(authUser);

        FileSystemResource fileSystemSource = new FileSystemResource(file); //NOSONAR
        MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
        map.add("file", fileSystemSource);
        map.add("folders", folder);

        HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(map, headers);
        try {

            ResponseEntity<JsonNode> response = restTemplate.exchange(url, HttpMethod.POST, httpEntity, JsonNode.class);
            result = response.getBody();
            LOGGER.info("uploaded a file to dsd" + response.getBody());

        } catch (Exception e) {
            LOGGER.error("Exception while uploading file {}", file.getName(), e);
            return null;
        }

        return result;
    }

    public JsonNode uploadMultipleFiles(List<File> files, String folder, AuthenticatedUserDetailsImpl authUser) {

        if (files == null) {
            LOGGER.error("No file received to upload");
            return null;
        }

        String url = adaptorProperties.getAppDsdMultiFilesUploadUrl();
        HttpHeaders headers = generateHeaderForFileUpload(authUser);

        MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
        map.add("files", files);
        map.add("folders", folder);

        HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(map, headers);

        try {

            ResponseEntity<JsonNode> response = restTemplate.exchange(url, HttpMethod.POST, httpEntity, JsonNode.class);
            return response.getBody() != null ? response.getBody().get("result") : null;  //NOSONAR

        } catch (Exception e) {
            LOGGER.error("Exception while uploading list of files", e);
            return null;
        }

    }

    private HttpHeaders generateHeaderForFileUpload(AuthenticatedUserDetailsImpl authUser) {

        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.add(AUTHORIZATION, "Bearer " + authUser.getAuthToken());
        headers.add(ACCEPT_LANGUAGE, AppConstants.ACCEPT_LANGUAGE_EN);
        if (authUser.isSystemUser()) {
            headers.add(AppConstants.SYSTEM_USER_DETAILS, authUser.getTenantId()+ ":"+ authUser.getEmailId());
        }
        return headers;
    }

    public long getContentSize(String contentUrl, AuthenticatedUserDetailsImpl authBean) {
        try {
            LOGGER.info("fetching data from DSD Url");
            URLConnection connection = new URL(contentUrl).openConnection();  //NOSONAR
            connection.setRequestProperty(AUTHORIZATION, AppConstants.BEARER + authBean.getAuthToken());
            return  connection.getContentLengthLong(); //NOSONAR

        } catch (IOException ignore) {
            LOGGER.error("failed to read data from url");
            return 0;
        }

    }
}
