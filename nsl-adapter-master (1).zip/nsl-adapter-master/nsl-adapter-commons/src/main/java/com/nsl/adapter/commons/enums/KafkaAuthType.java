package com.nsl.adapter.commons.enums;

public enum KafkaAuthType {
    SASL_PLAIN
}
