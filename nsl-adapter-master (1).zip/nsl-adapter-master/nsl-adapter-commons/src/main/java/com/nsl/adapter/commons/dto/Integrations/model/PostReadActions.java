package com.nsl.adapter.commons.dto.Integrations.model;

import com.nsl.common.utils.JacksonUtils;

import java.util.Properties;

public class PostReadActions {

    MoveToFolder moveToFolder;
    Boolean delete = Boolean.FALSE;
    Boolean dynamicFolder = Boolean.FALSE;
    Properties folderMap;
    Long aimlConnectionId;

    public MoveToFolder getMoveToFolder() {
        return moveToFolder;
    }

    public void setMoveToFolder(MoveToFolder moveToFolder) {
        this.moveToFolder = moveToFolder;
    }

    public Boolean getDelete() {
        return delete;
    }

    public void setDelete(Boolean delete) {
        this.delete = delete;
    }

    public Boolean getDynamicFolder() {
        return dynamicFolder;
    }

    public void setDynamicFolder(Boolean dynamicFolder) {
        this.dynamicFolder = dynamicFolder;
    }

    public Properties getFolderMap() {
        return folderMap;
    }

    public void setFolderMap(Properties folderMap) {
        this.folderMap = folderMap;
    }

    public Long getAimlConnectionId() {
        return aimlConnectionId;
    }

    public void setAimlConnectionId(Long aimlConnectionId) {
        this.aimlConnectionId = aimlConnectionId;
    }

    public static String buildString(PostReadActions postReadActions) {

        if(postReadActions==null)
            return "";


        return JacksonUtils.toJson(postReadActions);

    }

    public static PostReadActions buildActions(String postReadActionsString) {

        PostReadActions postReadActions = new PostReadActions();

        if(postReadActionsString==null || postReadActionsString.isEmpty())
            return postReadActions;

        postReadActions = JacksonUtils.fromJson(postReadActionsString, PostReadActions.class);

        return postReadActions;
    }
}
