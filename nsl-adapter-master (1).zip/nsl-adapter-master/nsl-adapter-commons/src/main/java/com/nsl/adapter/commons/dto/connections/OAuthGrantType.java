package com.nsl.adapter.commons.dto.connections;

public enum OAuthGrantType {
    CLIENTCREDENTIALS("Client Credentials"),
    AUTHORIZATIONCODE("Authorization Code"),
    AUTHORIZATIONCODE_PKCE("Authorization Code with PKCE"),
    PASSWORD("Password Credentials");
//    CLIENT_CREDENTIALS("client_credentials");

    private final String granttype;

    OAuthGrantType(String granttype) {
        this.granttype = granttype;
    }

    public String getGranttype() {
        return granttype;
    }
}
