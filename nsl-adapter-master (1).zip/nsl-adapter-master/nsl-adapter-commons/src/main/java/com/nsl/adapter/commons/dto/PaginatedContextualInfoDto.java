package com.nsl.adapter.commons.dto;

import com.nsl.adapter.commons.dto.ContextualInfoDto;

import java.util.List;

public class PaginatedContextualInfoDto {
    List<ContextualInfoDto> contextualInfoDtoList;
    Integer pageNumber;
    Integer pageSize;
    Long totalHits;
    Integer currentPageSize;
    Long totalPages;

    public List<ContextualInfoDto> getContextualInfoDtoList() {
        return contextualInfoDtoList;
    }

    public void setContextualInfoDtoList(List<ContextualInfoDto> contextualInfoDtoList) {
        this.contextualInfoDtoList = contextualInfoDtoList;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Long getTotalHits() {
        return totalHits;
    }

    public void setTotalHits(Long totalHits) {
        this.totalHits = totalHits;
    }

    public Integer getCurrentPageSize() {
        return currentPageSize;
    }

    public void setCurrentPageSize(Integer currentPageSize) {
        this.currentPageSize = currentPageSize;
    }

    public Long getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(Long totalPages) {
        this.totalPages = totalPages;
    }
}
