package com.nsl.adapter.commons.utils.create_entity;

import com.nsl.dsd.store.models.base.NslDataType;
import com.nsl.dsd.store.models.base.UIElementInfo;
import com.nsl.logical.enums.DataType;

public class CreateEntityUtil {

    protected static NslDataType getNslDataType(String dataType) {
        NslDataType nslDataType = new NslDataType();
        switch (dataType) {
            case "Entity":
                nslDataType.setType(DataType.ENTITY);
                break;
            case "List":
                nslDataType.setType(DataType.LIST);
                break;
            case "class java.lang.Integer":
            case "class java.lang.Long":
                nslDataType.setType(DataType.NUMBER);
                break;
            case "class java.lang.Boolean":
                nslDataType.setType(DataType.BOOLEAN);
                break;
            case "class java.lang.Double":
                nslDataType.setType(DataType.FLOAT);
                break;
            default:
                nslDataType.setType(DataType.STRING);
                break;
        }
        return nslDataType;
    }

    protected static UIElementInfo getUiElementInfo(String dataTypeInformation) {
        UIElementInfo uiElementInfo = new UIElementInfo();
        switch (dataTypeInformation) {

            case "class java.lang.Integer":
            case "class java.lang.Long":
            case "integer":
                uiElementInfo.setName("Number");
                uiElementInfo.setUiElement("number");
                uiElementInfo.setDataType("number");
                uiElementInfo.setIsMulti(Boolean.FALSE);
                break;
            case "class java.lang.Boolean":
            case "boolean":
                uiElementInfo.setName("Boolean");
                uiElementInfo.setUiElement("boolean");
                uiElementInfo.setDataType("boolean");
                uiElementInfo.setIsMulti(Boolean.FALSE);
                break;
            case "class java.lang.Double":
                uiElementInfo.setName("Float");
                uiElementInfo.setUiElement("float");
                uiElementInfo.setDataType("float");
                uiElementInfo.setIsMulti(Boolean.FALSE);
                break;
            default:
                uiElementInfo.setName("Text");
                uiElementInfo.setUiElement("text");
                uiElementInfo.setDataType("string");
                uiElementInfo.setIsMulti(Boolean.FALSE);
                break;
        }
        return uiElementInfo;
    }


}
