package com.nsl.adapter.commons.dto.Integrations.dto;

public class SoapIntegrationDto {
    private String inputEntityDsdId;
    private String outputEntityDsdId;
    private boolean wsdlEnabled;
    private String wsdlURL;
    private boolean betStoreTCULayer;
    private String portName;
    private String serviceName;
    private String targetNameSpace;
    private String SOAPAction;
    private String dataFormat;
    private String extSolnsType;

    public SoapIntegrationDto() {
    }

    public String getInputEntityDsdId() {
        return inputEntityDsdId;
    }

    public void setInputEntityDsdId(String inputEntityDsdId) {
        this.inputEntityDsdId = inputEntityDsdId;
    }

    public String getOutputEntityDsdId() {
        return outputEntityDsdId;
    }

    public void setOutputEntityDsdId(String outputEntityDsdId) {
        this.outputEntityDsdId = outputEntityDsdId;
    }

    public boolean isWsdlEnabled() {
        return wsdlEnabled;
    }

    public void setWsdlEnabled(boolean wsdlEnabled) {
        this.wsdlEnabled = wsdlEnabled;
    }

    public String getWsdlURL() {
        return wsdlURL;
    }

    public void setWsdlURL(String wsdlURL) {
        this.wsdlURL = wsdlURL;
    }

    public boolean isBetStoreTCULayer() {
        return betStoreTCULayer;
    }

    public void setBetStoreTCULayer(boolean betStoreTCULayer) {
        this.betStoreTCULayer = betStoreTCULayer;
    }

    public String getPortName() {
        return portName;
    }

    public void setPortName(String portName) {
        this.portName = portName;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getTargetNameSpace() {
        return targetNameSpace;
    }

    public void setTargetNameSpace(String targetNameSpace) {
        this.targetNameSpace = targetNameSpace;
    }

    public String getDataFormat() {
        return dataFormat;
    }

    public void setDataFormat(String dataFormat) {
        this.dataFormat = dataFormat;
    }

    public String getSOAPAction() {
        return SOAPAction;
    }

    public void setSOAPAction(String SOAPAction) {
        this.SOAPAction = SOAPAction;
    }

    public String getExtSolnsType() {
        return extSolnsType;
    }

    public void setExtSolnsType(String extSolnsType) {
        this.extSolnsType = extSolnsType;
    }
}
