package com.nsl.adapter.commons.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

@Component
public class ThreadBeanUtil {

    @Value("${sftp.inbound.kafka.concurrency}")
    private Integer inboundKafkaConcurrency;

    @Value("${sftp.inbound.kafka.concurrency.queue.size}")
    private Integer inboundKafkaConcurrencyQueueSize;

    /**
     * Public Method.
     */
    public ThreadPoolTaskExecutor getThread(String threadName){
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(inboundKafkaConcurrency);
        executor.setMaxPoolSize(inboundKafkaConcurrency);
        executor.setQueueCapacity(inboundKafkaConcurrencyQueueSize);
        executor.setThreadNamePrefix(threadName);
        executor.initialize();
        return executor;
    }
}
