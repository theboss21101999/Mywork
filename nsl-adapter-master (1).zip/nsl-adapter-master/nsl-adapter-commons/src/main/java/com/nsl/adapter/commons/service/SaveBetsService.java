package com.nsl.adapter.commons.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.dsd.store.config.DSDStoreConfiguration;
import com.nsl.dsd.store.models.BindableGSI;
import com.nsl.dsd.store.models.DSDBETMetaIO;
import com.nsl.dsd.store.models.Page;
import com.nsl.dsd.store.models.tenant.io.TenantBookIO;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import com.nsl.dsd.store.models.tenant.io.TenantGSIInput;
import com.nsl.dsd.store.models.tenant.io.TenantGSIOutput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dto.response.ResponseDTO;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.Book;
import org.apache.poi.ss.formula.functions.T;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.Resource;
import java.util.*;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;
import static org.springframework.http.HttpHeaders.ACCEPT_LANGUAGE;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Service
public class SaveBetsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SaveBetsService.class);
    private static final String CALLRECEIVED = "Call received to save CU";
    public static final String CU_SAVED_SUCCESSFULLY = "CU saved successfully";

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authenticatedUserDetails;

    @Value("${dsd.url}")
    String dsdUrl;

    @Autowired
    @Qualifier("dsdRestTemplate")
    RestTemplate restTemplate;

    public TenantChangeUnitInput saveChangeUnit(TenantChangeUnitInput changeUnit) throws NSLException {

        LOGGER.info(CALLRECEIVED);
        String changeUnitUrl = dsdUrl + "/tenant/change-unit";
        HttpHeaders headers = getHeaders();

        try {
            String changeUnitJson = JacksonUtils.toJson(changeUnit);
            LOGGER.info("changeunit save : {}", changeUnitJson);
            HttpEntity<TenantCUEntityInput> httpEntity = new HttpEntity(changeUnitJson, headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.POST, httpEntity, ApiResponse.class);

            TenantChangeUnitInput changeUnitTwo = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)),
                    TenantChangeUnitInput.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
            return changeUnitTwo;
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while saving CU: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }

    public TenantGSIInput saveGSI(TenantGSIInput gsiInput) throws NSLException {

        LOGGER.info(CALLRECEIVED);
        String changeUnitUrl = dsdUrl + "/tenant/gsi";
        HttpHeaders headers = getHeaders();

        try {
            String gsiJson = JacksonUtils.toJson(gsiInput);
            LOGGER.info("GSI save : {}", gsiJson);
            HttpEntity<TenantCUEntityInput> httpEntity = new HttpEntity(gsiJson, headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.POST, httpEntity, ApiResponse.class);
            TenantGSIInput gsiTwo = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)),
                    TenantGSIInput.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
            return gsiTwo;
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while saving GSI: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }


    public TenantGSIInput finishGSI(TenantGSIInput gsiInput, boolean disableWarnings) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(dsdUrl + "/tenant/finish/gsi")
                .queryParam("disableWarnings", disableWarnings);
        String changeUnitUrl = builder.toUriString();
        HttpHeaders headers = getHeaders();

        try {
            String gsiJson = JacksonUtils.toJson(gsiInput);
            LOGGER.info("GSI finish : {}", gsiJson);
            HttpEntity<TenantCUEntityInput> httpEntity = new HttpEntity(gsiJson, headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.POST, httpEntity, ApiResponse.class);

            TenantGSIInput gsiTwo = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)),
                    TenantGSIInput.class);
            return gsiTwo;
        } catch (Exception e) {
            LOGGER.error("Exception while finish GSI: "+ e.getMessage());
            throw e;
        }
    }

    public ApiResponse approveGSI(TenantGSIInput gsiInput, String comment) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(dsdUrl + "/tenant/approve/gsi/"+gsiInput.getId());
        if (comment != null) builder.queryParam("comment", comment);
        String changeUnitUrl = builder.toUriString();
        HttpHeaders headers = getHeaders();

        try {
            String gsiJson = JacksonUtils.toJson(gsiInput);
            LOGGER.info("GSI approve : {}", gsiJson);
            HttpEntity<TenantCUEntityInput> httpEntity = new HttpEntity(gsiJson, headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.POST, httpEntity, ApiResponse.class);
            return response.getBody();
        } catch (Exception e) {
            LOGGER.error("Exception while approving GSI: "+ e.getMessage());
            throw e;
        }
    }


    public ApiResponse rejectGSI(TenantGSIInput gsiInput, String comment, Boolean cancelReview) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(dsdUrl + "/tenant/reject/gsi/"+gsiInput.getId());
        if (comment != null) builder.queryParam("comment", comment);
        if (cancelReview!=null) builder.queryParam("cancelReview", cancelReview);
        String changeUnitUrl = builder.toUriString();
        HttpHeaders headers = getHeaders();

        try {
            String gsiJson = JacksonUtils.toJson(gsiInput);
            LOGGER.info("GSI reject : {}", gsiJson);
            HttpEntity<TenantCUEntityInput> httpEntity = new HttpEntity(gsiJson, headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.POST, httpEntity, ApiResponse.class);
            return response.getBody();
        } catch (Exception e) {
            LOGGER.error("Exception while rejecting GSI: "+ e.getMessage());
            throw e;
        }
    }

    public TenantGSIInput publishGSI(TenantGSIInput gsiInput, boolean skipApproval) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(dsdUrl + "/tenant/publish/gsi")
                .queryParam("skipApproval", skipApproval);
        String changeUnitUrl = builder.toUriString();
        HttpHeaders headers = getHeaders();

        try {
            String gsiJson = JacksonUtils.toJson(gsiInput);
            LOGGER.info("GSI publish : {}", gsiJson);
            HttpEntity<TenantCUEntityInput> httpEntity = new HttpEntity(gsiJson, headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.POST, httpEntity, ApiResponse.class);

            TenantGSIInput gsiTwo = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)),
                    TenantGSIInput.class);
            return gsiTwo;
        } catch (Exception e) {
            LOGGER.error("Exception while publish GSI: " + e.getMessage());
            throw e;
        }
    }

    public TenantBookIO addGSIToBook(BindableGSI gsiInput, Long bookId) throws NSLException {

        LOGGER.info(CALLRECEIVED);
        String changeUnitUrl = dsdUrl + "/tenant/book/{dsdId}/gsi";
        Map<String, Object> uriVariables = new HashMap<>();
        uriVariables.put(AppConstants.DSD_ID, bookId);
        HttpHeaders headers = getHeaders();

        try {
            String gsiJson = JacksonUtils.toJson(gsiInput);
            LOGGER.info("GSI save : {}", gsiJson);
            HttpEntity<TenantCUEntityInput> httpEntity = new HttpEntity(gsiJson, headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.POST, httpEntity, ApiResponse.class, uriVariables);

            TenantBookIO book = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)),
                    TenantBookIO.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
            return book;
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while saving GSI: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }

    public TenantChangeUnitInput findChangeUnitById(String dsdId) throws NSLException {

        LOGGER.info(CALLRECEIVED);
        String changeUnitUrl = dsdUrl + "/tenant/change-unit/{dsdId}";
        Map<String, Object> uriVariables = new HashMap<>();
        uriVariables.put(AppConstants.DSD_ID, dsdId);
        HttpHeaders headers = getHeaders();

        TenantChangeUnitInput changeUnit;
        try {
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.GET,
                    new HttpEntity<>(headers), ApiResponse.class, uriVariables);
            changeUnit = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)), TenantChangeUnitInput.class);
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while fetching CU: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
        return changeUnit;
    }

    public TenantChangeUnitInput findGSIById(String dsdId) throws NSLException {

        LOGGER.info(CALLRECEIVED);
        String changeUnitUrl = dsdUrl + "/tenant/gsi/{dsdId}";
        Map<String, Object> uriVariables = new HashMap<>();
        uriVariables.put(AppConstants.DSD_ID, dsdId);
        HttpHeaders headers = getHeaders();

        TenantGSIInput tenantGSIInput;
        try {
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.GET,
                    new HttpEntity<>(headers), ApiResponse.class, uriVariables);

            tenantGSIInput = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)), TenantGSIInput.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while fetching CU: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
        return tenantGSIInput;
    }

    public TenantChangeUnitInput getEditChangeUnit(String dsdId) throws NSLException {

        LOGGER.info(CALLRECEIVED);
        String changeUnitUrl = dsdUrl + "/tenant/edit/change-unit/{dsdId}";
        Map<String, Object> uriVariables = new HashMap<>();
        uriVariables.put(AppConstants.DSD_ID, dsdId);
        HttpHeaders headers = getHeaders();

        try {
            HttpEntity<Object> httpEntity = new HttpEntity(new JSONObject(), headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.POST,
                    httpEntity, ApiResponse.class, uriVariables);
            TenantChangeUnitInput changeUnit = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)), TenantChangeUnitInput.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
            return changeUnit;
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while fetching CU: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }

    public TenantChangeUnitInput getTemplateReservedChangeUnitByName(String dsdId) throws NSLException {

        LOGGER.info(CALLRECEIVED);
        String changeUnitUrl = dsdUrl + "/change-unit/reserved/name/{dsdId}";
        Map<String, Object> uriVariables = new HashMap<>();
        uriVariables.put(AppConstants.DSD_ID, dsdId);
        HttpHeaders headers = getHeaders();

        try {
            HttpEntity<Object> httpEntity = new HttpEntity(new JSONObject(), headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.GET,
                    httpEntity, ApiResponse.class, uriVariables);

            TenantChangeUnitInput changeUnit = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)), TenantChangeUnitInput.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
            return changeUnit;
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while fetching CU: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }

    public TenantCUEntityInput getReservedEntityByName(String name) throws NSLException {
        LOGGER.info(CALLRECEIVED);
        String changeUnitUrl = dsdUrl + "/entity/reserved/name/{name}";
        Map<String, Object> uriVariables = new HashMap<>();
        uriVariables.put(AppConstants.NAME, name);
        HttpHeaders headers = getHeaders();

        try {
            HttpEntity<Object> httpEntity = new HttpEntity(new JSONObject(), headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.GET,
                    httpEntity, ApiResponse.class, uriVariables);

            TenantCUEntityInput entityInput = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)), TenantCUEntityInput.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
            return entityInput;
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while fetching CU: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }
    public TenantChangeUnitInput getTemplateReservedChangeUnitById(String dsdId) throws NSLException {
        LOGGER.info(CALLRECEIVED);
        String changeUnitUrl = dsdUrl + "/change-unit/reserved/fetch/{dsdId}";
        Map<String, Object> uriVariables = new HashMap<>();
        uriVariables.put(AppConstants.DSD_ID, dsdId);
        HttpHeaders headers = getHeaders();

        try {
            HttpEntity<Object> httpEntity = new HttpEntity(new JSONObject(), headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(changeUnitUrl, HttpMethod.GET,
                    httpEntity, ApiResponse.class, uriVariables);

            TenantChangeUnitInput changeUnit = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)), TenantChangeUnitInput.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
            return changeUnit;
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while fetching CU: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }

    public TenantBookIO saveBook(TenantBookIO book) throws NSLException {

        LOGGER.info("Call received to save book");
        String bookUrl = dsdUrl + "/tenant/book";
        HttpHeaders headers = getHeaders();
        HttpEntity<TenantBookIO> httpEntity = new HttpEntity(book, headers);

        try {
            ResponseEntity<ApiResponse> response = restTemplate.exchange(bookUrl, HttpMethod.POST, httpEntity, ApiResponse.class);

            TenantBookIO resultBook = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)), TenantBookIO.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
            return resultBook;
        } catch (Exception e) {
            LOGGER.error("Exception while saving Book", e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "Exception while saving Book:" + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }

    public TenantCUEntityInput saveGeneralEntity(TenantCUEntityInput generalEntity) throws NSLException {

        LOGGER.info("Call received to save Entity");
        String generalEntityUrl = dsdUrl + "/tenant/entity";
        HttpHeaders headers = getHeaders();
        HttpEntity<String> httpEntity = new HttpEntity(JacksonUtils.toJson(generalEntity), headers);

        try {
            ResponseEntity<ApiResponse> response = restTemplate.exchange(generalEntityUrl, HttpMethod.POST, httpEntity, ApiResponse.class);

            TenantCUEntityInput generalEntityTemp = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)), TenantCUEntityInput.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
            return generalEntityTemp;
        } catch (Exception e) {
            LOGGER.error("Exception while saving Entity", e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "Exception while saving Entity:" + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }

    public TenantCUEntityInput findEntityById(String inputEntityId) throws NSLException {
        String generalEntityUrl = dsdUrl + "/tenant/entity/{dsdId}";
        Map<String, Object> uriVariables = new HashMap<>();
        uriVariables.put(AppConstants.DSD_ID, inputEntityId);
        HttpHeaders headers = getHeaders();

        try {
            ResponseEntity<ApiResponse> response = restTemplate.exchange(generalEntityUrl, HttpMethod.GET,
                    new HttpEntity<Object>(headers), ApiResponse.class, uriVariables);
            TenantCUEntityInput generalEntity = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)), TenantCUEntityInput.class);
            LOGGER.info(CU_SAVED_SUCCESSFULLY);
            return generalEntity;
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "CU",
                    "Exception while fetching Entity: " + e,
                    ExceptionSeverity.MAJOR, e);
        }

    }

    private Object getResultfromBody(ResponseEntity<ApiResponse> response){
        Object result = null;
        ApiResponse resp = response.getBody();
        if (response.getBody()==null){
            return result;
        }
        result = resp.getResult();  //NOSONAR
        return result;
    }

    public TenantCUEntityInput getEntityByName(String entityName,AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {

        String baseUrl = dsdUrl + "/entity/reserved/name/" + entityName;

        HttpHeaders headers = getHeaders(authenticatedUserDetails);
        HttpEntity<String> httpEntity = new HttpEntity<>(headers);

        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(baseUrl, HttpMethod.GET, httpEntity, JsonNode.class);

            JsonNode jsonNode = response.getBody().get("result");  //NOSONAR
            return JacksonUtils.getObjectFromJsonString(jsonNode.toString(), TenantCUEntityInput.class);
        }catch (Exception e){
            LOGGER.error("Exception while fetching Entity: {}",e.getMessage());
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"Exception while fetching Entity: " + e, ExceptionSeverity.MAJOR, e);
        }

    }

    public TenantCUEntityInput getGeneralEntityByName(String entityName,AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {

        String baseUrl = dsdUrl + "/tenant/entity?query="+ entityName;

        HttpHeaders headers = getHeaders(authenticatedUserDetails);
        HttpEntity<String> httpEntity = new HttpEntity<>(headers);

        try {
            ResponseEntity<JsonNode> response = restTemplate.exchange(baseUrl, HttpMethod.GET, httpEntity, JsonNode.class);

            JsonNode jsonNode = response.getBody().get("result").get("data").get(0);  //NOSONAR
            return JacksonUtils.getObjectFromJsonString(jsonNode.toString(), TenantCUEntityInput.class);
        }catch (Exception e){
            LOGGER.error("Exception  while fetching Entity: {}",e.getMessage());
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"Exception while fetching Entity: " +
                    e, ExceptionSeverity.MAJOR, e);
        }

    }

    public TenantCUEntityInput getGeneralEntityByName(String entityName) throws NSLException {
        return getGeneralEntityByName(entityName,authenticatedUserDetails);
    }

    public TenantCUEntityInput getEntityByName(String entityName) throws NSLException {
        return getEntityByName(entityName,authenticatedUserDetails);
    }

    public PageImpl<TenantCUEntityInput> getMatchingEntity(String searchCriteria, Integer pageNumber,Integer pageSize,boolean isPublished){
        String geMatchingUrl = dsdUrl + "/tenant/entity";
        searchCriteria = searchCriteria!=null ? searchCriteria : "";
        geMatchingUrl = geMatchingUrl +"?" + "query="+searchCriteria + "&page="+ pageNumber+"&limit="+pageSize;
        if(isPublished){
            geMatchingUrl = geMatchingUrl + "&isPublished=" + true;
        }
        HttpHeaders headers = getHeaders(authenticatedUserDetails);

        try{
            ResponseEntity<ApiResponse> dsdResp = restTemplate.exchange(geMatchingUrl, HttpMethod.GET, new HttpEntity<Object>(headers), ApiResponse.class );
            Map resultOfEntities;
            resultOfEntities = (Map) getResultfromBody(dsdResp);
            List<Map> dsdEntities = (List<Map>) resultOfEntities.getOrDefault("data", new ArrayList<>());

            List<TenantCUEntityInput> respList = createEntityObject(dsdEntities);

            return new PageImpl<>(respList, PageRequest.of(pageNumber, pageSize), (Integer) resultOfEntities.get("totalResults"));
        }catch (Exception e) {
            LOGGER.error("Exception while fetching Entity List: {}",e.getMessage());
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.GENERAL_ENTITY,
                    "Exception while fetching matching entity list: " + e,
                    ExceptionSeverity.MAJOR, e);
        }
    }

    public TenantGSIInput cloneGSI(Long sourceGsiId, String gsiToCreate){
        LOGGER.info("In clone gsi for id {}" , sourceGsiId);
        String gsiUrl = dsdUrl + "/tenant/gsi/clone/" + sourceGsiId.toString();
        HttpHeaders headers = getHeaders();

        try {
            var gsiMetaInfo = new DSDBETMetaIO();
            gsiMetaInfo.setName(gsiToCreate);
            String requestJson = JacksonUtils.toJson(gsiMetaInfo);

            LOGGER.info("Clone GSI json : {}", requestJson);
            HttpEntity<TenantCUEntityInput> httpEntity = new HttpEntity(requestJson, headers);
            ResponseEntity<ApiResponse> response = restTemplate.exchange(gsiUrl, HttpMethod.POST, httpEntity, ApiResponse.class);
            TenantGSIInput clonedGSI = JacksonUtils.fromJson(JacksonUtils.toJson(getResultfromBody(response)),
                    TenantGSIInput.class);
            LOGGER.info("GSI with id  {} cloned successfully" , sourceGsiId);

            return clonedGSI;
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.CU_GSI, "GSI",
                    "Exception while cloning GSI: " + e, ExceptionSeverity.MAJOR, e);
        }
    }

    private HttpHeaders getHeaders(AuthenticatedUserDetailsImpl authenticatedUserDetails) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(AUTHORIZATION, AppConstants.BEARER+ authenticatedUserDetails.getAuthToken());
        headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        headers.add(ACCEPT_LANGUAGE, AppConstants.ACCEPT_LANGUAGE_EN);
        if (authenticatedUserDetails.isSystemUser() || authenticatedUserDetails.isSystemAdmin()){
            headers.add(AppConstants.SYSTEM_USER_DETAILS,
                    authenticatedUserDetails.getTenantId().concat(":").concat(authenticatedUserDetails.getEmailId()));
        }
        return headers;
    }

    private HttpHeaders getHeaders(){
        HttpHeaders headers = new HttpHeaders();
        headers.add(AUTHORIZATION, AppConstants.BEARER+ authenticatedUserDetails.getAuthToken());
        headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        headers.add(ACCEPT_LANGUAGE, AppConstants.ACCEPT_LANGUAGE_EN);
        return headers;
    }

    private List<TenantCUEntityInput> createEntityObject(List<Map> entityList){
        var dsdEntList = new ArrayList<TenantCUEntityInput>();

        if(!CollectionUtils.isEmpty(entityList)){
            entityList.forEach( entObj -> {
                var dsdEnt = new TenantCUEntityInput();
                dsdEnt.setName((String) entObj.get("name"));
                dsdEnt.setDisplayName((String) entObj.get("displayName"));
                dsdEnt.setStatus(StatusEnum.valueOf((String)entObj.get("status")));
                dsdEnt.setId((Long)entObj.get("id"));
                dsdEnt.setVersion((String)entObj.get("version"));
                dsdEnt.setReserved((boolean)entObj.get("isReserved"));
                dsdEnt.setOwnerId((Long)entObj.get("ownerId"));

                dsdEntList.add(dsdEnt);
            });
        }
        return dsdEntList;
    }
}