package com.nsl.adapter.commons.dto.connections;

public enum SFTPCredentialType {
    PASSWORD,
    KEY,
    KEYPASSWORD
}