package com.nsl.adapter.commons.dto.connections;

import java.util.List;

public class TwitterAdapterConnectionDto extends  BasicAdapterConnection {
    String CONSUMER_KEY;
    String CONSUMER_SECRET;
    String ACCESS_TOKEN_STR;
    String ACCESS_TOKEN_SECRET;

    public TwitterAdapterConnectionDto() {
    }

    public TwitterAdapterConnectionDto(String CONSUMER_KEY, String CONSUMER_SECRET, String ACCESS_TOKEN_STR, String ACCESS_TOKEN_SECRET) {
        this.CONSUMER_KEY = CONSUMER_KEY;
        this.CONSUMER_SECRET = CONSUMER_SECRET;
        this.ACCESS_TOKEN_STR = ACCESS_TOKEN_STR;
        this.ACCESS_TOKEN_SECRET = ACCESS_TOKEN_SECRET;
    }

    public String getCONSUMER_KEY() {
        return CONSUMER_KEY;
    }

    public void setCONSUMER_KEY(String CONSUMER_KEY) {
        this.CONSUMER_KEY = CONSUMER_KEY;
    }

    public String getCONSUMER_SECRET() {
        return CONSUMER_SECRET;
    }

    public void setCONSUMER_SECRET(String CONSUMER_SECRET) {
        this.CONSUMER_SECRET = CONSUMER_SECRET;
    }

    public String getACCESS_TOKEN_STR() {
        return ACCESS_TOKEN_STR;
    }

    public void setACCESS_TOKEN_STR(String ACCESS_TOKEN_STR) {
        this.ACCESS_TOKEN_STR = ACCESS_TOKEN_STR;
    }

    public String getACCESS_TOKEN_SECRET() {
        return ACCESS_TOKEN_SECRET;
    }

    public void setACCESS_TOKEN_SECRET(String ACCESS_TOKEN_SECRET) {
        this.ACCESS_TOKEN_SECRET = ACCESS_TOKEN_SECRET;
    }
}
