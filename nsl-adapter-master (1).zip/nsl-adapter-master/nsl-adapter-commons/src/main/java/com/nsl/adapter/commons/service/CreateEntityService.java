package com.nsl.adapter.commons.service;

import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;

import com.nsl.logical.exception.NSLException;
import org.springframework.web.multipart.MultipartFile;

import java.util.Map;


/** 
* The interface create entity service.
*/
public interface CreateEntityService {

    TenantCUEntityInput convertIntoEntity(String fileType, MultipartFile file, String entityName, Map<String,Object> PropertMap) throws NSLException;

}
