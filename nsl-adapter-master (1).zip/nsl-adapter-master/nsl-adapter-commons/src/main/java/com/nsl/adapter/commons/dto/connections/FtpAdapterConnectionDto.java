package com.nsl.adapter.commons.dto.connections;

public class FtpAdapterConnectionDto extends BasicAdapterConnection {
    private String host;
    private String port;
    private FtpCredential authentication;

    public FtpAdapterConnectionDto() {
    }

    public FtpAdapterConnectionDto(String host, String port, FtpCredential authentication) {
        this.host = host;
        this.port = port;
        this.authentication = authentication;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public FtpCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(FtpCredential authentication) {
        this.authentication = authentication;
    }
}
