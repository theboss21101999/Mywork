package com.nsl.adapter.commons.dto.Integrations.dto;

import com.nsl.adapter.commons.dto.AdapterScheduleReq;
import com.nsl.adapter.commons.dto.DynamicGsiRouteDto;
import com.nsl.adapter.commons.dto.Integrations.model.ImapIntegration;


public class IMAPAdapterDTO {
    private Long configEntityRecordId;
    private String configEntityRecordName;
    private ImapIntegration imapIntegration;
    private AdapterScheduleReq scheduleReq;
    private DynamicGsiRouteDto dynamicGsiReq;
    public Long getConfigEntityRecordId() {
        return configEntityRecordId;
    }

    public void setConfigEntityRecordId(Long configEntityRecordId) {
        this.configEntityRecordId = configEntityRecordId;
    }

    public String getConfigEntityRecordName() {
        return configEntityRecordName;
    }

    public void setConfigEntityRecordName(String configEntityRecordName) {
        this.configEntityRecordName = configEntityRecordName;
    }

    public ImapIntegration getImapIntegration() {
        return imapIntegration;
    }

    public void setImapIntegration(ImapIntegration imapIntegration) {
        this.imapIntegration = imapIntegration;
    }

    public AdapterScheduleReq getScheduleReq() {
        return scheduleReq;
    }

    public void setScheduleReq(AdapterScheduleReq scheduleReq) {
        this.scheduleReq = scheduleReq;
    }

    public DynamicGsiRouteDto getDynamicGsiReq() {
        return dynamicGsiReq;
    }

    public void setDynamicGsiReq(DynamicGsiRouteDto dynamicGsiReq) {
        this.dynamicGsiReq = dynamicGsiReq;
    }

}
