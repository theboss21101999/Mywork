package com.nsl.adapter.commons.dto.connections;

import org.springframework.web.multipart.MultipartFile;

public class AS2AdapterConnectionDto extends BasicAdapterConnection  {

    private String targetHostname;
    private String targetPortNumber;
    private String requestUri;

    public String getTargetHostname() {
        return targetHostname;
    }

    public void setTargetHostname(String targetHostname) {
        this.targetHostname = targetHostname;
    }

    public String getTargetPortNumber() {
        return targetPortNumber;
    }

    public void setTargetPortNumber(String targetPortNumber) {
        this.targetPortNumber = targetPortNumber;
    }

    public String getRequestUri() {
        return requestUri;
    }

    public void setRequestUri(String requestUri) {
        this.requestUri = requestUri;
    }
}
