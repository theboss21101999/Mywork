package com.nsl.adapter.commons.dto.Integrations.model;

import java.util.Collections;
import java.util.List;

public class ImapIntegration {

    List<SearchCriteria> searchCriteria;
    PostReadActions postReadActions;

    public List<SearchCriteria> getSearchCriteria() {
        return searchCriteria;
    }

    public void setSearchCriteria(List<SearchCriteria> searchCriteria) {
        this.searchCriteria = searchCriteria;
    }

    public PostReadActions getPostReadActions() {
        return postReadActions;
    }

    public void setPostReadActions(PostReadActions postReadActions) {
        this.postReadActions = postReadActions;
    }
}
