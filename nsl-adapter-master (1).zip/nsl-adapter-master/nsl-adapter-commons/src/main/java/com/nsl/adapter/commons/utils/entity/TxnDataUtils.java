package com.nsl.adapter.commons.utils.entity;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.model.*;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class TxnDataUtils {

    public TxnData setChangeDriverInTxnData(ChangeDriverData changeDriverDataTriggerCES, LayerType layerType) {
        TxnData result = new TxnData();
        List<TxnCULayer> transactionCULayerList = new ArrayList<>();
        TxnCULayer transactionCULayer = new TxnCULayer();
        List<TxnSlotItem> slots = new ArrayList<>();
        TxnSlotItem slot1 = new TxnSlotItem();
        slot1.setItem(changeDriverDataTriggerCES);
        slots.add(slot1);
        transactionCULayer.setTxnSlotItems(slots);
        transactionCULayer.setType(layerType);
        transactionCULayerList.add(transactionCULayer);
        result.setTxnCULayer(transactionCULayerList);
        return result;
    }

    public TxnData setChangeDriverInTxnData(ChangeDriverData changeDriverDataTriggerCES, LayerType layerType,boolean isMultivalue) {
        TxnData result = new TxnData();
        List<TxnCULayer> transactionCULayerList = new ArrayList<>();
        TxnCULayer transactionCULayer = new TxnCULayer();
        List<TxnSlotItem> slots = new ArrayList<>();
        TxnSlotItem slot1 = new TxnSlotItem();
        slot1.setItem(changeDriverDataTriggerCES);
        slot1.setIsMultiValue(isMultivalue);
        slots.add(slot1);
        transactionCULayer.setTxnSlotItems(slots);
        transactionCULayer.setType(layerType);
        transactionCULayerList.add(transactionCULayer);
        result.setTxnCULayer(transactionCULayerList);
        return result;
    }

    public TxnData setChangeDriverInTxnData(List<ChangeDriverData> changeDriverDataTriggerCESList, LayerType layerType) {
        TxnData result = new TxnData();
        List<TxnCULayer> transactionCULayerList = new ArrayList<>();
        TxnCULayer transactionCULayer = new TxnCULayer();
        List<TxnSlotItem> slots = new ArrayList<>();

        for (ChangeDriverData changeDriverDataTriggerCES :changeDriverDataTriggerCESList) {
            TxnSlotItem slot = new TxnSlotItem();
            slot.setItem(changeDriverDataTriggerCES);
            slots.add(slot);
        }

        transactionCULayer.setTxnSlotItems(slots);
        transactionCULayer.setType(layerType);
        transactionCULayerList.add(transactionCULayer);
        result.setTxnCULayer(transactionCULayerList);
        return result;
    }

    public TxnData OutputtoEntityMapping(TriggerCU triggerCu, JsonNode result) {
        GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, AppConstants.TRIGGER_CES_LAYER);
        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, result);
        TxnData transData = setChangeDriverInTxnData(txnGeneralEntity,LayerType.TRIGGERCES);
        return transData;
    }
    public String CreateRequestBodyForLongDrawn(String triggerCu, TxnData transdata, String gsiId, String contextualId, String transactionId) throws JSONException {


        TriggerCU triggerCu1 = JacksonUtils.getObjectFromJsonString(triggerCu, TriggerCU.class);
        List<TxnCULayer> txnCuLayers = transdata.getTxnCULayer();

        List<TxnSlotItem> transEntityDetails = new ArrayList<>();
        for (TxnCULayer cuLayer : txnCuLayers) {
            if (cuLayer.getType().getLayerType().equalsIgnoreCase("triggerces")) {
                transEntityDetails = cuLayer.getTxnSlotItems();
                break;
            }
        }

        JSONObject attributeObject = new JSONObject();

        JSONObject generalEntityObject = new JSONObject();
        TxnGeneralEntity txnGeneralEntity= ((TxnGeneralEntity) transEntityDetails.get(0).getItem());
        String entityName = txnGeneralEntity.getName();
        List<TxnGeneralEntityRecord> txnGeneralEntityRecords = txnGeneralEntity.getTransEntityRecords();
        for(TxnGeneralEntityRecord txnGeneralEntityRecord : txnGeneralEntityRecords){

            List<TxnNslAttribute> txnNslAttributeList = txnGeneralEntityRecord.getTxnNslAttribute();
            for(TxnNslAttribute txnNslAttribute: txnNslAttributeList){
                attributeObject.put(txnNslAttribute.getName(),txnNslAttribute.getValues());
            }
            generalEntityObject.put(entityName,attributeObject);
        }


        JSONArray triggerCesArray = new JSONArray();
        triggerCesArray.put(generalEntityObject);
        JSONObject triggercesObject = new JSONObject();
        triggercesObject.put("triggerCES", triggerCesArray);
        JSONObject txnCuLayerObject = new JSONObject();
        txnCuLayerObject.put("txnCuLayers",triggercesObject);


        JSONObject requestJsonObject = new JSONObject();
        requestJsonObject.put("data",txnCuLayerObject);
        requestJsonObject.put("gsiId",gsiId);
        requestJsonObject.put("transactionId",transactionId);
        requestJsonObject.put("cuContextualId",contextualId);
        requestJsonObject.put("cuId",triggerCu1.getId());
        requestJsonObject.put("status","SUCCESS");


        return requestJsonObject.toString();
    }


}
