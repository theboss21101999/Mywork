package com.nsl.adapter.commons.utils.create_entity;


import com.nsl.adapter.commons.enums.EntityCreationFileType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;




@Component
public class CreateEntityFactory {
    
    @Autowired
    CreateEntityFromJsonSchemaUtil createEntityFromJSONSCHEMAUtil;

    @Autowired
    CreateEntityFromJSONUtil createEntityFromJSONUtil;

    @Autowired
    CreateEntityFromHL7 createEntityFromHL7;

    @Autowired
    CreateEntityFromCSVUtil createEntityFromCSVUtil;

    @Autowired
    CreateEntityFromXML createEntityFromXML;
    @Autowired
    CreateEntityFromXlsxUtil createEntityFromXlsxUtil;

    public CreateEntityFromFile createEntity(EntityCreationFileType fileType){
        switch (fileType) {
            case JSON:
                return createEntityFromJSONUtil;
            case HL7:
                return createEntityFromHL7;
            case CSV:
                return createEntityFromCSVUtil;
            case XML:
                return createEntityFromXML;
            case JSONSCHEMA:
                return createEntityFromJSONSCHEMAUtil;
            case XLSX:
                return createEntityFromXlsxUtil;
        }
        return null;
    }
}
