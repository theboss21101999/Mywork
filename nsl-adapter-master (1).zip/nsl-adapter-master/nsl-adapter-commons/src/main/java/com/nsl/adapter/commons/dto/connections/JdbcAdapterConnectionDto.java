package com.nsl.adapter.commons.dto.connections;

public class JdbcAdapterConnectionDto extends BasicAdapterConnection {
    private String dataSourceName;
    private JdbcConnectionDetails connectionDetails;

    public JdbcAdapterConnectionDto() {
    }

    public JdbcConnectionDetails getConnectionDetails() {
        return new JdbcConnectionDetails(connectionDetails);
    }

    public void setConnectionDetails(JdbcConnectionDetails jdbcConnectionDetails) {
        this.connectionDetails = new JdbcConnectionDetails(jdbcConnectionDetails);
    }

    public String getDataSourceName() {
        return dataSourceName;
    }

    public void setDataSourceName(String dataSourceName) {
        this.dataSourceName = dataSourceName;
    }
}
