package com.nsl.adapter.commons.dto.connections;

import java.util.Properties;

public class SFTPAdapterConnectionDto extends BasicAdapterConnection {

    String host;
    int port;
    SFTPCredential authentication;
    Properties advancedConfig;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public SFTPCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(SFTPCredential authentication) {
        this.authentication = authentication;
    }

    public Properties getAdvancedConfig() {
        return advancedConfig;
    }

    public void setAdvancedConfig(Properties advancedConfig) {
        this.advancedConfig = advancedConfig;
    }
}