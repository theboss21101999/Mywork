package com.nsl.adapter.commons.dto;

public class AdapterScheduleReq {

    private String jobKey;
    private ScheduleInterval interval;
    private String incrementValue;
    private String dayOfWeek;
    private String dateOfMonth;
    private String time;
    private String timezone;
    private String startDate;
    private String endDate;
    private String recurrenceExpression;

    public String getJobKey() {
        return jobKey;
    }

    public void setJobKey(String jobKey) {
        this.jobKey = jobKey;
    }

    public ScheduleInterval getInterval() {
        return interval;
    }

    public void setInterval(ScheduleInterval interval) {
        this.interval = interval;
    }

    public String getIncrementValue() {
        return incrementValue;
    }

    public void setIncrementValue(String incrementValue) {
        this.incrementValue = incrementValue;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public String getDateOfMonth() {
        return dateOfMonth;
    }

    public void setDateOfMonth(String dateOfMonth) {
        this.dateOfMonth = dateOfMonth;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTimezone() {
        return timezone;
    }

    public void setTimezone(String timezone) {
        this.timezone = timezone;
    }

    public String getRecurrenceExpression() {
        return recurrenceExpression;
    }

    public void setRecurrenceExpression(String recurrenceExpression) {
        this.recurrenceExpression = recurrenceExpression;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
}
