package com.nsl.adapter.commons.utils;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class HashCodeIdGenerator {

    private HashCodeIdGenerator() {
    }
    static Long max = 2*(2147483647L);

    public static long getId(){
        UUID guid = UUID.randomUUID();
        // IDs in range of 3x to 5x is reserved for reserved cus & entities,
        // so possible range here is 5x to 1001x
        // using only evens to get non overlapping ids
        return ThreadLocalRandom.current().nextInt(3, 501) * max + guid.hashCode(); //NOSONAR
    }
}
