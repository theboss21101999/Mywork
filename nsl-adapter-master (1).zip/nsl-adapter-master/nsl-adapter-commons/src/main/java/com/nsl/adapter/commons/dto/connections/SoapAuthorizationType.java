package com.nsl.adapter.commons.dto.connections;

public enum SoapAuthorizationType {
    BASIC("Basic"),
    PASSWORD_DIGEST("Password_Digest"),
    USERNAME_TOKEN("Username_Token");

    private final String type;

    SoapAuthorizationType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }


    @Override
    public String toString() {
        return type;
    }
}
