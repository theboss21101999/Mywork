package com.nsl.adapter.commons.enums;

public enum EntityCreationFileType {
    JSON("json"),
    HL7("hl7"),
    JSONSCHEMA("jsonschema"),
    XML("xml"),
    CSV("csv"),
    XLSX("xlsx");

    private String fileType;

    private EntityCreationFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getEntityCreationFileType() {
        return this.fileType;
    }

    public static EntityCreationFileType fromValue(String val) {
        for (EntityCreationFileType at : EntityCreationFileType.values()) {
            if (at.getEntityCreationFileType().equalsIgnoreCase(val)) {
                return at;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return String.valueOf(this.fileType);
    }
}
