package com.nsl.adapter.commons.parsers;

import com.nsl.adapter.commons.parsers.service.ParserV2;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.entity.TxnDataUtils;
import com.nsl.adapter.commons.utils.entity.EntityToXML;
import com.nsl.adapter.commons.utils.entity.XmlToEntityUtil;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class XMLParserV2 implements ParserV2 {

    @Autowired
    TxnDataUtils txnDataUtils;

    @Override
    public List<TxnData> inboundParser(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued, Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {

        List<TxnData> transDatas = new ArrayList<>();
        List<TxnGeneralEntity> txnGeneralEntityList = inboundParserV2(inputStream,tcesGeneralEntity,isMultivalued,cuSystemProp,LayerType.PHYSICAL,authBean);
        for (TxnGeneralEntity txnGeneralEntity:txnGeneralEntityList){
            transDatas.add(txnDataUtils.setChangeDriverInTxnData(txnGeneralEntity,layerType));
        }
        return transDatas;
    }

    @Override
    public List<TxnGeneralEntity> inboundParserV2(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued, Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {
        TxnGeneralEntity txnGeneralEntity;
        try {

            String data = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))
                    .lines().collect(Collectors.joining("\n"));
            /*removing extra spaces and new lines and tab spaces */
            String cleanString = data.replaceAll(AppConstants.XMLRegex,"");

            txnGeneralEntity = XmlToEntityUtil.convertXMLToTxnEntity(tcesGeneralEntity,
                    new ByteArrayInputStream(cleanString.getBytes(StandardCharsets.UTF_8)));
        }catch(Exception e){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "failed during xml parsing ", ExceptionSeverity.BLOCKER,e);

        }
        return Collections.singletonList(txnGeneralEntity);
    }

    @Override
    public InputStream outboundParser(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity, Boolean isFileExists,Map<String,String> cuSystemProps) throws NSLException {

        try {
            ByteArrayOutputStream buffer = EntityToXML.getXml(txnGeneralEntity, inputGeneralEntity);
            if(buffer == null)
                return null;
            byte[] bytes = buffer.toByteArray();
            return new ByteArrayInputStream(bytes);

        }catch(Exception e){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "failed during xml parsing ", ExceptionSeverity.BLOCKER,e);
        }

    }

}
