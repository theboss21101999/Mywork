package com.nsl.adapter.commons.impl;

import com.nsl.common.utils.JacksonUtils;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.PaginatedConnectionsListDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.dataservices.cache.common.CacheServiceFactory;
import com.nsl.dataservices.cache.impl.CacheManagerType;
import com.nsl.dataservices.cache.impl.CacheOperationException;
import com.nsl.dataservices.cache.impl.ICacheService;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.cache.CacheType;
import org.springframework.stereotype.Service;

@Service("adapterConnectionsRedisDao")
public class AdapterConnectionsRedisDao implements AdapterConnnectionsDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdapterConnectionsRedisDao.class);
    private static final String ADAPTER_CONNECTIONS = "AdapterConnections";

    @Override
    public PaginatedConnectionsListDto fetchAllConnections(ConnectionDtoType adapterType, String searchName, int pageNumber, int pageSize, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        return null;
    }

    @Override
    public TxnAdapterConnection saveConnection(TxnAdapterConnection txnAdapterConnection, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        ICacheService cacheService = CacheServiceFactory.getCacheService(CacheType.REDIS);
        try {
            assert cacheService != null;
            LOGGER.info("accessing redis server");
            cacheService.putInCache(ADAPTER_CONNECTIONS + "_" + authenticatedUserDetails.getTenantId(),
                    txnAdapterConnection.getConnectionDtoType().toString() + ":" + txnAdapterConnection.getRecordId(),
                    JacksonUtils.toJson(txnAdapterConnection.getConnection()), CacheManagerType.IRDR);
            LOGGER.info("saved to redis - recordId : {}", txnAdapterConnection.getRecordId());
        } catch (CacheOperationException e) {
            LOGGER.error("failed to save in redis %s",e);
        }
        return txnAdapterConnection;
    }

    @Override
    public TxnAdapterConnection getConnectionByRecordId(ConnectionDtoType adapterType, Long recordId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        ICacheService cacheService = CacheServiceFactory.getCacheService(CacheType.REDIS);
        try {
            assert cacheService != null;
            LOGGER.info("accessing redis server");
            String connectionJson = cacheService.getFromCache(ADAPTER_CONNECTIONS + "_" + authenticatedUserDetails.getTenantId(),
                    adapterType.toString() + ":" + recordId, String.class, CacheManagerType.IRDR);
            if (connectionJson!=null){
                TxnAdapterConnection txnAdapterConnection = new TxnAdapterConnection();
                txnAdapterConnection.setConnectionDtoType(adapterType);
                txnAdapterConnection.setRecordId(recordId);
                txnAdapterConnection.setConnection(JacksonUtils.fromJson(connectionJson, adapterType.getClassType()));
                LOGGER.info("fetched from redis - recordId : {}", recordId);
                return txnAdapterConnection;
            }
        } catch (CacheOperationException e) {
            LOGGER.error("failed to get from redis %s",e);
        }
        return null;
    }

    @Override
    public String getRawConnection(ConnectionDtoType adapterType, Long recordId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        ICacheService cacheService = CacheServiceFactory.getCacheService(CacheType.REDIS);
        try {
            assert cacheService != null;
            LOGGER.info("accessing redis server");
            return cacheService.getFromCache(ADAPTER_CONNECTIONS + "_" + authenticatedUserDetails.getTenantId(),
                    adapterType.toString() + ":" + recordId, String.class, CacheManagerType.IRDR);
        } catch (CacheOperationException e) {
            LOGGER.error("failed to get from redis %s",e);
        }
        return null;
    }

    @Override
    public String saveRawConnection(String rawConnection, ConnectionDtoType adapterType, Long recordId,
                                    AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        ICacheService cacheService = CacheServiceFactory.getCacheService(CacheType.REDIS);
        try {
            assert cacheService != null;
            LOGGER.info("accessing redis server");
            cacheService.putInCache(ADAPTER_CONNECTIONS + "_" + authenticatedUserDetails.getTenantId(),
                    adapterType.toString() + ":" + recordId,
                    rawConnection, CacheManagerType.IRDR);
            LOGGER.info("saved raw data to redis - recordId : {}", recordId);
        } catch (CacheOperationException e) {
            LOGGER.error("failed to save in redis %s",e);
        }
        return rawConnection;
    }

    @Override
    public TxnAdapterConnection getConnectionByName(ConnectionDtoType adapterType, String connectionName, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        return null;
    }

    @Override
    public boolean deleteConnectionById(ConnectionDtoType adapterType, Long connectionId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        return false;
    }
}
