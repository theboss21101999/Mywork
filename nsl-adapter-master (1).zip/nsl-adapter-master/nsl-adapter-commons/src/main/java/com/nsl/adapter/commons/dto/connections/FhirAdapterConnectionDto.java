package com.nsl.adapter.commons.dto.connections;

public class FhirAdapterConnectionDto extends BasicAdapterConnection {
    private String serverUrl;
    private FhirCredential authentication;

    public FhirAdapterConnectionDto() {
    }

    public FhirAdapterConnectionDto(FhirCredential authentication, String serverUrl) {
        this.authentication = authentication;
        this.serverUrl = serverUrl;
    }

    public String getServerUrl() {
        return serverUrl;
    }

    public void setServerUrl(String serverUrl) {
        this.serverUrl = serverUrl;
    }

    public FhirCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(FhirCredential authentication) {
        this.authentication = authentication;
    }
}
