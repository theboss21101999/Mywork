package com.nsl.adapter.commons.dto.connections;

public class MQConnectionDTO extends BasicAdapterConnection{
    MQCredential authentication;

    public MQCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(MQCredential authentication) {
        this.authentication = authentication;
    }
}
