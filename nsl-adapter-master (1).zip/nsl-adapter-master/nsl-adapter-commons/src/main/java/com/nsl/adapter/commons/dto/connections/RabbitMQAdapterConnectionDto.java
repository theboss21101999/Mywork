package com.nsl.adapter.commons.dto.connections;

public class RabbitMQAdapterConnectionDto extends BasicAdapterConnection{
    private String hostname;
    private String portNumber;
    private String exchange;
    private String autoDelete;
    MQCredential authentication;

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public String getPortNumber() {
        return portNumber;
    }

    public void setPortNumber(String portNumber) {
        this.portNumber = portNumber;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public String getAutoDelete() {
        return autoDelete;
    }

    public void setAutoDelete(String autoDelete) {
        this.autoDelete = autoDelete;
    }

    public MQCredential getAuthentication() {
        return authentication;
    }

    public void setAuthentication(MQCredential authentication) {
        this.authentication = authentication;
    }
}
