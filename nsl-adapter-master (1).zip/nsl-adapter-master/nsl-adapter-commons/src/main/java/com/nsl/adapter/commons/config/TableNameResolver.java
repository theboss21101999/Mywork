package com.nsl.adapter.commons.config;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class TableNameResolver extends DynamoDBMapperConfig.DefaultTableNameResolver {

    @Value("${app.dynamo.table.name.prefix:null}")
    private String tableNamePrefix;


    @Override
    public String getTableName(Class<?> clazz, DynamoDBMapperConfig config) {
        return tableNamePrefix.concat("_").concat(super.getTableName(clazz, config));
    }
}
