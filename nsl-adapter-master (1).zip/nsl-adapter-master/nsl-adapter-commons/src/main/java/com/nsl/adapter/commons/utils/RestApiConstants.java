package com.nsl.adapter.commons.utils;

public class RestApiConstants {
    public static final String OK_CODE = "200";
    public static final String CREATED_CODE = "201";
    public static final String BAD_REQUEST_CODE = "400";
    public static final String BAD_REQUEST_DESCRIPTION = "Bad Request";
    public static final String UNAUTHORIZED_CODE = "401";
    public static final String UNAUTHORIZED_DESCRIPTION = "Unauthorized";
    public static final String FORBIDDEN_CODE = "403";
    public static final String FORBIDDEN_DESCRIPTION = "Forbidden";
    public static final String NOT_FOUND_CODE = "404";
    public static final String NOT_FOUND_DESCRIPTION = "Not found";
    public static final String INTERNAL_SERVER_ERROR_CODE ="500";
    public static final String INTERNAL_SERVER_ERROR_DESCRIPTION = "Internal Server Error";
    public static final String EXECUTE_DESCRIPTION = "Executed Successfully";
    public static final String INVOKE_EVENTS_DESCRIPTION = "Invoked Successfully";
    public static final String CREATE_ADAPTER_ENTITY_MAP_DESCRIPTION="Created Successfully";
    public static final String SAVE_MAP_CONFIGURATION_DESCRIPTION="Saved Successfully";
    public static final String GET_MAP_CONFIGURATION_DESCRIPTION="Getting Successfully";
    public static final String GET_SOURCE_ENTITY_SAMPLES_DESCRIPTION="getting Successfully";
    public static final String GET_SOURCE_OR_TARGET_ENTITIES_DESCRIPTION="Getting Successfully";
    public static final String VALIDATE_OR_EXECUTE_MAP_CONFIGURATION_DESCRIPTION="Validated or Executed Successfully";
    public static final String GET_SOURCE_OR_TARGET_ENTITIES_FROM_CU_DESCRIPTION="Getting Successfully";
    public static final String GET_ARITHIMATIC_OPERATORS_DESCRIPTION="Getting Successfully";
    public static final String GET_FUNCTION_CATEGORIES_DESCRIPTION="Getting Successfully";
    public static final String GET_FUNCTION_DEFINITIONS_DESCRIPTION="Getting Successfully";
    public static final String STRIPE_REDIRECT_DESCRIPTION = "Fetch redirect url successfully";
    public static final String FETCH_GOOGLE_OAUTH_DESCRIPTION = "Fetch google oauth code successfully";
    public static final String FETCH_OAUTH_CODE_DESCRIPTION = "Fetch oauth code successfully";
    public static final String FETCH_OAUTH_CODE_WRAPPER_DESCRIPTION = "Fetch oauth code successfully";
    public static final String WEBHOOK_CU_EXECUTION_DESCRIPTION = "Getting Successfully";
    public static final String GET_WEBHOOK_URL_DESCRIPTION = "Getting Webhook URL Successfully";
    public static final String GET_STATUS_DESCRIPTION = "Getting Status Successfully";
    public static final String GET_SWAGGER_JSON_DESCRIPTION = "Getting Swagger Json Successfully";
    public static final String EXECUTE_CU_BY_XML_VALUE_DESCRIPTION = "Executed CU by XML Successfully";
    public static final String EXECUTE_CU_BY_JSON_VALUE_DESCRIPTION = "Executed CU by Json Successfully";
    public static final String EXECUTE_CU_BY_FORMDATA_VALUE_DESCRIPTION = "Executed CU by Formdata value Successfully";
    public static final String EXECUTE_EXTERNAL_API_RESERVED_CU_SERVICE_DESCRIPTION = "Executed external api reserved cu service successfully";
    public static final String EXECUTE = "{\n" +
            "  \"status\": \"200 OK\",\n" +
            "  \"message\": \"Success\",\n" +
            "  \"result\":{\n" +
            "    \"serialVersionUID\": 1,\n" +
            "    \"txnCULayer\": [],\n" +
            "    \"gsiId\": 123456789,\n" +
            "    \"gsiMasterId\": 987654321,\n" +
            "    \"referenceChangeUnitMasterId\": 456789012,\n" +
            "    \"referenceChangeUnitId\": 789012345,\n" +
            "    \"triggerCuIndex\": 2,\n" +
            "    \"debugInfo\": {\n" +
            "      \"serialVersionUID\": 1,\n" +
            "      \"changeDriverSourceInfoMap\": {\n" +
            "        \"source1\": {\n" +
            "          \"info1\": \"value1\",\n" +
            "          \"info2\": \"value2\"\n" +
            "        },\n" +
            "        \"source2\": {\n" +
            "          \"info1\": \"value3\",\n" +
            "          \"info2\": \"value4\"\n" +
            "        }\n" +
            "      },\n" +
            "      \"changeDriverTargetInfoMap\": {\n" +
            "        \"target1\": [\n" +
            "          \"targetValue1\",\n" +
            "          \"targetValue2\"\n" +
            "        ],\n" +
            "        \"target2\": [\n" +
            "          \"targetValue3\",\n" +
            "          \"targetValue4\"\n" +
            "        ]\n" +
            "      }\n" +
            "    },\n" +
            "    \"paginatedSearchGEntity\": {\n" +
            "      \"name\": \"ExampleName\",\n" +
            "      \"displayName\": \"ExampleDisplayName\",\n" +
            "      \"entityClassification\": \"ExampleClassification\",\n" +
            "      \"entityType\": \"ExampleType\",\n" +
            "      \"entityProperties\": {\n" +
            "        \"property1\": \"value1\",\n" +
            "        \"property2\": \"value2\"\n" +
            "      },\n" +
            "      \"masterId\": 123,\n" +
            "      \"version\": \"1.0\",\n" +
            "      \"status\": \"Active\",\n" +
            "      \"memberShip\": \"ExampleMembership\",\n" +
            "      \"memberShipName\": \"ExampleMembershipName\",\n" +
            "      \"helpText\": \"ExampleHelpText\",\n" +
            "      \"botQuestion\": \"ExampleBotQuestion\",\n" +
            "      \"uniqueConstraints\": [\n" +
            "        [\n" +
            "          {\n" +
            "            \"attr1\": \"attrValue1\",\n" +
            "            \"attr2\": \"attrValue2\"\n" +
            "          }\n" +
            "        ]\n" +
            "      ],\n" +
            "      \"isConnectedEntity\": true,\n" +
            "      \"nslAttributes\": [\n" +
            "        {\n" +
            "          \"attrName\": \"Attribute1\",\n" +
            "          \"attrValue\": \"Value1\"\n" +
            "        }\n" +
            "      ],\n" +
            "      \"isReserved\": false,\n" +
            "      \"isMasterData\": true\n" +
            "    }\n" +
            "  }\n" +
            "}";
    public static final String INVOKE_EVENTS = "{\n" +
            "  \"status\": \"OK\",\n" +
            "  \"message\": \"Success\",\n" +
            "  \"result\": \"eventId\"\n" +
            "}";

    public static final String INVOKE_GSI = "{\n" +
            "  \"status\": \"OK\",\n" +
            "  \"message\": \"Success\",\n" +
            "  \"result\": \"eventId\"\n" +
            "}";
    public static final String CREATE_ADAPTER_ENTITY_MAP = "{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [{JsonElement},{JsonElement},{JsonElement}],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String GET_SOURCE_ENTITIES = "{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [{JsonElement},{JsonElement},{JsonElement}],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String GET_TARGET_ENTITIES = "{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [{JsonElement},{JsonElement},{JsonElement}],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String SAVE_MAP_CONFIGURATION = "{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [{JsonElement},{JsonElement},{JsonElement}],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String GET_MAP_CONFIGURATION = "{\n"
            + "  \"status\": \"ok\",\n"
            + "  \"message\": \"success\",\n"
            + "  \"result\": {\n"
            + "    \"id\": 123,\n"
            + "    \"name\": \"Sample Map Configuration\",\n"
            + "    \"layers\": [\n"
            + "      {\n"
            + "        \"name\": \"Layer 1\",\n"
            + "        \"type\": \"Tile\",\n"
            + "        \"url\": \"https://example.com/tile-layer-1/{z}/{x}/{y}.png\"\n"
            + "      },\n"
            + "      {\n"
            + "        \"name\": \"Layer 2\",\n"
            + "        \"type\": \"Vector\",\n"
            + "        \"url\": \"https://example.com/vector-layer-2\"\n"
            + "      }\n"
            + "    ],\n"
            + "    \"options\": {\n"
            + "      \"center\": [45.123, -78.456],\n"
            + "      \"zoom\": 10,\n"
            + "      \"maxZoom\": 18,\n"
            + "      \"minZoom\": 2\n"
            + "    }\n"
            + "  },\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String VALIDATE_MAP_CONFIGURATION = "{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String EXECUTE_MAP_CONFIGURATION = "{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [\n"
            + "    {\n"
            + "      \"field1\": \"value1\",\n"
            + "      \"field2\": \"value2\",\n"
            + "      \"field3\": \"value3\"\n"
            + "    },\n"
            + "    {\n"
            + "      \"field1\": \"value4\",\n"
            + "      \"field2\": \"value5\",\n"
            + "      \"field3\": \"value6\"\n"
            + "    },\n"
            + "    {\n"
            + "      \"field1\": \"value7\",\n"
            + "      \"field2\": \"value8\",\n"
            + "      \"field3\": \"value9\"\n"
            + "    }\n"
            + "  ],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String GET_SOURCE_ENTITY_SAMPLES = "{\n"
            + "  \"status\": \"OK\",\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [\n"
            + "    {\n"
            + "      \"testValues\": {\n"
            + "        \"field1\": \"value1\",\n"
            + "        \"field2\": \"value2\",\n"
            + "        \"field3\": \"value3\"\n"
            + "      }\n"
            + "    },\n"
            + "    {\n"
            + "      \"testValues\": {\n"
            + "        \"field1\": \"value4\",\n"
            + "        \"field2\": \"value5\",\n"
            + "        \"field3\": \"value6\"\n"
            + "      }\n"
            + "    },\n"
            + "    {\n"
            + "      \"testValues\": {\n"
            + "        \"field1\": \"value7\",\n"
            + "        \"field2\": \"value8\",\n"
            + "        \"field3\": \"value9\"\n"
            + "      }\n"
            + "    }\n"
            + "  ],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String GET_SOURCE_ENTITIES_FROM_CU ="{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [\n"
            + "    {\n"
            + "      \"id\": 1,\n"
            + "      \"name\": \"Entity 1\",\n"
            + "      \"description\": \"Description of Entity 1\",\n"
            + "      \"type\": \"Type A\"\n"
            + "    },\n"
            + "    {\n"
            + "      \"id\": 2,\n"
            + "      \"name\": \"Entity 2\",\n"
            + "      \"description\": \"Description of Entity 2\",\n"
            + "      \"type\": \"Type B\"\n"
            + "    },\n"
            + "    {\n"
            + "      \"id\": 3,\n"
            + "      \"name\": \"Entity 3\",\n"
            + "      \"description\": \"Description of Entity 3\",\n"
            + "      \"type\": \"Type A\"\n"
            + "    }\n"
            + "  ],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String GET_TARGET_ENTITIES_FROM_CU ="{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [\n"
            + "    {\n"
            + "      \"id\": 1,\n"
            + "      \"name\": \"Entity 1\",\n"
            + "      \"description\": \"Description of Entity 1\",\n"
            + "      \"type\": \"Type A\"\n"
            + "    },\n"
            + "    {\n"
            + "      \"id\": 2,\n"
            + "      \"name\": \"Entity 2\",\n"
            + "      \"description\": \"Description of Entity 2\",\n"
            + "      \"type\": \"Type B\"\n"
            + "    },\n"
            + "    {\n"
            + "      \"id\": 3,\n"
            + "      \"name\": \"Entity 3\",\n"
            + "      \"description\": \"Description of Entity 3\",\n"
            + "      \"type\": \"Type A\"\n"
            + "    }\n"
            + "  ],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String GET_ARITHMETIC_OPERATORS = "{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [\"+\", \"-\", \"*\", \"/\", \"(\", \")\"],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String GET_FUNCTION_CATEGORIES = "{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"success\",\n"
            + "  \"result\": {\n"
            + "    \"nslName\": \"CategoryName\",\n"
            + "    \"typeClass\": \"CategoryType\",\n"
            + "    \"fieldName\": \"CategoryField\",\n"
            + "    \"nlFunctionMap\": {\n"
            + "      \"Function1\": {\n"
            + "        \"object\": \"ObjectReference1\",\n"
            + "        \"method\": \"methodName1\",\n"
            + "        \"arguments\": [\n"
            + "          {\n"
            + "            \"name\": \"arg1Name\",\n"
            + "            \"type\": \"arg1Type\",\n"
            + "            \"value\": \"arg1Value\"\n"
            + "          }\n"
            + "        ]\n"
            + "      },\n"
            + "      \"Function2\": {\n"
            + "        \"object\": \"ObjectReference2\",\n"
            + "        \"method\": \"methodName2\",\n"
            + "        \"arguments\": [\n"
            + "          {\n"
            + "            \"name\": \"arg1Name\",\n"
            + "            \"type\": \"arg1Type\",\n"
            + "            \"value\": \"arg1Value\"\n"
            + "          }\n"
            + "        ]\n"
            + "      }\n"
            + "    }\n"
            + "  },\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";

    public static final String GET_FUNCTION_DEFINITIONS = "{\n"
            + "  \"status\": 200,\n"
            + "  \"message\": \"Success\",\n"
            + "  \"result\": [{JsonElement},{JsonElement},{JsonElement}],\n"
            + "  \"translatedData\": null,\n"
            + "  \"errorMessage\": null\n"
            + "}\n"
            + "";
    public static final String VALIDATE_MEETING_ID = "{\n" +
            "  \"status\": \"200\",\n" +
            "  \"message\":\"Success\",\n" +
            "  \"result\": {\n" +
            "    \"status\": 1,\n" +
            "    \"message\": \"Success\"\n" +
            "  }\n" +
            "}\n";
    public static final String GENERATE_MEETING_ID = "{\n" +
            "  \"status\": \"200\",\n" +
            "  \"message\":\"Success\",\n" +
            "  \"result\": \"url\"\n" +
            "}\n";
    public static final String EXECUTE_EXTERNAL_API_RESERVED_CU_SERVICE = "{\n" +
            "  \"status\": \"200\",\n" +
            "  \"message\": \"Success\",\n" +
            "  \"result\": {\n" +
            "    \"txnCULayer\": [\n" +
            "      {\n" +
            "        \"type\": \"physical\",\n" +
            "        \"txnSlotItems\": [\n" +
            "          {\n" +
            "            \"isMultiValue\": true\n" +
            "          }\n" +
            "        ]\n" +
            "      },\n" +
            "      {\n" +
            "        \"type\": \"information\",\n" +
            "        \"txnSlotItems\": []\n" +
            "      },\n" +
            "      {\n" +
            "        \"type\": \"mind\",\n" +
            "        \"txnSlotItems\": []\n" +
            "      },\n" +
            "      {\n" +
            "        \"type\": \"triggerCES\",\n" +
            "        \"txnSlotItems\": []\n" +
            "      },\n" +
            "      {\n" +
            "        \"type\": \"reservedActions\",\n" +
            "        \"txnSlotItems\": []\n" +
            "      }\n" +
            "    ],\n" +
            "    \"gsiId\": 0,\n" +
            "    \"gsiMasterId\": 0,\n" +
            "    \"referenceChangeUnitMasterId\": 0,\n" +
            "    \"referenceChangeUnitId\": 0,\n" +
            "    \"triggerCuIndex\": 0,\n" +
            "    \"debugInfo\": {\n" +
            "      \"changeDriverSourceInfoMap\": {},\n" +
            "      \"changeDriverTargetInfoMap\": {}\n" +
            "    },\n" +
            "    \"paginatedSearchGEntity\": {\n" +
            "      \"name\": \"\",\n" +
            "      \"displayName\": \"\",\n" +
            "      \"entityClassification\": \"\",\n" +
            "      \"entityType\": \"\",\n" +
            "      \"entityProperties\": {},\n" +
            "      \"masterId\": null,\n" +
            "      \"version\": \"\",\n" +
            "      \"status\": \"\",\n" +
            "      \"memberShip\": \"\",\n" +
            "      \"memberShipName\": \"\",\n" +
            "      \"helpText\": \"\",\n" +
            "      \"botQuestion\": \"\",\n" +
            "      \"uniqueConstraints\": [],\n" +
            "      \"isConnectedEntity\": false,\n" +
            "      \"nslAttributes\": [],\n" +
            "      \"isReserved\": false,\n" +
            "      \"isMasterData\": false\n" +
            "    }\n" +
            "  }\n" +
            "}\n";
}

