package com.nsl.adapter.commons.parsers;

import ca.uhn.hl7v2.HL7Exception;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.parsers.service.ParserV2;
import com.nsl.adapter.commons.utils.entity.EntityToHl7;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.commons.utils.entity.Hl7ToEntity;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.adapter.commons.utils.entity.TxnDataUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class HL7ParserV2 implements ParserV2 {

    public final Logger LOGGER = LoggerFactory.getLogger(HL7ParserV2.class);

    @Autowired
    EntityToHl7 entityToHl7;

    @Autowired
    Hl7ToEntity hl7ToEntity;

    @Autowired
    EntityToJSONUtil entityToJSONUtil;

    @Autowired
    TxnDataUtils txnDataUtils;

    @Override
    public InputStream outboundParser(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity, Boolean isFileExists,Map<String,String> cuSystemProps) throws NSLException {

        JSONObject jsonObject = entityToJSONUtil.getJsonObjectFromGE(txnGeneralEntity, inputGeneralEntity);

        String msgType,messageTriggerEvent,message_Type;
        try {
            JSONObject msgObject = jsonObject.getJSONObject("MSH");

            msgType = msgObject.getJSONObject("Message Type").getString("Message Type_1");
            messageTriggerEvent = msgObject.getJSONObject("Message Type").optString("Message Type_2");

            if (messageTriggerEvent.isEmpty())
                message_Type = msgType;
            else
                message_Type = msgType+ "_" + messageTriggerEvent;

        }catch (JSONException e){
            LOGGER.error("please provide Msg Type information",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "please provide Msg Type information "+ e.getMessage(), ExceptionSeverity.BLOCKER,e);
        }

        String hl7Message = entityToHl7.getHl7Message(jsonObject, message_Type);
        return new ByteArrayInputStream(hl7Message.getBytes(StandardCharsets.UTF_8));

    }

    @Override
    public List<TxnData> inboundParser(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued,
                                       Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {
        List<TxnData> transDatas = new ArrayList<>();
        List<TxnGeneralEntity> txnGeneralEntityList = inboundParserV2(inputStream,tcesGeneralEntity,isMultivalued,cuSystemProp,LayerType.PHYSICAL,authBean);
        for (TxnGeneralEntity txnGeneralEntity:txnGeneralEntityList){
            transDatas.add(txnDataUtils.setChangeDriverInTxnData(txnGeneralEntity,layerType));
        }
        return transDatas;
    }

    @Override
    public List<TxnGeneralEntity> inboundParserV2(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued, Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {
        LOGGER.info("fetching content from file");
        StringBuilder responseStrBuilder = new StringBuilder();
        try (BufferedReader streamReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            String inputStr;
            while ((inputStr = streamReader.readLine()) != null)
                responseStrBuilder.append(inputStr).append("\r");
        } catch (IOException e) {
            LOGGER.error("failed to read content from input file: ", e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "failed to read content from input file: "+ e.getMessage(), ExceptionSeverity.BLOCKER,e);
        }

        TxnGeneralEntity txnGeneralEntity;
        try {
            JSONObject jsonObject =  hl7ToEntity.readHl7Message(responseStrBuilder.toString());
            txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity,
                    new ObjectMapper().readTree(jsonObject.toString()));
        }catch(IOException | HL7Exception | JSONException e){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "failed during hl7 parsing ", ExceptionSeverity.BLOCKER,e);
        }
        return Collections.singletonList(txnGeneralEntity);
    }
}
