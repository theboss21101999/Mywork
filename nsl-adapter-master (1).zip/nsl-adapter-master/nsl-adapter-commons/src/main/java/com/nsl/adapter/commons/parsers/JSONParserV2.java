package com.nsl.adapter.commons.parsers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.parsers.service.ParserV2;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.adapter.commons.utils.entity.TxnDataUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class JSONParserV2 implements ParserV2 {

    @Autowired
    TxnDataUtils txnDataUtils;

    @Autowired
    EntityToJSONUtil entityToJSONUtil;

    @Override
    public List<TxnData> inboundParser(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued, Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {

        List<TxnData> transDatas = new ArrayList<>();
        List<TxnGeneralEntity> txnGeneralEntityList = inboundParserV2(inputStream,tcesGeneralEntity,isMultivalued,cuSystemProp,LayerType.PHYSICAL,authBean);
        for (TxnGeneralEntity txnGeneralEntity:txnGeneralEntityList){
            transDatas.add(txnDataUtils.setChangeDriverInTxnData(txnGeneralEntity,layerType));
        }
        return transDatas;
    }

    @Override
    public List<TxnGeneralEntity> inboundParserV2(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued, Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {
        TxnGeneralEntity txnGeneralEntity;
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode request = mapper.readTree(inputStream);
            txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, request);
        }catch(IOException e){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "failed during json parsing ", ExceptionSeverity.BLOCKER,e);
        }
        return Collections.singletonList(txnGeneralEntity);
    }

    @Override
    public InputStream outboundParser(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity, Boolean isFileExists,Map<String,String> cuSystemProps) throws NSLException {

        JSONObject transObject;
        try {
            transObject = entityToJSONUtil.getJsonObjectFromGE(txnGeneralEntity, inputGeneralEntity);
            String str = transObject.toString();
            return new ByteArrayInputStream(str.getBytes(StandardCharsets.UTF_8));

        }catch( NSLException e){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    "failed during json parsing ", ExceptionSeverity.BLOCKER,e);
        }
    }
}
