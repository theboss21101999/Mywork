package com.nsl.adapter.commons.utils.entity;

import com.nsl.logical.enums.DataType;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CSVToEntityUtil {

    private static final Logger logger = LoggerFactory.getLogger(CSVToEntityUtil.class);

    public static TxnGeneralEntity getTriggerTxnGeneralEntityWithData(GeneralEntity generalEntity,
                                                                      Map<String, Integer> headersMap, List<List<String>> data, String prefix) {
        return getTriggerTxnGeneralEntityWithData(generalEntity, headersMap, data, prefix, "", new HashMap<>());
    }

    public static TxnGeneralEntity getTriggerTxnGeneralEntityWithData(GeneralEntity generalEntity,
                                                                      Map<String, Integer> headersMap,
                                                                      List<List<String>> data, String prefix,
                                                                      String mapperPrefix, Map<String, String> mapper) {

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();
        txnGeneralEntity.setGeneralEntityID(generalEntity.getId());
        txnGeneralEntity.setName(generalEntity.getName());
        List<TxnGeneralEntityRecord> txnGeneralEntityRecordList = new ArrayList<>();
        data.forEach( x -> txnGeneralEntityRecordList.add(
                                        buildTxnGeneralEntityRecord(generalEntity, headersMap, x, prefix, mapperPrefix, mapper)));
        txnGeneralEntity.setTransEntityRecords(txnGeneralEntityRecordList);
        return txnGeneralEntity;
    }

    public static TxnGeneralEntityRecord buildTxnGeneralEntityRecord(GeneralEntity generalEntity,
                                                Map<String, Integer> headersMap, List<String> data, String prefix,
                                                                     String mapperPrefix, Map<String, String> mapper) {

        TxnGeneralEntityRecord txnGeneralEntityRecord = new TxnGeneralEntityRecord();
        List<NslAttribute> attributeList = generalEntity.getNslAttributes();
        List<TxnNslAttribute> txnNslAttributeList = new ArrayList<>();
        for (NslAttribute attribute : attributeList) {

            String attributeName = attribute.getName();
            TxnNslAttribute txnNslAttribute = new TxnNslAttribute();
            txnNslAttribute.setName(attributeName);
            txnNslAttribute.setNslAttributeID(attribute.getId());

            String attributePrefix = prefix + attributeName;
            String header = mapperPrefix + mapper.getOrDefault(attributePrefix, attributeName);
            if (attribute.getAttributeType().getType() != DataType.ENTITY &&
                    attribute.getAttributeType().getType() != DataType.LIST) {
                if (headersMap.containsKey(header)) {
                    String value;
                    if(headersMap.get(header)>=data.size()){
                        value="";
                    }else {
                        value = data.get(headersMap.get(header));
                    }
                    if (value.isEmpty())
                        txnNslAttribute.setValues(new ArrayList<>());
                    else
                        txnNslAttribute.setValues(Collections.singletonList(value));
                }
            } else if (attribute.getAttributeType().getType() == DataType.LIST) {
                if (attribute.getGeneralEntity() != null)
                    txnNslAttribute.setTxnGeneralEntity(getTriggerTxnGeneralEntityWithData(attribute.getGeneralEntity(),
                            headersMap, Collections.singletonList(data), attributePrefix + ".", header + ".", mapper));
                else if (headersMap.containsKey(header)) {
                    String value;
                    if(headersMap.get(header)>=data.size()){
                        value="";
                    }else {
                        value = data.get(headersMap.get(header));
                    }
                    if(value.isEmpty())
                        txnNslAttribute.setValues(new ArrayList<>());
                    else
                        txnNslAttribute.setValues(Arrays.asList(value.split(",")));
                }
            } else
                txnNslAttribute.setTxnGeneralEntity(getTriggerTxnGeneralEntityWithData(attribute.getGeneralEntity(),
                                           headersMap, Collections.singletonList(data), attributePrefix + ".", header + ".", mapper));
            txnNslAttributeList.add(txnNslAttribute);

        }
        txnGeneralEntityRecord.setTxnNslAttribute(txnNslAttributeList);
        return txnGeneralEntityRecord;

    }
}
