package com.nsl.adapter.commons.dto.Integrations.model;

public class MoveToFolder {

    String staticFolder;

    public MoveToFolder(String staticFolder) {
        this.staticFolder = staticFolder;
    }

    public String getStaticFolder() {
        return staticFolder;
    }

    public void setStaticFolder(String staticFolder) {
        this.staticFolder = staticFolder;
    }
}
