package com.nsl.adapter.commons.dto.connections;

public class OpenAPIConnectionDTO extends BasicAdapterConnection {

    private String operation;

    private String specificationUri;

    private String basePath;

    private String host;

    public OpenAPIConnectionDTO(String operation, String specificationUri, String basePath, String host) {
        this.operation = operation;
        this.specificationUri = specificationUri;
        this.basePath = basePath;
        this.host = host;
    }

    public OpenAPIConnectionDTO() {
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getSpecificationUri() {
        return specificationUri;
    }

    public void setSpecificationUri(String specificationUri) {
        this.specificationUri = specificationUri;
    }

    public String getBasePath() {
        return basePath;
    }

    public void setBasePath(String basePath) {
        this.basePath = basePath;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }
}
