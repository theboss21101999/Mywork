package com.nsl.adapter.commons.impl;

import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.PaginatedConnectionsListDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service
@Primary
public class AdapterConnectionsSelectorDao implements AdapterConnnectionsDao {

    @Autowired
    @Qualifier("adapterConnectionsDynamoDao")
    private AdapterConnnectionsDao adapterConnnectionsDynamoDao;

    @Autowired
    @Qualifier("adapterConnectionsRedisDao")
    private AdapterConnnectionsDao adapterConnnectionsRedisDao;

    @Autowired
    private AdaptorCommonsProperties adaptorCommonsProperties;

    @Override
    public PaginatedConnectionsListDto fetchAllConnections(ConnectionDtoType adapterType, String searchName, int pageNumber, int pageSize, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException{
        if (pageSize <1 || pageNumber<1){
            throw new NSLException(ExceptionCategory.VALIDATION, ExceptionSubCategory.VALIDATE_GENERAL_ENTITY,
                    "Please provide size grater than 0", ExceptionSeverity.MAJOR, null);
        }
        return adapterConnnectionsDynamoDao.fetchAllConnections(adapterType, searchName, pageNumber, pageSize, authenticatedUserDetails);
    }

    @Override
    public TxnAdapterConnection saveConnection(TxnAdapterConnection txnAdapterConnection, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException{
        if (txnAdapterConnection.getConnection()==null || txnAdapterConnection.getConnectionDtoType()==null){
            throw new NSLException(ExceptionCategory.VALIDATION, ExceptionSubCategory.VALIDATE_GENERAL_ENTITY,
                    "Please provide valid data.", ExceptionSeverity.MAJOR, null);
        }
        txnAdapterConnection = adapterConnnectionsDynamoDao.saveConnection(txnAdapterConnection, authenticatedUserDetails);
        if (adaptorCommonsProperties.getCacheEnabled()){
            txnAdapterConnection = adapterConnnectionsRedisDao.saveConnection(txnAdapterConnection, authenticatedUserDetails);
        }
        return txnAdapterConnection;
    }

    @Override
    public TxnAdapterConnection getConnectionByRecordId(ConnectionDtoType adapterType, Long recordId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        if (adapterType==null || recordId==null
                || !((Class) adapterType.getClassType()).getSuperclass().getName().equals("com.nsl.adapter.commons.dto.connections.BasicAdapterConnection")){
            throw new NSLException(ExceptionCategory.VALIDATION, ExceptionSubCategory.VALIDATE_GENERAL_ENTITY,
                    "Please provide valid data.", ExceptionSeverity.MAJOR, null);
        }
        TxnAdapterConnection adapterConnection = null;
        if (adaptorCommonsProperties.getCacheEnabled()){
            adapterConnection = adapterConnnectionsRedisDao.getConnectionByRecordId(adapterType, recordId, authenticatedUserDetails);
        }
        if (adapterConnection==null){
            adapterConnection = adapterConnnectionsDynamoDao.getConnectionByRecordId(adapterType, recordId, authenticatedUserDetails);
            if (adaptorCommonsProperties.getCacheEnabled() && adapterConnection!=null){
                adapterConnection = adapterConnnectionsRedisDao.saveConnection(adapterConnection, authenticatedUserDetails);
            }
        }
        return adapterConnection;
    }

    @Override
    public String getRawConnection(ConnectionDtoType adapterType, Long recordId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        if (adapterType==null || recordId==null
                || !((Class) adapterType.getClassType()).getSuperclass().getName().equals("com.nsl.adapter.commons.dto.connections.BasicAdapterConnection")){
            throw new NSLException(ExceptionCategory.VALIDATION, ExceptionSubCategory.VALIDATE_GENERAL_ENTITY,
                    "Please provide valid data.", ExceptionSeverity.MAJOR, null);
        }
        String rawConnection = null;
        if (adaptorCommonsProperties.getCacheEnabled()){
            rawConnection = adapterConnnectionsRedisDao.getRawConnection(adapterType, recordId, authenticatedUserDetails);
        }
        if (rawConnection==null){
            rawConnection = adapterConnnectionsDynamoDao.getRawConnection(adapterType, recordId, authenticatedUserDetails);
            if (adaptorCommonsProperties.getCacheEnabled() && rawConnection!=null){
                rawConnection = adapterConnnectionsRedisDao.saveRawConnection(rawConnection, adapterType, recordId, authenticatedUserDetails);
            }
        }

        return rawConnection;
    }

    @Override
    public TxnAdapterConnection getConnectionByName(ConnectionDtoType adapterType, String connectionName, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        if (adapterType==null || connectionName==null || connectionName.strip().equals("")
                || !((Class) adapterType.getClassType()).getSuperclass().getName().equals("com.nsl.adapter.commons.dto.connections.BasicAdapterConnection")){
            throw new NSLException(ExceptionCategory.VALIDATION, ExceptionSubCategory.VALIDATE_GENERAL_ENTITY,
                    "Please provide valid data.", ExceptionSeverity.MAJOR, null);
        }
        TxnAdapterConnection adapterConnection = null;
        adapterConnection = adapterConnnectionsDynamoDao.getConnectionByName(adapterType, connectionName, authenticatedUserDetails);
        return adapterConnection;
    }

    @Override
    public boolean deleteConnectionById(ConnectionDtoType adapterType, Long connectionId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
//        TxnAdapterConnection connection = getConnectionByRecordId(adapterType, connectionId, authenticatedUserDetails);
//        if (connection==null){
//            return false;
//        }
//        if (adaptorCommonsProperties.getCacheEnabled()){
//            return adapterConnectionsCacheDao.deleteConnectionById(adapterType, connectionId, authenticatedUserDetails);
//        }
        return true;
    }

    @Override
    public String saveRawConnection(String rawConnection, ConnectionDtoType adapterType, Long recordId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        return null;
    }
}
