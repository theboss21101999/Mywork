package com.nsl.adapter.commons.dto.connections;

public enum GraphQLAuthType {

    NONE,
    JWT
}
