package com.nsl.adapter.commons.dto.connections;

public enum NegotiationType {
    TLS,
    PLAINTEXT_UPGRADE,
    PLAINTEXT
}
