package com.nsl.adapter.commons.impl;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.Page;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.internal.PageIterable;
import com.amazonaws.services.dynamodbv2.document.spec.DeleteItemSpec;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;

import com.nsl.common.utils.JacksonUtils;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.ConnectionListDto;
import com.nsl.adapter.commons.dto.PaginatedConnectionsListDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.models.DynamoDBDto;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.HashCodeIdGenerator;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

@Service("adapterConnectionsDynamoDao")
public class AdapterConnectionsDynamoDao implements AdapterConnnectionsDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdapterConnectionsDynamoDao.class);

    @Autowired
    DynamoDB dynamoDB;

    @Autowired
    AmazonDynamoDB amazonDynamoDB;

    @Autowired
    DynamoDBMapper dynamoDBMapper;

    @Value("${app.dynamo.table.name.prefix:null}")
    private String tableNamePrefix;

    @Override
    public PaginatedConnectionsListDto fetchAllConnections(ConnectionDtoType adapterType, String searchName, int pageNumber, int pageSize, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        try{
            Table table = dynamoDB.getTable(tableNamePrefix.concat("_").concat(AppConstants.ADAPTER_CONNECTION_TABLE_NAME));
            Index index = table.getIndex("ConnectionNameLowerIndex");
            ValueMap valueMap = new ValueMap()
                    .withString(":v_parentid", authenticatedUserDetails.getTenantId().concat(":").concat(adapterType.toString()));
            boolean nameSearch = false;
            if (searchName!=null && !"".equals(searchName.strip())){
                valueMap.withString(":v_name", searchName.strip().toLowerCase());
                nameSearch = true;
            }
            QuerySpec spec = new QuerySpec()
                    .withKeyConditionExpression("parentId = :v_parentid" + (nameSearch?" AND begins_with(connectionNameLower , :v_name)":""))
                    .withValueMap(valueMap);
            spec.withMaxPageSize(pageSize);
            ItemCollection<QueryOutcome> items = index.query(spec);

            PaginatedConnectionsListDto dto = new PaginatedConnectionsListDto();
            List<ConnectionListDto> connectionListDtos = new ArrayList<>();

            PageIterable<Item, QueryOutcome> pages = items.pages();
            int pageNum = 0;
            int currPageSize=0;
            int totalHits = 0;
            for (Page<Item, QueryOutcome> page : items.pages()) {
                if (page.size() == 0) {
                    continue;
                }
                totalHits = totalHits + page.size();
                ++pageNum;
            }
            if (pageNum!=0 && pageNum<pageNumber){
                pageNumber = pageNum;
            }
            if (pageNum==0){
                pageNum=1;
                pageNumber=1;
            }else{
                pageNum=0;
                for (Page<Item, QueryOutcome> page : items.pages()){
                    if (page.size() == 0) {
                        continue;
                    }
                    ++pageNum;
                    if (pageNum==pageNumber){
                        Iterator<Item> itemsIter = page.iterator();
                        while (itemsIter.hasNext()) {
                            Item item = itemsIter.next();
                            DynamoDBDto dynamoDBDto = JacksonUtils.fromJson(item.toJSON(), DynamoDBDto.class); //NOSONAR
                            ConnectionListDto connectionListDto = new ConnectionListDto();
                            connectionListDto.setConnectionName(dynamoDBDto.getConnectionName().split("#",2)[1]);
                            connectionListDto.setConnId(dynamoDBDto.getRecordId());
                            connectionListDto.setCreatedAt(new Date(dynamoDBDto.getInsertTime()));
                            connectionListDtos.add(connectionListDto);
                            ++currPageSize;
                        }
                    }
                }
            }
            dto.setPageNumber(pageNumber);
            dto.setPageSize(pageSize);
            dto.setCurrentPageSize(currPageSize);
            dto.setTotalHits(Long.valueOf(totalHits));
            dto.setTotalPages(Long.valueOf(pageNum));
            dto.setConnectionsList(connectionListDtos);
            return dto;
        }catch (Exception e){
            LOGGER.error("some error while fetching from dynamo : ", e);
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.FETCH,
                    "error while fetching records", ExceptionSeverity.MAJOR, null);
        }
    }

    @Override
    public TxnAdapterConnection saveConnection(TxnAdapterConnection txnAdapterConnection, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException{
        try{
            DynamoDBDto dto = new DynamoDBDto();
            if (txnAdapterConnection.getRecordId()==null || txnAdapterConnection.getRecordId()==0){
                txnAdapterConnection.setRecordId(HashCodeIdGenerator.getId());
            }
            dto.setRecordId(txnAdapterConnection.getRecordId());
            dto.setInsertTime(new Date().getTime());
            dto.setConnectionName(txnAdapterConnection.getConnection().getConnectionStatus().toString()
                    .concat("#").concat(txnAdapterConnection.getConnection().getConnectionName()));
            dto.setConnectionNameLower(txnAdapterConnection.getConnection().getConnectionName().toLowerCase());
            dto.setPayload(JacksonUtils.toJson(txnAdapterConnection.getConnection()));
            dto.setParentId(authenticatedUserDetails.getTenantId().concat(":").concat(txnAdapterConnection.getConnectionDtoType().toString()));
            dynamoDBMapper.save(dto);
            return txnAdapterConnection;
        }catch (Exception e){
            LOGGER.error("some error while saving to dynamo : ", e);
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.EXPORT,
                    "error while saving connection"+ e.getMessage(), ExceptionSeverity.MAJOR, e);
        }
    }

    @Override
    public TxnAdapterConnection getConnectionByRecordId(ConnectionDtoType adapterType, Long recordId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        try{
            TxnAdapterConnection txnAdapterConnection = null;
            Table table = dynamoDB.getTable(tableNamePrefix.concat("_").concat(AppConstants.ADAPTER_CONNECTION_TABLE_NAME));

            QuerySpec spec = new QuerySpec()
                    .withKeyConditionExpression("parentId = :v_parentid AND recordId = :v_recordid")
                    .withValueMap(new ValueMap()
                            .withString(":v_parentid", authenticatedUserDetails.getTenantId().concat(":").concat(adapterType.toString()))
                            .withNumber(":v_recordid", recordId));

            ItemCollection<QueryOutcome> items = table.query(spec);

            Iterator<Item> iterator = items.iterator();
            while (iterator.hasNext()) {
                Item item = iterator.next();
                DynamoDBDto dynamoDBDto = JacksonUtils.fromJson(item.toJSON(), DynamoDBDto.class);
                txnAdapterConnection = new TxnAdapterConnection();
                txnAdapterConnection.setConnectionDtoType(adapterType);
                txnAdapterConnection.setRecordId(recordId);
                txnAdapterConnection.setConnection(JacksonUtils.fromJson(dynamoDBDto.getPayload(), adapterType.getClassType()));
                break;
            }

            return txnAdapterConnection;
        }catch (Exception e){
            LOGGER.error("some error while saving to dynamo : ", e);
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.EXPORT,
                    "error while fetching records", ExceptionSeverity.MAJOR, null);
        }
    }

    @Override
    public String getRawConnection(ConnectionDtoType adapterType, Long recordId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        try{
            Table table = dynamoDB.getTable(tableNamePrefix.concat("_").concat(AppConstants.ADAPTER_CONNECTION_TABLE_NAME));

            QuerySpec spec = new QuerySpec()
                    .withKeyConditionExpression("parentId = :v_parentid AND recordId = :v_recordid")
                    .withValueMap(new ValueMap()
                            .withString(":v_parentid", authenticatedUserDetails.getTenantId().concat(":").concat(adapterType.toString()))
                            .withNumber(":v_recordid", recordId));

            ItemCollection<QueryOutcome> items = table.query(spec);

            Iterator<Item> iterator = items.iterator();
            while (iterator.hasNext()) {
                Item item = iterator.next();
                DynamoDBDto dynamoDBDto = JacksonUtils.fromJson(item.toJSON(), DynamoDBDto.class);
                return dynamoDBDto.getPayload();
            }

            return null;
        }catch (Exception e){
            LOGGER.error("some error while saving to dynamo : ", e);
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.EXPORT,
                    "error while fetching records", ExceptionSeverity.MAJOR, null);
        }
    }

    @Override
    public TxnAdapterConnection getConnectionByName(ConnectionDtoType adapterType, String connectionName, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        try{
            TxnAdapterConnection txnAdapterConnection = null;
            Table table = dynamoDB.getTable(tableNamePrefix.concat("_").concat(AppConstants.ADAPTER_CONNECTION_TABLE_NAME));
            Index index = table.getIndex("ConnectionNameLowerIndex");

            QuerySpec spec = new QuerySpec()
                    .withKeyConditionExpression("parentId = :v_parentid AND connectionNameLower = :v_connectionname")
                    .withFilterExpression("connectionName = :v_connectionname1 OR connectionName = :v_connectionname2")
                    .withValueMap(new ValueMap()
                            .withString(":v_parentid", authenticatedUserDetails.getTenantId().concat(":").concat(adapterType.toString()))
                            .withString(":v_connectionname", connectionName.toLowerCase())
                            .withString(":v_connectionname1", "VALID#"+connectionName)
                            .withString(":v_connectionname2", "INVALID#"+connectionName));

            ItemCollection<QueryOutcome> items = index.query(spec);

            Iterator<Item> iterator = items.iterator();
            while (iterator.hasNext()) {
                Item item = iterator.next();
                DynamoDBDto dynamoDBDto = JacksonUtils.fromJson(item.toJSON(), DynamoDBDto.class);
                txnAdapterConnection = new TxnAdapterConnection();
                txnAdapterConnection.setConnectionDtoType(adapterType);
                txnAdapterConnection.setRecordId(dynamoDBDto.getRecordId());
                txnAdapterConnection.setConnection(JacksonUtils.fromJson(dynamoDBDto.getPayload(), adapterType.getClassType()));
                break;
            }

            return txnAdapterConnection;
        }catch (Exception e){
            LOGGER.error("some error while saving to dynamo : ", e);
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.EXPORT,
                    "error while fetching records", ExceptionSeverity.MAJOR, null);
        }
    }

    @Override
    public boolean deleteConnectionById(ConnectionDtoType adapterType, Long connectionId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
       boolean result=false;
        try {
           Table table = dynamoDB.getTable(tableNamePrefix.concat("_").concat(AppConstants.ADAPTER_CONNECTION_TABLE_NAME));
           DeleteItemSpec deleteItemSpec = new DeleteItemSpec()
                   .withPrimaryKey("parentId", authenticatedUserDetails.getTenantId().toLowerCase() + ":" + adapterType.toString(), "recordId", connectionId);
            table.deleteItem(deleteItemSpec);
           result=true;

       }
       catch (Exception e){
            LOGGER.error("some error while deleting record in dynamo : ", e);
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.EXPORT,
                    "error while deleting record in dynamo", ExceptionSeverity.MAJOR, null);
        }
        return result;
        
    }

    @Override
    public String saveRawConnection(String rawConnection, ConnectionDtoType adapterType, Long recordId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException {
        return null;
    }
}
