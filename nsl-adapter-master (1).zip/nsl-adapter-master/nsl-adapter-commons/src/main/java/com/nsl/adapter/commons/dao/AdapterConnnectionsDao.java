package com.nsl.adapter.commons.dao;


import com.nsl.adapter.commons.dto.PaginatedConnectionsListDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;

import java.lang.reflect.Type;

public interface AdapterConnnectionsDao {
     PaginatedConnectionsListDto fetchAllConnections(ConnectionDtoType adapterType, String searchName, int pageNumber,
                                                     int pageSize, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException;

     TxnAdapterConnection saveConnection(TxnAdapterConnection txnAdapterConnection, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException;

     TxnAdapterConnection getConnectionByRecordId(ConnectionDtoType adapterType, Long recordId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException;

     String getRawConnection(ConnectionDtoType adapterType, Long recordId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException;

     TxnAdapterConnection getConnectionByName(ConnectionDtoType adapterType, String connectionName, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException;

     boolean deleteConnectionById(ConnectionDtoType adapterType, Long connectionId, AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException;

     String saveRawConnection(String rawConnection, ConnectionDtoType adapterType, Long recordId,
                                     AuthenticatedUserDetailsImpl authenticatedUserDetails) throws NSLException;

}
