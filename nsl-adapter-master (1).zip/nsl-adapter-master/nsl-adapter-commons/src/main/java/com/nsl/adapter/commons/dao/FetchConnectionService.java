package com.nsl.adapter.commons.dao;

import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;

public interface FetchConnectionService {

    <T> T getConnection(ConnectionDtoType connectionType, Long recordId, AuthenticatedUserDetailsImpl authBean) throws NSLException;
}
