package com.nsl.adapter.commons.enums;

public enum ModelStatus {
    TRAINING_PENDING,
    TRAINING_PROCESSING,
    APPROVAL_PENDING,
    APPROVED
}
