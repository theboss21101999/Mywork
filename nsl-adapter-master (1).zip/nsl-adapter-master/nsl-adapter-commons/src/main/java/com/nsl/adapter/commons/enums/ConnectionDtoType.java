package com.nsl.adapter.commons.enums;

import com.nsl.adapter.commons.dto.connections.*;

import java.lang.reflect.Type;

public enum ConnectionDtoType {
    REST (RESTAdapterConnectionDto.class),
    SFTP (SFTPAdapterConnectionDto.class),
    S3 (S3AdapterConnectionDto.class),
    Google (GoogleOauthDto.class),
    SMTP (SmtpAdapterConnectionDto.class),
    ZOOM (ZoomConnectionDto.class),
    DB (DBConnectionDto.class),
    Cisco (CiscoOauthconnectionDto.class),
    IMAP (ImapConnection.class),
    POP3 (PopAdapterDto.class),
    Kafka (KafkaConnectionDto.class),
    Graph (GraphOauthConnectionDto.class),
    MQTT(MqttConnectionDto.class),
    FACEBOOK(FacebookAdapterConnectionDto.class),
    JIRA(JiraAdapterConnectionDto.class),
    TWITTER(TwitterAdapterConnectionDto.class),
    DOCUSIGN(DocusignAdapterConnectionDto.class),
    ADOBESIGN(AdobeSignAdapterConnectionDto.class),
    AIML(AiMlConnectionDto.class),
    TELEGRAM(TelegramConnectionDto.class),
    LINKEDIN(LinkedinAdapterConnectionDto.class),
    SES (SESConnectionDto.class),
    InboundCu(MetaInfoEntityDto.class),

    SOAP(SoapAdapterConnectionDto.class),
    ActiveMQ(ActiveMQAdapterConnectionDto.class),
    IBMMQ(IBMMQAdapterConnectionDto.class),
    RabbitMQ(RabbitMQAdapterConnectionDto.class),
    FHIR(FhirAdapterConnectionDto.class),
    FTP(FtpAdapterConnectionDto.class),
    AS2(AS2AdapterConnectionDto.class),
    GRPC(GrpcAdapterConnectionDto.class),
    JDBC(JdbcAdapterConnectionDto.class),
    OPENAPI(OpenAPIConnectionDTO.class),
    GRAPHQL(GraphQLConnectionDto.class);


    ConnectionDtoType(Type classType) { this.classType = classType; }

    public Type getClassType() { return classType; }

    private Type classType;
}
