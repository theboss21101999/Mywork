package com.nsl.adapter.commons.dto;

import java.util.List;

public class PaginatedConnectionsListDto {
    List<ConnectionListDto> connectionsList;
    Integer pageNumber;
    Integer pageSize;
    Long totalHits;
    Integer currentPageSize;
    Long totalPages;

    public List<ConnectionListDto> getConnectionsList() {
        return connectionsList;
    }

    public void setConnectionsList(List<ConnectionListDto> connectionsList) {
        this.connectionsList = connectionsList;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public Long getTotalHits() {
        return totalHits;
    }

    public void setTotalHits(Long totalHits) {
        this.totalHits = totalHits;
    }

    public Integer getCurrentPageSize() {
        return currentPageSize;
    }

    public void setCurrentPageSize(Integer currentPageSize) {
        this.currentPageSize = currentPageSize;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Long getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(Long totalPages) {
        this.totalPages = totalPages;
    }
}
