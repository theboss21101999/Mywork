package com.nsl.adapter.commons.utils.create_entity;

import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.IRDRUtils;
import com.nsl.dsd.store.models.base.NslDataType;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityAttributeInput;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class CreateEntityFromCSVUtil extends CreateEntityUtil implements CreateEntityFromFile {


    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Autowired
    SaveBetsService saveBetsService;

    @Autowired
    IRDRUtils irdrUtils;

    @Override
    public TenantCUEntityInput convertFileIntoEntity(MultipartFile file, String entityName,Map<String,Object> PropertyMap) throws NSLException {

        try {
            String data = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))
                    .lines().collect(Collectors.joining("\n"));
            if (data.isEmpty())
                return null;
            List<String> dataList = new ArrayList<>(Arrays.asList(data.split("\n")));
            String delimeter;
            if (PropertyMap==null){
                delimeter="|";
            }else {
                delimeter = (String) PropertyMap.getOrDefault(AppConstants.DELIMETER,"|");
            }
            if(delimeter.equals("|")){
                delimeter="\\|";
            }
            String regex = delimeter+AppConstants.CSVRegex;
            List<String> headers = Arrays.asList(dataList.get(0).split(regex));
            List<String> values = Arrays.asList(dataList.get(1).split(regex));

            TenantCUEntityInput generalEntity = new TenantCUEntityInput();
            for (int i = 0; i < headers.size(); i++)
                updateGE(generalEntity, entityName,headers.get(i).trim(), values.get(i));

            return saveGE(generalEntity);

        }catch (NSLException e) {
            throw e;
        }catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"Exception while creating Entity: " +
                    e, ExceptionSeverity.MAJOR, e);
        }
    }

    private TenantCUEntityInput saveGE(TenantCUEntityInput generalEntity) throws NSLException {

        for (TenantCUEntityAttributeInput nslAttribute:generalEntity.getNslAttributes()){
            if (nslAttribute.getGeneralEntity()!=null)
                nslAttribute.setGeneralEntity(saveGE(nslAttribute.getGeneralEntity()));
        }
        return saveBetsService.saveGeneralEntity(generalEntity);
    }

    public void updateGE(TenantCUEntityInput generalEntity, String entityName, String header, String value) throws NSLException {

        if (generalEntity.getName() == null) {
            generalEntity.setName(entityName);
            generalEntity.setDisplayName(entityName);
            generalEntity.setNslAttributes(new ArrayList<>());
            generalEntity.setStatus(StatusEnum.DRAFT);
            irdrUtils.setGeIRDR(generalEntity);
        }

        String attrName;
        String subAttr;
        if (header.contains(".")) {
            String[] attribute = header.split("\\.", 2);
            attrName = attribute[0];
            subAttr = attribute[1];
        } else {
            attrName = header;
            subAttr = "";
        }

        if (subAttr.isEmpty()) {
            TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();
            nslAttribute.setName(attrName);
            nslAttribute.setDisplayName(attrName);

            NslDataType attributeType;
            if (value.contains(",")) {
                attributeType = getNslDataType(AppConstants.LIST);
                Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE,getNslDataType(value.split(",")[0].getClass().toString()));
                attributeType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);
            } else {
                attributeType = getNslDataType(value.getClass().toString());
            }

            attributeType.setUiElement(getUiElementInfo(value.getClass().toString()));
            nslAttribute.setAttributeType(attributeType);
            generalEntity.getNslAttributes().add(nslAttribute);
        } else {
            TenantCUEntityAttributeInput nslAttribute = null;
            for (TenantCUEntityAttributeInput attribute : generalEntity.getNslAttributes()) {
                if (attribute.getName().equals(attrName)) {
                    nslAttribute = attribute;
                    break;
                }
            }
            if (nslAttribute == null) {
                nslAttribute = new TenantCUEntityAttributeInput();
                nslAttribute.setName(attrName);
                nslAttribute.setDisplayName(attrName);

                NslDataType attributeType = getNslDataType(AppConstants.ENTITY);
                Map<String, String> attributeTypeProperties = new HashMap<>();
                attributeTypeProperties.put(AppConstants.REFERENCINGTYPE, attrName);
                attributeType.setProperties(attributeTypeProperties);

                nslAttribute.setAttributeType(attributeType);
                nslAttribute.setGeneralEntity(new TenantCUEntityInput());
                generalEntity.getNslAttributes().add(nslAttribute);
            }

            updateGE(nslAttribute.getGeneralEntity(), generalEntity.getName() + "_" + attrName, subAttr, value);
        }

    }

}
