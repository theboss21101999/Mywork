package com.nsl.adapter.commons.dto.connections;

import com.nsl.adapter.commons.enums.ModelType;

import java.util.List;
import java.util.Properties;

public class AiMlConnectionDto extends BasicAdapterConnection{
    Boolean labelledData;
    Boolean isMl;
    ModelType type;
    Boolean discardHeaderRow;
    List<String> inputColumns;
    List<String> outputColumns;
    String datasetKey;
    String modelKey;
    Properties properties = new Properties();

    public Boolean getLabelledData() {
        return labelledData;
    }

    public void setLabelledData(Boolean labelledData) {
        this.labelledData = labelledData;
    }

    public Boolean getIsMl() {
        return isMl;
    }

    public void setIsMl(Boolean ml) {
        isMl = ml;
    }

    public ModelType getType() {
        return type;
    }

    public void setType(ModelType type) {
        this.type = type;
    }

    public List<String> getInputColumns() {
        return inputColumns;
    }

    public void setInputColumns(List<String> inputColumns) {
        this.inputColumns = inputColumns;
    }

    public Boolean getDiscardHeaderRow() {
        return discardHeaderRow;
    }

    public void setDiscardHeaderRow(Boolean discardHeaderRow) {
        this.discardHeaderRow = discardHeaderRow;
    }

    public List<String> getOutputColumns() {
        return outputColumns;
    }

    public void setOutputColumns(List<String> outputColumns) {
        this.outputColumns = outputColumns;
    }

    public String getDatasetKey() {
        return datasetKey;
    }

    public void setDatasetKey(String datasetKey) {
        this.datasetKey = datasetKey;
    }

    public String getModelKey() {
        return modelKey;
    }

    public void setModelKey(String modelKey) {
        this.modelKey = modelKey;
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }
}
