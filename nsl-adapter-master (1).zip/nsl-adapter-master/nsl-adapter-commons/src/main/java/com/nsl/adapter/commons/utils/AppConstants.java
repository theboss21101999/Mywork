package com.nsl.adapter.commons.utils;

public final class AppConstants {


    public static final String ADAPTER = "adapter";
    public static final String EXTERNAL_SOLUTION_PREFIX = "externalSolution:";
    public static final String EXTERNAL_SOLUTION_TYPE = "extSolnsType";
    public static final String CONNECTION_NAME = "connectionName";
    public static final String CONFIG_ENTITY_RECORD_ID = "configEntityRecordId";

    public static final String BEARER = "Bearer ";
    public static final String DSD_ID = "dsdId";

    public static final String NAME = "name";
    public static final String ACCEPT_LANGUAGE_EN = "EN";
    public static final String SYSTEM_USER_DETAILS = "systemUserDetails";

    public static final String TYPE="type";
    public static final String SUB_TYPE="subType";
    public static final String ARRAY="array";
    public static final String OBJECT="object";
    public static final String LIST="List";
    public static final String ENTITY="Entity";
    public static final String MULTI_LINE="Multi Line";
    public static final String REFERENCINGTYPE="referencingType";
    public static final String ITEMTYPE="itemType";
    public static final String SCHEMA_REFFERENCE="$ref";
    public static final String SCHEMA_PROPERTIES="properties";
    public static final String SCHEMA_ITEMS="items";
    public static final String JSONOBJECT_CLASS="class org.json.JSONObject";
    public static final String JSONARRAY_CLASS="class org.json.JSONArray";

    public static final String OPTIONAL = "optional";

    public static final String PHYSICAL_LAYER = "physical";
    public static final String TRIGGER_CES_LAYER = "triggerces";
    public static final String INFORMATION_LAYER = "information";

    public static final String FILENAME="fileName";
    public static final String FILETYPE="fileType";

    public static final String DSD_LOCATION= "dsdLocation";
    public static final String CONTENT_URL= "contentUrl";

    public static final String XMLRegex= "(^[ \\t]+)|([ \\t]+$)|(?<=>)\\s+(?=<)|(?<==\")\\s+|\\s+(?=\")";

    public static final String ADAPTER_CONNECTION_TABLE_NAME= "a_adapters_connections";
    public static final String LAST_RUN_START_TIME = "last_run_start_time";
    public static final String GSI_ID_LIST = "gsi_id_list";

    public static final String ADAPTER_CACHE_NAME= "adapter_connections";

    public static final String DELIMETER = "delimeter";
    public static final String MAPPER="mapper";

    public static final String CSVRegex = "(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)";

    public static final String EXCLUDE = "exclude";

    public static final String INCLUDE = "include";

    public static final String EXCLUDE_PATTERN = "excludePattern";

    public static final String INCLUDE_PATTERN = "includePattern";
    public static final String MAX_RAISE = "maxRaise";

    public static final String LARGE_FILE_DELIVERY_TABLE_NAME = "large_file_delivery";

}
