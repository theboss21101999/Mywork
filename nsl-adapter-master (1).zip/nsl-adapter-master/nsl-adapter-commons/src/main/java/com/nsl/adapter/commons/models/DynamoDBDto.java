package com.nsl.adapter.commons.models;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.nsl.adapter.commons.utils.AppConstants;

@DynamoDBTable(tableName = AppConstants.ADAPTER_CONNECTION_TABLE_NAME)
public class DynamoDBDto {


    private String parentId;
    private Long insertTime;
    private Long recordId;
    private String connectionName;
    private String connectionNameLower;
    private String payload;

    @DynamoDBIndexRangeKey(attributeName = "connectionName", localSecondaryIndexName = "ConnectionNameIndex")
    @DynamoDBAttribute(attributeName = "connectionName")
    public String getConnectionName() {
        return connectionName;
    }

    public void setConnectionName(String connectionName) {
        this.connectionName = connectionName;
    }

    @DynamoDBIndexRangeKey(attributeName = "connectionNameLower", localSecondaryIndexName = "ConnectionNameLowerIndex")
    @DynamoDBAttribute(attributeName = "connectionNameLower")
    public String getConnectionNameLower() {
        return connectionNameLower;
    }

    public void setConnectionNameLower(String connectionNameLower) {
        this.connectionNameLower = connectionNameLower;
    }

    @DynamoDBAttribute(attributeName = "payload")
    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    @DynamoDBRangeKey(attributeName = "recordId")
    public Long getRecordId() {
        return recordId;
    }

    public void setRecordId(Long recordId) {
        this.recordId = recordId;
    }

    public DynamoDBDto() {
        super();
    }

    public DynamoDBDto(String parentId, Long insertTime, Long recordId, String connectionName, String connectionNameLower, String payload) {
        this.parentId = parentId;
        this.insertTime = insertTime;
        this.recordId = recordId;
        this.connectionName = connectionName;
        this.connectionNameLower = connectionNameLower;
        this.payload = payload;
    }

    @DynamoDBHashKey(attributeName = "parentId")
    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    @DynamoDBAttribute(attributeName = "insertTime")
    public Long getInsertTime() {
        return insertTime;
    }

    public void setInsertTime(Long insertTime) {
        this.insertTime = insertTime;
    }
}
