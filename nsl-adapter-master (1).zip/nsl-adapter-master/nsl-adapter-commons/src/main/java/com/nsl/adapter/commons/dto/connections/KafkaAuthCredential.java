package com.nsl.adapter.commons.dto.connections;

import com.nsl.adapter.commons.enums.KafkaAuthType;

public class KafkaAuthCredential {

    private String username;
    private String password;
    private KafkaAuthType authType;

    public KafkaAuthCredential() {
    }

    public KafkaAuthCredential(String username, String password, KafkaAuthType authType) {
        this.username = username;
        this.password = password;
        this.authType = authType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public KafkaAuthType getAuthType() {
        return authType;
    }

    public void setAuthType(KafkaAuthType authType) {
        this.authType = authType;
    }
}
