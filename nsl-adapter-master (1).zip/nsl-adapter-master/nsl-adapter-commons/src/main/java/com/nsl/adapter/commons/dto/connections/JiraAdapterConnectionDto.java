package com.nsl.adapter.commons.dto.connections;

import java.util.List;

public class JiraAdapterConnectionDto extends BasicAdapterConnection{
    String appId;
    String appSecret;
    String refreshToken;
    List<String> scope;

    public JiraAdapterConnectionDto() {
    }

    public JiraAdapterConnectionDto(String appSecret, String appId, String refreshToken, List<String> scope) {
        this.appSecret = appSecret;
        this.appId = appId;
        this.refreshToken = refreshToken;
        this.scope = scope;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public List<String> getScope() {
        return scope;
    }

    public void setScope(List<String> scope) {
        this.scope = scope;
    }
}
