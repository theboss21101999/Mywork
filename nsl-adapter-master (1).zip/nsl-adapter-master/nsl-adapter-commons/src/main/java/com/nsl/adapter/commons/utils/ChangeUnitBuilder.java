package com.nsl.adapter.commons.utils;

import com.nsl.dsd.store.models.tenant.io.TenantCULayerInput;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.model.Agent;

import java.util.List;
import java.util.Map;


public class ChangeUnitBuilder extends TenantChangeUnitInput {
    private  String name;
    private  String displayName;
    private boolean reserved;
    private String reservedCUType;
    private String version;
    private StatusEnum status;
    private List<Agent> agents;
    private List<TenantCULayerInput> layers;
    private Map<String, String> cuSystemProperties;

    public ChangeUnitBuilder name(String name)
    {
        this.name=name;
        return this;
    }
    public ChangeUnitBuilder displayName(String displayName)
    {
        this.displayName=displayName;
        return this;
    }
    public ChangeUnitBuilder reserved(boolean reserved)
    {
        this.reserved=reserved;
        return this;
    }
    public ChangeUnitBuilder reservedCUType(String reservedCUType)
    {
        this.reservedCUType=reservedCUType;
        return this;
    }
    public ChangeUnitBuilder version(String version)
    {
        this.version=version;
        return this;
    }
    public ChangeUnitBuilder status(StatusEnum status)
    {
        this.status=status;
        return this;
    }
    public ChangeUnitBuilder agents(List<Agent> agents)
    {
        this.agents=agents;
        return this;
    }
    public ChangeUnitBuilder layers(List<TenantCULayerInput> layers)
    {
        this.layers=layers;
        return this;
    }
    public ChangeUnitBuilder cuSystemProperties( Map<String, String> cuSystemProperties)
    {
        this.cuSystemProperties=cuSystemProperties;
        return this;
    }

    public TenantChangeUnitInput build() {
        TenantChangeUnitInput changeUnit = new TenantChangeUnitInput();
        changeUnit.setLayers(this.layers);
        changeUnit.setAgents(this.agents);
        changeUnit.setName(this.name);
        changeUnit.setDisplayName(this.displayName);
        changeUnit.setVersion(this.version);
        changeUnit.setReserved(this.reserved);
        changeUnit.setReservedCUType(this.reservedCUType);
        changeUnit.setStatus(this.status);
        changeUnit.setCuSystemProperties(this.cuSystemProperties);
        return changeUnit;
    }


}
