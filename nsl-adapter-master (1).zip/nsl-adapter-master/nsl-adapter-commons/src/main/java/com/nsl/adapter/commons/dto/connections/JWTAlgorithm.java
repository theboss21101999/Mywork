package com.nsl.adapter.commons.dto.connections;

public enum JWTAlgorithm {
    HMAC256,
    HMAC384,
    HMAC512
}
