package com.nsl.adapter.commons.enums;

public enum AdapterType {
    REST ("REST"),
    SFTP("SFTP"),
    KAFKA("Kafka"),
    POP3("POP3"),
    IMAP("IMAP"),
    S3("S3"),
    MQTT("MQTT"),
    STRIPE(null),
    RESTINBOUND(null),
    RESTOUTPUT(null),
    SMTP("SMTP"),

    FACEBOOK("FACEBOOK"),

    JIRA("JIRA"),
    TWITTER(null),
    GDRIVE("Google"),
    DB("DB"),
    STAGE(null),
    GOOGLECALENDAR("Google"),
    ONEDRIVE("Graph"),
    CISCOWEBEX("Cisco"),
    ZOOM("ZOOM"),
    MSTEAMS("Graph"),
    WEBHOOK(null),
    AIML("AIML"),
    TELEGRAM("TELEGRAM"),
    MONGODB("MONGODB"),
    GOOGLEFORMS("Google"),
    LINKEDIN("LINKEDIN"),
    MFT(null),
    MAPPER("mapper"),
    SES("SES"),
    DOCUSIGN("DOCUSIGN"),
    ADOBESIGN("ADOBESIGN"),


    // Integration Types
    SOAP("SOAP"),
    ACTIVEMQ("ACTIVEMQ"),
    IBMMQ("IBMMQ"),
    RABBITMQ("RABBITMQ"),
    FHIR("FHIR"),
    FTP("FTP"),
    FTPS("FTPS"),
    AS2("AS2"),
    GRPC("GRPC"),
    POSTGRESS("POSTGRESS"),
    MYSQL("MYSQL"),
    SQLSERVER("SQLSERVER"),
    JDBC("JDBC"),
    OPENAPI("OPENAPI"),
    GRAPHQL("GRAPHQL"),
    GOOGLE_SHEETS("GOOGLE");
    private String connectionType;

    AdapterType(String rest) {
        this.connectionType = rest;
    }

    public String getConnectionType() { return connectionType; }
}
