package com.nsl.adapter.commons.dto.connections;

public class GraphQLCredential{

    private GraphQLAuthType authType;
    private JWTAlgorithm jwtAlgorithm;
    private String jwtSecret;
    private String username;
    private String password;

    public GraphQLAuthType getAuthType() {
        return authType;
    }

    public void setAuthType(GraphQLAuthType authType) {
        this.authType = authType;
    }

    public JWTAlgorithm getJwtAlgorithm() {
        return jwtAlgorithm;
    }

    public void setJwtAlgorithm(JWTAlgorithm jwtAlgorithm) {
        this.jwtAlgorithm = jwtAlgorithm;
    }

    public String getJwtSecret() {
        return jwtSecret;
    }

    public void setJwtSecret(String jwtSecret) {
        this.jwtSecret = jwtSecret;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
