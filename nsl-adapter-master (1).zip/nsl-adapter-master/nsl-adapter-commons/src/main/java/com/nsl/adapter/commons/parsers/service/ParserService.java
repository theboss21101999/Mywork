package com.nsl.adapter.commons.parsers.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.FileUploadUtil;
import com.nsl.adapter.commons.utils.UUIDGenerator;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class ParserService {

    private static final Logger logger = LoggerFactory.getLogger(ParserService.class);

    @Autowired
    FileUploadUtil fileUploadUtil;

    public String uploadToDsd(InputStream inputStream, Map<String, String> cuSystemProp,
                                                            AuthenticatedUserDetailsImpl authBean) throws NSLException {
        String fileName = cuSystemProp.get(AppConstants.FILENAME);

        logger.info("Uploading file to DSD {}", fileName);
        File file = null;
        Path tempfolderpath = null;
        try {
            tempfolderpath = Files.createTempDirectory(UUIDGenerator.generateType1UUID()); //NOSONAR
            file = new File(tempfolderpath.toFile().getAbsolutePath(), fileName); //NOSONAR
            FileUtils.copyInputStreamToFile(inputStream, file);
            JsonNode uploadResponse = fileUploadUtil.uploadSingleFile(file, cuSystemProp.get(AppConstants.DSD_LOCATION),
                                                                                                        authBean);
            logger.info("JSON File " + fileName + " uploaded successfully to DSD..", uploadResponse);
            return uploadResponse.toString();
        } catch (Exception e) {
            logger.info("Exception occured while uploading JSON file " + fileName + " to DSD..", e.getMessage());
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.CU_GSI, "failed to upload file into DSD",
                    ExceptionSeverity.BLOCKER, e);
        } finally {
            if (file != null && file.exists() && file.delete()) {
                logger.info("Deleted Temporary file.");
            }
            if (tempfolderpath != null && tempfolderpath.toFile().exists() && tempfolderpath.toFile().delete()) {
                logger.info("Deleted Temporary folder.");
            }
        }
    }
}