package com.nsl.adapter.commons.utils.entity;


import com.nsl.datatypes.constants.AppConstants;
import com.nsl.logical.enums.DataType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import com.nsl.logical.std.logs.Category;
import com.nsl.logical.std.logs.ErrorType;
import com.nsl.logical.std.logs.MessageUtil;
import com.nsl.logical.std.logs.Module;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.nsl.adapter.commons.utils.AppConstants.ITEMTYPE;
import static com.nsl.adapter.commons.utils.AppConstants.PHYSICAL_LAYER;

@Service
public class EntityToJSONUtil {

    private static final Logger logger = LoggerFactory.getLogger(EntityToJSONUtil.class);
    public JSONObject createTransObject(TriggerCU triggerCu, TxnData transData) throws NSLException {

        List<TxnCULayer> txnCuLayers = transData.getTxnCULayer();
        List<TxnSlotItem> transEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnCuLayers, PHYSICAL_LAYER);
        TxnGeneralEntity txnGeneralEntity = GeneralEntityUtils.getExpectedTxnGeneralEntity(transEntityDetails);
        GeneralEntity inputGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, PHYSICAL_LAYER);
        return getJsonObjectFromGE(txnGeneralEntity,inputGeneralEntity);

    }

    public JSONObject getJsonObjectFromGE(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity)
                                                                                                throws NSLException {
        try {
            return getJsonArrayFromGE(txnGeneralEntity, inputGeneralEntity).getJSONObject(0);
        }catch (Exception e){
            throw new NSLException(ExceptionCategory.RESERVED_CU, ExceptionSubCategory.FETCH,
                    "failed to get Data from GE :"+ e.getMessage() , ExceptionSeverity.BLOCKER, e);
        }
    }

    public JSONArray getJsonArrayFromGE(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity) throws NSLException {
        try {
            Map<String, NslAttribute> dataTypeMap = new HashMap<>();
            getDataTypeMap(dataTypeMap, inputGeneralEntity, "");
            return getJsonFromEntity(dataTypeMap,txnGeneralEntity, "");
        }catch (Exception e){
            throw new NSLException(ExceptionCategory.RESERVED_CU, ExceptionSubCategory.FETCH,
                    "failed to get Data from GE :"+ e.getMessage() , ExceptionSeverity.BLOCKER, e);
        }
    }

    public JSONArray getJsonFromEntity (Map<String, NslAttribute> dataTypeMap , TxnGeneralEntity txnGeneralEntity,
                                                                   String prefixString ) throws JSONException, NSLException {

        JSONArray array = new JSONArray();
        logger.info("|||||||||||||||||||||||||");
        logger.info(dataTypeMap.toString());
        for (TxnGeneralEntityRecord txnGeneralEntityRecord : txnGeneralEntity.getTransEntityRecords()) {
            JSONObject extApiReqParams = getJsonFromEntity(dataTypeMap, txnGeneralEntityRecord , prefixString);
            array.put(extApiReqParams);
        }
        return array;
    }

    private JSONObject getJsonFromEntity( Map<String, NslAttribute> dataTypeMap,TxnGeneralEntityRecord txnGeRecord ,
                                            String prefixString) throws JSONException, NSLException {

        JSONObject extApiReqParams = new JSONObject();
        for (TxnNslAttribute attribute : txnGeRecord.getTxnNslAttribute()) {

                String key = attribute.getName();
                String attributeId;
                if(prefixString.equalsIgnoreCase(""))
                    attributeId=attribute.getNslAttributeID().toString();
                else
                    attributeId=prefixString+"."+attribute.getNslAttributeID();

                NslDataType nslDataType = dataTypeMap.get(attributeId).getAttributeType();
                DataType dataType = nslDataType.getType();

                logger.info(attributeId);
                if (dataType == DataType.ENTITY && attribute.getTxnGeneralEntity() != null) {
                    extApiReqParams.put(key, getJsonFromEntity(dataTypeMap, attribute.getTxnGeneralEntity(),
                                                                                            attributeId).getJSONObject(0));
                } else if ( dataType == DataType.LIST ) {
                    if(attribute.getTxnGeneralEntity() != null) {
                        extApiReqParams.put(key, getJsonFromEntity(dataTypeMap, attribute.getTxnGeneralEntity(), attributeId));
                    }else {
                        JSONArray values = new JSONArray();
                        if (!CollectionUtils.isEmpty(attribute.getValues()))
                            for (String value : attribute.getValues()){
                                values.put(
                                        (AppConstants.getValueFromPrimitiveType(value, nslDataType.getNestedNslDataTypeProperties().get(ITEMTYPE))));
                            }
                        extApiReqParams.put(key, values);
                    }
                }else {
                    if (!CollectionUtils.isEmpty(attribute.getValues())){
                        Object value = AppConstants.getValueFromPrimitiveType(attribute.getValues().get(0),nslDataType);
                        extApiReqParams.put(key, value);
                    }
                }
            }

        return extApiReqParams;
    }

    /************************************************************************************/

    public JSONObject getDataFromGE(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity) throws NSLException {
        try {
            Map<String, NslAttribute> dataTypeMap = new HashMap<>();
            getDataTypeMap(dataTypeMap, inputGeneralEntity, "");
            return createRequestForRestAdapter(dataTypeMap, txnGeneralEntity, inputGeneralEntity, "");
        }catch (Exception e){
            throw new NSLException(ExceptionCategory.RESERVED_CU, ExceptionSubCategory.FETCH,
                    "failed to get Data from GE :"+ e.getMessage() , ExceptionSeverity.BLOCKER, e);
        }
    }

    public JSONObject createRequestForRestAdapter( Map<String, NslAttribute> dataTypeMap,TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity, String prefixString)
            throws JSONException, NSLException {

        JSONObject extApiReqParams = new JSONObject();
        logger.info("|||||||||||||||||||||| extracting json from entity");
        logger.info(dataTypeMap.toString());
        for (TxnGeneralEntityRecord txnAttributeRecord : txnGeneralEntity.getTransEntityRecords()) {
            for (TxnNslAttribute attribute : txnAttributeRecord.getTxnNslAttribute()) {
                String key = attribute.getName();
                String attributeId;
                if(prefixString.equalsIgnoreCase(""))
                    attributeId=attribute.getNslAttributeID().toString();
                else
                    attributeId=prefixString+"."+attribute.getNslAttributeID();
                logger.info(attributeId);
                if (dataTypeMap.get(attributeId).getAttributeType().getType() == DataType.ENTITY
                        && attribute.getTxnGeneralEntity() != null) {
                    extApiReqParams.put(key, createRequestForRestAdapter(dataTypeMap,attribute.getTxnGeneralEntity(),dataTypeMap.get(attributeId).getGeneralEntity(),attributeId));
                } else if (dataTypeMap.get(attributeId).getAttributeType().getType() == DataType.LIST
                        && attribute.getTxnGeneralEntity() != null) {
                    extApiReqParams.put(key, createRequestForNestedList(attribute.getTxnGeneralEntity(), dataTypeMap,attributeId));
                } else if (dataTypeMap.get(attributeId).getAttributeType().getType() == DataType.LIST ||
                        isMultiselect(dataTypeMap.get(attributeId).getAttributeType())) {
                    JSONArray values = new JSONArray();
                    NslDataType dataType = new NslDataType();
                    dataType.setType(DataType.STRING);
                    if (attribute.getValues() != null && !attribute.getValues().isEmpty()) {
                        attribute.getValues().forEach(value -> {
                            try {
                                values.put((AppConstants.getValueFromPrimitiveType(value, dataType)));
                            } catch (NSLException e) {
                                logger.error(MessageUtil.format(Module.Platform,
                                        Category.NSL_RESERVED_CUS,
                                        null,
                                        (ErrorType) null,
                                        null,
                                        getClass().getName(),
                                        "The variable value is null"), e);
                            }
                        });
                    }
                    extApiReqParams.put(key, values);
                }else {
                    if (!CollectionUtils.isEmpty(attribute.getValues())){
                        Object value = AppConstants.getValueFromPrimitiveType(attribute.getValues().get(0),
                                dataTypeMap.get(attributeId).getAttributeType());
                        extApiReqParams.put(key, value);
                    }
                }
            }
        }
        return extApiReqParams;
    }


    private boolean isMultiselect(NslDataType attributeType) {
        if (DataType.STRING!=attributeType.getType())
            return false;
        if (attributeType.getExtendedProperties()!=null &&
                attributeType.getExtendedProperties().getOrDefault("sourceValues",null)!=null &&
                !attributeType.getExtendedProperties().get("sourceValues").isEmpty())
            return true;
        return false;
    }

    private JSONArray createRequestForNestedList(TxnGeneralEntity txnGeneralEntity,
                                                        Map<String, NslAttribute> dataTypeMap,String prefixString) throws JSONException, NSLException {
        JSONArray listParams = new JSONArray();
        for (TxnGeneralEntityRecord txnAttributeRecord : txnGeneralEntity.getTransEntityRecords()) {
            JSONObject param = new JSONObject();
            for (TxnNslAttribute attribute : txnAttributeRecord.getTxnNslAttribute()) {

                String key = attribute.getName();
                String attributeId;
                if(prefixString.equalsIgnoreCase(""))
                    attributeId=attribute.getNslAttributeID().toString();
                else
                    attributeId=prefixString+"."+attribute.getNslAttributeID();

                logger.info(attributeId);
                System.out.println(dataTypeMap.containsKey(attributeId));
                if (dataTypeMap.get(attributeId).getAttributeType().getType() == DataType.ENTITY
                        && attribute.getTxnGeneralEntity() != null) {
                    param.put(key, createRequestForRestAdapter(dataTypeMap,attribute.getTxnGeneralEntity(),dataTypeMap.get(attributeId).getGeneralEntity(),attributeId));
                } else if (dataTypeMap.get(attributeId).getAttributeType().getType() == DataType.LIST
                        && attribute.getTxnGeneralEntity() != null) {
                    param.put(key, createRequestForNestedList(attribute.getTxnGeneralEntity(), dataTypeMap,attributeId));
                } else if (dataTypeMap.get(attributeId).getAttributeType().getType() == DataType.LIST) {
                    JSONArray values = new JSONArray();
                    NslDataType dataType = new NslDataType();
                    dataType.setType(DataType.STRING);
                    if (attribute.getValues() != null && !attribute.getValues().isEmpty()) {
                        attribute.getValues().forEach(value -> {
                            try {
                                values.put((AppConstants.getValueFromPrimitiveType(value, dataType)));
                            } catch (NSLException e) {
                                logger.error(MessageUtil.format(Module.Platform,
                                        Category.NSL_RESERVED_CUS,
                                        null,
                                        (ErrorType) null,
                                        null,
                                        getClass().getName(),
                                        "The variable value is null"), e);
                            }
                        });
                    }
                    param.put(key, values);
                } else {
                    if (!CollectionUtils.isEmpty(attribute.getValues())){
                        Object value = AppConstants.getValueFromPrimitiveType(attribute.getValues().get(0),
                                dataTypeMap.get(attributeId).getAttributeType());
                        param.put(key, value);
                    }

                }
            }
            listParams.put(param);
        }
        return listParams;
    }

    public void getDataTypeMap(Map<String, NslAttribute> dataTypeMap, GeneralEntity generalEntity , String prefix) {
        if(!prefix.equalsIgnoreCase(""))
         prefix=prefix+".";
        if (generalEntity == null || generalEntity.getNslAttributes() == null || generalEntity.getNslAttributes().isEmpty())
            return;
        for (NslAttribute attribute : generalEntity.getNslAttributes()) {
            logger.info("attribute");
            logger.info(prefix+attribute.getId());
            dataTypeMap.put(prefix+attribute.getId(), attribute);
            if (attribute.getGeneralEntity() != null)
                getDataTypeMap(dataTypeMap, attribute.getGeneralEntity(),prefix+attribute.getId());
        }
    }
}