package com.nsl.adapter.commons.dto.connections;

public class HawkCredentials {

    private String authId;
    private String authKey;
    private String algorithm;
    private boolean payloadHash;

    public HawkCredentials() {
    }

    public HawkCredentials(String authId, String authKey, String algorithm, boolean payloadHash) {
        this.authId = authId;
        this.authKey = authKey;
        this.algorithm = algorithm;
        this.payloadHash = payloadHash;
    }

    public String getAuthId() {
        return authId;
    }

    public void setAuthId(String authId) {
        this.authId = authId;
    }

    public String getAuthKey() {
        return authKey;
    }

    public void setAuthKey(String authKey) {
        this.authKey = authKey;
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    public boolean isPayloadHash() {
        return payloadHash;
    }

    public void setPayloadHash(boolean payloadHash) {
        this.payloadHash = payloadHash;
    }
}
