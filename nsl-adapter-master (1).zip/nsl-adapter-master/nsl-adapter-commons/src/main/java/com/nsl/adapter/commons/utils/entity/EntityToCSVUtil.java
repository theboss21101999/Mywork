package com.nsl.adapter.commons.utils.entity;

import com.nsl.logical.enums.DataType;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class EntityToCSVUtil {


    public String createRequestForSftpAdapter(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity,
                                              String conflictAction,String delimeter) {

        Boolean fileAction = Boolean.FALSE;
        if ("append".equalsIgnoreCase(conflictAction))
            fileAction = Boolean.TRUE;

        Map<String, NslAttribute> dataTypeMap = new HashMap<>();
        getDataTypeMap(dataTypeMap, inputGeneralEntity, "");
        HashMap<String, String> csv = fetchDataString(txnGeneralEntity, dataTypeMap, "", true,delimeter);
        String value = csv.get("value");
        String header = csv.get("headers");

        if (fileAction)
            return value;
        return header + value;
    }

    public void getDataTypeMap(Map<String, NslAttribute> dataTypeMap, GeneralEntity generalEntity, String prefix) {
        if (generalEntity == null || generalEntity.getNslAttributes() == null ||
                generalEntity.getNslAttributes().isEmpty()) {
            return;
        }
        for (NslAttribute attribute : generalEntity.getNslAttributes()) {
            dataTypeMap.put(prefix + attribute.getName(), attribute);
            if (attribute.getGeneralEntity() != null)
                getDataTypeMap(dataTypeMap, attribute.getGeneralEntity(), prefix + attribute.getName() + ".");
        }
    }

    public HashMap<String, String> fetchDataString(TxnGeneralEntity txnGeneralEntity, Map<String, NslAttribute> dataTypeMap,
                                                   String prefixAttributeName, boolean isRoot,String delimeter) {
        return fetchDataString(txnGeneralEntity, dataTypeMap, prefixAttributeName, "", new HashMap<>(), isRoot, delimeter);
    }

    public HashMap<String, String> fetchDataString(TxnGeneralEntity txnGeneralEntity, Map<String, NslAttribute> dataTypeMap,
                                                   String prefixAttributeName, String mapperPrefix, Map<String, String> mapper, boolean isRoot,String delimeter) {

        List<TxnGeneralEntityRecord> txnGERecordList = txnGeneralEntity.getTransEntityRecords();

        boolean addHeaders = true;
        StringBuilder valueStringBuilder = new StringBuilder();
        StringBuilder headerBuilder = new StringBuilder();

        for (TxnGeneralEntityRecord txnGERecord : txnGERecordList) {
            StringBuilder rowStringBuilder = new StringBuilder();

            for (TxnNslAttribute txnNslAttribute : txnGERecord.getTxnNslAttribute()) {

                String attributeName = prefixAttributeName + txnNslAttribute.getName();
                String key = mapperPrefix + mapper.getOrDefault(attributeName, txnNslAttribute.getName());

                if (dataTypeMap.get(attributeName).getAttributeType().getType() == DataType.ENTITY) {
                    Map<String, String> subEntityCsv = fetchDataString(txnNslAttribute.getTxnGeneralEntity(), dataTypeMap, attributeName + ".", key + ".", mapper, false,delimeter);
                    rowStringBuilder.append(subEntityCsv.get("value").substring(1));
                    if (addHeaders)
                        headerBuilder.append(subEntityCsv.get("headers"));
                } else if (dataTypeMap.get(attributeName).getAttributeType().getType() == DataType.LIST) {
                    if (txnNslAttribute.getTxnGeneralEntity() != null) {
                        Map<String, String> listEntityCsv = fetchDataString(txnNslAttribute.getTxnGeneralEntity(), dataTypeMap,
                                attributeName + ".", key + ".", mapper, false,delimeter);
                        rowStringBuilder.append(listEntityCsv.get("value").substring(1));
                        if (addHeaders)
                            headerBuilder.append(listEntityCsv.get("headers"));


                    } else {
                        StringBuilder arraystringbuilder = new StringBuilder();
                        arraystringbuilder.append("\"");
                        for (String value : txnNslAttribute.getValues()) {
                            arraystringbuilder.append(value).append(",");
                        }
                        if(arraystringbuilder.length()>0){
                            arraystringbuilder.deleteCharAt(arraystringbuilder.length()-1);
                        }
                        arraystringbuilder.append("\"");
                        String arraystring = arraystringbuilder.toString();
                        if (addHeaders)
                            headerBuilder.append(key);
                        rowStringBuilder.append(arraystring.toString());//NOSONAR
                    }
                } else {
                    if (addHeaders)
                        headerBuilder.append(key);
                    if (!txnNslAttribute.getValues().isEmpty()) {
                        rowStringBuilder.append(convertToString(txnNslAttribute.getValues().get(0)));
                    }
                }

                if (addHeaders)
                    headerBuilder.append(delimeter);
                rowStringBuilder.append(delimeter);
            }

            addHeaders = false;
            String rowString = rowStringBuilder.toString();
            if (!rowString.isEmpty())
                valueStringBuilder.append("\n").append(rowString.substring(0,rowString.length()-1));
            if (!isRoot)
                break;
        }

        HashMap<String, String> csvData = new HashMap<>();
        csvData.put("headers", headerBuilder.substring(0,headerBuilder.length()-1));
        csvData.put("value", valueStringBuilder.toString());

        return csvData;

    }

    public String convertToString(String data){
        return new StringBuilder().append("\"").append(data).append("\"").toString();
    }

}
