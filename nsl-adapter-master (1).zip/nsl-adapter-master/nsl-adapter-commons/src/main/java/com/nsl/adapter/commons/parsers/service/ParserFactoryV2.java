package com.nsl.adapter.commons.parsers.service;

import com.nsl.adapter.commons.parsers.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ParserFactoryV2 {
    @Autowired
    JSONParserV2 jsonParserV2;

    @Autowired
    CSVParserV2 csvParserV2;

    @Autowired
    NativeParserV2 nativeParserV2;

    @Autowired
    XMLParserV2 xmlParserV2;

    @Autowired
    HL7ParserV2 hl7ParserV2;
    @Autowired
    ExcelParserV2 excelParserV2;

    public ParserV2 getParser(String fileType){
        switch (fileType.toLowerCase()) {
            case "json":
                return jsonParserV2;
            case "csv":
                return csvParserV2;
            case "native":
                return nativeParserV2;
            case "xml":
                return xmlParserV2;
            case "hl7":
                return hl7ParserV2;
            case "xlsx":
                return excelParserV2;
            default:
                return null;
        }
    }
}
