package com.nsl.adapter.commons.dto.connections;

public class SFTPCredential {

	private SFTPCredentialType type;
	private String username;
	private String password;
	private String sshKey;
//	private String keypath;
//	private String keyPassword;


	public SFTPCredentialType getType() {
		return type;
	}

	public void setType(SFTPCredentialType type) {
		this.type = type;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSshKey() {
		return sshKey;
	}

	public void setSshKey(String sshKey) {
		this.sshKey = sshKey;
	}
}