package com.nsl.adapter.commons.enums;


public enum ModelType {
    TEXT_CLASSIFICATION,
    REGRESSION
}
