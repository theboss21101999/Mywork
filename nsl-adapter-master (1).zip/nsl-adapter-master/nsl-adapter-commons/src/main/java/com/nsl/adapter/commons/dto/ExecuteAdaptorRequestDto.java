package com.nsl.adapter.commons.dto;

import java.io.Serializable;

public class ExecuteAdaptorRequestDto implements Serializable {

    private String triggerCU;

    private String transData;

    public String getTriggerCU() {
        return triggerCU;
    }

    public void setTriggerCU(String triggerCU) {
        this.triggerCU = triggerCU;
    }

    public String getTransData() {
        return transData;
    }

    public void setTransData(String transData) {
        this.transData = transData;
    }

    @Override
    public String toString() {
        return "ExecuteAdaptorRequestDto [transData=" + transData + ", triggerCU=" + triggerCU + "]";
    }

}
