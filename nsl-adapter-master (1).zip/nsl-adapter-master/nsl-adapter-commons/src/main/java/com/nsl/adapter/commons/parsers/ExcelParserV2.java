package com.nsl.adapter.commons.parsers;

import com.google.common.reflect.TypeToken;
import com.nsl.adapter.commons.parsers.service.ParserV2;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.entity.CSVToEntityUtil;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.commons.utils.entity.TxnDataUtils;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;

@Service
public class ExcelParserV2 implements ParserV2  {
    @Autowired
    TxnDataUtils txnDataUtils;
    @Autowired
    EntityToJSONUtil entityToJSONUtil;

    @Override
    public InputStream outboundParser(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity, Boolean isFileExists, Map<String, String> cuSystemProps) throws NSLException {
        JSONObject jsonObject = entityToJSONUtil.getJsonObjectFromGE(txnGeneralEntity, inputGeneralEntity);
        boolean create_horizontal = Boolean.parseBoolean(cuSystemProps.getOrDefault("horizontal", String.valueOf(true)));
        try (Workbook workbook = new XSSFWorkbook()) {  // Create a new sheet
            Sheet sheet = workbook.createSheet("Data");
            if (create_horizontal) {
                // Create the header row
                Row headerRow = sheet.createRow(0);
                int columnCount = 0;
                for (Iterator it = jsonObject.keys(); it.hasNext(); ) {
                    String key = (String) it.next();
                    Cell cell = headerRow.createCell(columnCount);
                    cell.setCellValue(key);
                    columnCount++;
                }

                // Create data rows
                int rowCount = 1;
                Row dataRow = sheet.createRow(rowCount);
                columnCount = 0;
                for (Iterator it = jsonObject.keys(); it.hasNext(); ) {
                    String key = (String) it.next();
                    Cell cell = dataRow.createCell(columnCount);
                    Object value = null;
                    try {
                        value = jsonObject.get(key);
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                    cell.setCellValue(value.toString());
                    columnCount++;
                }
            } else {
                int rowCount = 0;
                for (Iterator it = jsonObject.keys(); it.hasNext(); ) {
                    String key = (String) it.next();
                    Row row = sheet.createRow(rowCount);
                    Cell cell = row.createCell(0);
                    cell.setCellValue(key);
                    rowCount++;
                }

                // Create data columns
                rowCount = 0;
                int columnCount = 1;
                for (Iterator it = jsonObject.keys(); it.hasNext(); ) {
                    String key = (String) it.next();
                    Row row = sheet.getRow(rowCount);
                    if (row == null) {
                        row = sheet.createRow(rowCount);
                    }
                    Cell cell = row.createCell(columnCount);
                    Object value = null;
                    try {
                        value = jsonObject.get(key);
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                    cell.setCellValue(value.toString());
                    rowCount++;
                }
            }
                // Write the workbook content to a ByteArrayOutputStream
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                try {
                    workbook.write(outputStream);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                // Convert the ByteArrayOutputStream to an InputStream
                ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());
                return inputStream;
            } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }





    @Override
    public List<TxnData> inboundParser(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued, Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {
        List<TxnData> transDatas = new ArrayList<>();
        List<TxnGeneralEntity> txnGeneralEntityList = inboundParserV2(inputStream,tcesGeneralEntity,isMultivalued,cuSystemProp,LayerType.PHYSICAL,authBean);
        for (TxnGeneralEntity txnGeneralEntity:txnGeneralEntityList){
            transDatas.add(txnDataUtils.setChangeDriverInTxnData(txnGeneralEntity,layerType));
        }
        return transDatas;
    }

    @Override
    public List<TxnGeneralEntity> inboundParserV2(InputStream inputStream, GeneralEntity tcesGeneralEntity, boolean isMultivalued, Map<String, String> cuSystemProp, LayerType layerType, AuthenticatedUserDetailsImpl authBean) throws NSLException {
        boolean extract_horizontal = Boolean.parseBoolean(cuSystemProp.getOrDefault("horizontal", String.valueOf(true)));
        Workbook workbook = null;
        try {
            workbook = WorkbookFactory.create(inputStream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Sheet sheet = workbook.getSheetAt(0);
        List<List<String>> data = new ArrayList<>();
        List<String> headers= new ArrayList<>();
        Map<String, Integer> headersMap = new HashMap<>();
        if (extract_horizontal) {
            // Extract data vertically
            int rowCount = sheet.getLastRowNum() + 1;
            for (int rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                if(rowIndex==0){
                    Row row = sheet.getRow(rowIndex);
                    if (row != null) {
                        int cellCount = row.getLastCellNum();
                        for (int cellIndex = 0; cellIndex < cellCount; cellIndex++) {
                            Cell cell = row.getCell(cellIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                            String cellValue = getCellValue(cell);
                            headers.add(cellValue);
                        }
                        for (int i=0; i<headers.size(); i++)
                            headersMap.put(headers.get(i),i);
                    }
                }
                else {
                    Row row = sheet.getRow(rowIndex);
                    List<String> rowData = new ArrayList<>();

                    if (row != null) {
                        int cellCount = row.getLastCellNum();
                        if(cellCount==-1){
                            continue;
                        }
                        for (int cellIndex = 0; cellIndex < cellCount; cellIndex++) {
                            Cell cell = row.getCell(cellIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                            String cellValue = getCellValue(cell);
                            rowData.add(cellValue);
                        }
                    }
                    data.add(rowData);
                }
            }
        }
        else {
            // Extract data vertically
            int rowCount = sheet.getLastRowNum() + 1;
            int columnCount = sheet.getRow(0).getLastCellNum();

            for (int columnIndex = 0; columnIndex < columnCount; columnIndex++) {
                if(columnIndex==0) {
                    for (int rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                        Row row = sheet.getRow(rowIndex);
                        Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                        if (cell != null) {
                            String cellValue = getCellValue(cell);
                            headers.add(cellValue);
                        }
                        for (int i = 0; i < headers.size(); i++)
                            headersMap.put(headers.get(i), i);
                    }
                }
                else {
                    List<String> columnData = new ArrayList<>();
                    for (int rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                        Row row = sheet.getRow(rowIndex);
                        Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                        if (cell != null) {
                            String cellValue = getCellValue(cell);
                            columnData.add(cellValue);
                        }
                        else{
                            columnData.add("\n");
                        }
                    }
                    data.add(columnData);
                }
            }
        }
        try {
            workbook.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Map<String, Map<String, String>> mappers = new HashMap<>();
        if (cuSystemProp.containsKey(AppConstants.MAPPER) || cuSystemProp.get(AppConstants.MAPPER) != null) {
            mappers = JacksonUtils.fromJson(cuSystemProp.get(AppConstants.MAPPER), new TypeToken<Map<String, Map<String, String>>>() {}.getType());
        }
        List<TxnGeneralEntity> txnGeneralEntity = new ArrayList<>();
        if(mappers!=null) {
            if (isMultivalued) {
                txnGeneralEntity.add(CSVToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity,
                        headersMap, data, "","", mappers.getOrDefault(tcesGeneralEntity.getId().toString(), new HashMap<>())));
            } else {
                Map<String, Map<String, String>> finalMappers = mappers;
                data.forEach(x -> {
                    txnGeneralEntity.add(CSVToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity,
                            headersMap, Collections.singletonList(x), "","", finalMappers.getOrDefault(tcesGeneralEntity.getId().toString(), new HashMap<>())));

                });
            }
        }
        else{
            if (isMultivalued) {
                txnGeneralEntity.add(CSVToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity,
                        headersMap, data, ""));
            } else {
                data.forEach(x -> {
                    txnGeneralEntity.add(CSVToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity,
                            headersMap, Collections.singletonList(x), ""));
                });
            }
        }
        return txnGeneralEntity;
    }

    private String getCellValue(Cell cell) {
        if (cell.getCellType() == CellType.STRING) {
            return cell.getStringCellValue();
        } else if (cell.getCellType() == CellType.NUMERIC) {
            return String.valueOf(cell.getNumericCellValue());
        } else if (cell.getCellType() == CellType.BOOLEAN) {
            return String.valueOf(cell.getBooleanCellValue());
        } else {
            return "";
        }
    }

    }
