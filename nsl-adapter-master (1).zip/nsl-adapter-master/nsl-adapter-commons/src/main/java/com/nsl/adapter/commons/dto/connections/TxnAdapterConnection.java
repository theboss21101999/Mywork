package com.nsl.adapter.commons.dto.connections;

import com.nsl.adapter.commons.enums.ConnectionDtoType;

public class TxnAdapterConnection {
    private Long recordId;
    private BasicAdapterConnection connection;
    private ConnectionDtoType connectionDtoType;

    public TxnAdapterConnection(ConnectionDtoType dtoType){
        this.connectionDtoType = dtoType;
    }

    public TxnAdapterConnection(BasicAdapterConnection adapterConnection, ConnectionDtoType dtoType){
        this.connection = adapterConnection;
        this.connectionDtoType = dtoType;
    }

    public TxnAdapterConnection() {
    }

    public Long getRecordId() {
        return recordId;
    }

    public void setRecordId(Long recordId) {
        this.recordId = recordId;
    }

    public BasicAdapterConnection getConnection() {
        return connection;
    }

    public void setConnection(BasicAdapterConnection connection) {
        this.connection = connection;
    }

    public ConnectionDtoType getConnectionDtoType() {
        return connectionDtoType;
    }

    public void setConnectionDtoType(ConnectionDtoType connectionDtoType) {
        this.connectionDtoType = connectionDtoType;
    }
}
