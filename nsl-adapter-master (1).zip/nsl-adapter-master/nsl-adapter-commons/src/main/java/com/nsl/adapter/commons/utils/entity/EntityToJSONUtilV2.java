package com.nsl.adapter.commons.utils.entity;

import com.nsl.datatypes.constants.AppConstants;
import com.nsl.logical.enums.DataType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.NslDataType;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import com.nsl.logical.std.logs.Category;
import com.nsl.logical.std.logs.ErrorType;
import com.nsl.logical.std.logs.MessageUtil;
import com.nsl.logical.std.logs.Module;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class EntityToJSONUtilV2 {

    private static final Logger logger = LoggerFactory.getLogger(EntityToJSONUtilV2.class);

    private final List<DataType> dateTimeTypesList = new ArrayList<>(
            Arrays.asList(DataType.DATE, DataType.DATE_ONLY, DataType.DATE_TIME,
                    DataType.CURRENT_DATE, DataType.CURRENT_DATE_TIME));

    private final List<DataType> dateTypesList = new ArrayList<>(
            Arrays.asList(DataType.DATE, DataType.DATE_ONLY, DataType.CURRENT_DATE));

    public JSONObject createRequestForRestAdapter( Map<String, NslAttribute> dataTypeMap,TxnGeneralEntity txnGeneralEntity, String prefixString)
            throws JSONException, NSLException {

        JSONObject extApiReqParams = new JSONObject();
        logger.info("|||||||||||||||||||||| extracting json from entity");
        logger.info(dataTypeMap.toString());
        for (TxnGeneralEntityRecord txnAttributeRecord : txnGeneralEntity.getTransEntityRecords()) {
            return createRequestFromTxnRecord(dataTypeMap, txnAttributeRecord, prefixString,"", false, new HashMap<>());
        }
        return extApiReqParams;
    }

//    public JSONObject createRequestForRestAdapter( Map<String, NslAttribute> dataTypeMap,TxnGeneralEntity txnGeneralEntity, String prefixString, boolean excludeFiles)
//            throws JSONException, NSLException {
//        return createRequestForRestAdapter(dataTypeMap, txnGeneralEntity, prefixString,"", excludeFiles, new HashMap<>());
//    }

    public JSONObject createRequestForRestAdapter( Map<String, NslAttribute> dataTypeMap,TxnGeneralEntity txnGeneralEntity,
                                                   String prefixString, String mapperString, boolean excludeFiles, Map<String, String> mapper) throws JSONException, NSLException {

        logger.info("|||||||||||||||||||||| extracting json from entity");
        logger.info(dataTypeMap.toString());
        for (TxnGeneralEntityRecord txnAttributeRecord : txnGeneralEntity.getTransEntityRecords()) {
            return createRequestFromTxnRecord(dataTypeMap, txnAttributeRecord, prefixString,mapperString, excludeFiles, mapper);
        }
        return new JSONObject();
    }

    private JSONObject createRequestFromTxnRecord( Map<String, NslAttribute> dataTypeMap,TxnGeneralEntityRecord txnAttributeRecord,
                                                   String prefixString, String mapperString, boolean excludeFiles, Map<String, String> mapper) throws JSONException, NSLException {

        JSONObject extApiReqParams = new JSONObject();
        for (TxnNslAttribute attribute : txnAttributeRecord.getTxnNslAttribute()) {

            String attributeId;
            String attributeName;
            if(prefixString.equalsIgnoreCase(""))
                attributeId=attribute.getNslAttributeID().toString();
            else
                attributeId=prefixString+"."+attribute.getNslAttributeID();

            if(mapperString.equalsIgnoreCase(""))
                attributeName=attribute.getName();
            else
                attributeName=mapperString+"."+attribute.getName();
            String key = mapper.getOrDefault(attributeName, attribute.getName());
            logger.info(attributeId);
            logger.info(attributeName);
            if (dataTypeMap.get(attributeId).getAttributeType().getType() == DataType.ENTITY
                    && attribute.getTxnGeneralEntity() != null) {
                extApiReqParams.put(key, createRequestForRestAdapter(dataTypeMap,attribute.getTxnGeneralEntity(),attributeId, attributeName, excludeFiles, mapper));
            } else if (dataTypeMap.get(attributeId).getAttributeType().getType() == DataType.LIST
                    && attribute.getTxnGeneralEntity() != null) {
                extApiReqParams.put(key, createRequestForEntityList(dataTypeMap,attribute.getTxnGeneralEntity(),attributeId, attributeName, excludeFiles, mapper));
            } else if (dataTypeMap.get(attributeId).getAttributeType().getType() == DataType.LIST ||
                    isMultiselect(dataTypeMap.get(attributeId).getAttributeType())) {
                JSONArray values = new JSONArray();
                NslDataType dataType = new NslDataType();
                dataType.setType(DataType.STRING);
                if (attribute.getValues() != null && !attribute.getValues().isEmpty()) {
                    attribute.getValues().forEach(value -> {
                        try {
                            values.put((AppConstants.getValueFromPrimitiveType(value, dataType)));
                        } catch (NSLException e) {
                            logger.error(MessageUtil.format(Module.Platform,
                                    Category.NSL_RESERVED_CUS,
                                    null,
                                    (ErrorType) null,
                                    null,
                                    getClass().getName(),
                                    "The variable value is null"), e);
                        }
                    });
                }
                extApiReqParams.put(key, values);
            }else {
                if (!CollectionUtils.isEmpty(attribute.getValues())
                        && (!excludeFiles || dataTypeMap.get(attributeId).getAttributeType().getType()!=DataType.FILE)){
                    Object value = AppConstants.getValueFromPrimitiveType(attribute.getValues().get(0),
                            dataTypeMap.get(attributeId).getAttributeType());
                    if (dateTimeTypesList.contains(dataTypeMap.get(attributeId).getAttributeType().getType()) //NOSONAR
                            && dataTypeMap.get(attributeId).getAttributeType().getProperties()!=null
                            && dataTypeMap.get(attributeId).getAttributeType().getProperties().containsKey("format")){
                        value = ((ZonedDateTime) value).format(
                                DateTimeFormatter.ofPattern(getDateTimeFormat(dataTypeMap.get(attributeId)
                                        .getAttributeType())));
                    }
                    extApiReqParams.put(key, value);
                }
            }
        }
        return extApiReqParams;
    }

    private String getDateTimeFormat(NslDataType dataType){
        Map<String, String> properties = dataType.getProperties();
        String format = properties.get("format");
        if (dateTypesList.contains(dataType.getType())){//NOSONAR
            return format;
        }
        switch (properties.getOrDefault("timeFormat","")){
            case "12-hr":
                if(format==null) format = "MM/dd/yyyy";
                format+=" hh:mm a";
                break;
            case "24-hr":
                if(format==null) format = "dd/MM/yyyy";
                format+=" HH:mm";
                break;
            default:
                format="MM/dd/yyyy HH:mm";
                break;
        }
        return format;
    }


    private boolean isMultiselect(NslDataType attributeType) {
        if (DataType.STRING!=attributeType.getType())
            return false;
        if (attributeType.getExtendedProperties()!=null &&
                attributeType.getExtendedProperties().getOrDefault("sourceValues",null)!=null &&
                !attributeType.getExtendedProperties().get("sourceValues").isEmpty())
            return true;
        return false;
    }

    private JSONArray createRequestForEntityList(Map<String, NslAttribute> dataTypeMap,TxnGeneralEntity txnGeneralEntity,
                                                 String prefixString, String mapperString,
                                                 boolean excludeFiles, Map<String, String> mapper) throws JSONException, NSLException {
        JSONArray listParams = new JSONArray();
        for (TxnGeneralEntityRecord txnAttributeRecord : txnGeneralEntity.getTransEntityRecords()) {
            listParams.put(createRequestFromTxnRecord(dataTypeMap, txnAttributeRecord, prefixString, mapperString, excludeFiles, mapper));
        }
        return listParams;
    }

    public JSONArray createRequestForEntityList(Map<String, NslAttribute> dataTypeMap, TxnGeneralEntity txnGeneralEntity,
                                                String prefixString, boolean excludeFiles, Map<String, String> mapper) throws JSONException, NSLException {
        return createRequestForEntityList(dataTypeMap, txnGeneralEntity, prefixString, "", excludeFiles, mapper);
    }


    public void getDataTypeMap(Map<String, NslAttribute> dataTypeMap, GeneralEntity generalEntity , String prefix) {
        if(!prefix.equalsIgnoreCase(""))
            prefix=prefix+".";
        if (generalEntity == null || generalEntity.getNslAttributes() == null || generalEntity.getNslAttributes().isEmpty())
            return;
        for (NslAttribute attribute : generalEntity.getNslAttributes()) {
            logger.info("attribute");
            logger.info(prefix+attribute.getId());
            dataTypeMap.put(prefix+attribute.getId(), attribute);
            if (attribute.getGeneralEntity() != null)
                getDataTypeMap(dataTypeMap, attribute.getGeneralEntity(),prefix+attribute.getId());
        }
    }

    public JSONObject getJsonObjectFromGE(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity)
            throws NSLException {
        try {
            return getJsonArrayFromGE(txnGeneralEntity, inputGeneralEntity).getJSONObject(0);
        }catch (Exception e){
            throw new NSLException(ExceptionCategory.RESERVED_CU, ExceptionSubCategory.FETCH,
                    "failed to get Data from GE :"+ e.getMessage() , ExceptionSeverity.BLOCKER, e);
        }
    }

    public JSONArray getJsonArrayFromGE(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity) throws NSLException {
        try {
            Map<String, NslAttribute> dataTypeMap = new HashMap<>();
            getDataTypeMap(dataTypeMap, inputGeneralEntity, "");
            JSONArray array = new JSONArray();
            for (TxnGeneralEntityRecord txnGeneralEntityRecord : txnGeneralEntity.getTransEntityRecords()) {
                array.put(createRequestFromTxnRecord(dataTypeMap,txnGeneralEntityRecord, "",
                        "", false, new HashMap<>()));
            }
            return array;
        }catch (Exception e){
            throw new NSLException(ExceptionCategory.RESERVED_CU, ExceptionSubCategory.FETCH,
                    "failed to get Data from GE :"+ e.getMessage() , ExceptionSeverity.BLOCKER, e);
        }
    }
}
