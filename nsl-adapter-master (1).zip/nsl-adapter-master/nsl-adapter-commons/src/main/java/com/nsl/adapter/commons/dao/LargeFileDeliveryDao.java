package com.nsl.adapter.commons.dao;

import com.nsl.adapter.commons.enums.TransferStatus;
import com.nsl.adapter.commons.models.LargeFileDto;
import com.nsl.logical.exception.NSLException;

import java.util.List;

public interface LargeFileDeliveryDao {
    String save(LargeFileDto largeFileDto) throws NSLException;

    LargeFileDto fetchByTransferId(String transferId, String parentId);

    List<LargeFileDto> fetchByTransferStatus(TransferStatus transferStatus, String parentId);

    LargeFileDto updateCurrentSize(String transferId, String parentId, Long currentSize) throws NSLException;

    LargeFileDto updateTransferStatus(String transferId, String parentId, TransferStatus transferStatus);
}
