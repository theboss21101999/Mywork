package com.nsl.adapter.commons.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.dto.ConnectionListDto;
import com.nsl.adapter.commons.dto.ContextualInfoDto;
import com.nsl.adapter.commons.dto.PaginatedContextualInfoDto;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.SearchCUDAO;
import com.nsl.logical.dto.search.Sort;
import com.nsl.logical.dto.search.TxnGeneralEntitySearchRequest;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class ContextualInfoSavingService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ContextualInfoSavingService.class);

    @Autowired
    AdapterConnectionServiceV3 adapterConnectionServiceV3;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;
    @Autowired
    SearchCUDAO searchCUDAO;

    public void saveRecords(int errorRecords, int successfullRecords, AuthenticatedUserDetailsImpl authBean, AdapterType adapterType, String fileName) {
        try {
            GeneralEntity generalEntity = adapterConnectionServiceV3.getGEByName("NSL_ContextualRecord_Info",authBean);
            JSONObject Dto = RecordDto(errorRecords,successfullRecords,adapterType,fileName);
            List<TxnNslAttribute> attributesList = connectionDataToolsV3.JsonToAttributeList(JacksonUtils.fromJson(Dto.toString(), JsonNode.class), generalEntity,authBean.getTenantId() ,true);
            TxnGeneralEntityRecord entityRecord = new TxnGeneralEntityRecord();
            entityRecord.setTxnNslAttribute(attributesList);
            List<TxnGeneralEntityRecord> entityRecordList = new ArrayList<>();
            entityRecordList.add(entityRecord);
            adapterConnectionServiceV3.saveEntityRecord(entityRecordList,generalEntity,authBean,"create");
            LOGGER.info("Successfully saved record info {}",Dto);
        }catch (Exception e){
            LOGGER.info("Error in saving Record info {}",e.getMessage());
        }
    }

    public PaginatedContextualInfoDto getContextualInfoList(Integer pageNumber, Integer pageSize, String geName, String query,AuthenticatedUserDetailsImpl authBean) {
        StringBuilder result = new StringBuilder();
        if (query!=null){
            String[] list = query.split("");
            for (String ch: list)
                result.append("[").append(ch.toUpperCase(Locale.ROOT)).append(ch.toLowerCase(Locale.ROOT)).append("]");
        }

        String searchQuery;
        if (query==null || query.isEmpty())
            searchQuery = "";
        else
            searchQuery = "REGEX.*"+ result +".*";

        GeneralEntity generalEntity = adapterConnectionServiceV3.getGEByName(geName, authBean);
        List<TxnGeneralEntityRecord> response = getRecordListSorted(generalEntity, searchQuery, authBean);

        List<TxnGeneralEntityRecord> paginatedList = adapterConnectionServiceV3.getSubList(response,pageSize,pageNumber);

        List<ContextualInfoDto> recordList = new ArrayList<>();
        paginatedList.forEach(x -> {
            ContextualInfoDto dto = new ContextualInfoDto();
            List<TxnNslAttribute> attributeList = x.getTxnNslAttribute();
            for (TxnNslAttribute attribute : attributeList){
                   switch (attribute.getName()){
                       case "TimeStamp":
                           dto.setTimeStamp(attribute.getValues().get(0));
                           break;
                       case "FileName":
                           dto.setFileName(attribute.getValues().get(0));
                           break;
                       case "SuccessFullRecords":
                           dto.setSuccessFullRecords(attribute.getValues().get(0));
                           break;
                       case "ErrorRecords":
                           dto.setErrorRecords(attribute.getValues().get(0));
                           break;
                       case "Adapter":
                           dto.setAdapter(attribute.getValues().get(0));
                           break;
                   }
            }
            recordList.add(dto);
        });
        PaginatedContextualInfoDto paginatedContextualInfoDto = new PaginatedContextualInfoDto();
        paginatedContextualInfoDto.setContextualInfoDtoList(recordList);
        paginatedContextualInfoDto.setPageNumber(pageNumber);
        paginatedContextualInfoDto.setPageSize(pageSize);
        paginatedContextualInfoDto.setCurrentPageSize(recordList.size());
        paginatedContextualInfoDto.setTotalHits((long) recordList.size());
        float noOfPages;
        if (recordList.isEmpty())
            noOfPages = 0;
        else
            noOfPages = (float) response.size() / pageSize;  //NOSONAR
        paginatedContextualInfoDto.setTotalPages((long) Math.ceil(noOfPages));
        return paginatedContextualInfoDto;
    }

        public JSONObject RecordDto(int errorRecords, int successfullRecords,AdapterType adapterType,String fileName) throws JSONException {
        JSONObject jsonObject= new JSONObject();
        jsonObject.put("TimeStamp",new SimpleDateFormat("yyyy/MM/dd HH:mm").format(new Date()));
        jsonObject.put("FileName",fileName);
        jsonObject.put("SuccessFullRecords",successfullRecords);
        jsonObject.put("ErrorRecords",errorRecords);
        jsonObject.put("Adapter",adapterType.getConnectionType());
        return jsonObject;
    }
    public List<TxnGeneralEntityRecord> getRecordListSorted(GeneralEntity generalEntity, String searchQuery, AuthenticatedUserDetailsImpl authBean)  {
        List<NslAttribute> attributes = generalEntity.getNslAttributes();
        for(NslAttribute attribute:attributes){
            if(attribute.getName().equalsIgnoreCase("connectionName") && !searchQuery.isEmpty()){
                attribute.setMemberShip(searchQuery);
            }
        }

        TxnGeneralEntitySearchRequest dto1= new TxnGeneralEntitySearchRequest();
        Sort sort = new Sort();
        sort.setFieldName(generalEntity.getName()+".TimeStamp");
        sort.setOrder(Sort.Order.DESC);
        dto1.setSortList(Collections.singletonList(sort));
        dto1.setGeneralEntity(generalEntity);
        List<TxnGeneralEntitySearchRequest> generalEntityList = new ArrayList<>();
        generalEntityList.add(dto1);
        LOGGER.info("calling searchCuDao -> {}",searchCUDAO.getClass().getName());
        List<TxnGeneralEntityRecord> entityRecords = searchCUDAO.getEntities(generalEntityList, authBean);
        LOGGER.info("found {} records",entityRecords.size());
        return entityRecords;
    }
}
