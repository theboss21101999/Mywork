package com.nsl.adapter.commons.utils;

import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.RoleDao;
import com.nsl.logical.dao.UserDao;
import com.nsl.logical.enums.RightOwnerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.IRDR;
import com.nsl.logical.model.Role;
import com.nsl.logical.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;

import static com.nsl.logical.enums.ErrorType.VALIDATION;
import static com.nsl.logical.enums.ExceptionCategory.RESERVED_CU;
import static com.nsl.logical.enums.ExceptionSeverity.BLOCKER;

@Service
public class IRDRUtils {

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl userDetails;

    @Autowired private RoleDao roleRdfDao;

    @Autowired private UserDao userDao;

    private static final String ADAPTER_DESIGNER = "adapterDesigner";

    public void setIRDR(TenantChangeUnitInput changeUnit) throws NSLException {

        Role role = getAdapterDesignerRole();
        changeUnit.setDesignTimeRights(buildIRDR(role));
    }

    public void setGeIRDR(TenantCUEntityInput generalEntity) throws NSLException {

        Role role = getAdapterDesignerRole();
        generalEntity.setDesignTimeRights(buildIRDR(role));
    }

    private Role getAdapterDesignerRole() throws NSLException {

        Role role;
        Boolean isRolePresent = roleRdfDao.getRoleByName(ADAPTER_DESIGNER, userDetails);

        if(isRolePresent)
            role = roleRdfDao.getNamedRole(ADAPTER_DESIGNER, userDetails);
        else
            role = createAdapterDesignerRole();

        return role;
    }

    private List<IRDR> buildIRDR(Role role) {
        IRDR adapterIRDR = new IRDR();
        adapterIRDR.setInformationRight(true);
        adapterIRDR.setDecisionRight(true);
        adapterIRDR.setRightHolderId(role.getId());
        adapterIRDR.setRightHolderType(RightOwnerType.ROLE);
        adapterIRDR.setRightHolderName(role.getName());
        return Collections.singletonList(adapterIRDR);
    }

    private Role createAdapterDesignerRole() throws NSLException {

        Role role = new Role();
        role.setName(ADAPTER_DESIGNER);
        role.setIsEnabled(Boolean.TRUE);
        role.setIsAdmin(Boolean.FALSE);
        role.setDescription("Adapter Designer Role for Solution Architect");

        User currentUser = userDao.getUserById(userDetails.getUserId(), userDetails);
        role.setUsers(Collections.singletonList(currentUser));

        try {
            role = roleRdfDao.saveRole(role, userDetails);
        } catch (Exception e) {
            throw new NSLException(VALIDATION, RESERVED_CU, "Error while saving role", BLOCKER);
        }
        return role;
    }
}
