package com.nsl.adapter.commons.dto.connections;

public class DummyConnection extends BasicAdapterConnection{
    private String baseUrl;

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }
}
