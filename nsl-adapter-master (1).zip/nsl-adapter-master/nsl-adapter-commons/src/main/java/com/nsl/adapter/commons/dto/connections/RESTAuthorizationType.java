package com.nsl.adapter.commons.dto.connections;

public enum RESTAuthorizationType {
    PASSWORD("Password"),
    OAUTH("OAuth"),
    OAUTH2("OAuth2.O"),
    APIKEY("ApiKey"),
    HAWK("Hawk"),
    NONE("None");
    private final String type;

    RESTAuthorizationType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }


    @Override
    public String toString() {
        return type;
    }
}
