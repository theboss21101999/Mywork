package com.nsl.adapter.commons.utils.create_entity;

import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.IRDRUtils;
import com.nsl.dsd.store.models.base.NslDataType;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityAttributeInput;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import javax.annotation.Resource;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service

public class CreateEntityFromXlsxUtil extends CreateEntityUtil implements CreateEntityFromFile{
    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Autowired
    SaveBetsService saveBetsService;

    @Autowired
    IRDRUtils irdrUtils;
    @Override
    public TenantCUEntityInput convertFileIntoEntity(MultipartFile file, String entityName, Map<String, Object> PropertyMap) throws NSLException {
        boolean extract_horizontal= (boolean) PropertyMap.getOrDefault("horizontal", true); //NOSONAR
        Workbook workbook = null;
        try {
            workbook = WorkbookFactory.create(file.getInputStream());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Sheet sheet = workbook.getSheetAt(0);
        List<String> headers= new ArrayList<>();
        List<String>values=new ArrayList<>();

        if (extract_horizontal) {
            // Extract data vertically
            int rowCount = sheet.getLastRowNum() + 1;
            for (int rowIndex = 0; rowIndex < 2; rowIndex++) {
                if(rowIndex==0){
                    Row row = sheet.getRow(rowIndex);
                    if (row != null) {
                        int cellCount = row.getLastCellNum();
                        for (int cellIndex = 0; cellIndex < cellCount; cellIndex++) {
                            Cell cell = row.getCell(cellIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                            String cellValue = getCellValue(cell);
                            headers.add(cellValue);
                        }
                    }
                }
                else {
                    Row row = sheet.getRow(rowIndex);
                    if (row != null) {
                        int cellCount = row.getLastCellNum();
                        if(cellCount==-1){
                            continue;
                        }
                        for (int cellIndex = 0; cellIndex < cellCount; cellIndex++) {
                            Cell cell = row.getCell(cellIndex, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                            String cellValue = getCellValue(cell);
                            values.add(cellValue);
                        }
                    }
                }
            }
        }
        else {
            // Extract data horizontally
            int rowCount = sheet.getLastRowNum() + 1;
            int columnCount = sheet.getRow(0).getLastCellNum();

            for (int columnIndex = 0; columnIndex < 2; columnIndex++) {
                if(columnIndex==0) {
                    for (int rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                        Row row = sheet.getRow(rowIndex);
                        Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                        if (cell != null) {
                            String cellValue = getCellValue(cell);
                            headers.add(cellValue);
                        }
                    }
                }
                else {
                    for (int rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                        Row row = sheet.getRow(rowIndex);
                        Cell cell = row.getCell(columnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                        if (cell != null) {
                            String cellValue = getCellValue(cell);
                            values.add(cellValue);
                        }
                    }
                }
            }
        }
        try {
            workbook.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        TenantCUEntityInput generalEntity = new TenantCUEntityInput();
        for (int i = 0; i < headers.size(); i++)
            updateGE(generalEntity, entityName,headers.get(i).trim(), values.get(i));

        return saveGE(generalEntity);
    }
    private String getCellValue(Cell cell) {
        if (cell.getCellType() == CellType.STRING) {
            return cell.getStringCellValue();
        } else if (cell.getCellType() == CellType.NUMERIC) {
            return String.valueOf(cell.getNumericCellValue());
        } else if (cell.getCellType() == CellType.BOOLEAN) {
            return String.valueOf(cell.getBooleanCellValue());
        } else {
            return "";
        }
    }
    public void updateGE(TenantCUEntityInput generalEntity, String entityName, String header, String value) throws NSLException {

        if (generalEntity.getName() == null) {
            generalEntity.setName(entityName);
            generalEntity.setDisplayName(entityName);
            generalEntity.setNslAttributes(new ArrayList<>());
            generalEntity.setStatus(StatusEnum.DRAFT);
            irdrUtils.setGeIRDR(generalEntity);
        }

        String attrName;
        String subAttr;
        if (header.contains(".")) {
            String[] attribute = header.split("\\.", 2);
            attrName = attribute[0];
            subAttr = attribute[1];
        } else {
            attrName = header;
            subAttr = "";
        }

        if (subAttr.isEmpty()) {
            TenantCUEntityAttributeInput nslAttribute = new TenantCUEntityAttributeInput();
            nslAttribute.setName(attrName);
            nslAttribute.setDisplayName(attrName);

            NslDataType attributeType;
            if (value.contains(",")) {
                attributeType = getNslDataType(AppConstants.LIST);
                Map<String, NslDataType> nestedNslDataTypeProperties = new HashMap<>();
                nestedNslDataTypeProperties.put(AppConstants.ITEMTYPE,getNslDataType(value.split(",")[0].getClass().toString()));
                attributeType.setNestedNslDataTypeProperties(nestedNslDataTypeProperties);
            } else {
                attributeType = getNslDataType(value.getClass().toString());
            }

            attributeType.setUiElement(getUiElementInfo(value.getClass().toString()));
            nslAttribute.setAttributeType(attributeType);
            generalEntity.getNslAttributes().add(nslAttribute);
        } else {
            TenantCUEntityAttributeInput nslAttribute = null;
            for (TenantCUEntityAttributeInput attribute : generalEntity.getNslAttributes()) {
                if (attribute.getName().equals(attrName)) {
                    nslAttribute = attribute;
                    break;
                }
            }
            if (nslAttribute == null) {
                nslAttribute = new TenantCUEntityAttributeInput();
                nslAttribute.setName(attrName);
                nslAttribute.setDisplayName(attrName);

                NslDataType attributeType = getNslDataType(AppConstants.ENTITY);
                Map<String, String> attributeTypeProperties = new HashMap<>();
                attributeTypeProperties.put(AppConstants.REFERENCINGTYPE, attrName);
                attributeType.setProperties(attributeTypeProperties);

                nslAttribute.setAttributeType(attributeType);
                nslAttribute.setGeneralEntity(new TenantCUEntityInput());
                generalEntity.getNslAttributes().add(nslAttribute);
            }

            updateGE(nslAttribute.getGeneralEntity(), generalEntity.getName() + "_" + attrName, subAttr, value);
        }

    }
    private TenantCUEntityInput saveGE(TenantCUEntityInput generalEntity) throws NSLException {

        for (TenantCUEntityAttributeInput nslAttribute:generalEntity.getNslAttributes()){
            if (nslAttribute.getGeneralEntity()!=null)
                nslAttribute.setGeneralEntity(saveGE(nslAttribute.getGeneralEntity()));
        }
        return saveBetsService.saveGeneralEntity(generalEntity);
    }

}
