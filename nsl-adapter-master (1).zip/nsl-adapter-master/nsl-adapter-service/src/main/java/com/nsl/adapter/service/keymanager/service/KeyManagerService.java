package com.nsl.adapter.service.keymanager.service;

import com.amazonaws.services.secretsmanager.model.CreateSecretResult;
import com.amazonaws.services.secretsmanager.model.UpdateSecretResult;
import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.dto.SslCertificateDto;
import com.nsl.adapter.service.exception.AdapterException;
import com.nsl.adapter.service.keymanager.dto.KeyManagerDto;
import com.nsl.adapter.service.keymanager.dto.KmsConnectionDto;
import com.nsl.adapter.service.keymanager.dto.PaginatedKeys;
import com.nsl.adapter.service.keymanager.enums.KmsType;
import com.nsl.adapter.service.keymanager.utils.KeyManagerUtils;
import com.nsl.adapter.service.keymanager.utils.KmsConstants;
import com.nsl.adapter.service.rest.service.ConnectionToGeneral;
import com.nsl.adapter.service.rest.utils.ConnectionDataTools;
import com.nsl.adapter.service.service.SslService;
import com.nsl.adapter.commons.serviceImpl.AWSSecretManagerServiceImpl;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.commons.utils.FileUploadUtil;
import com.nsl.adapter.commons.utils.UUIDGenerator;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import javax.annotation.Resource;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class KeyManagerService {

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Autowired
    GeneralEntityDao generalEntityDao;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    ConnectionDataTools connectionDataTools;

    @Autowired
    AdapterConnectionServiceV3 connectionServiceV3;

    @Autowired
    private FileUploadUtil fileUploadUtil;

    @Autowired
    SslService sslService;

    @Autowired
    AWSSecretManagerServiceImpl secretManagerService;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    KeyManagerUtils managerUtils;

    @Autowired
    ConnectionToGeneral connectionToGeneral;

    @Autowired
            private MessageSource messageSource;

    private static final Logger LOGGER = LoggerFactory.getLogger(KeyManagerService.class);

    public TxnGeneralEntityRecord saveKmsFile(KeyManagerDto dto, MultipartFile file) throws NSLException {
        GeneralEntity generalEntity = generalEntityDao.findByName(KmsConstants.KMS_CONNECTION, requestScopedAuthenticatedUserBean);

        if (generalEntity==null){
            throw new NSLException(ErrorType.INTERNAL_SERVER,ExceptionCategory.GENERAL_ENTITY,messageSource.getMessage("Paas_Adapter_37", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER);
        }
        KmsConnectionDto connectionDto = new KmsConnectionDto();
        getKmsConnectionDto(connectionDto,dto,file);
        JsonNode json = JacksonUtils.getValueToTree(connectionDto);

//        Attributes
        List<TxnNslAttribute> attributesList= new ArrayList<TxnNslAttribute>();  //Attributes List
        for (NslAttribute nslAttribute : generalEntity.getNslAttributes()){
            if (json.has(nslAttribute.getName())){
                String text = "";
                if (nslAttribute.getName().equals("password")){
                    text = JacksonUtils.toJson(json.get(nslAttribute.getName()));
                    text = connectionDataTools.encryptText(text);
                }else if (nslAttribute.getName().equals("properties")){
                    text = JacksonUtils.toJson(json.get(nslAttribute.getName()));
                }else {
                    text = json.get(nslAttribute.getName()).asText();
                }
                TxnNslAttribute dataAttribute = connectionDataTools.createNslAttribute(nslAttribute,text);
                attributesList.add(dataAttribute);
            }
        }
        return managerUtils.saveRecord(attributesList,generalEntity.getId(),null,null);
    }

    private void getKmsConnectionDto(KmsConnectionDto connectionDto,KeyManagerDto dto, MultipartFile file) throws NSLException {
        switch (dto.getKmsType()){
            case SSLCERTIFICATE:
                uploadSslCertificate(connectionDto,dto, file);
                break;
            case ENCRYPTIONKEY:
                uploadEncryptionKey(connectionDto,dto,file);
                break;
            case SSHKEY:
                uploadSshKey(connectionDto,dto,file);
                break;
            case KEY:
                uploadKey(connectionDto, dto);
                break;
            default:
                break;
        }
    }

    private void uploadKey(KmsConnectionDto connectionDto, KeyManagerDto dto) throws NSLException {
        boolean isModify = false;
        if (connectionDto.getKmsType()!=null){
            if (connectionDto.getKmsType() != KmsType.KEY){
                throw new NSLException(ErrorType.VALIDATION,ExceptionCategory.ENTITY_ATTRIBUTE,
                        String.format(messageSource.getMessage("Paas_Adapter_38", null, Locale.ENGLISH), KmsType.KEY),
                        ExceptionSeverity.BLOCKER);
            }
            isModify=true;
        }

        connectionDto.setAlias(dto.getAlias());
        connectionDto.setName(dto.getName());
        connectionDto.setKmsType(dto.getKmsType());
        if (dto.getPassword()!=null){
            connectionDto.setPassword(dto.getPassword());
            uploadToAws(null,connectionDto, isModify);
            connectionDto.setPassword(null);
        }
        long dateInMillis = System.currentTimeMillis();
        if (isModify){
            connectionDto.setModifiedTime(String.valueOf(dateInMillis));
        }else {
            connectionDto.setCreatedTime(String.valueOf(dateInMillis));
        }
    }

    private void uploadSslCertificate(KmsConnectionDto connectionDto,KeyManagerDto dto, MultipartFile file) throws NSLException {

        boolean isModify = false;
        if (connectionDto.getKmsType()!=null){
            if (connectionDto.getKmsType() != KmsType.SSLCERTIFICATE){
                throw new NSLException(ErrorType.VALIDATION,ExceptionCategory.ENTITY_ATTRIBUTE,
                        String.format(messageSource.getMessage("Paas_Adapter_154", null, Locale.ENGLISH),KmsType.SSLCERTIFICATE),
                        ExceptionSeverity.BLOCKER);
            }
            isModify=true;
        }

        connectionDto.setAlias(dto.getAlias());
        connectionDto.setName(dto.getName());
        connectionDto.setKmsType(dto.getKmsType());

        if (file!=null){
            String sha256 = sslService.getSHA256(file);
            Long attrId = getIdBySha256(sha256);
            if (attrId!=null && !(isModify && attrId.equals(Long.valueOf(connectionDto.getAwsId())))){
                throw new NSLException(ErrorType.VALIDATION,ExceptionCategory.CLONE,
                        messageSource.getMessage("Paas_Adapter_39", null, Locale.ENGLISH),
                        ExceptionSeverity.BLOCKER);
            }
            SslCertificateDto sslCertificateDto = sslService.addCertificateToKeystore(file,dto.getAlias(),isModify);
            Properties props = connectionDto.getProperties()!=null ? connectionDto.getProperties() : new Properties();
            props.put(KmsConstants.KMS_SHA256,sha256);
            if (isModify){
                connectionDto.setModifiedTime(sslCertificateDto.getCertCreatedDate());
            }else {
                connectionDto.setCreatedTime(sslCertificateDto.getCertCreatedDate());
            }
            props.put(KmsConstants.KMS_EXPIRYTIME,sslCertificateDto.getCertExpiryDate());
            connectionDto.setProperties(props);
        }
        connectionDto.setAwsId(null);
        connectionDto.setDsdUrl(null);
    }

    private void uploadSshKey(KmsConnectionDto connectionDto,KeyManagerDto dto, MultipartFile file) throws NSLException {
        boolean isModify = false;
        if (connectionDto.getKmsType()!=null){
            if (connectionDto.getKmsType() != KmsType.SSHKEY){
                throw new NSLException(ErrorType.VALIDATION,ExceptionCategory.ENTITY_ATTRIBUTE,
                        String.format(messageSource.getMessage("Paas_Adapter_155", null, Locale.ENGLISH), KmsType.SSHKEY),
                        ExceptionSeverity.BLOCKER);
            }
            isModify=true;
        }
        connectionDto.setAlias(dto.getAlias());
        connectionDto.setName(dto.getName());
        connectionDto.setKmsType(dto.getKmsType());
        connectionDto.setPassword(dto.getPassword() != null ? dto.getPassword() : connectionDto.getPassword());
        if (file!=null){
            uploadToAws(file,connectionDto,isModify);
        }
        long dateInMillis = System.currentTimeMillis();
        if (isModify){
            connectionDto.setModifiedTime(String.valueOf(dateInMillis));
        }else {
            connectionDto.setCreatedTime(String.valueOf(dateInMillis));
        }

    }

    private void uploadEncryptionKey(KmsConnectionDto connectionDto, KeyManagerDto dto,
                                     MultipartFile file) throws NSLException {
        boolean isModify = false;
        if (connectionDto.getKmsType() != null) {
            if (!(connectionDto.getKmsType() == KmsType.ENCRYPTIONKEY ||
                    dto.getEncryptionKeyPrivate().toString().equals(connectionDto.getIsEncryptionKeyPrivate()))){
                throw new NSLException(ErrorType.VALIDATION,ExceptionCategory.ENTITY_ATTRIBUTE,
                        String.format(messageSource.getMessage("Paas_Adapter_40", null, Locale.ENGLISH), KmsType.ENCRYPTIONKEY, connectionDto.getIsEncryptionKeyPrivate()),
                        ExceptionSeverity.BLOCKER);
            }
            isModify = true;
            if (Boolean.TRUE.equals(dto.getEncryptionKeyPrivate())){
                connectionDto.setPassword(dto.getPassword() != null ? dto.getPassword() : connectionDto.getPassword());
            }
        }
        connectionDto.setAlias(dto.getAlias());
        connectionDto.setName(dto.getName());
        connectionDto.setKmsType(dto.getKmsType());
        connectionDto.setIsEncryptionKeyPrivate(dto.getEncryptionKeyPrivate().toString());
        if (file!=null){
            if (Boolean.TRUE.equals(dto.getEncryptionKeyPrivate())){
                uploadToAws(file,connectionDto,isModify);
            }else {
                connectionDto.setDsdUrl(
                        isModify?updatetoDsd(file, connectionDto.getDsdUrl(),connectionDto):
                                uploadtoDsd(file,dto.getName(),dto.getKmsType(),connectionDto));
            }
        }
        long dateInMillis = System.currentTimeMillis();
        if (isModify){
            connectionDto.setModifiedTime(String.valueOf(dateInMillis));
        }else {
            connectionDto.setCreatedTime(String.valueOf(dateInMillis));
        }

        if (dto.getEncryptionKeyType()!=null){
            Properties props = connectionDto.getProperties()!=null ? connectionDto.getProperties() : new Properties();
            props.put(KmsConstants.KMS_ENCRYPTIONKEYTYPE,dto.getEncryptionKeyType());
            connectionDto.setProperties(props);
        }else {
            if (connectionDto.getProperties()!=null && connectionDto.getProperties().keySet().size()==1 &&
                    connectionDto.getProperties().containsKey(KmsConstants.KMS_ENCRYPTIONKEYTYPE)){
                connectionDto.setProperties(null);
            }
        }
    }

    private void uploadToAws(MultipartFile multipartFile, KmsConnectionDto dto, boolean isModify) throws NSLException {
        String secretId = dto.getAwsId();
        if (!isModify){
            secretId = "/"+requestScopedAuthenticatedUserBean.getTenantId()+"/"+dto.getName()+"/"+dto.getAlias()+
                    "/"+UUIDGenerator.generateType1UUID();
        }
        Properties props = dto.getProperties()!=null ? dto.getProperties() : new Properties();
        if (multipartFile!=null){
            String ext = StringUtils.getFilenameExtension(multipartFile.getResource().getFilename());
            try{
                byte[] bytes = multipartFile.getBytes();
                String encoded = Base64.getEncoder().encodeToString(bytes);
                if (isModify){
                    String response = secretManagerService.updateSecret(secretId,encoded);
                    dto.setAwsId(response);
                    props.put(KmsConstants.KMS_AWSARN,response);
                }else {
                    String response = secretManagerService.createNewSecret(secretId,encoded);
                    dto.setAwsId(response);
                    props.put(KmsConstants.KMS_AWSARN,response);
                }
            }
            catch(Exception e){
                throw new NSLException(ExceptionCategory.PROCESS,messageSource.getMessage("Paas_Adapter_41", null, Locale.ENGLISH), ExceptionSeverity.BLOCKER);
            }
            props.put(KmsConstants.KMS_FILE_EXTENSION,ext);
        } else if (dto.getKmsType()==KmsType.KEY) {
            String encoded = Base64.getEncoder().encodeToString(dto.getPassword().getBytes(StandardCharsets.UTF_8));
            if (isModify){
                String response = secretManagerService.updateSecret(secretId,encoded);
                dto.setAwsId(response);
                props.put(KmsConstants.KMS_AWSARN,response);
            }else {
                String response = secretManagerService.createNewSecret(secretId,encoded);
                dto.setAwsId(response);
                props.put(KmsConstants.KMS_AWSARN,response);
            }
        }
        dto.setProperties(props);
    }

    private String uploadtoDsd(MultipartFile multipartFile, String name, KmsType type, KmsConnectionDto dto) throws NSLException {
        if (multipartFile==null){
            return null;
        }
        JsonNode uploadResponse = null;
        String ext = StringUtils.getFilenameExtension(multipartFile.getResource().getFilename());
        String folder = AppConstant.ADAPTER+"_"+type.toString().toLowerCase()+"_"+name;
        Properties props = dto.getProperties()!=null ? dto.getProperties() : new Properties();
        try{
            File file = File.createTempFile(UUIDGenerator.generateType1UUID(), "." + ext); //NOSONAR
            if (!file.exists())
                throw new AdapterException( messageSource.getMessage("Paas_Adapter_42", null, Locale.ENGLISH)+ file.getName());
            FileUtils.copyInputStreamToFile(multipartFile.getInputStream(), file);
            uploadResponse = fileUploadUtil.uploadSingleFile(file, folder,requestScopedAuthenticatedUserBean);
            props.put(KmsConstants.KMS_FILE_EXTENSION,ext);
            dto.setProperties(props);
            return uploadResponse.get("contentUrl").asText();
        }
        catch(Exception e){
            throw new NSLException(ExceptionCategory.PROCESS,messageSource.getMessage("Paas_Adapter_157", null, Locale.ENGLISH), ExceptionSeverity.BLOCKER);
        }
    }
    private String updatetoDsd(MultipartFile multipartFile, String dsdUrl, KmsConnectionDto dto) throws NSLException {
        if (multipartFile==null){
            return null;
        }
        String ext = StringUtils.getFilenameExtension(multipartFile.getResource().getFilename());
        ResponseEntity<JsonNode> response = null;
        Properties props = dto.getProperties()!=null ? dto.getProperties() : new Properties();
        try{
            File file = File.createTempFile(UUIDGenerator.generateType1UUID(), "." + ext); //NOSONAR
            if (!file.exists())
                throw new AdapterException(messageSource.getMessage("Paas_Adapter_159", null, Locale.ENGLISH) + file.getName());
            FileUtils.copyInputStreamToFile(multipartFile.getInputStream(), file);
            FileSystemResource fileSystemSource = new FileSystemResource(file);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);
            MultiValueMap<String, Object> map= new LinkedMultiValueMap<>();
            map.add("file", fileSystemSource);

            HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(map, headers);
            response = restTemplate.exchange(dsdUrl, HttpMethod.POST, httpEntity, JsonNode.class);
        }
        catch(Exception e){
            throw new NSLException(ExceptionCategory.PROCESS,messageSource.getMessage("Paas_Adapter_158", null, Locale.ENGLISH)+e, ExceptionSeverity.BLOCKER);
        }
        if (response.getStatusCodeValue()==500){
            throw new NSLException(ExceptionCategory.VALIDATION,messageSource.getMessage("Paas_Adapter_43", null, Locale.ENGLISH)+ response.getBody(), ExceptionSeverity.BLOCKER);
        }
        props.put(KmsConstants.KMS_FILE_EXTENSION,ext);
        dto.setProperties(props);
        return response.getBody().get("contentUrl").asText(); //NOSONAR
    }

    public Long getIdBySha256(String sha256) throws NSLException {
        List<TxnGeneralEntityRecord> resultList = managerUtils.getTotalRecords(KmsConstants.KMS_CONNECTION);
        for (TxnGeneralEntityRecord txnGeneralEntityRecord : resultList){
            if (managerUtils.checkEntityRecordIdBySha256(txnGeneralEntityRecord,sha256)){
                return txnGeneralEntityRecord.getId();
            }
        }
        return null;
    }

    public boolean checkvalidNameOrAlias(String name, String alias) throws NSLException {
        Map<String, String> regMap = new HashMap<>();
        regMap.put(KmsConstants.KMS_NAME, "="+name);
        List<TxnGeneralEntityRecord> resultList = connectionServiceV3.getRecordsByMap(KmsConstants.KMS_CONNECTION, regMap,requestScopedAuthenticatedUserBean);
        if (!resultList.isEmpty()){
            return false;
        }
        regMap.clear();
        regMap.put(KmsConstants.KMS_ALIAS, "="+alias);
        resultList = connectionServiceV3.getRecordsByMap(KmsConstants.KMS_CONNECTION, regMap,requestScopedAuthenticatedUserBean);
        if (!resultList.isEmpty()){
            return false;
        }
        return true;
    }

    public boolean checkvalidNameAndAlias(String name, String alias,Long attrId) throws NSLException {
        List<TxnGeneralEntityRecord> resultList = managerUtils.getTotalRecords(KmsConstants.KMS_CONNECTION);
        for (TxnGeneralEntityRecord txnGeneralEntityRecord : resultList){
            if (managerUtils.checkEntityRecordByNameAndAlias(txnGeneralEntityRecord,name,alias,attrId)){
                return false;
            }
        }
        return true;
    }

    public TxnGeneralEntityRecord updateKmsFile(KeyManagerDto dto, MultipartFile file, Long attrId) throws NSLException{

        GeneralEntity generalEntity = generalEntityDao.findByName(KmsConstants.KMS_CONNECTION, requestScopedAuthenticatedUserBean);

        if (generalEntity==null){
            throw new NSLException(ErrorType.INTERNAL_SERVER,ExceptionCategory.GENERAL_ENTITY,
                    messageSource.getMessage("Paas_Adapter_32", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER);
        }
        TxnGeneralEntityRecord fetchedEntityRecord = managerUtils.getRecordById(attrId);
        if (fetchedEntityRecord==null){
            throw new NSLException(ErrorType.VALIDATION,ExceptionCategory.GENERAL_ENTITY,
                    messageSource.getMessage("Paas_Adapter_140", null, Locale.ENGLISH) +attrId,
                    ExceptionSeverity.BLOCKER);
        }
        List<TxnNslAttribute> fetchedattribs = fetchedEntityRecord.getTxnNslAttribute();

        KmsConnectionDto connectionDto = managerUtils.getFromNslAtrributes(fetchedattribs,false);
        if (KmsType.SSLCERTIFICATE == dto.getKmsType()) connectionDto.setAwsId(String.valueOf(attrId));
        getKmsConnectionDto(connectionDto,dto,file);
        JsonNode json = JacksonUtils.getValueToTree(connectionDto);

//        Attributes
        List<TxnNslAttribute> attributesList= new ArrayList<TxnNslAttribute>();  //Attributes List
        for (NslAttribute nslAttribute : generalEntity.getNslAttributes()){
            if (json.has(nslAttribute.getName())){
                String text = "";
                if (nslAttribute.getName().equals("password")){
                    text = JacksonUtils.toJson(json.get(nslAttribute.getName()));
                    text = connectionDataTools.encryptText(text);
                }else if (nslAttribute.getName().equals("properties")){
                    text = JacksonUtils.toJson(json.get(nslAttribute.getName()));
                }else {
                    text = json.get(nslAttribute.getName()).asText();
                }
                TxnNslAttribute dataAttribute = connectionDataTools.createNslAttribute(nslAttribute,text);
                attributesList.add(dataAttribute);
            }else {
                TxnNslAttribute txnNslAttribute = new TxnNslAttribute();
                txnNslAttribute.setName(nslAttribute.getName());
                txnNslAttribute.setNslAttributeID(nslAttribute.getId());
                txnNslAttribute.setValues(new ArrayList<>());
                attributesList.add(txnNslAttribute);
            }
        }

        return managerUtils.saveRecord(attributesList,generalEntity.getId(),attrId,fetchedEntityRecord.getGuid());
    }


    public PaginatedKeys getPaginatedKeys(Integer pageNumber, Integer pageSize, KmsType kmsType, String name, String alias, String sortMethod) throws NSLException {

//        List<TxnGeneralEntityRecord> resultList = managerUtils.getTotalRecords(KmsConstants.KMS_CONNECTION);
        Map<String, String> regMap = new HashMap<>();
        if (name!=null) regMap.put(KmsConstants.KMS_NAME, "REGEX.*"+name+".*");
        if (alias!=null) regMap.put(KmsConstants.KMS_ALIAS, "REGEX.*"+alias+".*");
        if (kmsType!=null) regMap.put(KmsConstants.KMS_TYPE, "="+kmsType.toString());
        List<TxnGeneralEntityRecord> resultList = connectionServiceV3.getRecordsByMap(KmsConstants.KMS_CONNECTION, regMap,requestScopedAuthenticatedUserBean);
        List<TxnGeneralEntityRecord> subData = connectionServiceV3.getSubList(resultList, pageSize, pageNumber);
        List<KeyManagerDto> data = managerUtils.getFilteredAll(resultList);
        PaginatedKeys paginatedKeys = new PaginatedKeys();
        paginatedKeys.setKeyManagerDtoList(data);
        paginatedKeys.setPageNumber(pageNumber);
        paginatedKeys.setCurrentPageSize(subData.size());
        paginatedKeys.setTotalHits((long) data.size());
        paginatedKeys.setTotalPages((long)Math.ceil((double) data.size()/pageSize));
        return paginatedKeys;
    }

    public String getAwsSecretIdByName(String name){
        try {
            LOGGER.info("In getAwsSecretIdByName with name : {} ", name);
            Map<String, String> regMap = new HashMap<>();
            if (name!=null) regMap.put(KmsConstants.KMS_NAME, "REGEX.*"+name+".*");
            regMap.put(KmsConstants.KMS_TYPE, "="+KmsType.SSHKEY);
            List<TxnGeneralEntityRecord> resultList = connectionServiceV3.getRecordsByMap(KmsConstants.KMS_CONNECTION, regMap,requestScopedAuthenticatedUserBean);
            if(resultList.stream().findFirst().isPresent()){
                List<TxnNslAttribute> attributes =  resultList.stream().findFirst().get().getTxnNslAttribute(); //NOSONAR
                if(attributes.stream().filter(attribute -> attribute.getName().equalsIgnoreCase(KmsConstants.KMS_AWSID)).findFirst().isPresent()){
                    List<String> awsKeyValues  =   attributes.stream().filter(attribute -> attribute.getName().equalsIgnoreCase(KmsConstants.KMS_AWSID)).findFirst().get().getValues(); //NOSONAR
                    Optional<List<String>> values = Optional.ofNullable(awsKeyValues);
                  return  values.flatMap(list -> list.stream().findFirst()).orElse(null);
                }
            }
            return null;
        } catch (Exception e) {
            LOGGER.error("Error in fetching the aws SecretId : {}  ",e.getMessage());
           return null;
        }
    }
}
