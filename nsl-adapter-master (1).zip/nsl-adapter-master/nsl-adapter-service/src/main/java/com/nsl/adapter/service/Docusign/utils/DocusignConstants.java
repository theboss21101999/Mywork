package com.nsl.adapter.service.Docusign.utils;

public class DocusignConstants {

    public static final String REFRESH_TOKEN="refresh_token";
    public static final String DOCUSIGN = "Docusign";
    public static final String DOCUSIGN_AUTH_TOKEN = "https://account-d.docusign.com/oauth/auth";

    public static final String DOCUSIGN_ACCESS_TOKEN ="https://account-d.docusign.com/oauth/token";

    public static final String CONSENT="consent";
    public static final String ACCESS_TYPE="access_type";
    public static final String OFFLINE="offline";
    public static final String CODE="code";
    public static final String STATE="state";
    public static final String Url="url";
    public static final String AUTHORIZATION_CODE="authorization_code";
    public static final String CREATE_ENVELOPE = "CREATE_ENVELOPE";
    public static final String ENVELOPE_STATUS = "ENVELOPE_STATUS";
    public static final String LOCK_ENVELOPE="LOCK_ENVELOPE";
    public static final String DELETE_LOCK="DELETE_LOCK";
    public static final String CREATE_TEMPLATE="CREATE_TEMPLATE";

    private DocusignConstants(){
        throw new IllegalStateException("utility class");
    }
}
