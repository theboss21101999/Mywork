package com.nsl.adapter.service.enums;

public enum MapConfigAction {
    EXECUTE,
    VALIDATE
}
