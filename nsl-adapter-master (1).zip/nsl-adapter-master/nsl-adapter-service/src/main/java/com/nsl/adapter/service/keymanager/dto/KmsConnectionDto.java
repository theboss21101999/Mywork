package com.nsl.adapter.service.keymanager.dto;

import com.nsl.adapter.service.keymanager.enums.KmsType;
import java.util.Properties;

public class KmsConnectionDto {
    private String alias;
    private String name;
    private KmsType kmsType;

    private String awsId;
    private String dsdUrl;
    private String createdTime;
    private String modifiedTime;
    private String password;
    private String isEncryptionKeyPrivate;
    private String encryptionKeyType;
    private Properties properties;

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public KmsType getKmsType() {
        return kmsType;
    }

    public void setKmsType(KmsType kmsType) {
        this.kmsType = kmsType;
    }

    public String getAwsId() {
        return awsId;
    }

    public void setAwsId(String awsId) {
        this.awsId = awsId;
    }

    public String getDsdUrl() {
        return dsdUrl;
    }

    public void setDsdUrl(String dsdUrl) {
        this.dsdUrl = dsdUrl;
    }

    public String getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(String createdTime) {
        this.createdTime = createdTime;
    }

    public String getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(String modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getIsEncryptionKeyPrivate() {
        return isEncryptionKeyPrivate;
    }

    public void setIsEncryptionKeyPrivate(String isEncryptionKeyPrivate) {
        this.isEncryptionKeyPrivate = isEncryptionKeyPrivate;
    }

    public String getEncryptionKeyType() {
        return encryptionKeyType;
    }

    public void setEncryptionKeyType(String encryptionKeyType) {
        this.encryptionKeyType = encryptionKeyType;
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }
}
