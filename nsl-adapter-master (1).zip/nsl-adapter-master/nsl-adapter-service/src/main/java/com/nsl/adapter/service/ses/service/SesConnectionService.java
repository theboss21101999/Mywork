package com.nsl.adapter.service.ses.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dao.FetchConnectionService;
import com.nsl.adapter.commons.dto.connections.SESConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.Locale;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class SesConnectionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SesConnectionService.class);
    private static final ConnectionsType connType = ConnectionsType.SES;
    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;
    @Autowired
    FetchConnectionService fetchConnectionService;
    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;
    @Autowired
    MessageSource messageSource;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    public TxnAdapterConnection saveSesConnection(SESConnectionDto connectionDto) {
        try {
            if (connectionDto.getAccessKey() == null || connectionDto.getSecretKey() == null || connectionDto.getRegion() == null ||
                    connectionDto.getConnectionName() == null
                    || adapterConnnectionsDao.getConnectionByName(ConnectionDtoType.SES, connectionDto.getConnectionName(), authBean) != null) {
                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, messageSource.getMessage("Paas_Adapter_34", null, Locale.ENGLISH), null);
            }
            connectionDto.setSecretKey(connectionDataToolsV3.saveSecret(ConnectionDtoType.SES, "secretKey",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getSecretKey()));
            LOGGER.info("saving SES connection");
            TxnAdapterConnection result = new TxnAdapterConnection();
            result.setConnectionDtoType(ConnectionDtoType.SES);
            result.setConnection(connectionDto);
            return adapterConnnectionsDao.saveConnection(result, authBean);
        }
        catch(Exception e ){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "Pass_Adapter_182",
                    ExceptionSeverity.MINOR);
        }
    }

    public SESConnectionDto getSesConnection(Long id, boolean hide) {
        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.SES, id, authBean);
        if (previousConnection==null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_186", null, Locale.ENGLISH), null);
        }
        return txnToSesDto(previousConnection, hide);
    }

    public SESConnectionDto txnToSesDto(TxnAdapterConnection adapterConnection, boolean hide) {
        if (adapterConnection==null){
            return null;
        }
        SESConnectionDto dto = (SESConnectionDto) adapterConnection.getConnection();
        if (hide){
            //dto.setAccessKey(null);
            dto.setSecretKey(null);
            //dto.setRegion(null);
        }
        dto.getMetadata().put("dsdId",String.valueOf(adapterConnection.getRecordId()));
        return dto;
    }
    
    public TxnAdapterConnection updateSesConnection(Long id, SESConnectionDto connectionDto) {
        if(  connectionDto.getAccessKey() == null || connectionDto.getConnectionName() == null || 
            connectionDto.getSecretKey() == null || connectionDto.getRegion() == null || id == null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_182", null, Locale.ENGLISH), null);
        }

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.SES, id, authBean);
        if (previousConnection==null || !previousConnection.getConnection().getConnectionName().equals(connectionDto.getConnectionName())){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_182", null, Locale.ENGLISH), null);
        }

        SESConnectionDto prevsDto = (SESConnectionDto) previousConnection.getConnection();
        if (connectionDto.getSecretKey()!=null){
          prevsDto.setSecretKey(connectionDataToolsV3.updateSecret(ConnectionDtoType.SES, "secertKey",
              prevsDto.getConnectionName(), authBean.getTenantId(), connectionDto.getSecretKey()));
          prevsDto.setAccessKey(connectionDto.getAccessKey());
          prevsDto.setRegion(connectionDto.getRegion());
        }
        previousConnection.setConnection(prevsDto);
        LOGGER.info("update SES connection");
        return adapterConnnectionsDao.saveConnection(previousConnection, authBean);
    }
}
