package com.nsl.adapter.service.rest.utils;

public class RestConstants {

    public static final String REFRESH_TOKEN="refresh_token";
    public static final String REST = "Rest";
    public static final String PROMPT="prompt";
    public static final String CONSENT="consent";
    public static final String ACCESS_TYPE="access_type";
    public static final String OFFLINE="offline";
    public static final String CODE="code";
    public static final String STATE="state";
    public static final String Url="url";
    public static final String AUTHORIZATION_CODE="authorization_code";
    public static final String PASSWORD="password";
    public static final String CLIENT_CREDENTIALS="client_credentials";

    public static final String SHA_256="SHA-256";
    public static final String SHA_512="SHA-512";
    public static final String SHA_1="SHA-1";
    public static final String HmacSHA256="HmacSHA256";
    public static final String HmacSHA512="HmacSHA512";
    public static final String HmacSHA1="HmacSHA1";
    public static final String sha256="sha256";
    public static final String sha512="sha512";
    public static final String sha1="sha1";
    public static final String id="id";
    public static final String ts="ts";
    public static final String Nonce ="nonce";
    public static final String MAC="mac";
    public static final String Hash="hash";
    public static final String PathParamObject="pathParamObject";


    private RestConstants(){
        throw new IllegalStateException("utility class");
    }
}
