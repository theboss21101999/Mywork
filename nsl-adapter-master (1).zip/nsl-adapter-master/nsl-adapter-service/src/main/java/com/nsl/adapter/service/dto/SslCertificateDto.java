package com.nsl.adapter.service.dto;

public class SslCertificateDto {

    private String certCreatedDate;
    private String certValidFromDate;
    private String certExpiryDate;

    public String getCertCreatedDate() {
        return certCreatedDate;
    }

    public void setCertCreatedDate(String certCreatedDate) {
        this.certCreatedDate = certCreatedDate;
    }

    public String getCertValidFromDate() {
        return certValidFromDate;
    }

    public void setCertValidFromDate(String certValidFromDate) {
        this.certValidFromDate = certValidFromDate;
    }

    public String getCertExpiryDate() {
        return certExpiryDate;
    }

    public void setCertExpiryDate(String certExpiryDate) {
        this.certExpiryDate = certExpiryDate;
    }
}