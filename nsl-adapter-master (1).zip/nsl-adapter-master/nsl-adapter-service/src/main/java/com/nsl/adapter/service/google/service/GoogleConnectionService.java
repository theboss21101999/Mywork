package com.nsl.adapter.service.google.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.GoogleOauthDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.Locale;

@Service
public class GoogleConnectionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(GoogleConnectionService.class);

    private static final ConnectionDtoType connDtoType = ConnectionDtoType.Google;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    MessageSource messageSource;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;


    public TxnAdapterConnection saveGoogleConnection(GoogleOauthDto connectionDto) {

        if (connectionDto.getClientId() == null || connectionDto.getClientSecret() == null ||
                connectionDto.getApplicationName() == null || connectionDto.getScope() == null ||
                connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_82", null, Locale.ENGLISH) , null);

        connectionDataToolsV3.connectionCheck(ConnectionDtoType.Google, connectionDto.getConnectionName(), authBean);

        connectionDto.setClientSecret(connectionDataToolsV3.saveSecret(connDtoType,"clientSecret",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getClientSecret()));

        TxnAdapterConnection txnAdapterConnection = new TxnAdapterConnection();
        txnAdapterConnection.setConnection(connectionDto);
        txnAdapterConnection.setConnectionDtoType(connDtoType);

        LOGGER.info("saving Google connection");
        return adapterConnnectionsDao.saveConnection(txnAdapterConnection,authBean);
    }

    public GoogleOauthDto getGoogleConnection(Long id, boolean hide){

        TxnAdapterConnection adapterConnection = adapterConnnectionsDao.getConnectionByRecordId(connDtoType, id ,authBean);
        return txnToGoogleDto(adapterConnection,hide);
    }

    public TxnAdapterConnection updateGoogleConnection(Long id, GoogleOauthDto connectionDto){

        if (connectionDto.getClientId() == null || connectionDto.getApplicationName() == null ||
                    connectionDto.getScope() == null || connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "invalid input" , null);

        LOGGER.info("saving Google connection");
        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(connDtoType, id ,authBean);
        connectionDataToolsV3.connectionNameCheck(previousConnection,connectionDto.getConnectionName());

        connectionDto.setClientSecret(connectionDataToolsV3.updateSecret(connDtoType,"clientSecret",
                    connectionDto.getConnectionName(),authBean.getTenantId(),connectionDto.getClientSecret()));
        connectionDto.setRefreshToken(connectionDataToolsV3.updateSecret(connDtoType,"refreshToken",
                connectionDto.getConnectionName(),authBean.getTenantId(),connectionDto.getRefreshToken()));

        previousConnection.setConnection(connectionDto);

        return adapterConnnectionsDao.saveConnection(previousConnection, authBean );
    }

    public GoogleOauthDto txnToGoogleDto(TxnAdapterConnection adapterConnection, boolean hide) {

        if (adapterConnection.getConnection() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_190", null, Locale.ENGLISH) , null);

        GoogleOauthDto result = (GoogleOauthDto) adapterConnection.getConnection();

        if (!hide){
            result.setRefreshToken(connectionDataToolsV3.getSecret(result.getRefreshToken()));
            result.setClientSecret(connectionDataToolsV3.getSecret(result.getClientSecret()));
        }

        return result;
    }

}