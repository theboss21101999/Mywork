package com.nsl.adapter.service.kafka.utils;

import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.service.kafka.dto.InboundMsgReqDto;
import com.nsl.adapter.commons.dto.connections.KafkaAuthCredential;
import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.service.kafka.enums.ConnectionType;
import com.nsl.adapter.service.kafka.enums.KafkaMethodType;
import com.nsl.adapter.service.sftp.connection.AuthenticateUser;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.model.ChangeUnit;
import com.nsl.logical.model.GSI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.Collections;
import java.util.Map;
import java.util.Properties;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.*;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.SASL_JAAS_CONFIG;
import static com.nsl.adapter.service.utils.AppConstant.ADAPTER;
import static com.nsl.adapter.service.utils.AppConstant.CONFIG_ENTITY_RECORD_ID;

@Component
public class InboundKafkaUtil {

    @Autowired
    AuthenticateUser authenticateUser;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    ConnectionToEntity connectionToEntity;

    public static String inboundKafkaGSI(GSI gsi) {
        Map<String, String> properties;
        AdapterType adapterType;
        KafkaMethodType kafkaMethodType;
        for(ChangeUnit changeUnit : gsi.getSolutionLogic()) {
            properties = changeUnit.getCuSystemProperties();
            try {
                adapterType = AdapterType.valueOf(properties.get(ADAPTER));
                kafkaMethodType = KafkaMethodType.valueOf(properties.get(METHOD_TYPE));
                if((adapterType == AdapterType.KAFKA) && (kafkaMethodType == KafkaMethodType.INBOUND))
                    return changeUnit.getName();
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }

    public KafkaConnectionDto buildKafkaConnectionDto(InboundMsgReqDto inboundMsgReqDto) {

        AuthenticatedUserDetailsImpl authenticatedUser = authenticateUser.getAuthenticatedUser(inboundMsgReqDto.getUserId(), inboundMsgReqDto.getTenantId());
        connectionToEntity.setRequestScopedAuthenticatedUserBean(authenticatedUser);

        ChangeUnit changeUnit = changeUnitDao.getChangeUnitByName(inboundMsgReqDto.getCuName(), authenticatedUser);
        changeUnit = changeUnitDao.getChangeUnitById(changeUnit.getId(), authenticatedUser);
        Map<String, String> properties = changeUnit.getCuSystemProperties();
        Long connectionId = Long.valueOf(properties.get(CONFIG_ENTITY_RECORD_ID));
        KafkaConnectionDto connection = connectionToEntity.getConnectionById(connectionId);
        buildConnection(connection, properties);

        return connection;
    }

    public static void buildConnection(KafkaConnectionDto connection, Map<String, String> properties) {
        String connectionType = properties.get(CONNECTION_TYPE);
        if(connectionType==null)
            connectionType = String.valueOf(ConnectionType.PLAINTEXT);
        String topic = properties.get(TOPIC);

        Properties config = connection.getAdvancedConfig();
        if(config == null)
            config = new Properties();
        config.put(TOPIC, topic);
        config.put(CONNECTION_TYPE, connectionType);

        KafkaAuthCredential credential = connection.getAuthentication();
        if(credential!=null) {
            String saslJaasConfig = "org.apache.kafka.common.security.plain.PlainLoginModule   required username=" + credential.getUsername() + "   password=" + credential.getPassword() + ";";
            config.put(SASL_JAAS_CONFIG, saslJaasConfig);
        }
        connection.setAdvancedConfig(config);

        if(connection.getBootstrapServer()==null)
            connection.setBootstrapServer(Collections.singletonList("localhost"));
        connection.setBootstrapServer(Collections.singletonList(connection.getBootstrapServer().get(0) + ":" + connection.getPartition()));

    }
}
