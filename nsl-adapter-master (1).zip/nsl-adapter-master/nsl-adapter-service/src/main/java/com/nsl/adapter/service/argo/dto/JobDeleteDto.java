package com.nsl.adapter.service.argo.dto;

import java.util.Date;

public class JobDeleteDto {
    String jobId;
    Date timeStamp;

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }
}
