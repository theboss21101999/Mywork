package com.nsl.adapter.service.kafka.listener;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.adapter.service.kafka.serviceImpl.InboundKafkaService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.listener.MessageListener;

public class InboundKafkaListener implements MessageListener<String, String> {
    private static final Logger log = LoggerFactory.getLogger(InboundKafkaListener.class);

   @Autowired
   InboundKafkaService inboundKafkaService;

    @Override
    public void onMessage(ConsumerRecord<String, String> consumerRecord) {

        // process message
        try {
            inboundKafkaService.processClientMessage(consumerRecord);
        } catch (JsonProcessingException e) {
            log.error("Exception in process client message", e);
        }
    }
}
