package com.nsl.adapter.service.google;

import com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl;
import com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest;
import com.google.api.client.auth.oauth2.RefreshTokenRequest;
import com.google.api.client.auth.oauth2.TokenRequest;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.http.BasicAuthentication;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.nsl.adapter.commons.dto.connections.GoogleOauthDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.google.service.GoogleConnectionService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.adapter.service.utils.RefreshTokenScheduler;
import com.nsl.adapter.service.v2.utills.RedisIntegration;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import static com.nsl.adapter.service.google.utils.GoogleConstants.*;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class OauthConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(OauthConnection.class);
    private int DAYS=0;
    private int MONTHS=6;

    @Autowired
    RedisIntegration redisIntegration;

    @Autowired
    CdmUtils cdmUtils;

    @Autowired
    private MessageSource messageSource;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    GoogleConnectionService googleConnectionService;

    Base64.Encoder encoder = Base64.getEncoder();

    @Autowired
    AdaptorProperties adaptorProperties;
    @Autowired
    RefreshTokenScheduler refreshTokenScheduler;

    public String getStateParam(Long connId, String connName, String tenantId) {
        Map<String, Object> valueMap = new HashMap<>();
        valueMap.put(AppConstant.CONFIG_ENTITY_RECORD_ID, connId.toString());
        valueMap.put(AppConstant.ADAPTER, GOOGLE);
        valueMap.put(AppConstant.TENANTID, tenantId);
        valueMap.put(AppConstant.ENV_NAME ,cdmUtils.getEnvironmentNameByTenantId(tenantId));
        valueMap.put(AppConstant.CONNECTION_NAME, connName);
        return encodeData(Objects.requireNonNull(JacksonUtils.toJson(valueMap)));
    }

    public JSONObject getAuthorizationcode(GoogleOauthDto connectionDto, TxnAdapterConnection result) throws NSLException {

        LOGGER.info("generating redirect url ..");
        try {
            AuthorizationCodeRequestUrl url = new AuthorizationCodeRequestUrl(GOOGLE_AUTH_TOKEN,
                    connectionDto.getClientId());
            url.setRedirectUri(adaptorProperties.getRedirectUrl()).setScopes(connectionDto.getScope())
                    .set(PROMPT, CONSENT).set(ACCESS_TYPE, OFFLINE).setResponseTypes(Collections.singleton(CODE));

            String stateParams = getStateParam(result.getRecordId(), connectionDto.getConnectionName(), bean.getTenantId());
            LOGGER.info("appending state params to redirect url {} ", stateParams);
            url.set(STATE, stateParams);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put(AppConstant.RESULT, result);
            jsonObject.put(Url, url.build());

            return jsonObject;
        } catch (Exception e) {
            LOGGER.error("exception occurred during generating redirect url");
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_127", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER,e);
        }
    }

    public TxnAdapterConnection getRefreshToken(Long id) throws NSLException {

        String cacheName = GOOGLE + "_" + bean.getTenantId();
        String code = redisIntegration.getOAuthCode(cacheName, id.toString());
        try {
            GoogleOauthDto connectionDto = googleConnectionService.getGoogleConnection(id, false);

            connectionDto.setRefreshToken(getRefreshToken(connectionDto, code));
            return googleConnectionService.updateGoogleConnection(id, connectionDto);
        } catch (IOException e) {
            LOGGER.error("failed to generate refresh Token  {}" ,e.getMessage());
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_141", null, Locale.ENGLISH), ExceptionSeverity.BLOCKER, e);
        }
    }

    public String getRefreshToken(GoogleOauthDto connectionDto, String code) throws IOException {

    /*    RefreshTokenDto refreshTokenDto = new RefreshTokenDto();
        refreshTokenDto.setEndDate(refreshTokenScheduler.CalculateEndDate(DAYS,MONTHS));
        refreshTokenDto.setConnectionType(ConnectionsType.Google.getEntityName());
        refreshTokenDto.setConnectionName(connectionDto.getConnectionName());*/
        /*if(connectionDto.getJobid()==null)
            connectionDto.setJobid(refreshTokenScheduler.createJobId(refreshTokenDto,bean));
        else{
            refreshTokenDto.setJobId(connectionDto.getJobid());
            refreshTokenScheduler.updateJob(refreshTokenDto,false);
        }*/


        TokenRequest request = new AuthorizationCodeTokenRequest(new NetHttpTransport(), new JacksonFactory(),
                new GenericUrl(GOOGLE_REFRESH_TOKEN), code).setRedirectUri(adaptorProperties.getRedirectUrl())
                .setGrantType(AUTHORIZATION_CODE).setClientAuthentication(
                        new BasicAuthentication(connectionDto.getClientId(), connectionDto.getClientSecret()));

        TokenResponse response = request.execute();
        return response.getRefreshToken();
    }

    public String getAccessToken(GoogleOauthDto connectionDto) throws NSLException {

        TokenResponse response = null;
        LOGGER.info("generating access token..");
        try {
            TokenRequest request = new RefreshTokenRequest(new NetHttpTransport(), new JacksonFactory(),
                    new GenericUrl(GOOGLE_ACCESS_TOKEN), connectionDto.getRefreshToken());
            request.setClientAuthentication(new BasicAuthentication(connectionDto.getClientId(),
                    connectionDto.getClientSecret())).setGrantType(REFRESH_TOKEN);
            response = request.execute();
        } catch (IOException e) {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_144", null, Locale.ENGLISH), ExceptionSeverity.BLOCKER, e);
        }
        return response.getAccessToken();
    }

    private String encodeData(String value) {
        return encoder.encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

}
