package com.nsl.adapter.service.mqtt.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.springframework.boot.configurationprocessor.json.JSONException;

public interface MqttReservedCUService {
    TxnData reservedCUService(TriggerCU triggerCu, TxnData transData) throws NSLException, JSONException, MqttException, JsonProcessingException;

}
