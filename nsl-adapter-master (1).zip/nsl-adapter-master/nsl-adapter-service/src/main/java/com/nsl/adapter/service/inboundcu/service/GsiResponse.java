package com.nsl.adapter.service.inboundcu.service;

import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtilV2;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.dao.TransactionDao;
import com.nsl.logical.dao.TransactionDataDao;
import com.nsl.logical.model.GSI;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TransactionDto;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnBaseEntity;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnSlotItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;

@Service
public class GsiResponse {

    private static final Logger LOGGER = LoggerFactory.getLogger(GsiResponse.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authUser;

    @Autowired
    EntityToJSONUtilV2 entityToJsonUtil;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    TransactionDao transactionDao;

    @Autowired
    TransactionDataDao transactionDataDao;

    public HashMap<String,Object> getCuTxnData(String transId, Long gsiId) {

        LOGGER.info("fetching gsi with Id : {}",gsiId);
        GSI gsi = changeUnitDao.getGsiById(gsiId,authUser);
        List<TriggerCU> solutionLogic = gsi.getSolutionLogic();
        TriggerCU triggerCU= null;
        for(int i=solutionLogic.size()-1;i>=0;i--) {
                if(solutionLogic.get(i).getCuSystemProperties().containsKey("adapter") && solutionLogic.get(i).getCuSystemProperties().get("adapter").equals("RESTOUTPUT")){
                    triggerCU = solutionLogic.get(i);
                    break;
                }
        }
        if(triggerCU==null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,"TriggerCu data is null" , null);
        }

        String contexualId = "GS" + gsiId + ".CU" + triggerCU.getId() + "_" + triggerCU.getReferencedChangeUnit();
        GeneralEntity inputGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCU.getLayers(),
                AppConstant.INFORMATION);

        TxnBaseEntity txnBaseEntity = new TxnBaseEntity();
        txnBaseEntity.setTransactionId(transId);
        txnBaseEntity.setCuContextualId(contexualId);
        LOGGER.info("fetching transaction with GSI Context : {}",contexualId);

        TxnData txnData;
        try {
            txnData = transactionDataDao.fetchCuData(txnBaseEntity, authUser);
        }catch (Exception e){
            LOGGER.error("failed to fetch transaction CuData:" , e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "failed to fetch transaction CuData:" + e.getMessage()); //NOSONAR
        }

        List<TxnSlotItem> transEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnData.getTxnCULayer(),
                AppConstant.INFORMATION);
        TxnGeneralEntity txnGeneralEntity = GeneralEntityUtils.getExpectedTxnGeneralEntity(transEntityDetails);

        Boolean isMultivalued = triggerCU.getLayers().get(0).getParticipatingItems().get(0).getIsMultiValue();

        LOGGER.info("reading data from information layer");
        JSONObject response = new JSONObject();
        try {
            if (isMultivalued)
                response.put("response", entityToJsonUtil.getJsonArrayFromGE(txnGeneralEntity, inputGeneralEntity));
            else
                response.put("response", entityToJsonUtil.getJsonObjectFromGE(txnGeneralEntity, inputGeneralEntity));
        }catch (Exception e){
            LOGGER.error("failed to read data from information layer:" , e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "failed to read data from information layer:" + e.getMessage()); //NOSONAR
        }

        return JacksonUtils.fromJson(response.toString(), HashMap.class);
    }

    public TransactionDto getTransactionById(String transId ) {
        try {
            return transactionDao.getTransactionById(transId, authUser);
        }catch (Exception e){
            LOGGER.error("failed to read transaction :" , e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "failed to read transaction :" + e.getMessage()); //NOSONAR
        }
    }
}
