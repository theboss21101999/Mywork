package com.nsl.adapter.service.rest.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.RESTCredential;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.rest.utils.ConnectionDataTools;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.CreateGeneralEntityCUDao;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.dao.SearchCUDAO;
import com.nsl.logical.dto.search.TxnGeneralEntitySearchRequest;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.*;

import static com.nsl.adapter.commons.dto.connections.OAuthGrantType.AUTHORIZATIONCODE;
import static com.nsl.adapter.commons.dto.connections.OAuthGrantType.AUTHORIZATIONCODE_PKCE;
import static com.nsl.adapter.service.rest.utils.ConnectionConstants.REST_CONNECTION;

@Service
public class ConnectionToGeneral {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConnectionToGeneral.class);
    private static final ConnectionDtoType connType = ConnectionDtoType.REST;
    @Autowired
    GeneralEntityDao generalEntityDao;

    @Autowired
    private CreateGeneralEntityCUDao createGeneralEntityCUDao;

    @Autowired
    SearchCUDAO searchCUDAO;

    @Autowired
    ConnectionDataTools connectionDataTools;

    @Autowired
    AdapterConnectionServiceV3 connectionServiceV3;
    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;


    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    public TxnAdapterConnection restSaved(RESTAdapterConnectionDto restAdapterConnectionDto){
        restAdapterConnectionDto.setAuthentication(connectionDataTools.cleanRestCredentials(restAdapterConnectionDto.getAuthentication()));

        LOGGER.info("saving Rest connection");
        switch (restAdapterConnectionDto.getAuthentication().getAuthorizationType()) {
            case PASSWORD:
                restAdapterConnectionDto.getAuthentication().setPassword(connectionDataToolsV3.saveSecret(connType, "password",
                        restAdapterConnectionDto.getConnectionName(), requestScopedAuthenticatedUserBean.getTenantId(), restAdapterConnectionDto.getAuthentication().getPassword()));
                break;
            case OAUTH2:
                if(restAdapterConnectionDto.getAuthentication().getOAuthCredentials().getGrantType() == AUTHORIZATIONCODE || restAdapterConnectionDto.getAuthentication().getOAuthCredentials().getGrantType() == AUTHORIZATIONCODE_PKCE) {
                    restAdapterConnectionDto.getAuthentication().getOAuthCredentials().setRefreshToken(connectionDataToolsV3.saveSecret(connType, "refreshToken", restAdapterConnectionDto.getConnectionName(), requestScopedAuthenticatedUserBean.getTenantId(), restAdapterConnectionDto.getAuthentication().getOAuthCredentials().getRefreshToken()));

                }
                restAdapterConnectionDto.getAuthentication().getOAuthCredentials().setClientSecret(connectionDataToolsV3.saveSecret(connType, "clientSecret", restAdapterConnectionDto.getConnectionName(), requestScopedAuthenticatedUserBean.getTenantId(), restAdapterConnectionDto.getAuthentication().getOAuthCredentials().getClientSecret()));
                break;
            case HAWK:
                restAdapterConnectionDto.getAuthentication().getHawkCredentials().setAuthKey(connectionDataToolsV3.saveSecret(connType, "authKey",
                        restAdapterConnectionDto.getConnectionName(), requestScopedAuthenticatedUserBean.getTenantId(), restAdapterConnectionDto.getAuthentication().getHawkCredentials().getAuthKey()));
                break;
        }
        TxnAdapterConnection connection = new TxnAdapterConnection();
        connection.setConnection(restAdapterConnectionDto);
        connection.setConnectionDtoType(connType);
        return adapterConnnectionsDao.saveConnection(connection ,requestScopedAuthenticatedUserBean );
    }

    public RESTAdapterConnectionDto getEntityRecordrest(Long id){

        return getEntityRecordrest(id,false);
    }
    public RESTAdapterConnectionDto getEntityRecordrest(Long id, boolean hide){

        TxnAdapterConnection txnGeneralEntityRecord = adapterConnnectionsDao.getConnectionByRecordId(connType,id,requestScopedAuthenticatedUserBean);
        return txnToRestDto(txnGeneralEntityRecord,hide);
    }
    public RESTAdapterConnectionDto txnToRestDto(TxnAdapterConnection record, boolean hide) {
        RESTAdapterConnectionDto restAdapterConnectionDto = (RESTAdapterConnectionDto) record.getConnection();

        if (!hide){
            switch (String.valueOf(restAdapterConnectionDto.getAuthentication().getAuthorizationType())) {
                case "PASSWORD":
                    restAdapterConnectionDto.getAuthentication().setPassword(connectionDataToolsV3.getSecret(restAdapterConnectionDto.getAuthentication().getPassword()));
                    break;
                case "OAUTH2":
                    restAdapterConnectionDto.getAuthentication().getOAuthCredentials().setClientSecret(connectionDataToolsV3.getSecret(restAdapterConnectionDto.getAuthentication().getOAuthCredentials().getClientSecret()));
                    break;
                case "HAWK":
                    restAdapterConnectionDto.getAuthentication().getHawkCredentials().setAuthKey(connectionDataToolsV3.getSecret(restAdapterConnectionDto.getAuthentication().getHawkCredentials().getAuthKey()));
                    break;
            }
        }

        return restAdapterConnectionDto;
    }

    public TxnAdapterConnection updateRestEntity(Long id, RESTAdapterConnectionDto restAdapterConnectionDto){

        LOGGER.info("updating Rest connection");

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(connType, id ,requestScopedAuthenticatedUserBean);
        connectionDataToolsV3.connectionNameCheck(previousConnection,restAdapterConnectionDto.getConnectionName());

        switch (String.valueOf(restAdapterConnectionDto.getAuthentication().getAuthorizationType())) {
            case "PASSWORD":
                restAdapterConnectionDto.getAuthentication().setPassword(connectionDataToolsV3.updateSecret(connType, "password",
                        restAdapterConnectionDto.getConnectionName(), requestScopedAuthenticatedUserBean.getTenantId(), restAdapterConnectionDto.getAuthentication().getPassword()));
                break;
            case "OAUTH2":
                if(restAdapterConnectionDto.getAuthentication().getOAuthCredentials().getGrantType() == AUTHORIZATIONCODE || restAdapterConnectionDto.getAuthentication().getOAuthCredentials().getGrantType() == AUTHORIZATIONCODE_PKCE) {
                    restAdapterConnectionDto.getAuthentication().getOAuthCredentials().setRefreshToken(connectionDataToolsV3.updateSecret(connType, "refreshToken", restAdapterConnectionDto.getConnectionName(), requestScopedAuthenticatedUserBean.getTenantId(), restAdapterConnectionDto.getAuthentication().getOAuthCredentials().getRefreshToken()));

                }
                restAdapterConnectionDto.getAuthentication().getOAuthCredentials().setClientSecret(connectionDataToolsV3.updateSecret(connType, "clientSecret",
                        restAdapterConnectionDto.getConnectionName(), requestScopedAuthenticatedUserBean.getTenantId(), restAdapterConnectionDto.getAuthentication().getOAuthCredentials().getClientSecret()));
                break;
            case "HAWK":
                restAdapterConnectionDto.getAuthentication().getHawkCredentials().setAuthKey(connectionDataToolsV3.updateSecret(connType, "authKey",
                        restAdapterConnectionDto.getConnectionName(), requestScopedAuthenticatedUserBean.getTenantId(), restAdapterConnectionDto.getAuthentication().getHawkCredentials().getAuthKey()));
                break;
        }

        previousConnection.setConnection(restAdapterConnectionDto);

        return adapterConnnectionsDao.saveConnection(previousConnection, requestScopedAuthenticatedUserBean );
    }

    public boolean checkConnectionName(String conn, String connectionName) throws NSLException {

        Map<String, String> regmap = new HashMap<>();
        regmap.put("connectionName", "="+connectionName);
        List<TxnGeneralEntityRecord> resultList = connectionServiceV3.getRecordsByMap(conn, regmap,requestScopedAuthenticatedUserBean);
        if (!resultList.isEmpty()){
            return true;
        }
        return false;
    }


}
