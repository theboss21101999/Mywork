package com.nsl.adapter.service.kafka.utils;


import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.service.kafka.enums.ConnectionType;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import static com.nsl.adapter.service.kafka.enums.ConnectionType.SASL_PLAINTEXT;
import static com.nsl.adapter.service.kafka.enums.ConnectionType.SSL;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.*;

public class KafkaConsumerConnectionUtil {
    
    public Map<String, Object> buildConsumerProperties(KafkaConnectionDto connection) {
        Map<String, Object> configProps= new HashMap<>(20);
        Properties advancedConfig = connection.getAdvancedConfig();
        ConnectionType connectionType = ConnectionType.valueOf(String.valueOf(advancedConfig.get(CONNECTION_TYPE)));

        switch (connectionType){
            case SASL_PLAIN:
                configProps.put(SECURITY_PROTOCOL, SASL_SSL);
                configProps.put(SSL_TRUSTSTORE_LOCATION, advancedConfig.get(TRUSTSTORE_PATH));
                configProps.put(SSL_TRUSTSTORE_PASSWORD, advancedConfig.get(TRUSTSTORE_PASSWORD));
                configProps.put(SSL_KEY_PASSWORD, advancedConfig.get(KEY_PASSWORD));
                configProps.put(SASL_JAAS_CONFIGS, advancedConfig.get(SASL_JAAS_CONFIG));
                break;
            case SSL:
                configProps.put(SECURITY_PROTOCOL, SSL.toString());
                configProps.put(SSL_TRUSTSTORE_LOCATION, advancedConfig.get(TRUSTSTORE_PATH));
                configProps.put(SSL_TRUSTSTORE_PASSWORD, advancedConfig.get(TRUSTSTORE_PASSWORD));
                configProps.put(SSL_KEY_PASSWORD, advancedConfig.get(KEY_PASSWORD));
                break;
            case SASL_PLAINTEXT:
                configProps.put(SECURITY_PROTOCOL, SASL_PLAINTEXT.toString());
                configProps.put(SECURITY_MECHANISM, SECURITY_MECHANISM_SASL_PT);
                configProps.put(SASL_JAAS_CONFIGS, advancedConfig.get(SASL_JAAS_CONFIG));
                break;
            default:
                break;
        }
        configProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, connection.getBootstrapServer().get(0));
        configProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
        configProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
        configProps.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        configProps.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        return configProps;
    }

}

