package com.nsl.adapter.service.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.adapter.service.dto.VideoConferenceValidateDto;

public interface VideoConferencingService {
    public String getMeetingUrl();
    public VideoConferenceValidateDto validateMeetingId(String meetingId) throws JsonProcessingException, ClassNotFoundException;
}
