package com.nsl.adapter.service.enums;


public enum OAuthKeywords {

    TOKEN_URL("tokenUrl"),
    AUTHORIZATION_URL("authUrl"),
    REFRESH_URL("refreshUrl"),
    API_END_POINT("apiEndPoint"),
    HTTP_METHOD("httpMethod"),
    SCOPES("scopes");

    private String keyword;

    OAuthKeywords(String keyword) {
        this.keyword = keyword;
    }

    public String getKeyword() {
        return this.keyword;
    }

    public static OAuthKeywords fromValue(String val) {
        for (OAuthKeywords b : OAuthKeywords.values()) {
            if (b.getKeyword().equalsIgnoreCase(val)) {
                return b;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return this.getKeyword();
    }

}
