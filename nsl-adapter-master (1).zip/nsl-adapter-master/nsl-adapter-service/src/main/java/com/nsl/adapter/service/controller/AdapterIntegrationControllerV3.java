package com.nsl.adapter.service.controller;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.PaginatedConnectionsListDto;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.service.config.AdminAuth;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.commons.dto.Integrations.dto.PaginatedCUsDto;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.service.service.AdapterIntegrationServiceV3;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import static com.nsl.adapter.commons.enums.ConnectionDtoType.*;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;


@AdminAuth
@RestController
@CrossOrigin
@RequestMapping(value = "/api/v3")
public class AdapterIntegrationControllerV3 {

    List<ConnectionDtoType> dynamoConnections = Arrays.asList(FACEBOOK, AIML, Google, ZOOM, Graph, S3, Cisco, POP3, IMAP, JIRA, LINKEDIN, TELEGRAM, TWITTER, REST,SFTP, SMTP,DOCUSIGN,DB,SOAP,ADOBESIGN,FHIR,AS2,ActiveMQ,RabbitMQ,IBMMQ,FTP,GRAPHQL,GRPC,JDBC,OPENAPI);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterIntegrationServiceV3 adapterIntegrationServiceV3;

    @Autowired
    AdapterConnectionServiceV3 connectionService;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    private MessageSource messageSource;

    @GetMapping(path = "/connections")
    public ApiResponse getConnectionsList(@RequestParam(required = false , defaultValue = "1") Integer pageNumber,
                                          @RequestParam(required = false , defaultValue = "20") Integer pageSize,
                                          @RequestParam ("connectionType") ConnectionDtoType connectionDtoType,
                                          @RequestParam(required = false) String query) {
        if (pageNumber<1 || pageSize<1 )
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_17", null, Locale.ENGLISH));
        if (connectionDtoType == null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_18", null, Locale.ENGLISH));
        PaginatedConnectionsListDto dto;
        if (dynamoConnections.contains(connectionDtoType)){ //NOSONAR
            try{
                dto = adapterConnnectionsDao.fetchAllConnections(connectionDtoType, query, pageNumber, pageSize, authBean);
            }catch (NSLException e){
                return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), e);
            }
        }else{
            ConnectionsType connectionsType= ConnectionsType.valueOf(connectionDtoType.toString());
            dto = connectionService.getConnectionList(pageNumber, pageSize, connectionsType.getEntityName(), query,authBean);
        }
        return new ApiResponse(HttpStatus.OK, SUCCESS, dto);

    }

    @GetMapping(value = "/integration/list")
    public ApiResponse getPaginatedIntegrations(@RequestParam(required = false , defaultValue = "1") Integer pageNumber,
                                                @RequestParam(required = false , defaultValue = "20") Integer pageSize,
                                                @RequestParam(required = false) AdapterType adapterType,
                                                @RequestParam(required = false) String query) throws Exception {
        if (pageNumber<1 || pageSize<1 )
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_17", null, Locale.ENGLISH) );
        PaginatedCUsDto paginatedCUsDto;
        if (adapterType == null) {
            paginatedCUsDto = adapterIntegrationServiceV3.getPaginatedIntegrations(pageNumber, pageSize, query, null);
        }
        else {
            paginatedCUsDto = adapterIntegrationServiceV3.getPaginatedIntegrations(pageNumber, pageSize, query, adapterType.name());
        }
        return new ApiResponse(HttpStatus.OK, SUCCESS, paginatedCUsDto);
    }
    @GetMapping(value = "/integration/inboundAdapters/list")
    public ApiResponse getInboundPaginatedIntegrations(@RequestParam(required = false , defaultValue = "1") Integer pageNumber,
                                                @RequestParam(required = false , defaultValue = "20") Integer pageSize,
                                                @RequestParam(required = false) AdapterType adapterType,
                                                @RequestParam(required = false) String query) throws Exception {
        if (pageNumber<1 || pageSize<1 )
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_17", null, Locale.ENGLISH) );
        PaginatedCUsDto paginatedCUsDto;
        if (adapterType == null) {
            paginatedCUsDto = adapterIntegrationServiceV3.getInboundPaginatedIntegrations(pageNumber, pageSize, query, null);  //NOSONAR
        }
        else {
            paginatedCUsDto = adapterIntegrationServiceV3.getInboundPaginatedIntegrations(pageNumber, pageSize, query, adapterType.name());
        }
        return new ApiResponse(HttpStatus.OK, SUCCESS, paginatedCUsDto);
    }


    @PostMapping(value = "/integration")
    public ApiResponse saveIntegration(@RequestBody IntegrationDtoV3 integrationDto) throws NSLException{

        TenantChangeUnitInput changeUnit = adapterIntegrationServiceV3.saveIntegration(integrationDto);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, changeUnit);
    }

    @GetMapping(value = "/integration/{dsdId}")
    public ApiResponse getIntegrationById(@PathVariable("dsdId") String dsdId) throws NSLException {
        IntegrationDtoV3 integrationDto = adapterIntegrationServiceV3.getIntegrationById(dsdId);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, integrationDto );
    }

    @PutMapping(value = "/integration/{dsdId}")
    public ApiResponse updateIntegration(@PathVariable("dsdId") String dsdId,
                                    @RequestBody IntegrationDtoV3 integrationDto) throws NSLException {

        TenantChangeUnitInput changeUnit = adapterIntegrationServiceV3.updateIntegration(dsdId, integrationDto);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, changeUnit);
    }


    @GetMapping(value = "/connections/viewCus/list")
    public ApiResponse getConnectionCuList( @RequestParam(required = false , defaultValue = "1") Integer pageNumber,
                                  @RequestParam(required = false , defaultValue = "20") Integer pageSize,
                                  @RequestParam(required = false) AdapterType adapterType,
                                  @RequestParam(required = false) String query,
                                   @RequestParam(required = false) String connectionId) throws Exception {
        PaginatedCUsDto paginatedCUsDto;
        if (adapterType == null) {
            paginatedCUsDto = adapterIntegrationServiceV3.getConnectionCuList(connectionId, query,null,pageNumber,pageSize);
        }
        else {
            paginatedCUsDto = adapterIntegrationServiceV3.getConnectionCuList(connectionId, query,adapterType.name(),pageNumber,pageSize);
        }
        return new ApiResponse(HttpStatus.OK, SUCCESS, paginatedCUsDto);
    }


}
