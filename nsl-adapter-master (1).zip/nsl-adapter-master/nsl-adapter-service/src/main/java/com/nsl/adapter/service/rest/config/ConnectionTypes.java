package com.nsl.adapter.service.rest.config;

import com.nsl.adapter.service.pop3.utils.Pop3Constants;

public enum ConnectionTypes {
    rest("NSL_Rest_Connection"),
    pop3(Pop3Constants.POP3_CONNECTION),
    sftp("NSL_SFTP_Connection");
    private final String type;

    ConnectionTypes(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
