package com.nsl.adapter.service.calendar.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.dto.SlotFetchDto;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.externalreservedcus.dto.calender.event.CalendarEvent;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.nsl.adapter.service.calendar.utils.SlotConstants.*;
import static org.springframework.http.HttpHeaders.*;
import static org.springframework.http.HttpHeaders.ACCEPT_LANGUAGE;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Component
public class SlotServiceUtils {
    @Autowired
    AdaptorProperties adaptorProperties;
    @Autowired
    SlotJsonUtils slotJsonUtils;
    @Autowired
    RestTemplate restTemplate;
    @Value("${app.send.email.notification.url}")
    private String emailUri;
    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;
    private static final String stringFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private static final Logger LOGGER = LoggerFactory.getLogger(SlotServiceUtils.class);
    private final DateFormat formatter = new SimpleDateFormat(DATE_PATTERN);

    private static String getTime(Date time) {
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_PATTERN);
        return formatter.format(time);
    }

    public Date stringToDate(String dateString, String format) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.parse(dateString);
    }

    public CalendarEvent fetchSlot(String eventId) throws ParseException {
        CalendarEvent calendarEvent = new CalendarEvent();
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put(EVENTID, eventId);
        String requestString = JacksonUtils.toJson(requestBody);
        HttpHeaders headers = new HttpHeaders();
        headers.add(AUTHORIZATION, AppConstant.BEARER + requestScopedAuthenticatedUserBean.getAuthToken());
        headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        headers.add(ACCEPT_LANGUAGE, AppConstant.ACCEPT_LANGUAGE_EN);
        HttpEntity<String> stringHttpEntity = new HttpEntity<>(requestString, headers);
        String uri = adaptorProperties.getDynamoNewUrl() + CALENDAR_FETCH_API;
        ResponseEntity<JsonNode> response = restTemplate.postForEntity(uri, stringHttpEntity, JsonNode.class);
        if (!response.hasBody() || response.getBody() == null || response.getStatusCodeValue() != 200)
            return calendarEvent;
        JsonNode responseNode = response.getBody();
        if (responseNode == null || !responseNode.has(RESULT) || responseNode.get(RESULT) == null)
            return calendarEvent;
        return slotJsonUtils.convertJsonNodeToCalendarEventList(responseNode.get(RESULT));
    }

    public CalendarEvent fetchSlots(String startTime, String endTime, SlotFetchDto slotFetchDto) throws ParseException {
        CalendarEvent calendarEvent = new CalendarEvent();
        Date startDate = stringToDate(startTime, stringFormat);
        Date endDate = stringToDate(endTime, stringFormat);
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put(START_TIME, getTime(startDate));
        requestBody.put(END_TIME, getTime(endDate));
        requestBody.put(CONFERENCE_TYPE, slotFetchDto.getConferenceType());
        requestBody.put(ORGANIZER, slotFetchDto.getOrganizer());
        requestBody.put(ADDITIONAL_INFO_4, slotFetchDto.getAdditionalInfo4());
        requestBody.put(ADDITIONAL_INFO_2, slotFetchDto.getAdditionalInfo2());
        String requestString = JacksonUtils.toJson(requestBody);
        HttpHeaders headers = new HttpHeaders();
        headers.add(AUTHORIZATION, AppConstant.BEARER + requestScopedAuthenticatedUserBean.getAuthToken());
        headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        headers.add(ACCEPT_LANGUAGE, AppConstant.ACCEPT_LANGUAGE_EN);
        HttpEntity<String> stringHttpEntity = new HttpEntity<>(requestString, headers);
        String uri = adaptorProperties.getDynamoNewUrl() + CALENDAR_FETCH_API;
        ResponseEntity<JsonNode> response = restTemplate.postForEntity(uri, stringHttpEntity, JsonNode.class);
        if (!response.hasBody() || response.getBody() == null || response.getStatusCodeValue() != 200)
            return calendarEvent;
        JsonNode responseNode = response.getBody();
        if (responseNode == null || !responseNode.has(RESULT) || responseNode.get(RESULT) == null)
            return calendarEvent;
        return slotJsonUtils.convertJsonNodeToCalendarEventList(responseNode.get(RESULT));
    }

    public ApiResponse deleteSlot(String conferenceType, List<String> events) {
        var isDynamoNewEnabled = adaptorProperties.getDynamoNewEnabled();
        ResponseEntity<ApiResponse> response = null;
        if (isDynamoNewEnabled) {
            HttpHeaders headers = new HttpHeaders();
            headers.add(AUTHORIZATION, AppConstant.BEARER + requestScopedAuthenticatedUserBean.getAuthToken());
            headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
            headers.add(ACCEPT_LANGUAGE, AppConstant.ACCEPT_LANGUAGE_EN);
            HttpEntity<HttpHeaders> request = new HttpEntity<>(headers);
            String eventsParam = serializeList(events);
            String uri = adaptorProperties.getDynamoNewUrl() + "/calendar/delete/slots?conferenceType=" + conferenceType;
            uri += "&events=" + eventsParam;
            LOGGER.info("calling delete url.....{}", uri);
            response = restTemplate.exchange(uri, HttpMethod.DELETE, request, ApiResponse.class);

        }
        if (response != null) {
            return response.getBody();
        } else {
            throw new NullPointerException("Error occurred while deleting the slot");
        }
    }

    public static String serializeList(Collection<String> collection) {
        return collection.stream()
                .map(Object::toString)
                .collect(Collectors.joining(","));
    }

    public void sendEmailNotification(List<String> participantList, String description, String status) {
        String result = String.join(",", participantList);
        Map<String, Object> emailRequest = new HashMap<>();
        emailRequest.put("nslName", "send email");
        Map<String, String> requestParams = new HashMap<>();
        requestParams.put("recipients", result);
        if (description == null) {
            description = "";
        }
        requestParams.put("content", description);
        requestParams.put("subject", status);
        emailRequest.put("requestParams", requestParams);
        HttpHeaders headers = new HttpHeaders();
        headers.add(AUTHORIZATION, AppConstant.BEARER + requestScopedAuthenticatedUserBean.getAuthToken());
        headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        headers.add(ACCEPT_LANGUAGE, AppConstant.ACCEPT_LANGUAGE_EN);
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(emailRequest, headers);
        String uri = adaptorProperties.getEmailNotification();
        LOGGER.info("calling email notifictaion url.....{}", uri);
        ResponseEntity<String> response = restTemplate.exchange(emailUri, HttpMethod.POST, request, String.class);
        LOGGER.info("Email response:" + response.getBody());
    }


}
