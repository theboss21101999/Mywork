package com.nsl.adapter.service.dto.integration;

import java.util.Map;

public class RestIntegrationReq {

    String inputEntityId;
    String inputEntityFileType;
    String outputEntityId;
    String outputEntityFileType;
    String headerEntityId;
    String pathparamEntityId;
    String queryparamEntityId;
    String headerResponseEntityId;
    String httpMethod;
    String contentType;
    String isInputMultivalue;
    String isOutputMultivalue;
    String accept;
    String uri;
    Map<String, StatusEntityDto> statusMap;
    Map<String, Map<String, String>> mapper;

    public RestIntegrationReq() {
    }

    public RestIntegrationReq(String inputEntityId, String inputEntityFileType, String outputEntityId, String outputEntityFileType, String headerEntityId, String pathparamEntityId, String queryparamEntityId, String headerResponseEntityId, String httpMethod, String contentType, String isInputMultivalue, String isOutputMultivalue, String accept, String uri, Map<String, StatusEntityDto> statusMap, Map<String, Map<String, String>> mapper) {
        this.inputEntityId = inputEntityId;
        this.inputEntityFileType = inputEntityFileType;
        this.outputEntityId = outputEntityId;
        this.outputEntityFileType = outputEntityFileType;
        this.headerEntityId = headerEntityId;
        this.pathparamEntityId = pathparamEntityId;
        this.queryparamEntityId = queryparamEntityId;
        this.headerResponseEntityId = headerResponseEntityId;
        this.httpMethod = httpMethod;
        this.contentType = contentType;
        this.isInputMultivalue = isInputMultivalue;
        this.isOutputMultivalue = isOutputMultivalue;
        this.accept = accept;
        this.uri = uri;
        this.statusMap = statusMap;
        this.mapper = mapper;
    }

    public String getInputEntityId() {
        return inputEntityId;
    }

    public void setInputEntityId(String inputEntityId) {
        this.inputEntityId = inputEntityId;
    }

    public String getInputEntityFileType() {
        return inputEntityFileType;
    }

    public void setInputEntityFileType(String inputEntityFileType) {
        this.inputEntityFileType = inputEntityFileType;
    }

    public String getOutputEntityId() {
        return outputEntityId;
    }

    public void setOutputEntityId(String outputEntityId) {
        this.outputEntityId = outputEntityId;
    }

    public String getOutputEntityFileType() {
        return outputEntityFileType;
    }

    public void setOutputEntityFileType(String outputEntityFileType) {
        this.outputEntityFileType = outputEntityFileType;
    }

    public String getHeaderEntityId() {
        return headerEntityId;
    }

    public void setHeaderEntityId(String headerEntityId) {
        this.headerEntityId = headerEntityId;
    }

    public String getPathparamEntityId() {
        return pathparamEntityId;
    }

    public void setPathparamEntityId(String pathparamEntityId) {
        this.pathparamEntityId = pathparamEntityId;
    }

    public String getQueryparamEntityId() {
        return queryparamEntityId;
    }

    public void setQueryparamEntityId(String queryparamEntityId) {
        this.queryparamEntityId = queryparamEntityId;
    }

    public String getHeaderResponseEntityId() {
        return headerResponseEntityId;
    }

    public void setHeaderResponseEntityId(String headerResponseEntityId) {
        this.headerResponseEntityId = headerResponseEntityId;
    }

    public String getHttpMethod() {
        return httpMethod;
    }

    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getIsInputMultivalue() {
        return isInputMultivalue;
    }

    public void setIsInputMultivalue(String isInputMultivalue) {
        this.isInputMultivalue = isInputMultivalue;
    }

    public String getIsOutputMultivalue() {
        return isOutputMultivalue;
    }

    public void setIsOutputMultivalue(String isOutputMultivalue) {
        this.isOutputMultivalue = isOutputMultivalue;
    }

    public String getAccept() {
        return accept;
    }

    public void setAccept(String accept) {
        this.accept = accept;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public Map<String, StatusEntityDto> getStatusMap() {
        return statusMap;
    }

    public void setStatusMap(Map<String, StatusEntityDto> statusMap) {
        this.statusMap = statusMap;
    }

    public Map<String, Map<String, String>> getMapper() {
        return mapper;
    }

    public void setMapper(Map<String, Map<String, String>> mapper) {
        this.mapper = mapper;
    }
}
