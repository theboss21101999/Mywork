package com.nsl.adapter.service.service;

import com.nsl.adapter.commons.dao.AdaptersIntegrationUtilsDao;
import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.commons.dto.Integrations.dto.PaginatedCUsDto;
import com.nsl.adapter.commons.dto.Integrations.dto.ViewCUDto;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.ChangeUnit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static com.nsl.adapter.service.utils.AppConstant.ADAPTER;
import static com.nsl.adapter.service.utils.AppConstant.Adapter_KEY;
import static com.nsl.adapter.service.utils.AppConstant.CONFIG_ENTITY_RECORD_ID;
import static com.nsl.adapter.service.utils.AppConstant.CONFIG_ENTITY_RECORD_NAME;
import static com.nsl.adapter.service.utils.AppConstant.EXT_SOL_TYPE;
import static com.nsl.adapter.service.utils.AppConstant.OPERATION;

@Service
public class AdapterIntegrationServiceV3 {

    @Autowired
    AdapterIntegrationFactory adapterIntegrationfactory;

    @Autowired
    AdaptersIntegrationUtilsDao adaptersIntegrationUtilsDao;
    @Autowired
    ChangeUnitDao changeUnitDao;


    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    public PaginatedCUsDto getPaginatedIntegrations(Integer pageNumber, Integer pageSize, String query, String adapter) throws Exception {

        Page<ChangeUnit> changeUnits = adaptersIntegrationUtilsDao.getCUsList(pageNumber-1, pageSize, query, adapter);

        PaginatedCUsDto paginatedCUsDto = new PaginatedCUsDto();
        paginatedCUsDto.setPageSize(changeUnits.getSize());
        paginatedCUsDto.setPageNo(changeUnits.getNumber()+1);
        paginatedCUsDto.setTotalHits(changeUnits.getTotalElements());
        paginatedCUsDto.setCuDtoList(new ArrayList<>());

        changeUnits.getContent().forEach(x -> {
            ViewCUDto viewCUDto = new ViewCUDto();
            viewCUDto.setName(x.getName());
            viewCUDto.setDsdId(x.getId().toString());
            viewCUDto.setStatusEnum(x.getStatus());
            viewCUDto.setAdapterType(AdapterType.valueOf(x.getCuSystemProperties().get(ADAPTER)));
            if(x.getCreatedAt()!=null) {
                viewCUDto.setCreatedAt(new Date(x.getCreatedAt()));
            }
            if(x.getUpdatedAt()!=null) {
                viewCUDto.setUpdatedAt(new Date(x.getUpdatedAt()));
            }
            paginatedCUsDto.getCuDtoList().add(viewCUDto);
        });

        return paginatedCUsDto;
    }

    public PaginatedCUsDto getConnectionCuList(String connectionId, String query, String adapter, int pageNumber, int pageSize)  {
        Map<String,String> cuSystemProps= new HashMap<>();
        Pageable pageable = PageRequest.of(pageNumber-1, pageSize);
        cuSystemProps.put("configEntityRecordId",connectionId);
        if(adapter!=null){
            cuSystemProps.put(AppConstants.ADAPTER, adapter.toUpperCase(Locale.ROOT));
        }
        else{
            cuSystemProps.put(AppConstants.EXTERNAL_SOLUTION_TYPE, "Adapter");
        }
        Page<ChangeUnit> changeUnits= changeUnitDao.getAllCUs(cuSystemProps, query, pageable, authBean);

        PaginatedCUsDto paginatedCUsDto = new PaginatedCUsDto();
        paginatedCUsDto.setPageSize(changeUnits.getSize());
        paginatedCUsDto.setPageNo(changeUnits.getNumber()+1);
        paginatedCUsDto.setTotalHits(changeUnits.getTotalElements());
        paginatedCUsDto.setCuDtoList(new ArrayList<>());

        changeUnits.getContent().forEach(x -> {
            ViewCUDto viewCUDto = new ViewCUDto();
            viewCUDto.setName(x.getName());
            viewCUDto.setDsdId(x.getId().toString());
            viewCUDto.setStatusEnum(x.getStatus());
            viewCUDto.setAdapterType(AdapterType.valueOf(x.getCuSystemProperties().get(ADAPTER)));
            if(x.getCreatedAt()!=null) {
                viewCUDto.setCreatedAt(new Date(x.getCreatedAt()));
            }
            if(x.getUpdatedAt()!=null) {
                viewCUDto.setUpdatedAt(new Date(x.getUpdatedAt()));
            }
            paginatedCUsDto.getCuDtoList().add(viewCUDto);
        });

        return paginatedCUsDto;

    }
    public PaginatedCUsDto getInboundPaginatedIntegrations(Integer pageNumber, Integer pageSize, String query, String adapter) throws Exception {
        Map<String,String> cuSystemProps= new HashMap<>();
        Pageable pageable = PageRequest.of(pageNumber-1, pageSize);

        if(adapter.equals((AdapterType.SFTP).toString())) {  //NOSONAR
            cuSystemProps.put("operation", "GET");
        }
        if(adapter.equals("ACTIVEMQ") || adapter.equals("RABBITMQ") || adapter.equals("IBMMQ") ){ //NOSONAR
            cuSystemProps.put("operation", "RECIEVE");
        }
        if(adapter!=null){  //NOSONAR
            cuSystemProps.put(AppConstants.ADAPTER, adapter.toUpperCase(Locale.ROOT));
        }
        else{
            cuSystemProps.put(AppConstants.EXTERNAL_SOLUTION_TYPE, "Adapter");
        }
        Page<ChangeUnit> changeUnits= changeUnitDao.getAllCUs(cuSystemProps, query, pageable, authBean);

        PaginatedCUsDto paginatedCUsDto = new PaginatedCUsDto();
        paginatedCUsDto.setPageSize(changeUnits.getSize());
        paginatedCUsDto.setPageNo(changeUnits.getNumber()+1);
        paginatedCUsDto.setTotalHits(changeUnits.getTotalElements());
        paginatedCUsDto.setCuDtoList(new ArrayList<>());

        changeUnits.getContent().forEach(x -> {
            ViewCUDto viewCUDto = new ViewCUDto();
            viewCUDto.setName(x.getName());
            viewCUDto.setDsdId(x.getId().toString());
            viewCUDto.setStatusEnum(x.getStatus());
            viewCUDto.setAdapterType(AdapterType.valueOf(x.getCuSystemProperties().get(ADAPTER)));
            if(x.getCreatedAt()!=null) {
                viewCUDto.setCreatedAt(new Date(x.getCreatedAt()));
            }
            if(x.getUpdatedAt()!=null) {
                viewCUDto.setUpdatedAt(new Date(x.getUpdatedAt()));
            }
            paginatedCUsDto.getCuDtoList().add(viewCUDto);
        });

        return paginatedCUsDto;
    }


    public TenantChangeUnitInput saveIntegration(IntegrationDtoV3 integrationDto) throws NSLException {

        adaptersIntegrationUtilsDao.checkCUName(integrationDto.getIntegrationName());

        IntegrationService integrationService = adapterIntegrationfactory.getIntegrationService(integrationDto.getAdapterType());
        CUPropsDto propsDto = integrationService.getSaveProperties(integrationDto);
        propsDto.setCuName(integrationDto.getIntegrationName());

        getCuSystemProps(integrationDto).forEach((key, value) ->
            propsDto.getCuSystemProps().putIfAbsent(key, value)
        );

        return adaptersIntegrationUtilsDao.saveIntegration(propsDto);
    }

    public IntegrationDtoV3 getIntegrationById(String dsdId) throws NSLException {

        CUPropsDto cuPropsDto = adaptersIntegrationUtilsDao.getIntegrationById(dsdId);
        Map<String, String> cuSystemProps = cuPropsDto.getCuSystemProps();

        IntegrationDtoV3 integrationDto = new IntegrationDtoV3();
        integrationDto.setIntegrationName(cuPropsDto.getCuName());
        integrationDto.setAdapterType(AdapterType.valueOf(cuSystemProps.remove(ADAPTER)));

        Long configEntityId = null;
        if(cuSystemProps.containsKey(CONFIG_ENTITY_RECORD_ID) && !"null".equals(cuSystemProps.get(CONFIG_ENTITY_RECORD_ID)))
            configEntityId = Long.valueOf(cuSystemProps.remove(CONFIG_ENTITY_RECORD_ID));

        integrationDto.setConfigEntityRecordId(configEntityId);
        integrationDto.setConfigEntityRecordName(cuSystemProps.remove(CONFIG_ENTITY_RECORD_NAME));
        integrationDto.setOperation(cuSystemProps.remove(OPERATION));

        IntegrationService integrationService = adapterIntegrationfactory.getIntegrationService(integrationDto.getAdapterType());
        integrationService.getIntegration(integrationDto,cuPropsDto);


        integrationDto.setPropertiesMap(cuPropsDto.getCuSystemProps());
        return integrationDto;
    }

    public TenantChangeUnitInput updateIntegration(String dsdId, IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto cuPropsDto = adaptersIntegrationUtilsDao.getIntegrationById(dsdId);

        IntegrationService integrationService = adapterIntegrationfactory.getIntegrationService(integrationDto.getAdapterType());
        CUPropsDto newCuPropsDto = integrationService.getUpdateProperties(cuPropsDto ,integrationDto );

        Map<String,String> newCuSystemProps = cuPropsDto.getCuSystemProps();
        newCuPropsDto.setCuSystemProps(getNewCuSystemProps(newCuSystemProps,integrationDto));
        return adaptersIntegrationUtilsDao.updateIntegration(dsdId,newCuPropsDto);

    }

    private Map<String , String> getCuSystemProps(IntegrationDtoV3 integrationDto){

        Map<String,String> cuSystemProps = new HashMap<>();
        cuSystemProps.put(EXT_SOL_TYPE, Adapter_KEY);
        cuSystemProps.put(ADAPTER, String.valueOf(integrationDto.getAdapterType()));
        cuSystemProps.put(OPERATION,integrationDto.getOperation());
        cuSystemProps.put(CONFIG_ENTITY_RECORD_ID, String.valueOf(integrationDto.getConfigEntityRecordId()));
        cuSystemProps.put(CONFIG_ENTITY_RECORD_NAME, integrationDto.getConfigEntityRecordName());

        return cuSystemProps;

    }

    private Map<String , String> getNewCuSystemProps(Map<String,String> newCuSystemProps ,IntegrationDtoV3 integrationDto){

        newCuSystemProps.put(OPERATION,integrationDto.getOperation());
        newCuSystemProps.put(CONFIG_ENTITY_RECORD_ID, String.valueOf(integrationDto.getConfigEntityRecordId()));
        newCuSystemProps.put(CONFIG_ENTITY_RECORD_NAME, integrationDto.getConfigEntityRecordName());

        return newCuSystemProps;
    }
}
