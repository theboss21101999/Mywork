package com.nsl.adapter.service.dto;

import javax.validation.constraints.NotNull;


public class SchedulerFetchDto {

    @NotNull
    private String startTime;
    @NotNull
    private String endTime;

    private String organizer;

    @NotNull
    private String additionalInfo4;

    private String additionalInfo3;

    private String additionalInfo5;
    @NotNull
    private String conferenceType;

    private String eventId;

    public @NotNull String getStartTime() {
        return startTime;
    }

    public void setStartTime(@NotNull String startTime) {
        this.startTime = startTime;
    }

    public @NotNull String getEndTime() {
        return endTime;
    }

    public void setEndTime(@NotNull String endTime) {
        this.endTime = endTime;
    }

    public String getOrganizer() {
        return organizer;
    }

    public void setOrganizer(String organizer) {
        this.organizer = organizer;
    }

    public @NotNull String getAdditionalInfo4() {
        return additionalInfo4;
    }

    public void setAdditionalInfo4(@NotNull String additionalInfo4) {
        this.additionalInfo4 = additionalInfo4;
    }

    public String getAdditionalInfo3() {
        return additionalInfo3;
    }

    public void setAdditionalInfo3(String additionalInfo3) {
        this.additionalInfo3 = additionalInfo3;
    }

    public String getAdditionalInfo5() {
        return additionalInfo5;
    }

    public void setAdditionalInfo5(String additionalInfo5) {
        this.additionalInfo5 = additionalInfo5;
    }

    public @NotNull String getConferenceType() {
        return conferenceType;
    }

    public void setConferenceType(@NotNull String conferenceType) {
        this.conferenceType = conferenceType;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }
}
