package com.nsl.adapter.service.mqtt.service;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.service.service.IntegrationService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CronExpressionHelper;
import com.nsl.adapter.service.v2.utills.EntityConstants;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.nsl.adapter.service.utils.AppConstant.*;
import static com.nsl.adapter.service.v2.utills.EntityConstants.NSL_Adapter_Native_File;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class MQTTIntegrationService implements IntegrationService {

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Autowired
    SaveBetsService saveBetsService;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Override
    public CUPropsDto getSaveProperties(IntegrationDtoV3 integrationDto) throws NSLException {
        if(!validate(integrationDto.getOperation())){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "please send valid data", ExceptionSeverity.MAJOR);
        }
        CUPropsDto cuPropsDto = null;
        HashMap<String, String> cuSystemProps = new HashMap<>(integrationDto.getPropertiesMap());
        if (integrationDto.getOperation().equalsIgnoreCase(AppConstant.PUBLISHER)){
            cuPropsDto = newEntitiesForPublisherMethod(integrationDto);
        }else if (integrationDto.getOperation().equalsIgnoreCase(AppConstant.SUBSCRIBER)){
            cuPropsDto = newEntitiesForReceiverMethod(integrationDto);
            String metaInfoEntityId = metaInfoEntityUtils.createMetaInfoEntity(integrationDto.getIntegrationName(), authBean);
            cuSystemProps.put(METAINFO_ENTITY_KEY, metaInfoEntityId);
            if (integrationDto.getScheduleReq() != null) {
                cuSystemProps.put(CRON_EXPRESSION,
                        CronExpressionHelper.generateCronExpression(integrationDto.getScheduleReq()));
                cuSystemProps.put(JOB_DELETE_TIME, integrationDto.getScheduleReq().getEndDate());
                cuSystemProps.put(ENDDATE,integrationDto.getScheduleReq().getEndDate());
                cuSystemProps.put(INCREMENTVALUE,integrationDto.getScheduleReq().getIncrementValue());
                cuSystemProps.put(INTERVAL, String.valueOf(integrationDto.getScheduleReq().getInterval()));
                cuSystemProps.put(TIME,integrationDto.getScheduleReq().getTime());
            }
        }else {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "Operation is not valid", ExceptionSeverity.MAJOR);
        }
        cuPropsDto.setCuSystemProps(cuSystemProps);
        cuPropsDto.setIsMachineCU(Boolean.FALSE);
        return cuPropsDto;
    }

    @Override
    public void getIntegration(IntegrationDtoV3 integrationDto, CUPropsDto cuPropsDto) {
            if(PUBLISHER.equalsIgnoreCase(integrationDto.getOperation())){
                integrationDto.setInputEntityDsdId(getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).get(0).getDsdId());
            }else if(SUBSCRIBER.equalsIgnoreCase(integrationDto.getOperation())){
                integrationDto.setOutputEntityDsdId(getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).get(0).getDsdId());
            }
    }

    @Override
    public CUPropsDto getUpdateProperties(CUPropsDto cuPropsDto, IntegrationDtoV3 integrationDto) throws NSLException {
        CUPropsDto newcuPropsDto;

        if (integrationDto.getOperation().equalsIgnoreCase(AppConstant.PUBLISHER)){
            newcuPropsDto = newEntitiesForPublisherMethod(integrationDto);
        }else if (integrationDto.getOperation().equalsIgnoreCase(AppConstant.SUBSCRIBER)){
            newcuPropsDto = newEntitiesForReceiverMethod(integrationDto);
        }else {
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "Operation is not valid", ExceptionSeverity.MAJOR);
        }
        Map<String, String> cuSystemProps = cuPropsDto.getCuSystemProps();
        cuSystemProps.putAll(integrationDto.getPropertiesMap());
        newcuPropsDto.setCuSystemProps(cuSystemProps);
        return newcuPropsDto;
    }

    private CUPropsDto newEntitiesForPublisherMethod(IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto cuPropsDto = new CUPropsDto();

        List<TenantCUEntityInput> physicalentity = new ArrayList<>();
        physicalentity.add(saveBetsService.findEntityById(integrationDto.getInputEntityDsdId()));

        List<TenantCUEntityInput> triggerEntity = new ArrayList<>();
        triggerEntity.add(saveBetsService.getEntityByName(EntityConstants.NSL_MQTT_RES));

        cuPropsDto.setPhysicalLayerItems(buildSlotItems(physicalentity));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(triggerEntity));

        return cuPropsDto;
    }

    private CUPropsDto newEntitiesForReceiverMethod(IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto cuPropsDto = new CUPropsDto();

        List<TenantCUEntityInput> entity = new ArrayList<>();
        entity.add(saveBetsService.findEntityById(integrationDto.getOutputEntityDsdId()));

        cuPropsDto.setPhysicalLayerItems(buildSlotItems(entity));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(entity));

        return cuPropsDto;
    }


    public boolean validate(String Operation){
        if(Operation!=null){
            return true;
        }
        return false;
    }
}
