package com.nsl.adapter.service.linkedin.utils;

public class LinkedinConstants {
    public static final String LINKEDIN = "Linkedin";
    public static final String REFRESH_TOKEN="refresh_token";
    public static final String LINKEDIN_AUTH_TOKEN = "https://www.linkedin.com/oauth/v2/authorization";
    public static final String LINKEDIN_ACCESS_TOKEN ="https://www.linkedin.com/oauth/v2/accessToken";

    public static final String AUTHORIZATION_CODE="authorization_code";
    public static final String PROMPT="prompt";
    public static final String CONSENT="consent";
    public static final String ACCESS_TYPE="access_type";
    public static final String OFFLINE="offline";
    public static final String CODE="code";
    public static final String STATE="state";
    public static final String Url="url";

}
