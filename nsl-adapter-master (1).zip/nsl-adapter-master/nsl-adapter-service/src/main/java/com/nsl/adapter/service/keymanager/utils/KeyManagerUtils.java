package com.nsl.adapter.service.keymanager.utils;

import com.nsl.adapter.service.keymanager.dto.KeyManagerDto;
import com.nsl.adapter.service.keymanager.dto.KmsConnectionDto;
import com.nsl.adapter.service.keymanager.enums.KmsType;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.CreateGeneralEntityCUDao;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.dao.SearchCUDAO;
import com.nsl.logical.dto.search.TxnGeneralEntitySearchRequest;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.*;

@Component
public class KeyManagerUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(KeyManagerUtils.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Autowired
    private CreateGeneralEntityCUDao createGeneralEntityCUDao;

    @Autowired
    GeneralEntityDao generalEntityDao;

    @Autowired
    SearchCUDAO searchCUDAO;

    @Autowired
            private MessageSource messageSource;

    public boolean isValidForSave(KeyManagerDto keyManagerDto, boolean isUpdate){
        if (keyManagerDto.getKmsType()==null
                || keyManagerDto.getName()==null
                || keyManagerDto.getAlias()==null) return false;

        if (!isUpdate &&
                (keyManagerDto.getKmsType() == KmsType.SSHKEY || keyManagerDto.getKmsType() == KmsType.KEY) &&
                keyManagerDto.getPassword()==null){
            return false;
        }
        if (keyManagerDto.getKmsType() == KmsType.ENCRYPTIONKEY){
            if (keyManagerDto.getEncryptionKeyPrivate()==null) return false;
            if (!isUpdate && keyManagerDto.getEncryptionKeyPrivate()
                    && keyManagerDto.getPassword()==null) return false;
        }
        return true;
    }

    public boolean checkEntityRecordByNameorAlias(TxnGeneralEntityRecord record, String name, String alias){
        List<TxnNslAttribute> attributeList = record.getTxnNslAttribute();
        for (TxnNslAttribute attribute : attributeList){
            if (attribute.getName().equals(KmsConstants.KMS_NAME)){
                if (attribute.getValues().get(0).equals(name)){
                    return true;
                }
            }
            if (attribute.getName().equals(KmsConstants.KMS_ALIAS)){
                if (attribute.getValues().get(0).equals(alias)){
                    return true;
                }
            }
        }
        return false;
    }

    public boolean checkEntityRecordByNameAndAlias(TxnGeneralEntityRecord record, String name, String alias,Long attrId) {
        List<TxnNslAttribute> attributeList = record.getTxnNslAttribute();
        for (TxnNslAttribute attribute : attributeList){
            if (attribute.getName().equals(KmsConstants.KMS_NAME) || attribute.getName().equals(KmsConstants.KMS_ALIAS)){
                String value = attribute.getName().equals(KmsConstants.KMS_NAME)?name:alias;
                if (attribute.getValues().get(0).equals(value) && !attrId.equals(record.getId())){
                    return true;
                }
                if (attrId.equals(record.getId()) && !attribute.getValues().get(0).equals(value)){
                    return true;
                }
            }
        }

        return false;
    }


    public boolean checkEntityRecordIdBySha256(TxnGeneralEntityRecord record, String sha256) {
        List<TxnNslAttribute> attributeList = record.getTxnNslAttribute();
        for (TxnNslAttribute attribute : attributeList){
            if (attribute.getName().equals(KmsConstants.KMS_PROPERTIES)){
                Properties prop = JacksonUtils.fromJson(attribute.getValues().get(0), Properties.class);
                if (sha256.equals(prop.get(KmsConstants.KMS_SHA256))){ //NOSONAR
                    return true;
                }
            }
        }

        return false;
    }

    public TxnGeneralEntityRecord getRecordById(Long attrId) throws NSLException {
        List<TxnGeneralEntityRecord> resultList = getTotalRecords(KmsConstants.KMS_CONNECTION);
        for (TxnGeneralEntityRecord txnGeneralEntityRecord : resultList){
            if (txnGeneralEntityRecord.getId().equals(attrId)){
                return txnGeneralEntityRecord;
            }
        }
        return null;
    }

    public TxnGeneralEntityRecord saveRecord(List<TxnNslAttribute> attributesList,Long generalEntityId,
                                             Long attrId, String guid){
        //        Entity Record
        TxnGeneralEntityRecord entityRecord = new TxnGeneralEntityRecord();  //Entity Record --> Attributes
        entityRecord.setTxnNslAttribute(attributesList);
        if (attrId!=null)entityRecord.setId(attrId);
        if (guid!=null)entityRecord.setGuid(guid);
        List<TxnGeneralEntityRecord> entityRecordList = new ArrayList<TxnGeneralEntityRecord>();
        entityRecordList.add(entityRecord);
//        General Entity
        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity(); //General Entity --> Entity Record --> Attributes
        txnGeneralEntity.setTransEntityRecords(entityRecordList);
        txnGeneralEntity.setName(KmsConstants.KMS_CONNECTION);
        txnGeneralEntity.setGeneralEntityID(generalEntityId);
//        Saving
        List<TxnGeneralEntity> generalEntityList= new ArrayList<TxnGeneralEntity>();
        generalEntityList.add(txnGeneralEntity);
        List<TxnGeneralEntityRecord> result = createGeneralEntityCUDao.saveEntities(generalEntityList,
                requestScopedAuthenticatedUserBean);
        return result.get(0);
    }

    public KmsConnectionDto getFromNslAtrributes(List<TxnNslAttribute> attributeList, boolean hide){
        KmsConnectionDto dto = new KmsConnectionDto();
        for (TxnNslAttribute attribute : attributeList){
            if (attribute.getValues()==null || attribute.getValues().isEmpty()){
                continue;
            }
            switch (attribute.getName()){
                case AppConstant.PASSWORD:
                    dto.setPassword(hide?null:attribute.getValues().get(0));
                    break;
                case KmsConstants.KMS_NAME:
                    dto.setName(attribute.getValues().get(0));
                    break;
                case KmsConstants.KMS_ALIAS:
                    dto.setAlias(attribute.getValues().get(0));
                    break;
                case KmsConstants.KMS_TYPE:
                    dto.setKmsType(KmsType.valueOf(attribute.getValues().get(0)));
                    break;
                case KmsConstants.KMS_AWSID:
                    dto.setAwsId(hide?null:attribute.getValues().get(0));
                    break;
                case KmsConstants.KMS_DSDURL:
                    dto.setDsdUrl(hide?null:attribute.getValues().get(0));
                    break;
                case KmsConstants.KMS_CREATETIME:
                    dto.setCreatedTime(attribute.getValues().get(0));
                    break;
                case KmsConstants.KMS_MODIFYTIME:
                    dto.setModifiedTime(attribute.getValues().get(0));
                    break;
                case KmsConstants.KMS_ISPRIVATE:
                    dto.setIsEncryptionKeyPrivate(attribute.getValues().get(0));
                    break;
                case KmsConstants.KMS_PROPERTIES:
                    Properties props = JacksonUtils.fromJson(attribute.getValues().get(0), Properties.class);
                    Properties temp = new Properties();
                    if (hide){
                        filterProperties(props,temp);
                        temp = temp.isEmpty()?null:temp;
                    }
                    dto.setProperties(hide?temp:props);
                    if (props.containsKey(KmsConstants.KMS_ENCRYPTIONKEYTYPE)){
                        dto.setEncryptionKeyType(props.getProperty(KmsConstants.KMS_ENCRYPTIONKEYTYPE));
                    }
                    break;
            }
        }
        return dto;
    }

    public List<TxnGeneralEntityRecord> getTotalRecords(String configEntityName) throws NSLException {
        GeneralEntity generalEntity = generalEntityDao.findByName(configEntityName,requestScopedAuthenticatedUserBean);
        if (generalEntity==null){
            throw new NSLException(ExceptionCategory.GENERAL_ENTITY,messageSource.getMessage("Paas_Adapter_44", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER);
        }
        TxnGeneralEntitySearchRequest dto1= new TxnGeneralEntitySearchRequest();
        dto1.setGeneralEntity(generalEntity);
        List<TxnGeneralEntitySearchRequest> generalEntityList = new ArrayList<>();
        generalEntityList.add(dto1);
        return searchCUDAO.getEntities(generalEntityList,requestScopedAuthenticatedUserBean);
    }

    public List<KeyManagerDto> getFilteredAll(List<TxnGeneralEntityRecord> resultList) {
     List<KeyManagerDto> data = new ArrayList<>();
     for (TxnGeneralEntityRecord record : resultList){
         checkFilter(record, data);
     }
     return data;
    }

    public void checkFilter(TxnGeneralEntityRecord record, List<KeyManagerDto> data){
        KeyManagerDto dto = new KeyManagerDto();
        Map<String,String> metaData = new HashMap<>();
        for (TxnNslAttribute attribute : record.getTxnNslAttribute()) {
            if (attribute.getValues()==null || attribute.getValues().isEmpty()){
                continue;
            }
            switch (attribute.getName()) {
                case KmsConstants.KMS_NAME:
                    dto.setName(attribute.getValues().get(0));
                    break;
                case KmsConstants.KMS_ALIAS:
                    dto.setAlias(attribute.getValues().get(0));
                    break;
                case KmsConstants.KMS_TYPE:
                    dto.setKmsType(KmsType.valueOf(attribute.getValues().get(0)));
                    break;
                case KmsConstants.KMS_ISPRIVATE:
                    dto.setEncryptionKeyPrivate(attribute.getValues().get(0).equals("true"));
                    break;
                case KmsConstants.KMS_PROPERTIES:
                    Properties props = JacksonUtils.fromJson(attribute.getValues().get(0),Properties.class);
                    filterProperties(props,metaData);
                    if (props.containsKey(KmsConstants.KMS_ENCRYPTIONKEYTYPE)){
                        dto.setEncryptionKeyType(props.getProperty(KmsConstants.KMS_ENCRYPTIONKEYTYPE));
                    }
                    break;
                default:
                    break;
            }
        }
        metaData.put("attributeId",String.valueOf(record.getId()));
        dto.setMetadata(metaData);
        data.add(dto);
    }


    public boolean checkExtensions(String nameOne, String nameTwo){
        nameOne = StringUtils.getFilenameExtension(nameOne);
        nameTwo = StringUtils.getFilenameExtension(nameTwo);
        if (nameTwo==null || nameOne==null) return false;
        return nameOne.equalsIgnoreCase(nameTwo);
    }

    private void filterProperties(Properties properties, Map<String,String> props){
        List<String> list = Arrays.asList(KmsConstants.KMS_EXPIRYTIME, KmsConstants.KMS_ENCRYPTIONKEYTYPE,
                KmsConstants.KMS_FILE_EXTENSION);
        for (String name : list){
            if (properties.containsKey(name)){
                props.put(name,(String) properties.get(name));
            }
        }
    }

    private void filterProperties(Properties properties, Properties props){
        List<String> list = Arrays.asList(KmsConstants.KMS_EXPIRYTIME, KmsConstants.KMS_ENCRYPTIONKEYTYPE,
                KmsConstants.KMS_FILE_EXTENSION);
        for (String name : list){
            if (properties.containsKey(name)){
                props.put(name,(String) properties.get(name));
            }
        }
    }


}
