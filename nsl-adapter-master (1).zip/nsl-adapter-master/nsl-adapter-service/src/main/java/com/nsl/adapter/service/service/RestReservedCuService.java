package com.nsl.adapter.service.service;

import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.service.rest.service.ConnectionToGeneral;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.HTTPUtil;
import com.nsl.logical.config.AuthenticatedUserDetails;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import java.util.Locale;

import static com.nsl.adapter.service.utils.AppConstant.BASE_URL;
import static com.nsl.adapter.service.utils.AppConstant.SSL_ENABLED;

@Service
public class RestReservedCuService {
    private static final Logger LOGGER = LoggerFactory.getLogger(RestReservedCuService.class);

    @Autowired
    HTTPUtil httpUtil;

    @Autowired
    ConnectionToGeneral connectionService;

    @Autowired
    private MessageSource messageSource;

    @Value("${rest.nslapi.url.prefix}")
    String nslApiUrlPrefix;

    public TxnData reservedCUService(TriggerCU triggerCu, TxnData transData, AuthenticatedUserDetails authenticatedUserDetails) throws JSONException, NSLException {

        LOGGER.info("||||||||||||||||||||||| reservedcuservice method initiated |||||||||||||||||||||||");

        String serviceName = triggerCu.getReservedCUType().split("\\:")[1];
        LOGGER.info("Reserved cu call received for {}", serviceName);

        Long connectionId = null;
        try {
            connectionId = Long.valueOf(triggerCu.getCuSystemProperties().get(AppConstant.CONFIG_ENTITY_RECORD_ID));
        }catch (Exception e){
            LOGGER.warn("Exception while getting connection id for rest. Continuing without connection.", e);
        }

        return processExternalApi(transData, connectionService.getEntityRecordrest(connectionId), triggerCu, authenticatedUserDetails);

    }

    private TxnData processExternalApi(TxnData transData, RESTAdapterConnectionDto restConnectionDto,
                                     TriggerCU triggerCU, AuthenticatedUserDetails userDetails) throws NSLException {

        loadAttributesToMap(restConnectionDto, triggerCU);

        try {
            return httpUtil.fireRequest(transData, restConnectionDto, triggerCU);
        }catch (NSLException e){
            throw e;
        }catch (Exception e){
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.BASIC_CU, messageSource.getMessage("Paas_Adapter_90", null, Locale.ENGLISH) + e.getMessage(), ExceptionSeverity.CRITICAL, e);
        }
    }
    private void loadAttributesToMap(RESTAdapterConnectionDto restConnectionDto, TriggerCU triggerCU) {

        if(restConnectionDto != null ) {
            triggerCU.getCuSystemProperties().put(BASE_URL, restConnectionDto.getBaseUrl());
            if (restConnectionDto.getAdvancedConfig()!=null && restConnectionDto.getAdvancedConfig().containsKey(SSL_ENABLED)){
                triggerCU.getCuSystemProperties().put(SSL_ENABLED,restConnectionDto.getAdvancedConfig().getProperty(SSL_ENABLED));
            }else{
                triggerCU.getCuSystemProperties().put(SSL_ENABLED,Boolean.FALSE.toString().toUpperCase(Locale.ROOT));
            }
        }

    }
}
