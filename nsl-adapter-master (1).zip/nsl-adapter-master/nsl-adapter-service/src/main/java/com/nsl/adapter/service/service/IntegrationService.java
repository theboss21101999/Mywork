package com.nsl.adapter.service.service;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.dsd.store.models.tenant.io.TenantSlotItemInput;
import com.nsl.logical.exception.NSLException;

import java.util.ArrayList;
import java.util.List;


public interface IntegrationService {


    CUPropsDto getSaveProperties(IntegrationDtoV3 integrationDto) throws NSLException;

    void getIntegration(IntegrationDtoV3 integrationDto, CUPropsDto cuPropsDto);

    CUPropsDto getUpdateProperties(CUPropsDto cuPropsDto, IntegrationDtoV3 integrationDto) throws NSLException;

    default List<TenantSlotItemInput> buildSlotItems(List<TenantCUEntityInput> entities){

        List<TenantSlotItemInput> slotItemInputs = new ArrayList<>();
        entities.forEach(x-> {
            TenantSlotItemInput slotItemInput = new TenantSlotItemInput();
            slotItemInput.setItem(x);
            slotItemInputs.add(slotItemInput);
        });
        return slotItemInputs;
    }

    default List<TenantCUEntityInput> getParticipatingItems(List<TenantSlotItemInput> entities){

        List<TenantCUEntityInput> participatingItems = new ArrayList<>();
        entities.forEach(x-> participatingItems.add((TenantCUEntityInput) x.getItem()));
        return participatingItems;
    }
}
