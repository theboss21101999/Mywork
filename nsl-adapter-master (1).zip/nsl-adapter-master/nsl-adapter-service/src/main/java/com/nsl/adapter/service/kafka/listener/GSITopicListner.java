package com.nsl.adapter.service.kafka.listener;

import com.nsl.adapter.service.kafka.service.KafkaService;
import com.nsl.adapter.service.kafka.serviceImpl.InboundKafkaService;
import com.nsl.adapter.service.kafka.utils.InboundKafkaUtil;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.model.GSI;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;
import java.util.Map;


@Service
@ConditionalOnProperty(
        value = "kafka.pipeline.enabled",
        havingValue = "true",
        matchIfMissing = false
)
public class GSITopicListner<V> {

    private static final Logger LOGGER = LoggerFactory.getLogger(GSITopicListner.class);

    @Autowired
    @Qualifier("sftpInboundGSIKafkaServiceImpl")
    private KafkaService kafkaService;

    @Autowired
    InboundKafkaService inboundKafkaService;

    @KafkaListener(topics = "${kafka.topic.adapters.gsi.response}",
            groupId = "${kafka.topic.adapters.gsi.response.group.id}",
            containerFactory = "adapterGsiContainerFactory")
    public void receiveNotifications(V v, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
                                     @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
                                     @Header(KafkaHeaders.OFFSET) int offset,
                                     @Header(KafkaHeaders.ACKNOWLEDGMENT) Acknowledgment acknowledgment) {
        try {

            ConsumerRecord<?, ?> consumerRecord = ((ConsumerRecord) v);

            Map<Object, Object> map = JacksonUtils.getObjectFromJsonString(consumerRecord.value().toString(), Map.class);
            GSI gsi = JacksonUtils.getObjectFromJsonString(JacksonUtils.toJson(map.get("data")), GSI.class);

            if (InboundKafkaUtil.inboundKafkaGSI(gsi) != null)
                inboundKafkaService.processGSIMessage(map, gsi);
            else
                kafkaService.processKafkaMessage(consumerRecord);
        }catch (Exception e){
            LOGGER.info("Error while listening to the message {}", e.getMessage() );
        }finally {
            acknowledgment.acknowledge();
        }
    }
}
