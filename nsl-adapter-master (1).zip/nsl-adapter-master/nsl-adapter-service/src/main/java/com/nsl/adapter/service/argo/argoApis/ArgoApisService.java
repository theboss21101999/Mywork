package com.nsl.adapter.service.argo.argoApis;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.HashMap;
import java.util.Comparator;

import static com.nsl.common.constant.AppConstant.FAILED;
import static com.nsl.common.constant.AppConstant.SUCCESS;

@Service
public class ArgoApisService {
    @Autowired
    RestTemplate restTemplate;
    @Autowired
    AdaptorProperties adaptorProperties;
    ObjectMapper mapper = new ObjectMapper();
    private static final Logger LOGGER = LoggerFactory.getLogger(ArgoApisService.class);

    //the below datafix code is for only internal use , to give data fix for argo schedular.

//    public ApiResponse argoWorkFlowDataFixMethod(String env) {
//        try {
//            HttpHeaders headers = new HttpHeaders();
//            headers.setContentType(MediaType.APPLICATION_JSON);
//            headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
//            HttpEntity<?> entity = new HttpEntity<>(headers);
//            String url = "https://argoworkflow-" + env + ".nslhub.com/api/v1/cron-workflows/argo-workflows?";
//            ResponseEntity<JsonNode> response = restTemplate.exchange(url,
//                    HttpMethod.GET, entity, JsonNode.class);
//            LOGGER.info("data before datafix : {}", response);
//            JsonNode schedulars = mapper.readTree(response.getBody().get("items").traverse());
//            for (int i = 0; i < schedulars.size(); i++) {
//                JsonNode schedular = schedulars.get(i);
//                JsonNode parameters = schedular.get("spec").get("workflowSpec").get("arguments").get("parameters");
//                JsonObject labels = g.fromJson(schedular.get("metadata").get("labels").toString(), JsonObject.class);
//                JsonObject metadata_new = g.fromJson(schedular.get("metadata").toString(), JsonObject.class);
//                JsonObject new_schedular = g.fromJson(schedular.toString(), JsonObject.class);
//                JsonObject cronWorkflow = new JsonObject();
//                if (!labels.has("cuName_search")) {
//                    labels.addProperty("cuName_search", (String) null);
//                }
//                if (!labels.has("adapter_search")) {
//                    labels.addProperty("adapter_search", (String) null);
//                }
//                for (int j = 0; j < parameters.size(); j++) {
//                    if (Objects.equals(parameters.get(j).get("name").asText(), "cu-name")) {
//                        String cuname = parameters.get(j).get("value").asText();
//                        labels.addProperty("cuName_search", cuname.replaceAll(" ", "-")); //label cant have empty spaces
//                    }
//                    if (Objects.equals(parameters.get(j).get("name").asText(), "adapter")) {
//                        String adapter = parameters.get(j).get("value").asText();
//                        labels.addProperty("adapter_search", adapter);
//                    }
//                    if (Objects.equals(parameters.get(j).get("name").asText(), "tenantId") && (!labels.has(parameters.get(j).get("value").asText()))) {
//                        String tenant_id = parameters.get(j).get("value").asText();
//                        labels.addProperty(tenant_id, "true");
//                    }
//                }
//                metadata_new.add("labels", labels);
//                new_schedular.add("metadata", metadata_new);
//                cronWorkflow.add("cronWorkflow", new_schedular);
//                //post request
//                HttpHeaders headers1 = new HttpHeaders();
//                headers1.setContentType(MediaType.APPLICATION_JSON);
//                headers1.add("Accept", MediaType.APPLICATION_JSON_VALUE);
//                HttpEntity<String> entity1 = new HttpEntity<String>(cronWorkflow.toString(), headers1);
//                String url1 = "https://argoworkflow-" + env + ".nslhub.com/api/v1/cron-workflows/argo-workflows/" + metadata_new.get("name");
//                ResponseEntity<JsonNode> response1 = restTemplate.exchange(url1,
//                        HttpMethod.PUT, entity1, JsonNode.class);
//                LOGGER.info("datafix for : {} schedular is successful", i);
//            }
//            HttpHeaders headers2 = new HttpHeaders();
//            headers2.setContentType(MediaType.APPLICATION_JSON);
//            headers2.add("Accept", MediaType.APPLICATION_JSON_VALUE);
//            HttpEntity<?> entity2 = new HttpEntity<>(headers2);
//            String url2 = "https://argoworkflow-" + env + ".nslhub.com/api/v1/cron-workflows/argo-workflows?";
//            ResponseEntity<JsonNode> response2 = restTemplate.exchange(url,
//                    HttpMethod.GET, entity, JsonNode.class);
//            LOGGER.info("data after datafix : {}", response2);
//            return new ApiResponse(HttpStatus.OK, SUCCESS, response2);
//        } catch (Exception e) {
//            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, FAILED, e.getMessage());
//
//        }
//
//    }

    public ApiResponse fetch(int pageNumber, int pageSize, String adapter_search, String cuName_search,String jobName, AuthenticatedUserDetailsImpl authenticatedUserDetails) {
        try {
            HttpHeaders headers = new HttpHeaders();

            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
            HttpEntity<?> entity = new HttpEntity<>(headers);

            if(jobName!=null){
                LOGGER.info("Single Scheduler fetch Api call");
                String url1=adaptorProperties.getArgoSchedulerUrl()+"/"+jobName;
                ResponseEntity<JsonNode> response = restTemplate.exchange(url1,
                        HttpMethod.GET, entity, JsonNode.class);
                LOGGER.info("fetched Successfully");
                HashMap<String,Object> output=new HashMap<>();
                ObjectNode Output_response= JacksonUtils.fromJson(Objects.requireNonNull(response.getBody()).toString(),ObjectNode.class);
                output.put("value",Output_response);
                output.put("count",1);
                return new ApiResponse(HttpStatus.OK, SUCCESS, output);
            }
            else {
                LOGGER.info("List of Scheduler fetch Api call");
                String baseURL = adaptorProperties.getArgoSchedulerUrl()+"?listOptions.labelSelector=" + authenticatedUserDetails.getTenantId() + "=true";
                if (adapter_search != null) {
                    adapter_search = adapter_search.toUpperCase(Locale.ROOT);
                    baseURL += ",adapter_search=" + adapter_search;
                }
                if (cuName_search != null) {
                    baseURL += ",cuName_search=" + cuName_search;
                }
                String url2 = baseURL;
                ResponseEntity<JsonNode> response = restTemplate.exchange(url2,
                        HttpMethod.GET, entity, JsonNode.class);
                LOGGER.info("fetched Successfully");
                JsonNode schedulars = mapper.readTree(response.getBody().get("items").traverse()); //NOSONAR
                List<ObjectNode> pageData = new ArrayList<>();
                int totalItems = schedulars.size();
                int totalPages = (int) Math.ceil((double) totalItems / pageSize);
                if (pageNumber <= totalPages) {
                    int startIndex = (pageNumber - 1) * pageSize;
                    int endIndex = Math.min(startIndex + pageSize, totalItems);

                    for (int i = startIndex; i < endIndex; i++) {
                        pageData.add(JacksonUtils.fromJson(schedulars.get(i).toString(), ObjectNode.class));
                    }
                }
                pageData.sort(Comparator.comparing(o -> o.get("metadata").get("creationTimestamp").asText(), Comparator.reverseOrder()));
                HashMap<String,Object> output=new HashMap<>();
                output.put("value",pageData);
                output.put("count",totalItems);
                return new ApiResponse(HttpStatus.OK, SUCCESS, output);
            }

        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, FAILED, e.getMessage());
        }
    }
    public ApiResponse suspend(String jobName) {
        try {
            LOGGER.info("suspend Api call");
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
            HttpEntity<?> entity = new HttpEntity<>(headers);
            String url = adaptorProperties.getArgoSchedulerUrl()+"/" +jobName+"/suspend";
            ResponseEntity<JsonNode> response = restTemplate.exchange(url,
                    HttpMethod.PUT, entity, JsonNode.class);
            LOGGER.info("suspending the scheduler is successful");
            ObjectNode Output_response=JacksonUtils.fromJson(Objects.requireNonNull(response.getBody()).toString(),ObjectNode.class);
            return new ApiResponse(HttpStatus.OK, SUCCESS, Output_response);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, FAILED, e.getMessage());
        }
    }
    public ApiResponse resume(String jobName) {
        try {
            LOGGER.info("resume api call ");
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
            HttpEntity<?> entity = new HttpEntity<>(headers);
            String url = adaptorProperties.getArgoSchedulerUrl()+"/" +jobName+"/resume";
            ResponseEntity<JsonNode> response = restTemplate.exchange(url,
                    HttpMethod.PUT, entity, JsonNode.class);
            LOGGER.info("resume api call is successful");
            ObjectNode Output_response=JacksonUtils.fromJson(Objects.requireNonNull(response.getBody()).toString(),ObjectNode.class);
            return new ApiResponse(HttpStatus.OK, SUCCESS, Output_response);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, FAILED, e.getMessage());
        }
    }
    public ApiResponse delete(String jobName) {
        try {
            LOGGER.info("delete api call ");
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
            HttpEntity<?> entity = new HttpEntity<>(headers);
            String url = adaptorProperties.getArgoSchedulerUrl()+"/" +jobName;
            ResponseEntity<JsonNode> response = restTemplate.exchange(url,
                    HttpMethod.DELETE, entity, JsonNode.class);
            LOGGER.info("delete api call is successful");
            return new ApiResponse(HttpStatus.OK, SUCCESS, "deleted the Job");
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, FAILED, e.getMessage());
        }
    }
}

