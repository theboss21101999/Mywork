package com.nsl.adapter.service.db.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.dto.connections.DBConnectionDto;
import com.nsl.adapter.commons.dto.connections.MetaInfoEntityDto;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.commons.utils.entity.TxnDataUtils;
import com.nsl.adapter.service.db.enums.DBType;
import com.nsl.adapter.commons.service.GsiExecutor;
import com.nsl.adapter.service.sftp.connection.AuthenticateUser;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.model.ChangeUnit;
import com.nsl.logical.model.GSI;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Service
public class DBGsiInvokerUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(DBGsiInvokerUtil.class);

    @Autowired
    AuthenticateUser authenticateUser;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Autowired
    TxnDataUtils txnDataUtils;

    @Autowired
    GsiExecutor gsiExecutor;

    @Autowired
    DBConnectionService dbConnectionService;

    @Autowired
    DBAdapterFactory dbAdapterFactory;

    @Async("DBGsiInvokerUtilExecutor")
    public void invokeGsi(Long gsiMasterId, Map<String, String> msg, ChangeUnit cu, AuthenticatedUserDetailsImpl authBean) {
        String tenantId = msg.get(AppConstant.TENANTID);
        String userEmail = msg.get(AppConstant.USEREMAIL);
        String fileName = msg.get(AppConstant.FILENAME);
        LOGGER.debug("Fetching GSI..");
        GSI gsiMaster = changeUnitDao.getGsiByMasterId(gsiMasterId, null, StatusEnum.PUBLISHED,authBean);
        Long gsiId = gsiMaster.getId();
        LOGGER.debug("GSI with master id {} fetched successfully..", gsiMaster.getName());
        GSI gsi = changeUnitDao.getGSI(gsiId,authBean);
        TriggerCU triggerCu = gsi.getSolutionLogic().get(0);
        GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, AppConstant.TRIGGER_CES_LAYER);
        Map<String, String> cuSystemProps = getModifiedCuSystemProp(cu.getCuSystemProperties(),
                                                                            msg.get(AppConstant.CUNAME), fileName);
        String metaInfoEntityName = cuSystemProps.get(AppConstant.METAINFO_ENTITY_KEY);
        LOGGER.debug("Fetching meta info entity having name {}", metaInfoEntityName);
        MetaInfoEntityDto metaInfoEntity = metaInfoEntityUtils.getMetaInfoEntityDto(metaInfoEntityName ,authBean);
        Long connectionId = Long.valueOf(cuSystemProps.get(AppConstant.CONFIG_ENTITY_RECORD_ID));
        DBConnectionDto dbConnectionDto =dbConnectionService.getDBConnection(connectionId, authBean);
        DBType dbType = null;
        if (dbConnectionDto.getDataSourceDriver().contains(AppConstant.POSTGRES_DRIVER)) {
            dbType = DBType.POSTGRES;
        } else if (dbConnectionDto.getDataSourceDriver().contains(AppConstant.MYSQL_DRIVER)) {
            dbType = DBType.MYSQL;
        }
        String tableName = triggerCu.getCuSystemProperties().get("tableName");
        String timeStampcol=getTimeStampColName(dbConnectionDto,tableName);
        List<Long> timeStamps = getTimeStamps(dbConnectionDto, metaInfoEntity ,authBean,tableName,timeStampcol);
        String query = null;
        if (dbType == DBType.POSTGRES) {
            query = "SELECT * FROM " + tableName + " where  extract(epoch from "+timeStampcol+") between " + timeStamps.get(0) + " and " + timeStamps.get(1);
        } else if (dbType == DBType.MYSQL) {
            query = "SELECT * FROM " + tableName + " where UNIX_TIMESTAMP("+timeStampcol+") between " + timeStamps.get(0) + " and " + timeStamps.get(1);
        }
        DBOperations dbOperations = dbAdapterFactory.getDBAdapter(dbType); //NOSONAR
        JsonNode jsonNode = dbOperations.getJsonNode(dbConnectionDto, query);
        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, jsonNode);
        TxnData transData = txnDataUtils.setChangeDriverInTxnData(txnGeneralEntity, LayerType.PHYSICAL);
        List<TxnData> txnDatas = Collections.singletonList(transData);
        for (TxnData txnData : txnDatas) {
            gsiExecutor.executeGsi(gsiId, tenantId, userEmail, txnData);
        }

    }

    public List<Long> getTimeStamps(DBConnectionDto connectionDto, MetaInfoEntityDto metaInfoEntity, AuthenticatedUserDetailsImpl authBean,
                                    String tableName, String timeStampcol) {
        Integer cutoffTimeStamp = 0;
        int nearestTime = 0;

        Long lastRunTime = metaInfoEntity.getLastRunStartTime();
        if (lastRunTime != null )
            cutoffTimeStamp = Math.toIntExact(lastRunTime);
        String query = null;
        if (connectionDto.getDataSourceDriver().contains(AppConstant.POSTGRES_DRIVER)) {
            query = "select "+timeStampcol+" from "+tableName+" where extract(epoch from "+timeStampcol+")>'" + cutoffTimeStamp + "'";
        } else if (connectionDto.getDataSourceDriver().contains(AppConstant.MYSQL_DRIVER)) {
            query = "select "+timeStampcol+" from "+tableName+" where UNIX_TIMESTAMP("+timeStampcol+")>'" + cutoffTimeStamp + "'";
        }
        Connection con = null;
        Statement st = null;
        try {
            Class.forName(connectionDto.getDataSourceDriver());
            con = DriverManager.getConnection(connectionDto.getDataSourceUrl(),
                    connectionDto.getUsername(), connectionDto.getPassword());
            st = con.createStatement();
            ResultSet rs = st.executeQuery(query); //NOSONAR
            while (rs.next()) {
                if (nearestTime < getTimeStamp(rs.getTimestamp(1)))
                    nearestTime = Math.toIntExact(getTimeStamp(rs.getTimestamp(1)));
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                assert st != null;   //NOSONAR
                st.close();
            } catch (Exception ignored) {
                LOGGER.error(ignored.toString());
            }
            try {
                con.close();
            } catch (Exception ignored) {
                LOGGER.error(ignored.toString());
            }
        }
        List<Long> res = new ArrayList();
        res.add(Long.valueOf(cutoffTimeStamp + 19800L));
        Long r = (long) nearestTime + 19801;
        res.add(r);
        cutoffTimeStamp = nearestTime+1;

        metaInfoEntity.setLastRunStartTime(Long.valueOf(cutoffTimeStamp));
        metaInfoEntityUtils.updateMetaInfoEntity(metaInfoEntity ,authBean);
        return res;

    }

    private Long getTimeStamp(Timestamp date) {
        return date.getTime() / 1000L;

    }


    private static Map<String, String> getModifiedCuSystemProp(Map<String, String> cuSystemProp,
                                                               String cuName, String fileName) {
        cuSystemProp.put(AppConstant.FILENAME, fileName);
        cuSystemProp.put(AppConstant.DSD_LOCATION, getDSDLocation(cuName));
        return cuSystemProp;
    }


    private static String getDSDLocation(String cuName) {
        String date = LocalDate.now().toString();
        return cuName + "," + date;
    }

    public String getTimeStampColName(DBConnectionDto connectionDto, String tableName) {
        Connection con = null;
        Statement statement = null;
        try {
            Class.forName(connectionDto.getDataSourceDriver());
            con = DriverManager.getConnection(connectionDto.getDataSourceUrl(),
                    connectionDto.getUsername(), connectionDto.getPassword());
            Statement st = con.createStatement();
            String query="select * from "+tableName;
            ResultSet rs = st.executeQuery(query); //NOSONAR
            ResultSetMetaData md = rs.getMetaData();
            int col = md.getColumnCount();
            while (rs.next()) {
                for (int i = 1; i <= col; i++) {
                    if (md.getColumnTypeName(i).equalsIgnoreCase("timestamp"))
                       return md.getColumnName(i);
                }
            }
            return null;
        } catch (SQLException | ClassNotFoundException ignored) {
            System.out.println(ignored);
        } finally {
            try {
                assert statement != null;   //NOSONAR
                statement.close();
            } catch (Exception ignored) {
                LOGGER.error(ignored.toString());
            }
            try {
                con.close();
            } catch (Exception ignored) {
                LOGGER.error(ignored.toString());
            }
        }
        return null;
    }

}
