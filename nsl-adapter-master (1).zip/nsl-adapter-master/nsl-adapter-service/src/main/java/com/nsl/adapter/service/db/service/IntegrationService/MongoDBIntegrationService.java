package com.nsl.adapter.service.db.service.IntegrationService;
import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.service.service.IntegrationService;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static com.nsl.adapter.service.utils.AppConstant.MONGODB_DELETE;
import static com.nsl.adapter.service.utils.AppConstant.MONGODB_INSERT;
import static com.nsl.adapter.service.utils.AppConstant.MONGODB_UPDATE;
import static com.nsl.adapter.service.utils.AppConstant.MONGODB_READ;
import static com.nsl.adapter.service.v2.utills.EntityConstants.NSL_MONGODB_INSERT_REQ;
import static com.nsl.adapter.service.v2.utills.EntityConstants.NSL_MONGODB_INSERT_RES;
import static com.nsl.adapter.service.v2.utills.EntityConstants.NSL_MONGODB_DELETE_REQ;
import static com.nsl.adapter.service.v2.utills.EntityConstants.NSL_MONGODB_DELETE_RES;
import static com.nsl.adapter.service.v2.utills.EntityConstants.NSL_MONGODB_READ_REQ;
import static com.nsl.adapter.service.v2.utills.EntityConstants.NSL_MONGODB_UPDATE_REQ;
import static com.nsl.adapter.service.v2.utills.EntityConstants.NSL_MONGODB_UPDATE_RES;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class MongoDBIntegrationService implements IntegrationService {
    @Autowired
    SaveBetsService saveBetsService;
    @Override
    public CUPropsDto getSaveProperties(IntegrationDtoV3 integrationDto) throws NSLException {
        if (!validate(integrationDto.getOperation()))
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"please send valid data", ExceptionSeverity.MAJOR);
        CUPropsDto cuPropsDto = new CUPropsDto();
        HashMap<String, String> cuSystemProps = new HashMap<>(integrationDto.getPropertiesMap());
        if (MONGODB_INSERT.equalsIgnoreCase(integrationDto.getOperation())){
            cuPropsDto = newEntitiesForINSERTMethod(integrationDto);
        }
        else if(MONGODB_UPDATE.equalsIgnoreCase(integrationDto.getOperation())){
            cuPropsDto=newEntitiesForUPDATEMethod(integrationDto);
        }
        else if(MONGODB_DELETE.equalsIgnoreCase(integrationDto.getOperation())){
            cuPropsDto=newEntitiesForDELETEMethod(integrationDto);
        }
        else if(MONGODB_READ.equalsIgnoreCase(integrationDto.getOperation())){
            cuPropsDto=newEntitiesForREADMethod(integrationDto);
        }
        cuPropsDto.setCuSystemProps(cuSystemProps);
        cuPropsDto.setIsMachineCU(Boolean.FALSE);
        return cuPropsDto;

    }

    private CUPropsDto newEntitiesForREADMethod(IntegrationDtoV3 integrationDto) {
        CUPropsDto cuPropsDto=new CUPropsDto();
        TenantCUEntityInput phyEntity1=saveBetsService.getEntityByName(NSL_MONGODB_READ_REQ);
        TenantCUEntityInput triggerCESEntity1 = saveBetsService.findEntityById(integrationDto.getOutputEntityDsdId());
        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Collections.singletonList(phyEntity1)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(triggerCESEntity1)));
        return cuPropsDto;
    }

    private CUPropsDto newEntitiesForDELETEMethod(IntegrationDtoV3 integrationDto) {
        CUPropsDto cuPropsDto = new CUPropsDto();
        TenantCUEntityInput phyEntity1 = saveBetsService.getEntityByName(NSL_MONGODB_DELETE_REQ);
        TenantCUEntityInput triggerCESEntity1 = saveBetsService.getEntityByName(NSL_MONGODB_DELETE_RES);
        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Collections.singletonList(phyEntity1)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(triggerCESEntity1)));
        return cuPropsDto;
    }

    private CUPropsDto newEntitiesForUPDATEMethod(IntegrationDtoV3 integrationDto) {
        CUPropsDto cuPropsDto = new CUPropsDto();
        TenantCUEntityInput phyEntity1 = saveBetsService.getEntityByName(NSL_MONGODB_UPDATE_REQ);
        TenantCUEntityInput phyEntity2 = saveBetsService.findEntityById(integrationDto.getInputEntityDsdId());
        TenantCUEntityInput triggerCESEntity1 = saveBetsService.getEntityByName(NSL_MONGODB_UPDATE_RES);
        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Arrays.asList(phyEntity1,phyEntity2)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(triggerCESEntity1)));
        return cuPropsDto;
    }

    private CUPropsDto newEntitiesForINSERTMethod(IntegrationDtoV3 integrationDto) {
        CUPropsDto cuPropsDto = new CUPropsDto();
        TenantCUEntityInput phyEntity1 = saveBetsService.getEntityByName(NSL_MONGODB_INSERT_REQ);
        TenantCUEntityInput phyEntity2 = saveBetsService.findEntityById(integrationDto.getInputEntityDsdId());
        TenantCUEntityInput triggerCESEntity1 = saveBetsService.getEntityByName(NSL_MONGODB_INSERT_RES);
        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Arrays.asList(phyEntity1,phyEntity2)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(triggerCESEntity1)));
        return cuPropsDto;
    }

    @Override
    public void getIntegration(IntegrationDtoV3 integrationDto, CUPropsDto cuPropsDto) {
        if (MONGODB_INSERT.equalsIgnoreCase(integrationDto.getOperation())){
            integrationDto.setInputEntityDsdId(getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).get(1).getDsdId());
        }
        else if(MONGODB_UPDATE.equalsIgnoreCase(integrationDto.getOperation())){
            integrationDto.setInputEntityDsdId(getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).get(1).getDsdId());
        }
        else if(MONGODB_READ.equalsIgnoreCase(integrationDto.getOperation())){
            integrationDto.setOutputEntityDsdId(getParticipatingItems(cuPropsDto.getTriggerCESLayerItems()).get(0).getDsdId());
        }
    }

    @Override
    public CUPropsDto getUpdateProperties(CUPropsDto cuPropsDto, IntegrationDtoV3 integrationDto) throws NSLException {
        CUPropsDto newcuPropsDto =new CUPropsDto();
        if (MONGODB_INSERT.equalsIgnoreCase(integrationDto.getOperation())){
            newcuPropsDto = newEntitiesForINSERTMethod(integrationDto);
        }
        else if(MONGODB_UPDATE.equalsIgnoreCase(integrationDto.getOperation())){
            newcuPropsDto=newEntitiesForUPDATEMethod(integrationDto);
        }
        else if(MONGODB_DELETE.equalsIgnoreCase(integrationDto.getOperation())){
            newcuPropsDto=newEntitiesForDELETEMethod(integrationDto);
        }
        else if(MONGODB_READ.equalsIgnoreCase(integrationDto.getOperation())){
            newcuPropsDto=newEntitiesForREADMethod(integrationDto);
        }
        Map<String, String> cuSystemProps = cuPropsDto.getCuSystemProps();
        cuSystemProps.putAll(integrationDto.getPropertiesMap());
        newcuPropsDto.setCuSystemProps(cuSystemProps);
        return newcuPropsDto;
    }
    private static boolean validate(String operation) {
        return operation != null;
    }

}

