package com.nsl.adapter.service.sftp.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.SFTPAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.SFTPCredential;
import com.nsl.adapter.commons.dto.connections.SFTPCredentialType;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.sftp.connection.SFTPConnectionFactory;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.Locale;

@Service
public class SFTPConnectionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SFTPConnectionService.class);

    private static final ConnectionDtoType connType = ConnectionDtoType.SFTP;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    MessageSource messageSource;

    @Autowired
    SFTPConnectionFactory sftpConnectionFactory;

    public TxnAdapterConnection saveSftpConn(SFTPAdapterConnectionDto connectionDto) {

        if (connectionDto.getConnectionName() == null || connectionDto.getHost() == null ||
                connectionDto.getPort() == 0  || validateSftpCredentials(connectionDto.getAuthentication()))
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_186", null, Locale.ENGLISH) , null);
        connectionDataToolsV3.connectionCheck(ConnectionDtoType.SFTP, connectionDto.getConnectionName(), authBean);

        String password = connectionDto.getAuthentication().getPassword();
        if (password != null)
            password = connectionDataToolsV3.saveSecret(connType,"password",
                    connectionDto.getConnectionName(), authBean.getTenantId(), password);
        connectionDto.getAuthentication().setPassword(password);

        TxnAdapterConnection connection = new TxnAdapterConnection();
        connection.setConnectionDtoType(connType);
        connection.setConnection(connectionDto);

        LOGGER.info("saving SFTP Dynamo connection");
        TxnAdapterConnection result =  adapterConnnectionsDao.saveConnection(connection,authBean );
        if (result == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_176", null, Locale.ENGLISH) , null);

        return result;
    }

    public TxnAdapterConnection updateSftpConn(SFTPAdapterConnectionDto connectionDto ,Long connId) {

        if (connectionDto.getConnectionName() == null || connectionDto.getHost() == null ||
                connectionDto.getPort() == 0  || validateSftpCredentials(connectionDto.getAuthentication()))
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_187", null, Locale.ENGLISH) , null);

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(connType,connId,authBean);

        String password = connectionDto.getAuthentication().getPassword();
        if (password != null && !password.startsWith(ConnectionDataToolsV3.prefix))
            password = connectionDataToolsV3.updateSecret(connType,"password",
                    connectionDto.getConnectionName(), authBean.getTenantId(), password);
        connectionDto.getAuthentication().setPassword(password);

        previousConnection.setConnection(connectionDto);

        LOGGER.info("Updating SFTP connection");
        TxnAdapterConnection result =  adapterConnnectionsDao.saveConnection(previousConnection,authBean);
        if (result == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_180", null, Locale.ENGLISH) , null);

        return result;
    }

    public SFTPAdapterConnectionDto getSftpConn(Long connId,Boolean hide) {

        TxnAdapterConnection entityRecord = adapterConnnectionsDao.getConnectionByRecordId(connType, connId ,authBean);
        return txnToSftp(entityRecord , hide);
    }

    public SFTPAdapterConnectionDto getSftpConn(Long connId, AuthenticatedUserDetailsImpl authBean) {

        TxnAdapterConnection entityRecord = adapterConnnectionsDao.getConnectionByRecordId(connType, connId,authBean);
        return txnToSftp(entityRecord , Boolean.FALSE);
    }

    public boolean validateSftpCredentials(SFTPCredential sftpCredential){

        if (sftpCredential.getType()==null || sftpCredential.getUsername()==null)
            return true;

        switch (sftpCredential.getType()){
            case PASSWORD:
                if (sftpCredential.getPassword()==null) return true;
                break;
            case KEY:
                if (sftpCredential.getSshKey()==null)  return true;
                break;
            case KEYPASSWORD:
                if (sftpCredential.getPassword() == null || sftpCredential.getSshKey() == null) return true;
            default:
                break;
        }
        return false;
    }

    public SFTPAdapterConnectionDto txnToSftp(TxnAdapterConnection entityRecord, Boolean hide) {
        if (entityRecord == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_189", null, Locale.ENGLISH)  , null);

        SFTPAdapterConnectionDto connectionDto = (SFTPAdapterConnectionDto) entityRecord.getConnection();
        if (connectionDto == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,  messageSource.getMessage("Paas_Adapter_83", null, Locale.ENGLISH), null);

        if (!hide)
            connectionDto.getAuthentication().setPassword(connectionDataToolsV3.getSecret(connectionDto.getAuthentication().getPassword()));
        return connectionDto;
    }


    public ApiResponse testConnection(SFTPAdapterConnectionDto connectionDto) {

        String password = connectionDto.getAuthentication().getPassword();
        if (password != null && password.startsWith(ConnectionDataToolsV3.prefix))
            connectionDto.getAuthentication().setPassword(connectionDataToolsV3.getSecret(password));

        return sftpConnectionFactory.testConnection(connectionDto);
    }
}