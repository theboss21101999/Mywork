package com.nsl.adapter.service.onedrive.service;

import com.nsl.adapter.commons.parsers.service.ParserFactoryV2;
import com.nsl.adapter.commons.parsers.service.ParserService;
import com.nsl.adapter.commons.parsers.service.ParserV2;
import com.nsl.adapter.service.graph.OauthGraphConnection;
import com.nsl.adapter.service.onedrive.serviceimpl.OnedriveService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.nsl.adapter.service.onedrive.utils.OnedriveConstants.ONEDRIVE_URL;

@Service
public class OnedriveGenericParser {

    private static final Logger LOGGER = LoggerFactory.getLogger(OnedriveGenericParser.class);

    @Autowired
    ParserFactoryV2 parserFactoryV2;

    @Autowired
    ParserService parserService;

    @Autowired
    OnedriveService onedriveService;

    @Autowired
    OauthGraphConnection oauthConnection;

    @Autowired
    RestTemplate restTemplate;


    public List<TxnData> onedriveinbound(GeneralEntity tcesGeneralEntity, Map<String, String> cuSystemProp,
                                         boolean isMultivalued, Map<String, String> cuSystemProps, AuthenticatedUserDetailsImpl authBean) throws NSLException {

        LOGGER.info("Starting Onedrive inbound Parsing");


        Long connectionId = Long.valueOf(cuSystemProp.get(AppConstant.CONFIG_ENTITY_RECORD_ID));
        String accessToken = oauthConnection.getAccessToken(connectionId);
        String uri;
        String fileKey = cuSystemProps.get(AppConstant.FILENAME);
        uri = ONEDRIVE_URL + fileKey + ":/content";
        String token = "Bearer " + accessToken;
        String name = new File(String.valueOf(fileKey)).getName();        //NOSONAR
        String fileType = onedriveService.getfileType(name, token);
        fileType = fileType.substring(1, fileType.length() - 1);
        if (fileType.equals("application/vnd.ms-excel"))
            fileType = "application/csv";
        fileType = fileType.split("/")[1];
        cuSystemProps.put(AppConstant.FILETYPE, fileType);

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.GET,
                new HttpEntity<Object>(headers), String.class);
        InputStream inputStream = null;
        if (response.getBody() != null) {
            String res = response.getBody().toString();     //NOSONAR
            inputStream = new ByteArrayInputStream(res.getBytes(StandardCharsets.UTF_8));
        }
        LOGGER.info("initializing inbound parsing :");
        ParserV2 parser = parserFactoryV2.getParser(fileType);
        List<TxnData> result = parser.inboundParser(inputStream, tcesGeneralEntity, isMultivalued,
                cuSystemProps, LayerType.PHYSICAL, authBean);
        String uploadToDsdResp = "";
        try {
            LOGGER.info("uploading to dsd");
            uploadToDsdResp = parserService.uploadToDsd(inputStream, cuSystemProp, authBean);
            LOGGER.info("uploaded to dsd {}", uploadToDsdResp);
        } catch (Exception e) {
            LOGGER.error("failed to upload a file to dsd ", e);
        }
        return result;

    }
}



