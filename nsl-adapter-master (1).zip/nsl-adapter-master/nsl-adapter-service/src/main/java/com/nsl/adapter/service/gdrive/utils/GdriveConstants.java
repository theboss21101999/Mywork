package com.nsl.adapter.service.gdrive.utils;

public final class GdriveConstants {

    public static final String VIEW_FILES = "VIEW_FILES";
    public static final String DELETE_FILE = "DELETE_FILE";
    public static final String GET_FILE = "GET_FILE";
    public static final String GET_ENTITY = "GET_ENTITY";
    public static final String UPLOAD_ENTITY = "UPLOAD_ENTITY";
    public static final String ID = "id";
    public static final String MIMETYPE = "mimeType";
    public static final String NAME = "name";
    public static final String WEB_CONTENT_LINK = "webContentLink";
    public static final String FILES_LIST = "NSL_File_Data";
    public static final String TEXT ="text/";
    public static final String GDRIVE_FOLDER = "application/vnd.google-apps.folder";

    private GdriveConstants(){
        throw new IllegalStateException("utility class");
    }
}
