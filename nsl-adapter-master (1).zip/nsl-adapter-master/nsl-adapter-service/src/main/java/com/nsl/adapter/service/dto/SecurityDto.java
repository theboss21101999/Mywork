package com.nsl.adapter.service.dto;

public class SecurityDto {
    private String serviceName;
    private String scope;
    private Credentials credentialDto;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public Credentials getCredentialDto() {
        return credentialDto;
    }

    public void setCredentialDto(Credentials credentialDto) {
        this.credentialDto = credentialDto;
    }

    public static class Credentials {
        private String username;
        private String password;
        private String apikey;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getApikey() {
            return apikey;
        }

        public void setApikey(String apikey) {
            this.apikey = apikey;
        }
    }
}
