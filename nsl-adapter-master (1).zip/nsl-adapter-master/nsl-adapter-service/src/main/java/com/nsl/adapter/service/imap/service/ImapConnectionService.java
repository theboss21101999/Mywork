package com.nsl.adapter.service.imap.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.GraphOauthConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.commons.dto.connections.ImapConnection;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.List;
import java.util.Locale;


@Service
public class ImapConnectionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ImapConnectionService.class);

    private static final ConnectionDtoType connType = ConnectionDtoType.IMAP;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnectionServiceV3 adapterConnectionServiceV3;


    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    MessageSource messageSource;

    public TxnAdapterConnection saveImapConnection(ImapConnection connectionDto) {

        if (connectionDto.getUsername() == null || connectionDto.getPassword() == null ||
                connectionDto.getHost() == null || connectionDto.getPort() == 0 ||
                connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_175", null, Locale.ENGLISH) , null);

        LOGGER.info("saving IMAP connection");
        connectionDto.setPassword(connectionDataToolsV3.saveSecret(connType,"password",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getPassword()));

        TxnAdapterConnection connection = new TxnAdapterConnection();
        connection.setConnection(connectionDto);
        connection.setConnectionDtoType(connType);

        LOGGER.info("saving IMAP connection");
        return adapterConnnectionsDao.saveConnection(connection ,authBean );
    }
    public ImapConnection getImapConnection(Long id, boolean hide){

        TxnAdapterConnection txnGeneralEntityRecord = adapterConnnectionsDao.getConnectionByRecordId(connType,id,authBean);
        return txnToImap(txnGeneralEntityRecord, hide);
    }

    public  TxnAdapterConnection updateImapConnection(ImapConnection connectionDto, Long connId) {

        if (connectionDto.getUsername() == null || connectionDto.getPassword() == null ||
                connectionDto.getHost() == null || connectionDto.getPort() == 0 ||
                connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_138", null, Locale.ENGLISH) , null);

        LOGGER.info("update IMAP connection");

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(connType, connId ,authBean);
        connectionDataToolsV3.connectionNameCheck(previousConnection,connectionDto.getConnectionName());

        connectionDto.setPassword(connectionDataToolsV3.updateSecret(connType,"password",
                connectionDto.getConnectionName(),authBean.getTenantId(),connectionDto.getPassword()));


        previousConnection.setConnection(connectionDto);

        return adapterConnnectionsDao.saveConnection(previousConnection, authBean );
    }
    public ImapConnection txnToImap(TxnAdapterConnection record, boolean hide) {


        ImapConnection connectionDto = (ImapConnection) record.getConnection();
        if (connectionDto == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,
                    messageSource.getMessage("Paas_Adapter_178", null, Locale.ENGLISH) , null);

        if (!hide){
            connectionDto.setPassword(connectionDataToolsV3.getSecret(connectionDto.getPassword()));
        }

        return connectionDto;
    }

    }




