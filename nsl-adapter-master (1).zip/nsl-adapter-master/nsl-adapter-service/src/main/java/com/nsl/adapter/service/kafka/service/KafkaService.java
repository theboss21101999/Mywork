package com.nsl.adapter.service.kafka.service;

import org.apache.kafka.clients.consumer.ConsumerRecord;

public interface KafkaService {

    void processKafkaMessage(ConsumerRecord<?, ?> consumerRecord);
}
