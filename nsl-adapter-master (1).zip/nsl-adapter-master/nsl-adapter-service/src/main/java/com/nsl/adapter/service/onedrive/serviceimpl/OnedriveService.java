package com.nsl.adapter.service.onedrive.serviceimpl;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.parsers.service.ParserFactoryV2;
import com.nsl.adapter.commons.parsers.service.ParserV2;
import com.nsl.adapter.service.graph.OauthGraphConnection;
import com.nsl.adapter.service.graph.service.GraphConnectionService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;

import static com.nsl.adapter.service.onedrive.utils.OnedriveConstants.ONEDRIVE_URL;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;


@Service
public class OnedriveService {

    private static final Logger LOGGER = LoggerFactory.getLogger(OnedriveService.class);

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    GraphConnectionService graphConnectionService;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authUser;

    @Autowired
    OauthGraphConnection oauthConnection;

    @Autowired
    ParserFactoryV2 parserFactoryV2;

    @Autowired
    private MessageSource messageSource;

    public String createObject(Long connectionId) throws NSLException {

        LOGGER.info("fetching Google Connection");

        String accessToken = null;
        try {
            //GraphOauthConnectionDto connectionDto = graphConnectionService.getGraphConnection(connectionId, false);



            return oauthConnection.getAccessToken(connectionId);

        } catch (Exception e) {
            LOGGER.error("failed to get accessToken");
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    messageSource.getMessage("Paas_Adapter_62", null, Locale.ENGLISH), ExceptionSeverity.BLOCKER);
        }

    }

    public String delete(RestTemplate restTemplate, String uri, HttpHeaders headers) {

        LOGGER.info("Performing Delete Operation...");
        try{
        ResponseEntity<JsonNode> response = restTemplate.exchange(uri, HttpMethod.DELETE,
                new HttpEntity<Object>(headers), JsonNode.class);
        return "{ \"response\" : \"Successfully deleted\" } ";
    } catch (Exception e) {
        LOGGER.error("Failed to delete");
        return "{ \"response\" : \"delete failed\" } ";
    }
}

    public TxnData getFile(GeneralEntity generalEntity, String fileKey, String accessToken,
                           Map<String, String> cuSystemProps, boolean isMultivalued) throws NSLException {
        String uri;
        try {
            uri = ONEDRIVE_URL + fileKey + ":/content";
            String token= "Bearer "+accessToken;
            String name=new File(String.valueOf(fileKey)).getName();        //NOSONAR
            String fileType = getfileType(name, token);
            fileType = fileType.substring(1,fileType.length()-1);
            if(fileType.equals("application/vnd.ms-excel"))
                fileType = "application/csv";
            fileType = fileType.split("/")[1];
            cuSystemProps.put(AppConstant.FILETYPE,fileType);

            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.AUTHORIZATION, token);
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.GET,
                    new HttpEntity<Object>(headers), String.class);
            InputStream inputStream = null;
            if(response.getBody()!=null) {
                String res = response.getBody().toString();     //NOSONAR
                inputStream = new ByteArrayInputStream(res.getBytes(StandardCharsets.UTF_8));
            }
            LOGGER.info("initializing inbound parsing :");
            ParserV2 parser = parserFactoryV2.getParser(fileType);
            return parser.inboundParser(inputStream,generalEntity,isMultivalued,
                    cuSystemProps, LayerType.TRIGGERCES, authUser).get(0);
        }
        catch(Exception e) {
            LOGGER.error("Failed to get the File");
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    messageSource.getMessage("Paas_Adapter_63", null, Locale.ENGLISH), ExceptionSeverity.BLOCKER);
        }
    }

    public String getfileType(String fileKey, String token) {

        LOGGER.info("Fetching the type of file...");

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        String uri = "https://graph.microsoft.com/v1.0/me/drive/root/search(q='" + fileKey + "')?select=name,file";
        HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(headers);
        ResponseEntity<JsonNode> response;
        response = restTemplate.exchange(uri, HttpMethod.GET,
                httpEntity, JsonNode.class);
        if (response.getBody() != null) {
            String fileType = String.valueOf(response.getBody().get("value").       //NOSONAR
                            get(0).get("file").get("mimeType"));
            return fileType;
        }
        return null;

    }



}
