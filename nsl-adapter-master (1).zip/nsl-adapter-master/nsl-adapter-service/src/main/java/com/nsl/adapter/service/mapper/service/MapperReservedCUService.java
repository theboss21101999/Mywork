package com.nsl.adapter.service.mapper.service;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.service.mapper.utils.MapperUtils;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import com.nsl.mapper.engine.MapperEngine;
import com.nsl.mapper.entity.MapSource;
import com.nsl.mapper.function.NLFunctionMap;
import com.nsl.mapper.service.MapperService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;
import static com.nsl.logical.enums.ErrorType.VALIDATION;

@Service
public class MapperReservedCUService {

    private static final String MAPPER_TEMPLATE_ENTITY = "NSL_Mapper_Template_Detail";
    private static final int MAPPER_ENTITY_SLOT_INDEX = 0;
    private static final int MAPPER_TEXT_INDEX = 0;

    @Autowired
    MapperUtils mapperUtils;

    @Autowired
    MapperService mapperService;

    @Autowired
    private MessageSource messageSource;
    private MapperEngine mapperEngine = new MapperEngine(new NLFunctionMap());

    public TxnData reservedCUService(TriggerCU triggerCU, TxnData transData) throws NSLException {

        StringBuilder stringBuilder = mapperUtils.validate(triggerCU, transData);
        if(stringBuilder.length() != 0){
            throw new NSLException(VALIDATION, ExceptionCategory.RESERVED_CU, stringBuilder.toString(),
                    ExceptionSeverity.MINOR);
        }

        List<TxnCULayer> txnCuLayers = transData.getTxnCULayer();
        List<TxnSlotItem> transEntityDetails = null;
        transEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnCuLayers, AppConstants.PHYSICAL_LAYER);
        List<TxnGeneralEntity> txnGeneralEntities = GeneralEntityUtils.getExpectedTxnMultipleGeneralEntities(transEntityDetails);

        if(CollectionUtils.isNotEmpty(txnGeneralEntities)
                && txnGeneralEntities.get(MAPPER_ENTITY_SLOT_INDEX).getName().equals(MAPPER_TEMPLATE_ENTITY)){
            TxnGeneralEntity mapperTemplateEntity = txnGeneralEntities.get(MAPPER_ENTITY_SLOT_INDEX);
            TxnNslAttribute mapText = mapperTemplateEntity.getTransEntityRecords().get(0).getTxnNslAttribute().get(MAPPER_TEXT_INDEX);
            String mappingConfig = mapText.getValues().get(0);

                mapperUtils.generateTcesLayerIfAbsent(txnCuLayers, triggerCU);

                List<Long> entityIds = mapperService.extractEntityIdsFromTCU(triggerCU, LayerType.PHYSICAL);
                MapSource sourceEntities = new MapSource(mapperService.getNSLEntities(entityIds));
                ArrayNode mapperResult = mapperEngine.execute(mappingConfig, sourceEntities, transData);
                ObjectNode mapperResultMap = mapperUtils.getMapperResponseAsMap(mapperResult);
                mapperUtils.setResultInTriggerCES(mapperResultMap, transData, triggerCU);

        } else {
            throw new NSLException(VALIDATION, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_Mapper_1", null, Locale.ENGLISH),
                    ExceptionSeverity.MINOR);
        }
        return transData;
    }
}
