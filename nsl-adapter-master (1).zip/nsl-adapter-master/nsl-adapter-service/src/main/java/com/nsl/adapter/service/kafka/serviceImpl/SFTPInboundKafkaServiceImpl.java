package com.nsl.adapter.service.kafka.serviceImpl;


import com.nsl.adapter.commons.dto.connections.MetaInfoEntityDto;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.service.db.service.DBGsiInvokerUtil;
import com.nsl.adapter.service.kafka.service.KafkaService;
import com.nsl.adapter.service.onedrive.serviceimpl.OneDriveGsiInvokerUtil;
import com.nsl.adapter.service.sftp.connection.AuthenticateUser;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.model.ChangeUnit;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

@Service("sftpInboundKafkaServiceImpl")
public class SFTPInboundKafkaServiceImpl implements KafkaService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SFTPInboundKafkaServiceImpl.class);
    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    DBGsiInvokerUtil dbGsiInvokerUtil;

    @Autowired
    OneDriveGsiInvokerUtil oneDriveGsiInvokerUtil;



    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Autowired
    AuthenticateUser authenticateUser;



    @Override
    @Async("sftpInboundKafkaExecutor")
    public void processKafkaMessage(ConsumerRecord<?, ?> consumerRecord) {

        String eventId = null;
        try {
            String kafkaMsg = (String) consumerRecord.value();
            LOGGER.info("Processing message: {}", kafkaMsg);
            Map<String, String> kafkaMsgMap = parseKafkaMessage(kafkaMsg);
            eventId = kafkaMsgMap.get(AppConstant.EVENT_ID);
         //   LOGGER.info("Received event with id : {}", eventId);

            AuthenticatedUserDetailsImpl authBean = authenticateUser.getAuthenticatedUser(kafkaMsgMap);
            LOGGER.info("Fetching change unit: {}", kafkaMsgMap.get(AppConstant.CUNAME));
            ChangeUnit changeUnit = changeUnitDao.getChangeUnitByName(kafkaMsgMap.get(AppConstant.CUNAME), authBean);
            ChangeUnit sftpInboundCu = changeUnitDao.getChangeUnitById(changeUnit.getId(), authBean);
            Map<String, String> cuSystemProp = sftpInboundCu.getCuSystemProperties();
            LOGGER.info("Received CU system Properties: {}" , cuSystemProp);

            String metaInfoEntityKey = cuSystemProp.get(AppConstant.METAINFO_ENTITY_KEY);
            MetaInfoEntityDto metaInfoEntity = metaInfoEntityUtils.getMetaInfoEntityDto(metaInfoEntityKey, authBean);
            LOGGER.info("Fetched metaInfoEntity {}", metaInfoEntity);
            List<Long> gsiMasterIdList = metaInfoEntity.getGsiIdList();
//            if (AdapterType.IMAP==AdapterType.valueOf(cuSystemProp.get(AppConstant.ADAPTER)) ||
//                    AdapterType.POP3==AdapterType.valueOf(cuSystemProp.get(AppConstant.ADAPTER))){
//                imapGsiInvokerUtil.invokeDynamicGsi(gsiMasterIdList,kafkaMsgMap,sftpInboundCu ,authBean);
//                return;
//            }
            for (Long gsiId : gsiMasterIdList) {
                switch (AdapterType.valueOf(cuSystemProp.get(AppConstant.ADAPTER))){
                    case DB:
                        dbGsiInvokerUtil.invokeGsi(gsiId,kafkaMsgMap,sftpInboundCu ,authBean);
                        break;
                    case ONEDRIVE:
                        oneDriveGsiInvokerUtil.invokeGsi(gsiId,kafkaMsgMap,sftpInboundCu ,authBean);
                        break;
                    default:
                        break;
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception occured while processing kafka message in thread {} with eventId {}",
                    Thread.currentThread().getName(), eventId, e);
        }
    }

    private Map<String, String> parseKafkaMessage(String kafkaMsg) {
        Map<String, String> map = new HashMap<>();
        StringTokenizer tokens = new StringTokenizer(kafkaMsg, "\r\n");
        while (tokens.hasMoreElements()) {
            String token = tokens.nextToken();
            String[] v = token.split(":", 2);
            map.put(v[0], v[1]);
        }
        return map;
    }
}


