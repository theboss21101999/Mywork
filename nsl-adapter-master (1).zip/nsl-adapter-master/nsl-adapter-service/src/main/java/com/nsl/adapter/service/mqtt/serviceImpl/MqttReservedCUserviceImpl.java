package com.nsl.adapter.service.mqtt.serviceImpl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.commons.dto.connections.MqttConnectionDto;
import com.nsl.adapter.service.mqtt.service.MqttConnectionService;
import com.nsl.adapter.service.mqtt.service.MqttReservedCUService;
import com.nsl.adapter.service.mqtt.utils.MqttConstants;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.ExtSolutionUtil;
import com.nsl.adapter.service.utils.GeneralUtils;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;
import java.util.Map;


@Service
public class MqttReservedCUserviceImpl implements MqttReservedCUService {
    private static final Logger logger = LoggerFactory.getLogger(MqttReservedCUserviceImpl.class);
    @Autowired
    GeneralUtils generalUtils;

    @Autowired
    MqttOpertations mqttOpertations;

    @Autowired
    MqttConnectionService mqttConnectionService;
    @Autowired
    ExtSolutionUtil extSolutionUtil;


    @Override
    public TxnData reservedCUService(TriggerCU triggerCu, TxnData transData) throws NSLException, JSONException, MqttException, JsonProcessingException {

        Map<String, String> cusystemprop = triggerCu.getCuSystemProperties();
        String operation = cusystemprop.get(AppConstant.OPERATION);
            logger.info("MQTT Operations {}", operation);
            if (MqttConstants.PUBLISHER.equals(operation.toUpperCase(Locale.ENGLISH))) {
                logger.debug("Mqtt reserved CU Service:");
                JSONObject transObject = generalUtils.createTransObject(triggerCu, transData);
                long connectionId;
                connectionId = Long.parseLong(triggerCu.getCuSystemProperties().get(AppConstant.CONFIG_ENTITY_RECORD_ID));
                MqttConnectionDto entityRecordMqtt = mqttConnectionService.getMqttConnection(connectionId, false);
                return mqttOpertations.publish(entityRecordMqtt, triggerCu, transObject);
            }
            else if(MqttConstants.SUBSCRIBER.equals(operation.toUpperCase(Locale.ENGLISH))){
                List<TxnCULayer> txnCuLayers = transData.getTxnCULayer();
                List<TxnSlotItem> transEntityDetails = null;
                transEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnCuLayers, AppConstant.PHYSICAL_LAYER);
                TxnGeneralEntity txnGeneralEntity = GeneralEntityUtils.getExpectedTxnGeneralEntity(transEntityDetails);

                logger.info("Call for mqtt inbound, copying physical layer to triggerces layer");
                transData = extSolutionUtil.setChangeDriverInTxnData(txnGeneralEntity, LayerType.TRIGGERCES);
                return transData;
            }


            return null;
        }
}

