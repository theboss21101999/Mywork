package com.nsl.adapter.service.mqtt.utils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.service.GsiExecutor;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.ExtSolutionUtil;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;

@Service
public class MqttInvokeGSIUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(MqttInvokeGSIUtil.class);

    @Autowired
    ExtSolutionUtil extSolutionUtil;

    @Autowired
    GsiExecutor gsiExecutor;

    @Autowired
    ChangeUnitDao changeUnitDao;

    public void invokeGsi(Long gsiMasterId, Map<String, String> msg, ChangeUnit cu, AuthenticatedUserDetailsImpl authBean
            , JsonNode response) {
        try{
            LOGGER.info("Fetching GSI..");
            GSI gsiMaster = changeUnitDao.getGsiByMasterId(gsiMasterId, null, StatusEnum.PUBLISHED, authBean);
            LOGGER.debug("GSI with master id {} fetched successfully..", gsiMaster.getName());
            GSI gsi = changeUnitDao.getGSI(gsiMaster.getId(), authBean);
            TriggerCU triggerCu = gsi.getSolutionLogic().get(0);
            GeneralEntity phyGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, AppConstant.PHYSICAL_LAYER);
            TxnGeneralEntity phytxnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(phyGeneralEntity, response);
            TxnData txnData = extSolutionUtil.setChangeDriverInTxnData(phytxnGeneralEntity, LayerType.PHYSICAL);
            LOGGER.info("executing the GSI with gsi name ="+gsi.getName());
            gsiExecutor.executeGsiSync(gsi.getId(), authBean.getTenantId(), authBean.getEmailId(), txnData);

        }catch(Exception e){
            LOGGER.error("Exception occurred while invoking GSI in thread {} : {}", Thread.currentThread().getName(), e.getMessage());
        }

    }


}
