package com.nsl.adapter.service.dto;


public class AWSSecretManagerDto {
    
    String secretName;
    String secretValue;
    String secretId;

    public String getSecretId() {
        return secretId;
    }
    public void setSecretId(String secretId) {
        this.secretId = secretId;
    }
    public String getSecretName() {
        return secretName;
    }
    public void setSecretName(String secretName) {
        this.secretName = secretName;
    }
    public String getSecretValue() {
        return secretValue;
    }
    public void setSecretValue(String secretValue) {
        this.secretValue = secretValue;
    }
    @Override
    public String toString() {
        return "AWSSecretManagerDto [secretId=" + secretId + ", secretName=" + secretName + ", secretValue="
                + secretValue + "]";
    }

}
