package com.nsl.adapter.service.inboundcu.service;

import com.nsl.adapter.commons.dto.connections.RestInboundDto;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.logical.model.CULayer;
import com.nsl.logical.model.ChangeUnit;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.NslDataType;
import com.nsl.logical.model.SlotItem;
import io.swagger.v3.oas.models.media.ArraySchema;
import io.swagger.v3.oas.models.media.BooleanSchema;
import io.swagger.v3.oas.models.media.DateSchema;
import io.swagger.v3.oas.models.media.DateTimeSchema;
import io.swagger.v3.oas.models.media.IntegerSchema;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.media.StringSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import static com.nsl.adapter.service.inboundcu.utils.RestInboundConstants.Error;
import static com.nsl.adapter.service.inboundcu.utils.RestInboundConstants.*;

@Service
public class SwaggerBuildSchema {

    private static final Logger LOGGER = LoggerFactory.getLogger(SwaggerBuildSchema.class);

    public Map<String, Schema> buildSchemas(ChangeUnit restInputCU, ChangeUnit restOutputCU) {
        Map<String, Schema> schemas = new HashMap<>();

        Map<String, Schema> schemaProperties = buildReqSchemaProperties(restInputCU);

        for (Map.Entry<String, Schema> key : schemaProperties.entrySet()) {
            schemas.put(key.getKey(), key.getValue().description(key.getKey() + " Input data"));
        }

        Schema respSchema;
        if (restOutputCU == null)
            respSchema = new Schema<>().description("response");
        else {
            schemaProperties = buildResSchemaProperties(restOutputCU);
            String name = "";
            for (Map.Entry<String, Schema> key : schemaProperties.entrySet()) {
                name = key.getKey();
                schemas.put(name, key.getValue().description(key.getKey() + " Input data"));
            }
            respSchema = new Schema<>().$ref(Components_schema +"/"+name);
        }

        schemas.put("Res." + Status_200 , new Schema<>()
                .description(Api_Response)
                .addProperties(Status, new IntegerSchema()
                        .description(Status_Code)).example(Status_200)
                .addProperties(Message, new StringSchema()
                        .description(Status_Message)).example(Success)
                .addProperties(Result, respSchema)
        );

        schemas.put("Req." + Status_200 , new Schema<>()
                .description(Api_Response)
                .addProperties(Status, new IntegerSchema()
                        .description(Status_Code)).example(Status_200)
                .addProperties(Message, new StringSchema()
                        .description(Status_Message)).example(Success)
                .addProperties(Result, new ArraySchema().description("Gsi invoking response")
                        .addProperties("gsiName",new StringSchema())
                        .addProperties("transactionId",new IntegerSchema()))

                );
        schemas.put("Res." + Status_202 , new Schema<>()
                .description(Api_Response)
                .addProperties(Status, new IntegerSchema()
                        .description(Status_Code)).example(Status_202)
                .addProperties(Message, new StringSchema()
                        .description(Status_Message)).example(Success)
                .addProperties(Result, new Schema<>().description("Res for transaction in pending state")
                        .addProperties("message",new StringSchema())
                        .addProperties("currentCu",new StringSchema()))
                );
        schemas.put(Status_401, new Schema<>()
                .description(Unauthorized)
                .addProperties(Status, new IntegerSchema()
                        .description(Status_Code)).example(Status_401)
                .addProperties(Message, new StringSchema()
                        .description(Status_Message)).example(Unauthorized)
                );

        schemas.put(Status_500, new Schema<>()
                .description(Error)
                .addProperties(Status, new IntegerSchema()
                        .description(Status_Code)).example(Status_500)
                .addProperties(Message, new StringSchema()
                        .description(Status_Message)).example(Internal_Server_Error)

                );

        return schemas;
    }
    public Map<String, Schema> buildSchemas(ChangeUnit restInputCU, ChangeUnit restOutputCU, RestInboundDto metaInfoEntity) {
        Map<String, Schema> schemas = new HashMap<>();

        Map<String, Schema> schemaProperties = buildReqSchemaProperties(restInputCU,metaInfoEntity);

        for (Map.Entry<String, Schema> key : schemaProperties.entrySet()) {
            schemas.put(key.getKey(), key.getValue().description(key.getKey() + " Input data"));
        }

        Schema respSchema;
        if (restOutputCU == null)
            respSchema = new Schema<>().description("response");
        else {
            schemaProperties = buildResSchemaProperties(restOutputCU);
            String name = "";
            for (Map.Entry<String, Schema> key : schemaProperties.entrySet()) {
                name = key.getKey();
                schemas.put(name, key.getValue().description(key.getKey() + " Input data"));
            }
            respSchema = new Schema<>().$ref(Components_schema +"/"+name);
        }

        schemas.put("Res." + Status_200 , new Schema<>()
                .description(Api_Response)
                .addProperties(Status, new IntegerSchema()
                        .description(Status_Code)).example(Status_200)
                .addProperties(Message, new StringSchema()
                        .description(Status_Message)).example(Success)
                .addProperties(Result, respSchema)
        );

        schemas.put("Req." + Status_200 , new Schema<>()
                .description(Api_Response)
                .addProperties(Status, new IntegerSchema()
                        .description(Status_Code)).example(Status_200)
                .addProperties(Message, new StringSchema()
                        .description(Status_Message)).example(Success)
                .addProperties(Result, new ArraySchema().description("Gsi invoking response")
                        .addProperties("gsiName",new StringSchema())
                        .addProperties("transactionId",new IntegerSchema()))

        );
        schemas.put("Res." + Status_202 , new Schema<>()
                .description(Api_Response)
                .addProperties(Status, new IntegerSchema()
                        .description(Status_Code)).example(Status_202)
                .addProperties(Message, new StringSchema()
                        .description(Status_Message)).example(Success)
                .addProperties(Result, new Schema<>().description("Res for transaction in pending state")
                        .addProperties("message",new StringSchema())
                        .addProperties("currentCu",new StringSchema()))
        );
        schemas.put(Status_401, new Schema<>()
                .description(Unauthorized)
                .addProperties(Status, new IntegerSchema()
                        .description(Status_Code)).example(Status_401)
                .addProperties(Message, new StringSchema()
                        .description(Status_Message)).example(Unauthorized)
        );

        schemas.put(Status_500, new Schema<>()
                .description(Error)
                .addProperties(Status, new IntegerSchema()
                        .description(Status_Code)).example(Status_500)
                .addProperties(Message, new StringSchema()
                        .description(Status_Message)).example(Internal_Server_Error)

        );

        return schemas;
    }

    private Map<String, Schema> buildResSchemaProperties(ChangeUnit restOutputCU) {
        GeneralEntity generalEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(restOutputCU.getLayers(),
                                                                                            AppConstant.INFORMATION);
        boolean isMultivalued = GeneralEntityUtils.getTriggerCUSlotItemsList(restOutputCU.getLayers(),
                AppConstant.INFORMATION).get(0).getIsMultiValue();
        return getGESchemaProperties(generalEntity.getName(), generalEntity, isMultivalued);
    }

    private Map<String, Schema> buildReqSchemaProperties(ChangeUnit cu) {

        if (cu.getCuSystemProperties().containsKey(AppConstant.REQUESTID)) {
            GeneralEntity generalEntity = getGeneralEntityByName(cu.getLayers(),
                    cu.getCuSystemProperties().get(AppConstant.REQUESTID));
            boolean isMultivalued = cu.getLayers().get(0).getParticipatingItems().get(0).getIsMultiValue();
            return getGESchemaProperties(generalEntity.getName(), generalEntity, isMultivalued);
        } else
            return new HashMap<>();
    }
    private Map<String, Schema> buildReqSchemaProperties(ChangeUnit cu,RestInboundDto metaInfoEntity) {

        if (metaInfoEntity.getBodyEntityName()!=null) {
            GeneralEntity generalEntity = getGeneralEntityByName(cu.getLayers(),
                    metaInfoEntity.getBodyEntityName());
            boolean isMultivalued = cu.getLayers().get(0).getParticipatingItems().get(0).getIsMultiValue();
            return getGESchemaProperties(generalEntity.getName(), generalEntity, isMultivalued);
        } else
            return new HashMap<>();
    }

    public GeneralEntity getGeneralEntityByName(List<CULayer> cuLayers, String name) {

        for (CULayer layer : cuLayers) {
            if (null != layer && null != layer.getParticipatingItems()
                    && Objects.equals(layer.getType().getLayerType(), AppConstant.PHYSICAL_LAYER)) {

                for (SlotItem slotItem : layer.getParticipatingItems()) {
                    if (((GeneralEntity) slotItem.getItem()).getName().equals(name)) {
                        LOGGER.debug("fetched general Entity {} with name {}", slotItem.getItem(), name);
                        return (GeneralEntity) slotItem.getItem();
                    }
                }
            }
        }
        return null;
    }

    private Map<String, Schema> getGESchemaProperties(String schemaName,GeneralEntity generalEntity, boolean isMultivalued) {

        Map<String, Schema> result = new HashMap<>();
        if (Boolean.TRUE.equals(isMultivalued)) {
            ArraySchema schema = new ArraySchema();
            Map properties = new HashMap();
            for (NslAttribute na : generalEntity.getNslAttributes()) {

                if (na.getGeneralEntity() == null)
                    properties.putAll(getNASchemaProperties(na));
                else {
                    result.putAll(getNASchemaProperties(na));
                    properties.put(na.getName(), new Schema<>().description(na.getName()).
                            $ref(Components_schema + "/" + na.getName()));
                }

            }
            if (!properties.isEmpty())
                schema.items(new Schema<>().description(generalEntity.getName()).properties(properties));
            result.put(schemaName, schema.description(generalEntity.getName()));
        } else {
            Schema schema = new Schema<>();
            for (NslAttribute na : generalEntity.getNslAttributes()) {

                if (na.getGeneralEntity() == null)
                    schema.addProperties(na.getName(), getNASchemaProperties(na).get(na.getName()));
                else {
                    result.putAll(getNASchemaProperties(na));
                    schema.addProperties(na.getName(), new Schema<>().$ref(Components_schema + "/" + na.getName()));
                }

            }
            result.put(schemaName, schema.description(generalEntity.getName()));
        }

        return result;
    }

    private Map<String, Schema> getNASchemaProperties(NslAttribute na) {

        Map<String, Schema> result = new LinkedHashMap<>();

        if (na.getGeneralEntity() == null) {
            Schema schema = getSchemaTypeFromNslAttType(na.getAttributeType(), na.getName());
            result.put(na.getName(), schema);
        } else {
            boolean isMultivalued = "list".equalsIgnoreCase(na.getAttributeType().getType().getName());
            result.putAll(getGESchemaProperties(na.getName(), na.getGeneralEntity(), isMultivalued));
        }
        return result;
    }

    private Schema getSchemaTypeFromNslAttType(NslDataType attributeType, String name) {

        switch (attributeType.getType().getName().toLowerCase(Locale.ROOT)) {
            case "number":
                return new IntegerSchema().description(name);
            case "list":
                ArraySchema schema = new ArraySchema();
                Schema childSchema = getSchemaTypeFromNslAttType(attributeType.getNestedNslDataTypeProperties()
                                                                                    .get(AppConstants.ITEMTYPE), name);
                return schema.items(childSchema).description(name);
            case "boolean":
                return new BooleanSchema().description(name);
            case "datetime":
                return new DateTimeSchema().description(name).example("2023-02-13T06:40:00.898Z");
            case "date":
                return new DateSchema().description(name);

            default:
                return new StringSchema().description(name);
        }
    }
}
