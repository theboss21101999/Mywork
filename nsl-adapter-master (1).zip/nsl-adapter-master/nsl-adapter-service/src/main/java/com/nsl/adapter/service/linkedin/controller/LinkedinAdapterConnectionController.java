package com.nsl.adapter.service.linkedin.controller;


import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.AppConstant;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;
import com.nsl.adapter.commons.dto.connections.LinkedinAdapterConnectionDto;
import com.nsl.adapter.service.linkedin.service.LinkedinConnectionService;
import com.nsl.adapter.service.linkedin.utils.LinkedinOauthConnection;


@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class LinkedinAdapterConnectionController {
    @Autowired
    LinkedinConnectionService linkedinConnectionService;
    @Autowired
    LinkedinOauthConnection linkedinOauthConnection;
    @PostMapping(path = "/linkedin", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveLinkedinConnection(@RequestBody LinkedinAdapterConnectionDto connectionDto) {
        TxnAdapterConnection result = linkedinConnectionService.saveLinkedinConnection(connectionDto);
        JSONObject jsonObject = linkedinOauthConnection.getAuthorizationcode(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
    @GetMapping(path = "/linkedin/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getLinkedinConnection(@PathVariable("id") Long id) {
        LinkedinAdapterConnectionDto response = linkedinConnectionService.getLinkedinConnection(id,true);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @PutMapping(path = "/linkedin/{id}" , consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse updateLinkedinConnection(@PathVariable("id") Long id,
                                                @RequestBody LinkedinAdapterConnectionDto connectionDto ) {

        TxnAdapterConnection result = linkedinConnectionService.updateLinkedinConnection(id, connectionDto);
        JSONObject jsonObject = linkedinOauthConnection.getAuthorizationcode(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
    @GetMapping(path = "/linkedin/refreshToken/{id}")
    public ApiResponse updateLinkedinToken(@PathVariable("id") Long id){

        TxnAdapterConnection result =linkedinOauthConnection.getRefreshToken(id);
        return new ApiResponse(HttpStatus.OK,SUCCESS,result);
    }


}
