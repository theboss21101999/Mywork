package com.nsl.adapter.service.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.service.rest.service.ConnectionToGeneral;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CuUtils;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.service.utils.ExtSolutionUtil;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.service.utils.GeneralUtils;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnCULayer;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnSlotItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
public class CHRestReservedCUService {
    private static final Logger logger = LoggerFactory.getLogger(CHRestReservedCUService.class);
    @Autowired
    ExtSolutionUtil extSolutionUtil;

    @Autowired
    EntityToJSONUtil entityToJSONUtil;

    @Autowired
    ConnectionToGeneral connectionService;

    @Autowired
    GeneralUtils generalUtils;

    @Autowired
    RestTemplate restTemplate;

    public TxnData reservedCUService(TriggerCU triggerCu, TxnData transData) throws JSONException, NSLException {

        List<TxnCULayer> txnCuLayers = transData.getTxnCULayer();
        List<TxnSlotItem> transEntityDetails;
        transEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnCuLayers, AppConstant.PHYSICAL_LAYER);

        JSONObject transObject;
        TxnGeneralEntity inputTxnGeneralEntity = GeneralEntityUtils.getExpectedTxnGeneralEntity(transEntityDetails);
        GeneralEntity inputGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, AppConstant.PHYSICAL_LAYER);
        Map<String, NslAttribute> dataTypeMap = new HashMap<>();
        entityToJSONUtil.getDataTypeMap(dataTypeMap, inputGeneralEntity, "");
        transObject = entityToJSONUtil.createRequestForRestAdapter(dataTypeMap, inputTxnGeneralEntity, inputGeneralEntity, "");

        triggerCu.setCuSystemProperties(CuUtils.addTxnId(transData.getTransactionId(), triggerCu.getCuSystemProperties()));
        Long connectionId = null;
        try {
            connectionId = Long.valueOf(triggerCu.getCuSystemProperties().get(AppConstant.CONFIG_ENTITY_RECORD_ID));
        } catch (Exception e) {
            logger.warn("Exception while getting connection id for rest. Continuing without connection.", e);
        }
        ObjectMapper ob = new ObjectMapper();
        RESTAdapterConnectionDto connectionDto = connectionService.getEntityRecordrest(connectionId);
        Map<String, String> cuSystemProperties = triggerCu.getCuSystemProperties();
        String uri = connectionDto.getBaseUrl();
        String endUri = cuSystemProperties.get(AppConstant.URI);
        endUri = endUri.startsWith("/") ? endUri : "/" + endUri;
        uri = uri == null ? cuSystemProperties.get(AppConstant.URI) : uri.replaceAll("/$", "") + endUri;
        HttpHeaders headers = new HttpHeaders();
        headers.add(AppConstant.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        Object requestBody = generalUtils.jsonToObjectConverter(transObject);
        HttpEntity<Object> entity = new HttpEntity<>(requestBody, headers);
        ResponseEntity<JsonNode> response = restTemplate.exchange(uri, HttpMethod.POST, entity, JsonNode.class);

        JSONObject jsonObject = new JSONObject(Objects.requireNonNull(response.getBody()).toString());
        JSONArray jsonArray = new JSONArray();
        Iterator it = jsonObject.keys();
        while (it.hasNext()) {
            jsonArray.put(jsonObject.getJSONObject((String) it.next()));
        }
        JsonNode finalResponse;
        try {
            finalResponse = ob.readTree(jsonArray.toString());
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, AppConstant.TRIGGER_CES_LAYER);
        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, finalResponse);
        transData = extSolutionUtil.setChangeDriverInTxnData(txnGeneralEntity, LayerType.TRIGGERCES);
        return transData;
    }

}

