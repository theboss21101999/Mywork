package com.nsl.adapter.service.argo.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.service.argo.dto.JobDeleteDto;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class ArgoConnectionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ArgoConnectionService.class);

    @Autowired
    AdaptorProperties adaptorProperties;

    @Autowired
    RestTemplate restTemplate;
    ObjectMapper ob = new ObjectMapper();

    public List getUnwantedJobs(AuthenticatedUserDetailsImpl authBean) {
        HttpEntity<String> httpEntity = new HttpEntity<>(null,getHttpHeaders(authBean));
        String url=adaptorProperties.getArgoExtsolnsUrl()+"/list";
        ResponseEntity<JsonNode> response = restTemplate.exchange(url,
                HttpMethod.GET, httpEntity, JsonNode.class);
        return ob.convertValue(response.getBody().get("result"),List.class);  //NOSONAR
    }

    public void saveArgoConn(JobDeleteDto jobDeleteDto, AuthenticatedUserDetailsImpl authBean) {
        Map<String,Object> jsonObject =new HashMap<>();
        jsonObject.put("jobId",jobDeleteDto.getJobId());
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        jsonObject.put("deletionTime",formatter.format(jobDeleteDto.getTimeStamp()));
        HttpEntity<Map<String, Object>> httpEntity = new HttpEntity<>(jsonObject, getHttpHeaders(authBean));
        String url=adaptorProperties.getArgoExtsolnsUrl()+"/save";
        ResponseEntity<JsonNode> response = restTemplate.exchange(url,
                HttpMethod.POST, httpEntity, JsonNode.class);

    }

    public void deleteJobs(List<String> unwantedJobs,AuthenticatedUserDetailsImpl authBean) {
        String url=adaptorProperties.getArgoExtsolnsUrl()+"/delete";
        HttpEntity<List> httpEntity = new HttpEntity<>(unwantedJobs,getHttpHeaders(authBean));
        ResponseEntity<JsonNode> response = restTemplate.exchange(url,
                HttpMethod.DELETE, httpEntity, JsonNode.class);
    }

    public HttpHeaders getHttpHeaders(AuthenticatedUserDetailsImpl authBean){
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION,"Bearer "+ authBean.getAuthToken());
        headers.add(HttpHeaders.ACCEPT_LANGUAGE, AppConstants.ACCEPT_LANGUAGE_EN);
        return headers;
    }
}
