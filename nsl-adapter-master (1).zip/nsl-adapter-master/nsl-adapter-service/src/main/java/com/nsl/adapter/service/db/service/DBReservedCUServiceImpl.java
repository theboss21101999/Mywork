package com.nsl.adapter.service.db.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.commons.dto.connections.DBConnectionDto;
import com.nsl.adapter.service.db.enums.DBType;
import com.nsl.adapter.service.utils.*;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnCULayer;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnSlotItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DBReservedCUServiceImpl implements DBReservedCUService {

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Autowired
    MYSQLDBOperations dbOperations;

    @Autowired
    EntityToJSONUtil entityToJSONUtil;
    @Autowired
    DBConnectionService dbConnectionService;
    @Autowired
    ExtSolutionUtil extSolutionUtil;
    @Autowired
    DBAdapterFactory dbAdapterFactory;

    @Override
    public TxnData reservedCUService(TriggerCU triggerCu, TxnData transData)
            throws JSONException, NSLException, SQLException, JsonProcessingException {
        List<TxnCULayer> txnCuLayers = transData.getTxnCULayer();
        List<TxnSlotItem> transEntityDetails = null;
        transEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnCuLayers, AppConstant.PHYSICAL_LAYER);
        TxnGeneralEntity txnGeneralEntity = GeneralEntityUtils.getExpectedTxnGeneralEntity(transEntityDetails);
        GeneralEntity inputGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu,
                AppConstant.PHYSICAL_LAYER);
        JSONObject transObject;
        Map<String, NslAttribute> dataTypeMap = new HashMap<>();
        entityToJSONUtil.getDataTypeMap(dataTypeMap, inputGeneralEntity, "");
        transObject = entityToJSONUtil.createRequestForRestAdapter(dataTypeMap, txnGeneralEntity,
                inputGeneralEntity, "");
        Map<String, String> DBProperties = triggerCu.getCuSystemProperties();
        String DBMethod = triggerCu.getCuSystemProperties().get(AppConstant.OPERATION);
        if(DBMethod.equals("GET"))
            return extSolutionUtil.setChangeDriverInTxnData(txnGeneralEntity, LayerType.TRIGGERCES);
        Long connectionId = Long.valueOf(DBProperties.get(AppConstant.CONFIG_ENTITY_RECORD_ID));
        DBConnectionDto dbConnectionDto = dbConnectionService.getDBConnection(connectionId, false);
        String query = transObject.optString("query");
        DBType dbType = null;
        if (dbConnectionDto.getDataSourceDriver().contains(AppConstant.POSTGRES_DRIVER)) {
            dbType = DBType.POSTGRES;
        } else if (dbConnectionDto.getDataSourceDriver().contains(AppConstant.MYSQL_DRIVER)) {
            dbType = DBType.MYSQL;
        }
        DBOperations dbOperations = dbAdapterFactory.getDBAdapter(dbType); //NOSONAR
        switch (DBMethod.toUpperCase()) {
            case "SELECT":
                return dbOperations.getTable(dbConnectionDto, query, triggerCu);
            case "INSERT":
                return dbOperations.updateTable(dbConnectionDto, transObject, triggerCu);


            default:
                return null;
        }

    }

}
