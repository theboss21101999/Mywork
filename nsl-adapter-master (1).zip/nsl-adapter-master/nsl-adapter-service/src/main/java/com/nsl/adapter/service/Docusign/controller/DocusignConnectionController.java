package com.nsl.adapter.service.Docusign.controller;

import com.nsl.adapter.commons.dto.connections.DocusignAdapterConnectionDto;
//import com.nsl.adapter.commons.dto.connections.FacebookAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.FacebookAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.Docusign.service.DocusignConnectionService;
import com.nsl.adapter.service.Docusign.utils.DocusignOauthConnection;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class DocusignConnectionController {

    @Autowired
    DocusignConnectionService docusignConnectionService;

    @Autowired
    DocusignOauthConnection oauthConnection;

    @PostMapping(path = "/docusign", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveDocusignConnection(@RequestBody DocusignAdapterConnectionDto connectionDto) {
        TxnAdapterConnection result = docusignConnectionService.saveDocusignConnection(connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationcode(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
    @GetMapping(path = "/docusign/{Id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getDocusignConnection(@PathVariable("Id") Long id) {

        DocusignAdapterConnectionDto response = docusignConnectionService.getDocusignConnection(id, true);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @PutMapping(path = "/docusign/{Id}" , consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse updateDocusignConnection(@PathVariable("Id") Long id,
                                                @RequestBody DocusignAdapterConnectionDto connectionDto ) {

        TxnAdapterConnection result = docusignConnectionService.updateDocusignConnection(id, connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationcode(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
    @GetMapping(path = "/docusign/refreshToken/{Id}")
    public ApiResponse updateDocusignToken(@PathVariable("Id") Long id){

        TxnAdapterConnection result =oauthConnection.getRefreshToken(id);
        return new ApiResponse(HttpStatus.OK,SUCCESS,result);
    }
}

