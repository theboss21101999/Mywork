package com.nsl.adapter.service.inboundcu.utils;

public final class RestInboundConstants {

    public static final String NSL_API = "NSL API";
    public static final String API_Version= "API Version 1.0";
    public static final String InfoEmail = "info@nslhub.com";
    public static final String NslEmail = "https://www.nslhub.com";
    public static final String SecurityToken = "SecurityToken";
    public static final String bearer = "bearer";
    public static final String ContentType = "contentType";
    public static final String Application_xml = "application/xml";
    public static final String Application_json = "application/json";
    public static final String Multipart_FormData = "multipart/form-data";
    public static final String ISFormData = "isFormData";
    public static final String FILESUPPORT = "fileSupport";
    public static final String ReqBody_Key = "reqBody";
    public static final String XMlReqBody_Key = "xmlBody";
    public static final String File_Key = "file";
    public static final String Components_schema = "#/components/schemas";
    public static final String Success = "SUCCESS";
    public static final String Support = "Support";
    public static final String Status = "status";
    public static final String Unauthorized = "Unauthorized";
    public static final String Message = "message";
    public static final String Status_Code = "Status Code";
    public static final String Status_Message = "Status Message";
    public static final String Api_Response = "API Response";
    public static final String Status_200 = "200";
    public static final String Status_202 = "202";
    public static final String Status_500 = "500";
    public static final String Status_401 = "401";
    public static final String Internal_Server_Error = "Internal Server Error";
    public static final String Server_Error = "Server Error";
    public static final String Header = "header";
    public static final String Query = "query";
    public static final String Error = "Error";
    public static final String Result = "result";
    public static final String ParticipatingChangeUnits = "participatingChangeUnits";
    public static final String CuContextualId = "cuContextualId";
    public static final String TriggerCuName = "triggerCuName";
    private RestInboundConstants(){
        throw new IllegalStateException("utility class");
    }
}
