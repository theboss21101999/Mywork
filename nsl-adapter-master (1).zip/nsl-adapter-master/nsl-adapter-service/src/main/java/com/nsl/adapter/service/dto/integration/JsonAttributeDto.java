package com.nsl.adapter.service.dto.integration;


public class JsonAttributeDto {
    String name;
    String path;
    JsonEntityDto entity;

    public JsonAttributeDto() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public JsonEntityDto getEntity() {
        return entity;
    }

    public void setEntity(JsonEntityDto entity) {
        this.entity = entity;
    }
}
