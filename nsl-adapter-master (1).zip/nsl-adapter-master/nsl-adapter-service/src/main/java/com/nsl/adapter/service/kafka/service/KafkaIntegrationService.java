package com.nsl.adapter.service.kafka.service;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.service.service.IntegrationService;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.nsl.adapter.service.kafka.utils.KafkaConstants.KAFKA_INBOUND;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.KAFKA_OUTBOUND;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.TOPIC;
import static com.nsl.adapter.service.v2.utills.EntityConstants.NSL_ADAPTER_RESPONSE;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class KafkaIntegrationService implements IntegrationService {

    @Autowired
    SaveBetsService saveBetsService;

    @Override
    public CUPropsDto getSaveProperties(IntegrationDtoV3 integrationDto) throws NSLException {

        if (validate(integrationDto.getPropertiesMap(),integrationDto.getOperation()))
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"please send valid data", ExceptionSeverity.MAJOR);

        CUPropsDto cuPropsDto;
        HashMap<String, String> cuSystemProps = new HashMap<>(integrationDto.getPropertiesMap());

        if (KAFKA_OUTBOUND.equalsIgnoreCase(integrationDto.getOperation()))
            cuPropsDto = newEntitiesForPUTMethod(integrationDto);
        else
            cuPropsDto = newEntitiesForGETMethod(integrationDto);

        cuPropsDto.setCuSystemProps(cuSystemProps);
        cuPropsDto.setIsMachineCU(Boolean.FALSE);
        return cuPropsDto;
    }

    @Override
    public void getIntegration(IntegrationDtoV3 integrationDto,CUPropsDto cuPropsDto) {

        if (KAFKA_OUTBOUND.equalsIgnoreCase(integrationDto.getOperation()))
            integrationDto.setInputEntityDsdId(getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).get(0).getDsdId());
        else
            integrationDto.setOutputEntityDsdId(getParticipatingItems(cuPropsDto.getTriggerCESLayerItems()).get(0).getDsdId());
    }

    @Override
    public CUPropsDto getUpdateProperties(CUPropsDto cuPropsDto, IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto newCUPropsDto;
        if (KAFKA_OUTBOUND.equalsIgnoreCase(integrationDto.getOperation()))
            newCUPropsDto = newEntitiesForPUTMethod(integrationDto);
        else
            newCUPropsDto = newEntitiesForGETMethod(integrationDto);

        Map<String, String> cuSystemProps = cuPropsDto.getCuSystemProps();
        cuSystemProps.putAll(integrationDto.getPropertiesMap());
        newCUPropsDto.setCuSystemProps(cuSystemProps);
        return newCUPropsDto;
    }

    private static boolean validate(Map<String, String> propertiesMap, String operation) {

        List<String> propertyList;
        if (operation.equals(KAFKA_OUTBOUND))
            propertyList = List.of(TOPIC);
        else if (operation.equals(KAFKA_INBOUND))
            propertyList = List.of(TOPIC);
        else
            return true;

        for (Object property : propertyList) {
            if (!propertiesMap.containsKey(property.toString()))
                return true;
        }
        return false;
    }

    private CUPropsDto newEntitiesForPUTMethod(IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto cuPropsDto = new CUPropsDto();

        TenantCUEntityInput phyEntity1 = saveBetsService.findEntityById(integrationDto.getInputEntityDsdId());
        TenantCUEntityInput triggerCESEntity1 = saveBetsService.getEntityByName(NSL_ADAPTER_RESPONSE);

        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Collections.singletonList(phyEntity1)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(triggerCESEntity1)));

        return cuPropsDto;
    }

    private CUPropsDto newEntitiesForGETMethod(IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto cuPropsDto = new CUPropsDto();

        TenantCUEntityInput entity = saveBetsService.findEntityById(integrationDto.getOutputEntityDsdId());

        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Collections.singletonList(entity)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(entity)));

        return cuPropsDto;
    }

}
