package com.nsl.adapter.service.inboundcu.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.MetaInfoEntityDto;
import com.nsl.adapter.commons.dto.connections.RestInboundDto;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionStatus;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.ChangeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class InvokeCu {

    private static final Logger LOGGER = LoggerFactory.getLogger(InvokeCu.class);

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Autowired
    MessageSource messageSource;

    @Autowired
    InboundGsiInvokerUtil inboundGsiInvokerUtil;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;
    private static final ConnectionDtoType connType = ConnectionDtoType.InboundCu;
    public ResponseEntity<Map<String, Object>> invokeCu(String cuName, String version, JsonNode body, String xmlString, List<MultipartFile> file,
                                                        Map<String, String> headerMap, Map<String, String> queryMap , AuthenticatedUserDetailsImpl bean) throws NSLException, JsonProcessingException {

        ChangeUnit changeUnit = changeUnitDao.getChangeUnitByName(cuName, bean);
        if (changeUnit == null)
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.CU_GSI, messageSource.
                    getMessage("Paas_Adapter_119", null, Locale.ENGLISH) + cuName, ExceptionSeverity.BLOCKER); //NOSONAR

        LOGGER.info("fetched cu using name {}...{}", cuName, changeUnit);
        String metaInfoEntityName = changeUnit.getCuSystemProperties().get(AppConstant.METAINFO_ENTITY_KEY);

        MetaInfoEntityDto metaInfoEntity = metaInfoEntityUtils.getMetaInfoEntityDto(metaInfoEntityName,bean);
        Long gsiId = metaInfoEntity.getGsiIdList().get(0);
        return inboundGsiInvokerUtil.invokeGsi(gsiId,version,bean, body ,xmlString,file, headerMap, queryMap);

    }

    public ResponseEntity<Map<String, Object>> invokeCu(String cuName, JsonNode body, AuthenticatedUserDetailsImpl authBean) throws JsonProcessingException {
        return invokeCu(cuName, null, body, null, null, null, null, authBean);
    }

    public String webHookUrl(String cuName, AuthenticatedUserDetailsImpl bean){

        ChangeUnit changeUnit = changeUnitDao.getChangeUnitByName(cuName, bean);
        if (changeUnit == null)
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.CU_GSI, messageSource.
                    getMessage("Paas_Adapter_119", null, Locale.ENGLISH) + cuName, ExceptionSeverity.BLOCKER); //NOSONAR

        LOGGER.info("fetched cu using cuid {}...{}",cuName,changeUnit);
        String metaInfoEntityId = changeUnit.getCuSystemProperties().get(AppConstant.METAINFO_ENTITY_KEY);
        MetaInfoEntityDto metaInfoEntity = metaInfoEntityUtils.getMetaInfoEntityDto(metaInfoEntityId,bean);

        if (metaInfoEntity.getConnectionStatus() == ConnectionStatus.INVALID)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR,"Please publish the cu in a GSI");

        return (String) metaInfoEntity.getAdditionalProperties().get("url");
    }

    public void  invokeRestGsi(String gsiName, RestInboundDto restInboundDto, AuthenticatedUserDetailsImpl bean) {
        try{
            if (adapterConnnectionsDao.getConnectionByName(connType, gsiName, bean) != null) {
//                RestInboundDto restInboundDto1 = metaInfoEntityUtils.getGsiMetaInfoEntityDto(gsiName, bean);
                metaInfoEntityUtils.updateGsiMetaInfoEntity(gsiName, restInboundDto, bean);
            } else {
                metaInfoEntityUtils.createGsiMetaInfoEntity(gsiName, restInboundDto, bean);
            }
        }
        catch (Exception e){
            LOGGER.error("error while restifying GSI : ", e);
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.EXPORT,
                    "error while restifying GSI", ExceptionSeverity.MAJOR, null);
        }
    }


    }
