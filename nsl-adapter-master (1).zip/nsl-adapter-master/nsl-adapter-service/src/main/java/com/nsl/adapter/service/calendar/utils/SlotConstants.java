package com.nsl.adapter.service.calendar.utils;


public class SlotConstants {

    public static final String BEARER = "Bearer";
    public static final String ORGANIZER = "organizer";
    public static final String START_TIME = "startTime";
    public static final String END_TIME = "endTime";
    public static final String BOOKED = "Booked";
    public static final String AVAILABLE = "Available";
    public static final String COMPLETED = "Completed";
    public static final String NOSHOW = "No Show";
    public static final String CANCEL = "Cancel";
    public static final String ONETOONE = "Personal (1:1)";
    public static final String NSL_SCHEDULER = "NSL_Scheduler";
    public static final String EVENTID = "eventId";
    public static final String GROUP = "Group Appointment";
    public static final String CONFERENCE_TYPE = "conferenceType";
    public static final String CALENDAR_FETCH_API = "/calendar/scheduler/fetch/slots";

    public static final String RESULT = "result";
    public static final String ADDITIONAL_INFO_4 = "additionalInfo4";
    public static final String ADDITIONAL_INFO_1 = "additionalInfo1";
    public static final String ADDITIONAL_INFO_2 = "additionalInfo2";
    public static final String ADDITIONAL_INFO_3 = "additionalInfo3";
    public static final String ADDITIONAL_INFO_5 = "additionalInfo5";
    public static final String METADATA = "metadata";
    public static final String UPDATE = "update";
    public static final String DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    public static final String PARTICIPANT_LIST = "participantList";
    public static final String COMMA = ",";
    public static final String PAYLOAD = "payload";
    public static final String TXN_NSL_ATTRIBUTE = "txnNslAttribute";

    public static final String NAME = "name";
    public static final String VALUES = "values";
    public static final String TITLE = "Title";
    public static final String EVENT_TYPE = "Event Type";
    public static final String ORGANIZER_ENUM_VALUE = "Organizer";
}

