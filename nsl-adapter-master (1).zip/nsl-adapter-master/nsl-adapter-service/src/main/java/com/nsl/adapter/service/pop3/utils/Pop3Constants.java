package com.nsl.adapter.service.pop3.utils;

public class Pop3Constants {
    public static final String POP3_CONNECTION = "NSL_POP3_Connection";
    public static final String POP3_ENTITY = "NSL_POP3_Adapter_Res";
    public static final String SSL_PROCOLS_LIST = "SSLv2Hello SSLv3 TLSv1 TLSv1.1 TLSv1.2";
    public static final String INBOX = "INBOX";
}
