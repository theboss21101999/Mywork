package com.nsl.adapter.service.onedrive.utils;

public class OnedriveConstants {
        public static final String LIST_FILE = "LIST_FILE";
        public static final String INBOUND = "INBOUND";
        public static final String DELETE_FILE = "DELETE_FILE";
        public static final String GET_FILE = "GET_FILE";
        public static final String UPLOAD_ENTITY = "UPLOAD_ENTITY";
        public static final String ID = "id";
        public static final String TEXT ="text/";
        public static final String ONEDRIVE_URL = "https://graph.microsoft.com/v1.0/me/drive/root:/";
        public static final String ONEDRIVE_URL_ID = "https://graph.microsoft.com/v1.0//me/drive/items/";

        private OnedriveConstants(){
            throw new IllegalStateException("utility class");
        }
    }


