package com.nsl.adapter.service.kafka.serviceImpl;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.service.kafka.enums.KafkaParserType;
import com.nsl.adapter.service.kafka.service.KafkaReservedCUService;
import com.nsl.adapter.service.kafka.utils.ConnectionToEntity;
import com.nsl.adapter.service.kafka.utils.InboundKafkaUtil;
import com.nsl.adapter.service.kafka.utils.KafkaParser;
import com.nsl.adapter.service.kafka.utils.KafkaParserFactory;
import com.nsl.adapter.service.utils.ExtSolutionUtil;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnCULayer;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnSlotItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.nsl.adapter.service.kafka.utils.KafkaConstants.JSON;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.KAFKA_INBOUND;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.KAFKA_OUTBOUND;
import static com.nsl.adapter.service.utils.AppConstant.CONFIG_ENTITY_RECORD_ID;
import static com.nsl.adapter.service.utils.AppConstant.OPERATION;
import static com.nsl.adapter.service.utils.AppConstant.PHYSICAL_LAYER;
import static com.nsl.adapter.service.utils.AppConstant.TRIGGER_CES_LAYER;

@Service
public class KafkaReservedCUServiceImpl implements KafkaReservedCUService {
    private static final Logger logger = LoggerFactory.getLogger(KafkaReservedCUServiceImpl.class);

    @Autowired
    ExtSolutionUtil extSolutionUtil;

    @Autowired
    KafkaParserFactory kafkaParserFactory;

    @Autowired
    ConnectionToEntity connectionService;

    @Override
    public TxnData reservedCUService(TriggerCU triggerCu, TxnData transData) {

        List<TxnCULayer> txnCuLayers = transData.getTxnCULayer();
        List<TxnSlotItem> transEntityDetails = null;
        transEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnCuLayers, PHYSICAL_LAYER);

        TxnGeneralEntity txnGeneralEntity = GeneralEntityUtils.getExpectedTxnGeneralEntity(transEntityDetails);
        GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, TRIGGER_CES_LAYER);
        GeneralEntity inputGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, PHYSICAL_LAYER);

        KafkaParser kafkaParser = kafkaParserFactory.createEntity(KafkaParserType.fromValue(JSON));
        String operation = triggerCu.getCuSystemProperties().get(OPERATION);
        try {
            switch (operation) {
                case KAFKA_OUTBOUND:
                    Long connectionId = Long.valueOf(triggerCu.getCuSystemProperties().get(CONFIG_ENTITY_RECORD_ID));
                    KafkaConnectionDto kafkaConnectionDto = connectionService.getConnectionById(connectionId);
                    InboundKafkaUtil.buildConnection(kafkaConnectionDto, triggerCu.getCuSystemProperties());

                    JsonNode result = kafkaParser.callOutBoundKafka(txnGeneralEntity, inputGeneralEntity, kafkaConnectionDto);
                    txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, result);
                    break;
                case KAFKA_INBOUND:
                    logger.info("Call for SFTP inbound, copying physical layer to triggerces layer");
                    break;
            }
            transData = extSolutionUtil.setChangeDriverInTxnData(txnGeneralEntity, LayerType.TRIGGERCES);
            return transData;
        } catch (Exception e) {
            logger.info("error", e);
            return null;
        }
    }

}


