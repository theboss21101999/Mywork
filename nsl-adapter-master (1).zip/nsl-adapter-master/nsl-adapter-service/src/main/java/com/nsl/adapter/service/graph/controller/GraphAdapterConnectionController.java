package com.nsl.adapter.service.graph.controller;

import com.nsl.adapter.commons.dto.connections.GraphOauthConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.graph.OauthGraphConnection;
import com.nsl.adapter.service.graph.service.GraphConnectionService;
import com.nsl.logical.exception.NSLException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class GraphAdapterConnectionController {

    @Autowired
    GraphConnectionService graphConnectionService;

    @Autowired
    OauthGraphConnection oauthConnection;

    @PostMapping(path = "/graph")
    public ApiResponse saveGraphConnection(@RequestBody GraphOauthConnectionDto connectionDto) throws NSLException {

        TxnAdapterConnection result = graphConnectionService.saveGraphConnection(connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationCode(connectionDto, result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);

    }

    @GetMapping(path = "/graph/{attrId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getGraphConnection(@PathVariable("attrId") Long attrId) {

        GraphOauthConnectionDto result = graphConnectionService.getGraphConnection(attrId, true);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);

    }

    @GetMapping(path = "/graph/refreshToken/{attrId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse refreshGraphToken(@PathVariable("attrId") Long attrId) throws NSLException {

        TxnAdapterConnection result = oauthConnection.getRefreshToken(attrId);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }

    @PutMapping(path = "/graph/{attrId}")
    public ApiResponse updateGraphConnection(@PathVariable("attrId") Long attrId,
                                             @RequestBody GraphOauthConnectionDto connectionDto) throws NSLException {

        TxnAdapterConnection result = graphConnectionService.updateGraphConnection(attrId, connectionDto);

        JSONObject url = oauthConnection.getAuthorizationCode(connectionDto, result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, url);
    }


}






