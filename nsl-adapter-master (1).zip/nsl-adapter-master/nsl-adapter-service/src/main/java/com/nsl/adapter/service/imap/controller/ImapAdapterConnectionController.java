package com.nsl.adapter.service.imap.controller;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.commons.dto.connections.ImapConnection;
import com.nsl.adapter.service.imap.service.ImapConnectionService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;



@RestController
@CrossOrigin
@RequestMapping(value = "/connect")

public class ImapAdapterConnectionController {

    @Autowired
    ImapConnectionService imapConnectionService;

    @PostMapping(path = "/imap",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveImapConnection(@RequestBody ImapConnection connectionDto)  {

        TxnAdapterConnection result = imapConnectionService.saveImapConnection(connectionDto);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }


    @GetMapping(path = "/imap/{connectionId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getImapConnection(@PathVariable("connectionId") Long connectionId) {
        ImapConnection response = imapConnectionService.getImapConnection(connectionId, false);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }


    @PutMapping(path = "/imap/{connectionId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse updateImapConnection(@PathVariable("connectionId") Long connectionId, @RequestBody ImapConnection connection) {
        TxnAdapterConnection result = imapConnectionService.updateImapConnection(connection, connectionId);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }
}
