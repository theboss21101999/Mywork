package com.nsl.adapter.service.kafka.utils;

import com.nsl.adapter.commons.dto.connections.KafkaAuthCredential;
import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.commons.enums.KafkaAuthType;
import com.nsl.adapter.service.rest.utils.ConnectionDataTools;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Collections;
import java.util.List;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.*;

@Service
public class KafkaConnectionTools {

    @Autowired
    ConnectionDataTools connectionDataTools;


    public boolean validateDto(KafkaConnectionDto connectionDto){
        if (connectionDto.getConnectionName()==null || connectionDto.getBootstrapServer()==null){
            return false;
        }
        return true;

    }

    public boolean checkConnectionName(String kafkaConnection, String connectionName) {
        return kafkaConnection.equalsIgnoreCase(connectionName);
    }

    public boolean validateAuthCredentials(KafkaAuthCredential credential) {
        if(credential == null)
            return true;
        if(credential.getAuthType() == null)
            return false;
        switch (credential.getAuthType()) {
            case SASL_PLAIN:
                if(credential.getUsername()==null || credential.getPassword()==null)
                    return false;
                break;
        }
        return true;
    }

    public KafkaConnectionDto txnToConnection(TxnGeneralEntityRecord record) {
        KafkaConnectionDto result = new KafkaConnectionDto();
        List<TxnNslAttribute> attributesList = record.getTxnNslAttribute();
        for(TxnNslAttribute attribute : attributesList){
            switch (attribute.getName()){
                case BOOTSTRAP_SERVER:
                    result.setBootstrapServer(Collections.singletonList(attribute.getValues().get(0)));
                    break;
                case PARTITION:
                    result.setPartition(attribute.getValues().get(0));
                    break;
                case CONNECTION_NAME:
                    result.setConnectionName(attribute.getValues().get(0));
                    break;
                case AUTHENTICATION:
                    result.setAuthentication(buildCredentials(attribute));
                    break;
                case ADVANCED_CONFIG:
                    result.setAdvancedConfig(connectionDataTools.createadvancedConfig(attribute));
                    break;
                default:
                    break;
            }
        }
        return result;
    }

    private KafkaAuthCredential buildCredentials(TxnNslAttribute attribute) {
        KafkaAuthCredential kafkaAuthCredential = new KafkaAuthCredential();
        JSONParser jsonparser = new JSONParser();
        try{
            JSONObject json = (JSONObject) jsonparser.parse(connectionDataTools.decryptText(attribute.getValues().get(0)));
            kafkaAuthCredential.setAuthType(JacksonUtils.fromJson(json.get(AUTH_TYPE).toString(), KafkaAuthType.class));

            switch (kafkaAuthCredential.getAuthType()){
                case SASL_PLAIN:
                    kafkaAuthCredential.setUsername(json.get(USERNAME).toString());
                    kafkaAuthCredential.setPassword(json.get(PASSWORD).toString());
                    break;
                default:
                    break;
            }
        }catch (Exception e){
            return null;
        }
        return kafkaAuthCredential;
    }

}
