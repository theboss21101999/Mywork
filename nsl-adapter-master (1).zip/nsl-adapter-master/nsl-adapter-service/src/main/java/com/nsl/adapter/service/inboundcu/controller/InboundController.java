package com.nsl.adapter.service.inboundcu.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.dto.connections.RestInboundDto;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.service.inboundcu.service.GsiResponse;
import com.nsl.adapter.commons.utils.RestApiConstants;
import com.nsl.adapter.service.inboundcu.service.SwaggerJsonBuilder;
import com.nsl.adapter.service.inboundcu.utils.InvokeCu;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TransactionDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import javax.annotation.Resource;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.media.ExampleObject;
/**
 * @author Kankatla SatyaSriram
 */
@RestController
@CrossOrigin
@RequestMapping(value = "/execute")
public class InboundController {

    @Autowired
    InvokeCu invokeCu;

    @Autowired
    SwaggerJsonBuilder swaggerJsonBuilder;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    GsiResponse gsiResponse;
    
    @Operation(summary = "Get Swagger Json", description = "This api is called to Get Swagger Json.", tags = {
    "" })
@ApiResponses(value = { @ApiResponse(responseCode = RestApiConstants.OK_CODE, description = RestApiConstants.GET_SWAGGER_JSON_DESCRIPTION, content = {
    @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseEntity.class))}),
    @ApiResponse(responseCode = RestApiConstants.BAD_REQUEST_CODE, description = RestApiConstants.BAD_REQUEST_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.UNAUTHORIZED_CODE, description = RestApiConstants.UNAUTHORIZED_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.FORBIDDEN_CODE, description = RestApiConstants.FORBIDDEN_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.NOT_FOUND_CODE, description = RestApiConstants.NOT_FOUND_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.INTERNAL_SERVER_ERROR_CODE, description = RestApiConstants.INTERNAL_SERVER_ERROR_DESCRIPTION, content = @Content)})
    @GetMapping(value = "/swagger-json/{cuName}",produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<StreamingResponseBody> getSwaggerJson(@PathVariable(name="cuName") String cuName) {

        String swaggerJson = swaggerJsonBuilder.buildSchema(cuName);

        InputStream inputStream = new ByteArrayInputStream(swaggerJson.getBytes(StandardCharsets.UTF_8));
        StreamingResponseBody responseBody = outputStream -> {
            int numberOfBytesToWrite;
            byte[] data = new byte[1024];
            while ((numberOfBytesToWrite = inputStream.read(data, 0, data.length)) != -1) {
                outputStream.write(data, 0, numberOfBytesToWrite);
            }
            inputStream.close();
        };

        return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM).body(responseBody);
    }

    //...........................................................................................................

    /**
     controller for invoking gsi using body , headers,query
     */
    @Operation(summary = "Execute CU Using XML VALUE", description = "This api is called to execute CU BY XML VALUE.", tags = {
    "" })
@ApiResponses(value = { @ApiResponse(responseCode = RestApiConstants.OK_CODE, description = RestApiConstants.EXECUTE_CU_BY_XML_VALUE_DESCRIPTION, content = {
    @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseEntity.class))}),
    @ApiResponse(responseCode = RestApiConstants.BAD_REQUEST_CODE, description = RestApiConstants.BAD_REQUEST_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.UNAUTHORIZED_CODE, description = RestApiConstants.UNAUTHORIZED_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.FORBIDDEN_CODE, description = RestApiConstants.FORBIDDEN_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.NOT_FOUND_CODE, description = RestApiConstants.NOT_FOUND_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.INTERNAL_SERVER_ERROR_CODE, description = RestApiConstants.INTERNAL_SERVER_ERROR_DESCRIPTION, content = @Content)})
    @PostMapping(value = { "/{cuName}", "/{cuName}/{version}" }, consumes = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<Map<String,Object>> executeCu(@PathVariable(name="cuName") String cuName,
                                                        @PathVariable(name="version" ,required = false) String version,
                                                        @Nullable @RequestBody String xmlString,
                                                        @RequestHeader Map<String,String> headerMap,
                                                        @RequestParam Map<String,String> queryMap) throws NSLException, JsonProcessingException {

        if (xmlString == null)
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        return executeCu(cuName,version, null, xmlString, new ArrayList<>(), headerMap , queryMap);
    }
    
    @Operation(summary = "Execute CU Using JSON VALUE", description = "This api is called to execute CU BY JSON VALUE.", tags = {
    "" })
@ApiResponses(value = { @ApiResponse(responseCode = RestApiConstants.OK_CODE, description = RestApiConstants.EXECUTE_CU_BY_JSON_VALUE_DESCRIPTION, content = {
    @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseEntity.class))}),
    @ApiResponse(responseCode = RestApiConstants.BAD_REQUEST_CODE, description = RestApiConstants.BAD_REQUEST_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.UNAUTHORIZED_CODE, description = RestApiConstants.UNAUTHORIZED_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.FORBIDDEN_CODE, description = RestApiConstants.FORBIDDEN_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.NOT_FOUND_CODE, description = RestApiConstants.NOT_FOUND_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.INTERNAL_SERVER_ERROR_CODE, description = RestApiConstants.INTERNAL_SERVER_ERROR_DESCRIPTION, content = @Content)})
    @PostMapping(value = { "/{cuName}", "/{cuName}/{version}" }, consumes = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<Map<String,Object>> executeCu(@PathVariable(name="cuName") String cuName,
                                                        @PathVariable(name="version" ,required = false) String version,
                                                        @Nullable @RequestBody JsonNode body,
                                                        @RequestHeader Map<String,String> headerMap,
                                                        @RequestParam Map<String,String> queryMap) throws NSLException, JsonProcessingException {

        return executeCu(cuName, version, body, null, new ArrayList<>(), headerMap , queryMap);
    }
    
    @Operation(summary = "Execute CU Using FORM DATA VALUE", description = "This api is called to execute CU BY FORM DATA VALUE.", tags = {
    "" })
@ApiResponses(value = { @ApiResponse(responseCode = RestApiConstants.OK_CODE, description = RestApiConstants.EXECUTE_CU_BY_FORMDATA_VALUE_DESCRIPTION, content = {
    @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseEntity.class))}),
    @ApiResponse(responseCode = RestApiConstants.BAD_REQUEST_CODE, description = RestApiConstants.BAD_REQUEST_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.UNAUTHORIZED_CODE, description = RestApiConstants.UNAUTHORIZED_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.FORBIDDEN_CODE, description = RestApiConstants.FORBIDDEN_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.NOT_FOUND_CODE, description = RestApiConstants.NOT_FOUND_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.INTERNAL_SERVER_ERROR_CODE, description = RestApiConstants.INTERNAL_SERVER_ERROR_DESCRIPTION, content = @Content)})
    @PostMapping(value = { "/{cuName}", "/{cuName}/{version}" }, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<Map<String,Object>> executeCu(@PathVariable(name = "cuName") String cuName,
                                                       @PathVariable(name = "version", required = false) String version,
                                                       @Nullable @RequestPart("reqBody") JsonNode body,
                                                       @Nullable @RequestPart("xmlBody") String xmlString,
                                                       @Nullable @RequestPart("file") List<MultipartFile> file,
                                                       @RequestHeader Map<String, String> headerMap,
                                                       @RequestParam Map<String, String> queryMap) throws NSLException, JsonProcessingException {

        if (xmlString != null)
            xmlString = xmlString.replaceAll(AppConstants.XMLRegex,"");
        return invokeCu.invokeCu(cuName,version, body,xmlString, file, headerMap , queryMap, bean);
    }
    
    @Operation(summary = "Get Status", description = "This api is called to Get Status.", tags = {
    "" })
@ApiResponses(value = { @ApiResponse(responseCode = RestApiConstants.OK_CODE, description = RestApiConstants.GET_STATUS_DESCRIPTION, content = {
    @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseEntity.class))}),
    @ApiResponse(responseCode = RestApiConstants.BAD_REQUEST_CODE, description = RestApiConstants.BAD_REQUEST_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.UNAUTHORIZED_CODE, description = RestApiConstants.UNAUTHORIZED_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.FORBIDDEN_CODE, description = RestApiConstants.FORBIDDEN_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.NOT_FOUND_CODE, description = RestApiConstants.NOT_FOUND_DESCRIPTION, content = @Content),
    @ApiResponse(responseCode = RestApiConstants.INTERNAL_SERVER_ERROR_CODE, description = RestApiConstants.INTERNAL_SERVER_ERROR_DESCRIPTION, content = @Content)})
    @GetMapping(value = "/{cuName}/instances/{transId}")
    public ResponseEntity<Object> getStatus(@PathVariable(name="transId") String transId) {

        TransactionDto transactionDto = gsiResponse.getTransactionById(transId);

        if("TRIGGERED".equals(transactionDto.getTransactionStatus())){
            Map<String,Object> body = new HashMap<>();
            body.put("response","transaction in progress");
            body.put("currentCu",transactionDto.getTriggerCuName());
            return ResponseEntity.status(HttpStatus.ACCEPTED).body(body);
        }
        else{
            HashMap<String, Object> output = gsiResponse.getCuTxnData(transId, transactionDto.getContainerCuId());
            ResponseEntity<Object> response ;
            if(output == null ) {
                Map<String,Object> body = new HashMap<>();
                body.put("response","failed to read data in information layer");
                response = ResponseEntity.status(HttpStatus.CONFLICT).body(body);
            } else {
                response = ResponseEntity.status(HttpStatus.OK).body(output);
            }
            return response;
        }

    }

    @PostMapping(value = { "/v1/restifyGsi/{gsiName}", "/v1/restifyGsi/{gsiName}/{version}" }, consumes = MediaType.APPLICATION_JSON_VALUE)
    public com.nsl.common.config.ApiResponse saveRestGsi(@RequestBody RestInboundDto restInboundDto,
                                                         @PathVariable(name = "gsiName") String gsiName){
        invokeCu.invokeRestGsi(gsiName,restInboundDto,bean);
        return new com.nsl.common.config.ApiResponse(HttpStatus.OK, SUCCESS);
    }

    @GetMapping(value = "/v1/restifyGsi/swagger-json/{gsiName}",produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<StreamingResponseBody> getGSISwaggerJson(@PathVariable(name="gsiName") String gsiName) {

        String swaggerJson = swaggerJsonBuilder.buildGSISchema(gsiName);

        InputStream inputStream = new ByteArrayInputStream(swaggerJson.getBytes(StandardCharsets.UTF_8));
        StreamingResponseBody responseBody = outputStream -> {
            int numberOfBytesToWrite;
            byte[] data = new byte[1024];
            while ((numberOfBytesToWrite = inputStream.read(data, 0, data.length)) != -1) {
                outputStream.write(data, 0, numberOfBytesToWrite);
            }
            inputStream.close();
        };

        return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM).body(responseBody);
    }



}
