package com.nsl.adapter.service.keymanager.dto;

import com.nsl.adapter.service.keymanager.enums.KmsType;

import java.util.Map;

public class KeyManagerDto {
    private String alias;
    private String name;
    private String password;
    private KmsType kmsType;
    private Boolean isEncryptionKeyPrivate;
    private String encryptionKeyType;
    Map<String, String> metadata;

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public KmsType getKmsType() {
        return kmsType;
    }

    public void setKmsType(KmsType kmsType) {
        this.kmsType = kmsType;
    }

    public Boolean getEncryptionKeyPrivate() {
        return isEncryptionKeyPrivate;
    }

    public void setEncryptionKeyPrivate(Boolean encryptionKeyPrivate) {
        isEncryptionKeyPrivate = encryptionKeyPrivate;
    }

    public String getEncryptionKeyType() {
        return encryptionKeyType;
    }

    public void setEncryptionKeyType(String encryptionKeyType) {
        this.encryptionKeyType = encryptionKeyType;
    }

    public Map<String, String> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, String> metadata) {
        this.metadata = metadata;
    }
}
