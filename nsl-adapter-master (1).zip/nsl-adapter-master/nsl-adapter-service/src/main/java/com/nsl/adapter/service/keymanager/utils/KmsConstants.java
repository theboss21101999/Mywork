package com.nsl.adapter.service.keymanager.utils;

public class KmsConstants {
    public static final String KMS_CONNECTION = "NSL_Kms_Connect";
    public static final String KMS_ALIAS = "alias";
    public static final String KMS_NAME = "name";
    public static final String KMS_TYPE = "kmsType";
    public static final String KMS_AWSID = "awsId";
    public static final String KMS_DSDURL = "dsdUrl";
    public static final String KMS_CREATETIME = "createdTime";
    public static final String KMS_EXPIRYTIME = "expiryTime";
    public static final String KMS_SHA256 = "sha256Key";
    public static final String KMS_PROPERTIES = "properties";
    public static final String KMS_MODIFYTIME = "modifiedTime";
    public static final String KMS_ISPRIVATE = "isEncryptionKeyPrivate";
    public static final String KMS_FILE_EXTENSION = "fileExtension";
    public static final String KMS_AWSARN = "awsArn";
    public static final String KMS_ENCRYPTIONKEYTYPE = "encryptionKeyType";

    public static final String KMS_CACERTS_TEMPLATE = "$cacerts";
    public static final String KMS_CACERTS = "cacerts";
    public static final String KMS_EMPTY_CACERTS = "emptycacerts";
}
