package com.nsl.adapter.service.dto;

import java.util.List;

public class SwaggerCategoryDto {

    List<SwaggerTag> swaggerTagList;

    public List<SwaggerTag> getSwaggerTagList() {
        return swaggerTagList;
    }

    public void setSwaggerTagList(List<SwaggerTag> swaggerTagList) {
        this.swaggerTagList = swaggerTagList;
    }
}
