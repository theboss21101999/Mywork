package com.nsl.adapter.service.graph.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.GraphOauthConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.Locale;

@Service
public class GraphConnectionService {

    private static final ConnectionDtoType connType = ConnectionDtoType.Graph;

    private static final Logger LOGGER = LoggerFactory.getLogger(GraphConnectionService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    MessageSource messageSource;
    
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    public TxnAdapterConnection saveGraphConnection(GraphOauthConnectionDto connectionDto) {

        if (connectionDto.getClientId() == null || connectionDto.getClientSecret() == null ||
                 connectionDto.getScope() == null || connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,
                                    messageSource.getMessage("Paas_Adapter_182", null, Locale.ENGLISH) , null);

        connectionDataToolsV3.connectionCheck(ConnectionDtoType.Graph, connectionDto.getConnectionName(), authBean);

        connectionDto.setClientSecret(connectionDataToolsV3.saveSecret(connType,"clientSecret",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getClientSecret()));

        TxnAdapterConnection connection = new TxnAdapterConnection();
        connection.setConnection(connectionDto);
        connection.setConnectionDtoType(connType);

        LOGGER.info("saving Graph connection");
        return adapterConnnectionsDao.saveConnection(connection ,authBean );
    }

    public GraphOauthConnectionDto getGraphConnection(Long id, boolean hide) {

        TxnAdapterConnection txnGeneralEntityRecord = adapterConnnectionsDao.getConnectionByRecordId(connType,id,authBean);
        return txnToGraphDto(txnGeneralEntityRecord,hide);
    }

    public TxnAdapterConnection updateGraphConnection(Long id, GraphOauthConnectionDto connectionDto) {

        if (connectionDto.getClientId() == null ||
                connectionDto.getScope() == null || connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,
                    messageSource.getMessage("Paas_Adapter_178", null, Locale.ENGLISH) , null);

        LOGGER.info("updating Graph connection");

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(connType, id ,authBean);
        connectionDataToolsV3.connectionNameCheck(previousConnection,connectionDto.getConnectionName());

        connectionDto.setClientSecret(connectionDataToolsV3.updateSecret(connType,"clientSecret",
                connectionDto.getConnectionName(),authBean.getTenantId(),connectionDto.getClientSecret()));
        connectionDto.setRefreshToken(connectionDataToolsV3.updateSecret(connType,"refreshToken",
                connectionDto.getConnectionName(),authBean.getTenantId(),connectionDto.getRefreshToken()));

        previousConnection.setConnection(connectionDto);

        return adapterConnnectionsDao.saveConnection(previousConnection, authBean );
    }

    public GraphOauthConnectionDto txnToGraphDto(TxnAdapterConnection record, boolean hide) {

        GraphOauthConnectionDto connectionDto = (GraphOauthConnectionDto) record.getConnection();
        if (connectionDto == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,
                        messageSource.getMessage("Paas_Adapter_178", null, Locale.ENGLISH) , null);

        if (!hide){
            connectionDto.setClientSecret(connectionDataToolsV3.getSecret(connectionDto.getClientSecret()));
            connectionDto.setRefreshToken(connectionDataToolsV3.getSecret(connectionDto.getRefreshToken()));
        }

        return connectionDto;
    }

}