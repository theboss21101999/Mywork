package com.nsl.adapter.service.service;

import com.nsl.adapter.service.db.service.DBAdapterInboundService;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.service.exception.ExtAuthException;
import com.nsl.adapter.service.onedrive.service.OneDriveInboundService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class InboundAdapterFactory {






    @Autowired
    DBAdapterInboundService dbAdapterInboundService;

    @Autowired
    OneDriveInboundService  oneDriveInboundService;
    @Autowired
    MqttInboundService mqttInboundService;


    @Autowired
    private MessageSource messageSource;

    public InboundIntegrationService getInboundIntegrationAdapter(AdapterType adapterType){
        switch (adapterType){
            case DB:
                return dbAdapterInboundService;
            case ONEDRIVE:
                return oneDriveInboundService;
            case MQTT:
                return mqttInboundService;

            default:
                break;
        }
        throw new ExtAuthException(String.format( messageSource.getMessage("Paas_Adapter_89", null, Locale.ENGLISH), adapterType.toString()));
    }

}
