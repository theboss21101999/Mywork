package com.nsl.adapter.service.kafka.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.RESPONSE_JSON;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.TOPIC;

@Service
public class KafkaJSONParser implements KafkaParser{
    private static final Logger logger = LoggerFactory.getLogger(KafkaJSONParser.class);

    @Autowired
    EntityToJSONUtil entityToJSONUtil;
    
    @Override
    public JsonNode callOutBoundKafka(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity, KafkaConnectionDto connection){
        try{

                Map<String, NslAttribute> dataTypeMap = new HashMap<>();
                entityToJSONUtil.getDataTypeMap(dataTypeMap, inputGeneralEntity,"");
                JSONObject transObject = entityToJSONUtil.createRequestForRestAdapter(dataTypeMap,txnGeneralEntity,inputGeneralEntity,"");
                String kafkaMessage = transObject.toString();
                KafkaProducerConnectionUtil kafkaProducerConnectionService = new KafkaProducerConnectionUtil(connection);
                kafkaProducerConnectionService.sendMessageTokafka(kafkaMessage, String.valueOf(connection.getAdvancedConfig().get(TOPIC)));
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode result = objectMapper.readTree(RESPONSE_JSON);
                return result;
        }catch(Exception e){
                logger.info("error",e);
                return null;
        }
    }
        
    @Override
    public JsonNode callInBoundKafka(GeneralEntity tcesGeneralEntity, KafkaConnectionDto connection) {
        return null;
    }
             
    
}
