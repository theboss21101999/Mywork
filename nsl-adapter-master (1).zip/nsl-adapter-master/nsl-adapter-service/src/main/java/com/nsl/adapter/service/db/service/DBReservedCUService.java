package com.nsl.adapter.service.db.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import org.springframework.boot.configurationprocessor.json.JSONException;
import java.sql.SQLException;

public interface DBReservedCUService {
    TxnData reservedCUService(TriggerCU triggerCu, TxnData transData) throws JSONException, NSLException, SQLException, JsonProcessingException;

}
