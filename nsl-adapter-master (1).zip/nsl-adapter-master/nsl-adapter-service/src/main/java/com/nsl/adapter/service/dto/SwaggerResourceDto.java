package com.nsl.adapter.service.dto;

import java.util.List;

public class SwaggerResourceDto {

    public SwaggerResourceDto() {

    }

    private List<PathOperationDto> pathOperationDtoList;

    public List<PathOperationDto> getPathOperationDtoList() {
        return pathOperationDtoList;
    }

    public void setPathOperationDtoList(List<PathOperationDto> pathOperationDtoList) {
        this.pathOperationDtoList = pathOperationDtoList;
    }
}
