package com.nsl.adapter.service.enums;

public enum SmtpConnection {
    //host
    HOST("host"),
    //port
    PORT("port"),
    //connection Name
    CONNECTION_NAME("connectionName"),
    //password
    PASSWORD("password"),
    //from email
    FROM("from"),
    //username
    USERNAME("username"),
    //advanced config
    ADVANCED_CONFIG("advancedConfig");

    private final String value;
    SmtpConnection(final String value){
        this.value = value;
    }

    //get value
    public String getValue(){
        return this.value;
    }

    //from String
    public static SmtpConnection fromString(String value){
        for(SmtpConnection field : SmtpConnection.values()) {
            if(field.value.equalsIgnoreCase(value)){
                return field;
            }
        }
        return null;
    }

}
