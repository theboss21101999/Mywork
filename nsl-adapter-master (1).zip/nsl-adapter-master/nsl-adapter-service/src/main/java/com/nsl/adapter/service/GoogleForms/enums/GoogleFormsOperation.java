package com.nsl.adapter.service.GoogleForms.enums;

public enum GoogleFormsOperation {

    CREATE_NEW_FORM,
    GET_FORM_DETAIL,
    UPDATE_THE_FORM;
}
