package com.nsl.adapter.service.onedrive.serviceimpl;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.service.exception.AdapterException;
import com.nsl.adapter.service.onedrive.service.OnedriveReservedCUService;
import com.nsl.adapter.service.onedrive.utils.OnedriveConstants;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.service.utils.ExtSolutionUtil;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnCULayer;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnSlotItem;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class OnedriveReservedCUServiceImpl implements OnedriveReservedCUService {

    private static final Logger LOGGER = LoggerFactory.getLogger(OnedriveReservedCUServiceImpl.class);

    @Autowired
    OnedriveOperations onedriveOperations;

    @Autowired
    ExtSolutionUtil extSolutionUtil;

    @Autowired
    EntityToJSONUtil entityToJSONUtil;

    @Override
    public TxnData reservedCUService(TriggerCU triggerCu, TxnData transData)
            throws IOException, JSONException, NSLException, AdapterException {

        LOGGER.info("Onedrive implementation :");
        List<TxnCULayer> txnCuLayers = transData.getTxnCULayer();
        List<TxnSlotItem> transEntityDetails = null;
        transEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnCuLayers, AppConstant.PHYSICAL_LAYER);
        List<TxnGeneralEntity> txnGeneralEntity =
                GeneralEntityUtils.getExpectedTxnMultipleGeneralEntities(transEntityDetails);
        List<GeneralEntity> inputGeneralEntity =
                GeneralEntityUtils.getTriggerCUMultipleGeneralEntities(triggerCu, AppConstant.PHYSICAL_LAYER);
        Map<String, NslAttribute> dataTypeMap = new HashMap<>();
        entityToJSONUtil.getDataTypeMap(dataTypeMap, inputGeneralEntity.get(0), "");
        JSONObject transObject = entityToJSONUtil.createRequestForRestAdapter(dataTypeMap,
                txnGeneralEntity.get(0), inputGeneralEntity.get(0),"");

        String OnedriveMethod =triggerCu.getCuSystemProperties().get(AppConstant.OPERATION);
        String fileName=transObject.optString(AppConstant.FILENAME);
        String fileType=transObject.optString(AppConstant.FILETYPE);
        String folderName= transObject.optString(AppConstant.FOLDER_NAME);
        String fileKey= transObject.optString(AppConstant.FILE_KEY);

        LOGGER.info("Onedrive Operations :");

        switch(OnedriveMethod.toUpperCase(Locale.ENGLISH)){
            case OnedriveConstants.UPLOAD_ENTITY:
                GeneralEntity generalEntity = inputGeneralEntity.get(1);
                TxnGeneralEntity txnGeneralEntity1 = txnGeneralEntity.get(1);
                JsonNode jsonnode= onedriveOperations.uploadToOneDrive(generalEntity, txnGeneralEntity1,
                                fileName,folderName, fileType, triggerCu);
                return extSolutionUtil.OutputtoEntityMapping(triggerCu, jsonnode);

            case OnedriveConstants.GET_FILE:
                return onedriveOperations.getEntity(fileKey, triggerCu);

            case OnedriveConstants.DELETE_FILE:
                JsonNode jsonnode2= onedriveOperations.deleteFile(fileKey, triggerCu);
                return extSolutionUtil.OutputtoEntityMapping(triggerCu, jsonnode2);

            case OnedriveConstants.LIST_FILE:
                JsonNode jsonNode3= onedriveOperations.listFile(triggerCu, folderName);
                return extSolutionUtil.OutputtoEntityMapping(triggerCu, jsonNode3);

            default :
                return null;
        }

    }
}
