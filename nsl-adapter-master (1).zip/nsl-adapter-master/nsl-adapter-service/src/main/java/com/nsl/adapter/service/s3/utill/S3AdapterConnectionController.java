package com.nsl.adapter.service.s3.utill;

import com.nsl.adapter.commons.dto.connections.S3AdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.AppConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class S3AdapterConnectionController {

    @Autowired
    S3ConnectionDataTools s3ConnectionDataTools;

    @PostMapping(path = "/s3")
    public ApiResponse saveS3Connection(@RequestBody S3AdapterConnectionDto s3AdapterConnectionDto) {

        TxnAdapterConnection response = s3ConnectionDataTools.saveS3Conn(s3AdapterConnectionDto);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @GetMapping(path = "/s3/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getS3Connection(@PathVariable("id") Long attrId) {

        S3AdapterConnectionDto response = s3ConnectionDataTools.getS3Conn(attrId, Boolean.TRUE);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @PutMapping(path = "/s3/{id}")
    public ApiResponse updateS3Connection(@PathVariable("id") Long attrId, @RequestBody S3AdapterConnectionDto s3AdapterConnectionDto) {

        TxnAdapterConnection response = s3ConnectionDataTools.updateS3Conn(s3AdapterConnectionDto, attrId);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);

    }


}
