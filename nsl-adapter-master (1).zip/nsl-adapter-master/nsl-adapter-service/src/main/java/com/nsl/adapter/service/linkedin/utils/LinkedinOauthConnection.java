package com.nsl.adapter.service.linkedin.utils;

import com.google.api.client.auth.oauth2.*;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.nsl.adapter.commons.dto.connections.LinkedinAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.linkedin.service.LinkedinConnectionService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.adapter.service.v2.utills.RedisIntegration;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;



import javax.annotation.Resource;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;


import static com.nsl.adapter.service.linkedin.utils.LinkedinConstants.*;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;
@Service
public class LinkedinOauthConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(LinkedinOauthConnection.class);

    @Autowired
    LinkedinConnectionService linkedinConnectionService;

    @Autowired
    RedisIntegration redisIntegration;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    CdmUtils cdmUtils;

    @Autowired
    AdaptorProperties adaptorProperties;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    Base64.Encoder encoder = Base64.getEncoder();


    public String getStateParam(Long connId, String connName, String tenantId) {
        Map<String, Object> valueMap = new HashMap<>();
        valueMap.put(AppConstant.CONFIG_ENTITY_RECORD_ID, connId.toString());
        valueMap.put(AppConstant.ADAPTER, LINKEDIN);
        valueMap.put(AppConstant.TENANTID, tenantId);
        valueMap.put(AppConstant.ENV_NAME ,cdmUtils.getEnvironmentNameByTenantId(tenantId));
        valueMap.put(AppConstant.CONNECTION_NAME, connName);
        return encodeData(Objects.requireNonNull(JacksonUtils.toJson(valueMap)));
    }




    public JSONObject getAuthorizationcode(TxnAdapterConnection result) throws NSLException {

        LOGGER.info("generating redirect url ..");
        try {
            LinkedinAdapterConnectionDto connectionDto = (LinkedinAdapterConnectionDto) result.getConnection();
            AuthorizationCodeRequestUrl url = new AuthorizationCodeRequestUrl(LINKEDIN_AUTH_TOKEN, connectionDto.getAppId());
            url.setRedirectUri(adaptorProperties.getRedirectUrl()).setScopes(connectionDto.getScope())
                    .set(PROMPT,CONSENT).set(ACCESS_TYPE,OFFLINE).setResponseTypes(Collections.singleton(CODE));

            String stateParams = getStateParam(result.getRecordId(), connectionDto.getConnectionName(), bean.getTenantId());
            LOGGER.info("appending state params to redirect url {} ", stateParams);
            url.set(STATE, stateParams);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(AppConstant.RESULT, result);
            jsonObject.put(Url, url.build());

            return jsonObject;
        } catch (Exception e) {
            LOGGER.error("exception occurred during generating redirect url: ",e );
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_1", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER,e);
        }
    }

    public TxnAdapterConnection getRefreshToken(Long id) throws NSLException {

        String cacheName = LINKEDIN + "_" + bean.getTenantId();

        String code = redisIntegration.getOAuthCode(cacheName, id.toString());
        LOGGER.info("updating connection with code: {}",code);
        try {
            LinkedinAdapterConnectionDto connectionDto = linkedinConnectionService.getLinkedinConnection(id,false);
            connectionDto.setAppSecret(connectionDataToolsV3.getSecret(connectionDto.getAppSecret()));
            connectionDto.setAccessToken(getAccessToken(connectionDto, code));
            return linkedinConnectionService.updateLinkedinConnection(id, connectionDto);
        } catch (Exception e) {
            LOGGER.error("failed to generate refresh Token",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,messageSource.getMessage
                    ("Paas_Adapter_13", null, Locale.ENGLISH) + e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }
    }

    public String getAccessToken(LinkedinAdapterConnectionDto connectionDto, String code) throws IOException {

        TokenRequest request = new AuthorizationCodeTokenRequest(new NetHttpTransport(), new JacksonFactory(), new GenericUrl(LINKEDIN_ACCESS_TOKEN), code)
                .setRedirectUri(adaptorProperties.getRedirectUrl()).setGrantType(AUTHORIZATION_CODE).set("client_id",connectionDto.getAppId()).set("client_secret",connectionDto.getAppSecret());

        TokenResponse response = request.execute();
        return response.getAccessToken();
    }


    private  String encodeData(String value){
        return encoder.encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }
}
