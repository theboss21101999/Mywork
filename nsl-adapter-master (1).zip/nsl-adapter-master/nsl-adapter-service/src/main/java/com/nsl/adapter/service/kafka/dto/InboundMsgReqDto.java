package com.nsl.adapter.service.kafka.dto;

public class InboundMsgReqDto {

    private String tenantId;
    private String userEmail;
    private Long userId;
    private Long gsiMasterId;
    private String cuName;

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getGsiMasterId() {
        return gsiMasterId;
    }

    public void setGsiMasterId(Long gsiMasterId) {
        this.gsiMasterId = gsiMasterId;
    }

    public String getCuName() {
        return cuName;
    }

    public void setCuName(String cuName) {
        this.cuName = cuName;
    }
}
