package com.nsl.adapter.service.ciscoWebex.Connection;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.commons.dto.connections.CiscoOauthconnectionDto;
import com.nsl.adapter.service.ciscoWebex.utils.CiscoConstants;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.List;
import java.util.Locale;

@Service
public class CiscoConnectionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CiscoConnectionService.class);

    private static final ConnectionDtoType connType = ConnectionDtoType.Cisco;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    MessageSource messageSource;
    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;


    public TxnAdapterConnection ciscoSave(CiscoOauthconnectionDto connectionDto) {

        if (connectionDto.getClientId() == null || connectionDto.getClientSecret() == null ||
                connectionDto.getScope() == null || connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_82", null, Locale.ENGLISH) , null);

        connectionDataToolsV3.connectionCheck(ConnectionDtoType.Cisco,connectionDto.getConnectionName(),authBean);
        LOGGER.info("saving Cisco connection");
        connectionDto.setClientSecret(connectionDataToolsV3.saveSecret(connType,"clientSecret",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getClientSecret()));

        TxnAdapterConnection connection = new TxnAdapterConnection();
        connection.setConnection(connectionDto);
        connection.setConnectionDtoType(connType);
        return adapterConnnectionsDao.saveConnection(connection ,authBean );
    }

    public CiscoOauthconnectionDto getCiscoConnection(Long id, boolean hide){

        TxnAdapterConnection txnGeneralEntityRecord = adapterConnnectionsDao.getConnectionByRecordId(connType,id,authBean);
        return txnToCiscoDto(txnGeneralEntityRecord,hide);
    }

    public TxnAdapterConnection updateCiscoEntity(Long id, CiscoOauthconnectionDto connectionDto){

        if (connectionDto.getClientId() == null ||
                connectionDto.getScope() == null || connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,
                    messageSource.getMessage("Paas_Adapter_178", null, Locale.ENGLISH) , null);

        LOGGER.info("updating Graph connection");

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(connType, id ,authBean);
        connectionDataToolsV3.connectionNameCheck(previousConnection,connectionDto.getConnectionName());

        connectionDto.setClientSecret(connectionDataToolsV3.updateSecret(connType,"clientSecret",
                connectionDto.getConnectionName(),authBean.getTenantId(),connectionDto.getClientSecret()));
        connectionDto.setRefreshToken(connectionDataToolsV3.updateSecret(connType,"refreshToken",
                connectionDto.getConnectionName(),authBean.getTenantId(),connectionDto.getRefreshToken()));

        previousConnection.setConnection(connectionDto);

        return adapterConnnectionsDao.saveConnection(previousConnection, authBean );
    }

    public CiscoOauthconnectionDto txnToCiscoDto(TxnAdapterConnection record, boolean hide){

        CiscoOauthconnectionDto connectionDto = (CiscoOauthconnectionDto) record.getConnection();
        if (connectionDto == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,
                    messageSource.getMessage("Paas_Adapter_178", null, Locale.ENGLISH) , null);

        if (!hide){
            connectionDto.setClientSecret(connectionDataToolsV3.getSecret(connectionDto.getClientSecret()));
            connectionDto.setRefreshToken(connectionDataToolsV3.getSecret(connectionDto.getRefreshToken()));
        }

        return connectionDto;
    }

}