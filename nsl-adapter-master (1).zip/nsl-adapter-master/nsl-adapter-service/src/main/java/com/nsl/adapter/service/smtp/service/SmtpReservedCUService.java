package com.nsl.adapter.service.smtp.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import org.springframework.boot.configurationprocessor.json.JSONException;

public interface SmtpReservedCUService {

    TxnData reservedCUService(TriggerCU triggerCu, TxnData transData) throws
            JSONException, NSLException, JsonProcessingException;
}
