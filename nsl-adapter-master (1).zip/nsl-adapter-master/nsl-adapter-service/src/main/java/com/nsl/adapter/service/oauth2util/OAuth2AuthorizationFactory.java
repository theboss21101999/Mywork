package com.nsl.adapter.service.oauth2util;

import com.nsl.adapter.service.exception.ExtAuthException;
import com.nsl.adapter.commons.dto.connections.OAuthGrantType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class OAuth2AuthorizationFactory {

    @Autowired
    ClientCredentialFlowAuthorization clientCredentialFlowAuthorization;

    @Autowired
    AuthCodeFlowAuthorization authCodeFlowAuthorization;

    @Autowired
    private MessageSource messageSource;
    @Autowired
    PasswordFlowAuthorization passwordFlowAuthorization;

    public OAuth2FlowAuthorization getOAuthAuthorization(OAuthGrantType oAuthGrantType) {
        switch (oAuthGrantType) {
            case AUTHORIZATIONCODE:
            case AUTHORIZATIONCODE_PKCE:
                return authCodeFlowAuthorization;
            case CLIENTCREDENTIALS:
                return clientCredentialFlowAuthorization;
            case PASSWORD:
                return passwordFlowAuthorization;
		default:
			break;
        }
        throw new ExtAuthException(String.format(messageSource.getMessage("Paas_Adapter_61", null, Locale.ENGLISH), oAuthGrantType.getGranttype()));
    }
}
