
package com.nsl.adapter.service.Docusign.enums;

public enum DocusignOperation {
//    GET_USER_INFO,
    CREATE_ENVELOPE,
    ENVELOPE_STATUS,
    LOCK_ENVELOPE,
    DELETE_LOCK,
    CREATE_ENVELOPE_MULTI_SIGNERS
//    CREATE_TEMPLATE
}