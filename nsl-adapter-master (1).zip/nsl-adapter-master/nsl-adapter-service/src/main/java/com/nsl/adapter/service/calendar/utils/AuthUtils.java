package com.nsl.adapter.service.calendar.utils;

import com.nsl.logical.config.AuthenticatedUserDetails;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.springframework.stereotype.Service;

@Service
public class AuthUtils {

    public AuthenticatedUserDetailsImpl getAuthDetails(AuthenticatedUserDetails authenticatedUserDetails) {
        return new AuthenticatedUserDetailsImpl(authenticatedUserDetails.getUserId(),
                authenticatedUserDetails.getRoleList(), authenticatedUserDetails.getTenantId(),
                authenticatedUserDetails.getAuthToken(), authenticatedUserDetails.getEmailId());
    }
}
