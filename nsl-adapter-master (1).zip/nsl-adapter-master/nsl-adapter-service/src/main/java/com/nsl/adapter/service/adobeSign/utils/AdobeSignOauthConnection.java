package com.nsl.adapter.service.adobeSign.utils;

import com.google.api.client.auth.oauth2.*;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.nsl.adapter.commons.dto.connections.AdobeSignAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.adobeSign.service.AdobeSignConnectionService;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.adapter.service.v2.utills.RedisIntegration;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static com.nsl.adapter.service.adobeSign.utils.AdobeSignConstants.*;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class AdobeSignOauthConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdobeSignOauthConnection.class);

    @Autowired
    AdobeSignConnectionService adobeSignConnectionService;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    RedisIntegration redisIntegration;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    CdmUtils cdmUtils;

    @Autowired
    AdaptorProperties adaptorProperties;

    @Autowired
    private MessageSource messageSource;

    Base64.Encoder encoder = Base64.getEncoder();


    public String getStateParam(Long connId, String connName, String tenantId) {
        Map<String, Object> valueMap = new HashMap<>();
        valueMap.put(AppConstant.CONFIG_ENTITY_RECORD_ID, connId.toString());
        valueMap.put(AppConstant.ADAPTER, ADOBESIGN);
        valueMap.put(AppConstant.TENANTID, tenantId);
        valueMap.put(AppConstant.ENV_NAME ,cdmUtils.getEnvironmentNameByTenantId(tenantId));
        valueMap.put(AppConstant.CONNECTION_NAME, connName);

        return encodeData(Objects.requireNonNull(JacksonUtils.toJson(valueMap)));
    }

    public JSONObject getAuthorizationcode(TxnAdapterConnection result) throws NSLException {

        LOGGER.info("generating redirect url ..");
        try {
            AdobeSignAdapterConnectionDto connectionDto=(AdobeSignAdapterConnectionDto) result.getConnection();
            AuthorizationCodeRequestUrl url = new AuthorizationCodeRequestUrl(ADOBESIGN_AUTH_TOKEN, connectionDto.getAppId());
            url.setRedirectUri(adaptorProperties.getRedirectUrl()).setScopes(connectionDto.getScope()).setResponseTypes(Collections.singleton(CODE));

            String stateParams = getStateParam(result.getRecordId(), connectionDto.getConnectionName(), bean.getTenantId());
            LOGGER.info("appending state params to redirect url {} ", stateParams);
            url.set(STATE, stateParams);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put(AppConstant.RESULT, result);
            jsonObject.put(Url, url.build());

            return jsonObject;
        } catch (Exception e) {
            LOGGER.error("exception occurred during generating redirect url: ",e );
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_1", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER,e);
        }
    }

    public TxnAdapterConnection getRefreshToken(Long id) throws NSLException {

        String cacheName = ADOBESIGN + "_" + bean.getTenantId();

        String code = redisIntegration.getOAuthCode(cacheName, id.toString());
        LOGGER.info("updating connection with code: {}",code);
        try {
            AdobeSignAdapterConnectionDto connectionDto =adobeSignConnectionService.getAdobeSignConnection(id,false);
            connectionDto.setRefreshToken(getRefreshToken(connectionDto, code));
            return adobeSignConnectionService.updateAdobeSignConnection(id,connectionDto);
        } catch (Exception e) {
            LOGGER.error("failed to generate refresh Token",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,messageSource.getMessage
                    ("Paas_Adapter_13", null, Locale.ENGLISH) + e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }
    }

    public String getRefreshToken(AdobeSignAdapterConnectionDto connectionDto, String code) throws IOException {
        TokenRequest request = new AuthorizationCodeTokenRequest(new NetHttpTransport(), new JacksonFactory(), new GenericUrl(ADOBESIGN_ACCESS_TOKEN), code)
                .setRedirectUri(adaptorProperties.getRedirectUrl()).setGrantType(AUTHORIZATION_CODE).set("client_id",connectionDto.getAppId()).set("client_secret",connectionDataToolsV3.getSecret(connectionDto.getAppSecret()));

        TokenResponse response = request.execute();
        return response.getRefreshToken();
    }

    public String getAccessToken(AdobeSignAdapterConnectionDto connectionDto) throws NSLException {

        TokenResponse response = null;

        try {
            TokenRequest request = new RefreshTokenRequest(new NetHttpTransport(), new JacksonFactory(),
                    new GenericUrl(ADOBESIGN_TOKEN), connectionDataToolsV3.getSecret(connectionDto.getRefreshToken()));
            request.set("client_id",connectionDto.getAppId()).
                    set("client_secret",connectionDataToolsV3.getSecret(connectionDto.getAppSecret())).setGrantType(REFRESH_TOKEN);
            response = request.execute();
        }catch(Exception e){
            LOGGER.error("error while generating access token",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_14", null, Locale.ENGLISH), ExceptionSeverity.BLOCKER,e);
        }
        return response.getAccessToken();
    }

    private  String encodeData(String value){
        return encoder.encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

}
       