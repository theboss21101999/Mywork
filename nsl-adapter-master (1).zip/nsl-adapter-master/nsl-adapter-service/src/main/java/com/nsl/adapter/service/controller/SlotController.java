package com.nsl.adapter.service.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.calendar.SlotService;
import com.nsl.adapter.service.calendar.dto.SchedulerSlotDto;
import com.nsl.externalreservedcus.dto.CalendarAdminSlotConfig;
import com.nsl.externalreservedcus.dto.calender.event.CalendarEvent;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;

@RequestMapping(value = "slot")
@RestController
public class SlotController {
    @Autowired
    SlotService slotService;

    @PutMapping(value = "/book")
    public ApiResponse bookSlot(@RequestBody(required = false)SchedulerSlotDto schedulerSlotDto,@RequestParam String eventId ,  @RequestParam String desiredStatus) throws NSLException, ParseException, JsonProcessingException {

        return slotService.bookSlot(schedulerSlotDto ,eventId, desiredStatus);

    }

    @PutMapping(value = "/rescheduleSlot")
    public ApiResponse rescheduleSlot(@RequestParam String eventId , @RequestParam(required = true) String startTime, @RequestParam(required = true) String endTime) throws NSLException, ParseException {

        return slotService.rescheduleSlot(startTime, endTime ,eventId);

    }

    @PutMapping(value = "/update")
    public ApiResponse updateSlot(@RequestBody CalendarEvent calendarEvent) throws NSLException {

        return slotService.updateSlot(calendarEvent);

    }

    @DeleteMapping(value = "/removeSlot")
    public ApiResponse removeSlot(@RequestBody SchedulerSlotDto schedulerSlotDto) throws NSLException, ParseException {

        return slotService.removeSlot(schedulerSlotDto);
    }

    @GetMapping(value = "/admin-config")
    public ApiResponse getAdminConfig() {

        return slotService.getCalendarAdminSlotConfig();
    }

    @PostMapping(value = "/admin-config")
    public ApiResponse saveAdminConfig(@RequestBody CalendarAdminSlotConfig calendarAdminSlotConfig) {
        return slotService.saveCalendarAdminSlotConfig(calendarAdminSlotConfig);
    }
}
