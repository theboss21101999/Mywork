package com.nsl.adapter.service.keymanager.service;

import com.nsl.adapter.commons.utils.FileUploadUtil;
import com.nsl.adapter.service.keymanager.dto.KmsConnectionDto;
import com.nsl.adapter.service.keymanager.utils.KeyManagerUtils;
import com.nsl.adapter.commons.serviceImpl.AWSSecretManagerServiceImpl;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.Locale;

@Service
public class FetchFileService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FetchFileService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    KeyManagerUtils managerUtils;

    @Autowired
    FileUploadUtil fileUploadUtil;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    AWSSecretManagerServiceImpl secretManagerService;

    public byte[] getFileById(Long attrId) throws NSLException {
        TxnGeneralEntityRecord fetchedEntityRecord = managerUtils.getRecordById(attrId);
        if (fetchedEntityRecord==null){
            throw new NSLException(ErrorType.NOT_FOUND, ExceptionCategory.ENTITY_ATTRIBUTE, ExceptionSubCategory.FETCH,
                    messageSource.getMessage("Paas_Adapter_34", null, Locale.ENGLISH), ExceptionSeverity.BLOCKER);
        }
        KmsConnectionDto dto = managerUtils.getFromNslAtrributes(fetchedEntityRecord.getTxnNslAttribute(),false);
        switch (dto.getKmsType()){
            case ENCRYPTIONKEY:
                if (dto.getIsEncryptionKeyPrivate().equalsIgnoreCase(Boolean.TRUE.toString()))
                    return getFilefromAws(dto.getAwsId());
                else
                    return getFilefromDsd(dto.getDsdUrl());
            case KEY:
            case SSHKEY:
                return getFilefromAws(dto.getAwsId());
            default:
                throw new NSLException(ErrorType.NOT_FOUND, ExceptionCategory.ENTITY_ATTRIBUTE, ExceptionSubCategory.FETCH,
                        messageSource.getMessage("Paas_Adapter_35", null, Locale.ENGLISH) , ExceptionSeverity.BLOCKER);
        }
    }

    private byte[] getFilefromDsd(String url) throws NSLException {
        try(InputStream inputStream =fileUploadUtil.getContentFromUrl(url,authBean)) {
            return inputStream.readAllBytes();
        }catch (IOException e){
            throw new NSLException(ErrorType.INTERNAL_SERVER,ExceptionCategory.PROCESS, ExceptionSubCategory.FETCH,
                    messageSource.getMessage("Paas_Adapter_36", null, Locale.ENGLISH) , ExceptionSeverity.BLOCKER);
        }
    }

    private byte[] getFilefromAws(String secretId) throws NSLException {
        try {

            String secret = secretManagerService.getSecret(secretId);
            return Base64.getDecoder().decode(secret);
        }catch (Exception e){
            throw new NSLException(ErrorType.INTERNAL_SERVER,ExceptionCategory.PROCESS, ExceptionSubCategory.FETCH,
                    messageSource.getMessage("Paas_Adapter_31", null, Locale.ENGLISH) , ExceptionSeverity.BLOCKER);
        }

    }
}
