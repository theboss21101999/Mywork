package com.nsl.adapter.service.controller;

import com.nsl.adapter.service.calendar.CalendarService;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.keymanager.enums.KmsType;
import com.nsl.externalreservedcus.dto.CalendarSlotConfig;
import com.nsl.logical.dto.search.TxnEntitySearchRequest;
import com.nsl.logical.exception.NSLException;
import com.nsl.externalreservedcus.dto.calender.event.CalendarEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.method.P;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.text.ParseException;


/**
 * @author Keshav
 **/
@RestController
@CrossOrigin
@RequestMapping(value = "/calendar")
public class CalendarController {

    @Autowired CalendarService calendarService;

    @PostMapping(value = "/entity-records")
    public ApiResponse fetchSlots( @RequestParam(required = false) String tag,
                                   @RequestParam(required = false) String eventType,
                                   @RequestParam(required = false) String title,
                                   @RequestParam(required = false) String categoryType,
                                   @RequestBody TxnEntitySearchRequest searchRequest) throws NSLException {
        return calendarService.fetchSlots(searchRequest,tag,eventType,title,categoryType);
    }

    @PostMapping(value = "/schedule")
    public ApiResponse scheduleEvent(@RequestBody CalendarEvent calendarEvent) throws NSLException, IOException, ParseException, GeneralSecurityException {

        return calendarService.scheduleEvent(calendarEvent);

    }

    @PutMapping(value = "/schedule")
    public ApiResponse updateEvent(@RequestBody CalendarEvent calendarEvent) throws NSLException {

        return calendarService.updateEvent(calendarEvent);
    }

    @DeleteMapping(value = "/schedule")
    public ApiResponse cancelEvent(@RequestBody CalendarEvent calendarEvent) throws NSLException {

        return calendarService.cancelEvent(calendarEvent);
    }

    @PostMapping(value = "/records")
    public ApiResponse fetchRecords( @RequestParam(required = false) String tag,
                                   @RequestParam(required = false) String eventType,
                                   @RequestParam(required = false) String title,
                                   @RequestParam(required = false) String categoryType,
                                   @RequestBody TxnEntitySearchRequest searchRequest) throws NSLException {
        return calendarService.fetchRecords(searchRequest,tag,eventType,title,categoryType);
    }

    @PutMapping(value = "/acceptanceStatus")

    public ApiResponse acceptanceStatus(
                                     @RequestParam String encodedData,
                                     @RequestParam String button
                                     ) throws NSLException {
        return calendarService.acceptanceStatus(encodedData,button);
    }

    @PutMapping(value = "/categorise/{id}/{userEmail}/{categoryType}")
    public ApiResponse addCategorise( @PathVariable("id") String id,
                                      @PathVariable("userEmail") String userEmail,
                                      @PathVariable("categoryType") String categoryType) throws NSLException {
        return calendarService.updateEventWithCategory(id,userEmail,categoryType);
    }

    @PostMapping(value = "/generate/slots")
    public ApiResponse generateSlots(@RequestBody CalendarSlotConfig slotConfig) {
        return calendarService.generateSlots(slotConfig);
    }


    @PostMapping(value = "/view/{id}")
    public ApiResponse viewRecords( @PathVariable("id") String id) throws NSLException{
        return calendarService.viewRecords(id);
    }
}
