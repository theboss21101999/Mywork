package com.nsl.adapter.service.dto;


import com.nsl.adapter.commons.enums.AdapterType;

public class Connection {

    AdapterType adapterType;
    Long sourceId;
    String connectionName;
    Long connectionId;
    String connectionData;
    String guId;

    public Connection() {
    }

    public Connection(AdapterType adapterType, Long sourceId, String connectionName, Long connectionId, String connectionData, String guId) {
        this.adapterType = adapterType;
        this.sourceId = sourceId;
        this.connectionName = connectionName;
        this.connectionId = connectionId;
        this.connectionData = connectionData;
        this.guId = guId;
    }

    public AdapterType getAdapterType() {
        return adapterType;
    }

    public void setAdapterType(AdapterType adapterType) {
        this.adapterType = adapterType;
    }

    public Long getSourceId() {
        return sourceId;
    }

    public void setSourceId(Long sourceId) {
        this.sourceId = sourceId;
    }

    public String getConnectionName() {
        return connectionName;
    }

    public void setConnectionName(String connectionName) {
        this.connectionName = connectionName;
    }

    public Long getConnectionId() {
        return connectionId;
    }

    public void setConnectionId(Long connectionId) {
        this.connectionId = connectionId;
    }

    public String getConnectionData() {
        return connectionData;
    }

    public void setConnectionData(String connectionData) {
        this.connectionData = connectionData;
    }

    public String getGuId() {
        return guId;
    }

    public void setGuId(String guId) {
        this.guId = guId;
    }
}
