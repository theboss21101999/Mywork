package com.nsl.adapter.service.jira.controller;
import com.nsl.adapter.commons.dto.connections.JiraAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
//import com.nsl.adapter.service.jira.utils.JiraOauthConnection;
//import com.nsl.adapter.service.jira.utils.JiraOauthConnection;
import com.nsl.adapter.service.jira.service.JiraConnectionService;
import com.nsl.adapter.service.jira.utils.JiraOauthConnection;
import com.nsl.adapter.service.utils.AppConstant;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class JiraConnectionController {

    @Autowired
    JiraConnectionService JiraConnectionService;

    @Autowired
    JiraOauthConnection oauthConnection;

    @PostMapping(path = "/jira", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveJiraConnection(@RequestBody JiraAdapterConnectionDto connectionDto) {
        TxnAdapterConnection result = JiraConnectionService.saveJiraConnection(connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationcode(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
    @GetMapping(path = "/jira/{Id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getJiraConnection(@PathVariable("Id") Long id) {

        JiraAdapterConnectionDto response = JiraConnectionService.getJiraConnection(id);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @PutMapping(path = "/jira/{id}" , consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse updateJiraConnection(@PathVariable("id") Long id,
                                            @RequestBody JiraAdapterConnectionDto connectionDto ) {

        TxnAdapterConnection result = JiraConnectionService.updateJiraConnection(id, connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationcode(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
    @GetMapping(path = "/jira/refreshToken/{Id}")
    public ApiResponse updateJiraToken(@PathVariable("Id") Long id){
        TxnAdapterConnection result =oauthConnection.getRefreshToken(id);
        return new ApiResponse(HttpStatus.OK,SUCCESS,result);
    }
}

