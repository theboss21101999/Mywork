package com.nsl.adapter.service.mqtt.serviceImpl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.adapter.commons.dto.connections.MqttConnectionDto;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.ExtSolutionUtil;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;


@Service
public class MqttOpertations {
    private static final Logger LOGGER = LoggerFactory.getLogger(MqttOpertations.class);
    private static final String RESPONSE = "message";
    private static final String RESPONSE_RESULT = "message send to the mqtt broker";
    @Autowired
    ExtSolutionUtil extSolutionUtil;
    public TxnData publish(MqttConnectionDto entityRecord, TriggerCU triggerCu, JSONObject transData) throws JSONException, JsonProcessingException {
        try {
            LOGGER.debug("Executing Mqtt operation : publishing to the mqtt broker");
            LOGGER.debug("== START PUBLISHER ==:");
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setUserName(entityRecord.getUsername());
            connOpts.setPassword(entityRecord.getPassword().toCharArray());
            connOpts.setCleanSession(true);
            MemoryPersistence persistence = new MemoryPersistence();
            try (MqttClient client = new MqttClient("tcp://" + entityRecord.getHost() + ":" + entityRecord.getPort(), MqttClient.generateClientId(), persistence)) {
                client.connect(connOpts);
                LOGGER.debug("connection successful");
                client.publish(
                        entityRecord.getTopic(),
                        transData.toString().getBytes(),
                        2, // QoS =0 will not guarantee the message delivery , Qos=1 will provide duplicates but ensures delivery , Qos=2 will ensure delivery but no duplicates!
                        true);
                LOGGER.debug("Message:" + transData + " sent to " + entityRecord.getTopic());
                client.disconnect();
            }
            LOGGER.debug("== END PUBLISHER ==:");
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(RESPONSE, RESPONSE_RESULT);
            return processMqttResponse(jsonObject, triggerCu);
        } catch (Exception e) {
            LOGGER.error("error occured while publishing",e);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(RESPONSE, e.getMessage());
            return processMqttResponse(jsonObject, triggerCu);
        }
    }



    public TxnData processMqttResponse(JSONObject jsonObject,TriggerCU triggerCu) throws JsonProcessingException {
        LOGGER.info("Processing json to entity.");
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode result = objectMapper.readTree(jsonObject.toString());
        GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(
                triggerCu, AppConstant.TRIGGER_CES_LAYER);

        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, result);
        return extSolutionUtil.setChangeDriverInTxnData(txnGeneralEntity, LayerType.TRIGGERCES);
    }

}
