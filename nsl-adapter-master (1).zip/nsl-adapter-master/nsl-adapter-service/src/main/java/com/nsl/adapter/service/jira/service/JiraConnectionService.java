package com.nsl.adapter.service.jira.service;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dao.FetchConnectionService;
import com.nsl.adapter.commons.dto.connections.FacebookAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.commons.dto.connections.JiraAdapterConnectionDto;
//import com.nsl.adapter.service.ciscoWebex.utils.CiscoConstants;
import com.nsl.adapter.service.graph.service.GraphConnectionService;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.List;
import java.util.Locale;


@Service
public class JiraConnectionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(JiraConnectionService.class);

    private static final ConnectionsType connType = ConnectionsType.JIRA;


    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    AdapterConnectionServiceV3 adapterConnectionServiceV3;

    @Autowired
    FetchConnectionService fetchConnectionService;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    MessageSource messageSource;

    public TxnAdapterConnection saveJiraConnection(JiraAdapterConnectionDto connectionDto) {

        if (connectionDto.getAppId() == null || connectionDto.getAppSecret() == null ||
                connectionDto.getConnectionName() == null
                || adapterConnnectionsDao.getConnectionByName(ConnectionDtoType.JIRA, connectionDto.getConnectionName(), authBean)!=null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_182", null, Locale.ENGLISH) , null);
        }

        connectionDto.setAppSecret(connectionDataToolsV3.saveSecret(ConnectionDtoType.JIRA, "appSecret",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getAppSecret()));
        connectionDto.setRefreshToken(connectionDataToolsV3.saveSecret(ConnectionDtoType.JIRA, "refreshToken",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getRefreshToken()));

        LOGGER.info("saving JIRA connection");
        TxnAdapterConnection result = new TxnAdapterConnection();
        result.setConnectionDtoType(ConnectionDtoType.JIRA);
        result.setConnection(connectionDto);
        result = adapterConnnectionsDao.saveConnection(result, authBean);

        return result;
    }



    public JiraAdapterConnectionDto getJiraConnection(Long id, boolean hide) {
        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.JIRA, id, authBean);
        if (previousConnection==null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }
        return txnToJiraDto(previousConnection, hide);
    }

    public JiraAdapterConnectionDto getJiraConnection(Long id) {

        TxnAdapterConnection previousConnection1 = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.JIRA, id,authBean);

        if (previousConnection1==null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }

        JiraAdapterConnectionDto previousConnection=txnToJiraDto(previousConnection1,false);

        previousConnection.setAppSecret(connectionDataToolsV3.getSecret(previousConnection.getAppSecret()));
        previousConnection.setRefreshToken(connectionDataToolsV3.getSecret(previousConnection.getRefreshToken()));

        return previousConnection;
    }

    public TxnAdapterConnection updateJiraConnection(Long id, JiraAdapterConnectionDto connectionDto) {
        if(  connectionDto.getAppSecret() == null || connectionDto.getAppId() == null ||
                connectionDto.getConnectionName() == null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.JIRA, id, authBean);
        if (previousConnection==null || !previousConnection.getConnection().getConnectionName().equals(connectionDto.getConnectionName())){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }

        JiraAdapterConnectionDto prevsDto = (JiraAdapterConnectionDto) previousConnection.getConnection();
        if (connectionDto.getAppId()!=null){
            prevsDto.setAppId(connectionDto.getAppId());
        }
        if (connectionDto.getRefreshToken()!=null){
            prevsDto.setRefreshToken(connectionDataToolsV3.updateSecret(ConnectionDtoType.JIRA, "refreshToken",
                    connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getRefreshToken()));
        }
        previousConnection.setConnection(prevsDto);
        LOGGER.info("update JIRA connection");
        TxnAdapterConnection result = adapterConnnectionsDao.saveConnection(previousConnection, authBean);

        return result;
    }

    public JiraAdapterConnectionDto txnToJiraDto(TxnAdapterConnection adapterConnection, boolean hide) {
        if (adapterConnection==null){
            return null;
        }
        JiraAdapterConnectionDto dto = (JiraAdapterConnectionDto) adapterConnection.getConnection();
        if (hide){
            dto.setAppSecret(null);
            dto.setRefreshToken(null);
        }
        dto.getMetadata().put("dsdId",String.valueOf(adapterConnection.getRecordId()));
        return dto;
    }
}

