package com.nsl.adapter.service.calendar;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.argo.dto.JobDeleteDto;
import com.nsl.adapter.service.argo.service.ArgoConnectionService;
import com.nsl.adapter.service.argo.service.ArgoSchedulerService;
import com.nsl.adapter.service.calendar.dto.AvailabilitySlot;
import com.nsl.adapter.service.calendar.dto.OccupiedSlot;
import com.nsl.adapter.service.calendar.dto.ResponseSlot;
import com.nsl.adapter.service.calendar.dto.ViewResponse;
import com.nsl.adapter.service.calendar.utils.AuthUtils;
import com.nsl.adapter.service.calendar.utils.CalendarEventUtils;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.service.VideoConferencingService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.dataservices.idgeneration.HashcodeIdGenerator;
import com.nsl.externalreservedcus.dto.CalendarSlotConfig;
import com.nsl.externalreservedcus.dto.CalendarSlotSummary;
import com.nsl.externalreservedcus.dto.calender.event.ActionButton;
import com.nsl.externalreservedcus.impl.CalendarSaveSlotsImpl;
import com.nsl.logical.config.AuthenticatedUserDetails;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.CreateGeneralEntityCUDao;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.dto.search.TxnEntitySearchRequest;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.enums.NotificationChannel;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import com.nsl.externalreservedcus.dto.calender.event.CalendarEvent;
import com.nsl.externalreservedcus.dto.calender.event.CalendarEventMessage;
import com.nsl.externalreservedcus.dto.calender.event.CalendarMetadata;
import com.nsl.externalreservedcus.enums.CalendarEventStatusEnum;
import com.nsl.externalreservedcus.kafka.CalendarKafkaEventDispatcher;
import org.apache.commons.lang3.time.DateUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.Resource;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.*;


import static com.nsl.adapter.service.calendar.utils.CalendarEventUtils.buildNestedEntity;
import static com.nsl.adapter.service.utils.AppConstant.FAILURE;
import static com.nsl.adapter.service.utils.AppConstant.RESULT;
import static com.nsl.common.constant.AppConstant.SUCCESS;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;
import static org.springframework.http.HttpHeaders.*;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Service
public class CalendarService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CalendarService.class);

    private final String update = "update";

    private final String save = "save";

    private final String cancel = "cancel";

    private final String separator = "/";

    @Autowired
    AuthenticatedUserDetailsImpl userDetails;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Autowired
    AdaptorProperties adaptorProperties;

    @Autowired
    CalendarKafkaEventDispatcher calenderKafkaEventDispatcher;

    @Autowired
    AuthUtils authUtils;

    @Autowired
    GeneralEntityDao generalEntityDao;

    @Autowired
    CreateGeneralEntityCUDao createEntityCUDao;

    @Autowired
    ArgoSchedulerService argoSchedulerService;

    @Autowired
    ArgoConnectionService argoConnectionService;

    @Autowired
    VideoConferencingService videoConferencingService;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    CalendarEventUtils calendarEventUtils;

    @Autowired
    CalendarSaveSlotsImpl calendarSaveSlotsImpl;

    public ApiResponse scheduleEvent(CalendarEvent calendarEvent) throws NSLException {

        if (calendarEvent.getConferenceType() != null && calendarEvent.getConferenceType().equalsIgnoreCase("NSL_Conference")) {
            calendarEvent.setMeetingUrl(videoConferencingService.getMeetingUrl());
        }
        Long recordId = HashcodeIdGenerator.getId();
        //     Long recordId = saveCalendarEvent(calendarEvent);
        buildMetadata(calendarEvent, recordId);
        executeCalendarEvent(calendarEvent);
        try {
            argoSchedulerService.scheduleJob(calendarEvent, requestScopedAuthenticatedUserBean);
            JobDeleteDto jobDeleteDto = createJobDeleteDto(calendarEvent);
            if (jobDeleteDto.getTimeStamp() != null) {
                argoConnectionService.saveArgoConn(jobDeleteDto, requestScopedAuthenticatedUserBean);
            }
        } catch (Exception e) {
            LOGGER.error("Exception while creating notification for event : " + calendarEvent.getTitle(), e);
        }
        saveCalendarEvent(calendarEvent, save);
        sendPushNotification(calendarEvent, requestScopedAuthenticatedUserBean);

        return new ApiResponse(HttpStatus.OK, SUCCESS, calendarEvent);
    }

    private void buildMetadata(CalendarEvent calendarEvent, Long recordId) throws NSLException {
        CalendarMetadata calMeta = new CalendarMetadata();
        calMeta.setRecordId(recordId);
        calMeta.setSequence(0);
        calMeta.setStatus(CalendarEventStatusEnum.REQUEST);
        calMeta.setUid(UUID.randomUUID().toString() + "@google.com");

        calendarEvent.setMetadata(calMeta.buildString(calMeta));
//        saveCalendarEvent(calendarEvent);
    }

    private void executeCalendarEvent(CalendarEvent event) {
        CalendarEventMessage calendarEventMessage = new CalendarEventMessage();
        AuthenticatedUserDetailsImpl authenticatedUserData = authUtils.getAuthDetails(userDetails);
        calendarEventMessage.setEvent(event);
        calendarEventMessage.setAuthenticatedUserDetails(authenticatedUserData);
        calenderKafkaEventDispatcher.send(calendarEventMessage);
    }

    public Long saveCalendarEvent(CalendarEvent calendarEvent, String operation) throws NSLException {

        var isDynamoNewEnabled = adaptorProperties.getDynamoNewEnabled();
        GeneralEntity generalEntity = generalEntityDao.findByName("NSL_CalendarEvent", userDetails);

        if (generalEntity == null)
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.GENERAL_ENTITY, ExceptionSubCategory.valueOf("Entity"),
                    messageSource.getMessage("Paas_Adapter_8", null, Locale.ENGLISH), ExceptionSeverity.MAJOR);

        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();
        txnGeneralEntity.setName(generalEntity.getName());
        txnGeneralEntity.setGeneralEntityID(generalEntity.getId());
        txnGeneralEntity.setGeneralEntityMasterId(generalEntity.getMasterId());
        txnGeneralEntity.setDisplayName(generalEntity.getDisplayName());

        txnGeneralEntity.setTransEntityRecords(Collections.singletonList(buildRecord(generalEntity, calendarEvent)));
        ResponseEntity<TxnGeneralEntityRecord> response = null;
        if (isDynamoNewEnabled) {
            HttpHeaders headers = new HttpHeaders();
            headers.add(AUTHORIZATION, AppConstant.BEARER + requestScopedAuthenticatedUserBean.getAuthToken());
            headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
            headers.add(ACCEPT_LANGUAGE, AppConstant.ACCEPT_LANGUAGE_EN);
            HttpEntity<TxnGeneralEntityRecord> request = new HttpEntity<>(txnGeneralEntity.getTransEntityRecords().get(0), headers);
            if (operation.equals(save)) {
                String uri = adaptorProperties.getDynamoNewUrl() + "/calendar/schedule/event";

                LOGGER.info("calling save url.....{}", uri);
                response =
                        restTemplate.exchange(uri, HttpMethod.POST, request, TxnGeneralEntityRecord.class);
            }
            if (operation.equals(update)) {
                String uri = adaptorProperties.getDynamoNewUrl() + "/calendar/update/event";

                LOGGER.info("calling update url.....{}", uri);
                response =
                        restTemplate.exchange(uri, HttpMethod.PUT, request, TxnGeneralEntityRecord.class);
            }
            if (operation.equals(cancel)) {
                String uri = adaptorProperties.getDynamoNewUrl() + "/calendar/cancel/event";

                LOGGER.info("calling cancel url.....{}", uri);
                response =
                        restTemplate.exchange(uri, HttpMethod.DELETE, request, TxnGeneralEntityRecord.class);
            }

        }
        Long answer = 0L;
        if (response != null && response.getBody() != null)
            answer = response.getBody().getId();
        return answer;
    }


//        List<TxnGeneralEntityRecord> triggerCESRecords = createEntityCUDao.saveEntities(Collections.singletonList(txnGeneralEntity), userDetails);
//        LOGGER.debug("Saved calendar record {}", triggerCESRecords);

//        return triggerCESRecords.get(0).getId();


    private TxnGeneralEntityRecord buildRecord(GeneralEntity generalEntity, CalendarEvent calendarEvent) {

        Map<String, String> eventMap = calendarEventUtils.buildCalendarEventMap(calendarEvent, generalEntity);
        TxnGeneralEntityRecord record = new TxnGeneralEntityRecord();
        List<TxnNslAttribute> attributes = new ArrayList<>();

        record.setGeneralEntityId(generalEntity.getId());
        record.setGeneralEntityMasterId(generalEntity.getMasterId());
        record.setTxnNslAttribute(attributes);
        record.setId(getRecordId(calendarEvent.getMetadata()));

        generalEntity.getNslAttributes().forEach(nslAttribute -> {
            TxnNslAttribute attribute = new TxnNslAttribute();
            attributes.add(attribute);
            attribute.setName(nslAttribute.getName());
            attribute.setNslAttributeID(nslAttribute.getId());
            if (nslAttribute.getGeneralEntity() == null) {
                if (nslAttribute.getName().equalsIgnoreCase("participantList"))
                    attribute.setValues(Arrays.asList(eventMap.get(attribute.getName()).split("-")));
                else if (eventMap.get(attribute.getName()) != null)
                    attribute.setValues(Collections.singletonList(eventMap.get(attribute.getName())));
                else
                    attribute.setValues(new ArrayList<>());
            } else
                buildNestedEntity(attribute, nslAttribute, calendarEvent);
        });

        return record;
    }

    private Long getRecordId(String metadata) {
        CalendarMetadata calMeta = new CalendarMetadata();
        calMeta = calMeta.build(metadata);
        return calMeta.getRecordId();
    }


    public ApiResponse updateEvent(CalendarEvent calendarEvent) throws NSLException {

        if (calendarEvent.getMetadata() == null || calendarEvent.getMetadata().isEmpty())
            return new ApiResponse(HttpStatus.BAD_REQUEST, "Metadata Empty", calendarEvent);

        if (calendarEvent.getConferenceType() != null && calendarEvent.getConferenceType().equalsIgnoreCase("NSL_Conference")) {
            calendarEvent.setMeetingUrl(videoConferencingService.getMeetingUrl());
        }

        CalendarMetadata metadata = new CalendarMetadata();
        metadata = metadata.build(calendarEvent.getMetadata());
        metadata.setStatus(CalendarEventStatusEnum.REQUEST);
        metadata.setSequence(metadata.getSequence() + 1);
        calendarEvent.setMetadata(metadata.buildString(metadata));
        executeCalendarEvent(calendarEvent);
        saveCalendarEvent(calendarEvent, update);

        try {
            argoSchedulerService.updateJob(calendarEvent, requestScopedAuthenticatedUserBean);
        } catch (Exception e) {
            LOGGER.error("Exception while updating notification for event : " + calendarEvent.getTitle(), e);
        }

        return new ApiResponse(HttpStatus.OK, SUCCESS, calendarEvent);

    }

    public ApiResponse cancelEvent(CalendarEvent calendarEvent) throws NSLException {

        if (calendarEvent.getMetadata() == null || calendarEvent.getMetadata().isEmpty())
            return new ApiResponse(HttpStatus.BAD_REQUEST, "Metadata Empty", calendarEvent);

        CalendarMetadata metadata = new CalendarMetadata();
        metadata = metadata.build(calendarEvent.getMetadata());
        metadata.setStatus(CalendarEventStatusEnum.CANCEL);
        metadata.setSequence(metadata.getSequence() + 1);
        calendarEvent.setMetadata(metadata.buildString(metadata));

        executeCalendarEvent(calendarEvent);
        saveCalendarEvent(calendarEvent, cancel);
        String jobId = metadata.getJobId();

        try {
            argoSchedulerService.deleteJob(jobId);
        } catch (Exception e) {
            LOGGER.error("Exception while cancelling notification for event : " + calendarEvent.getTitle(), e);
        }

        return new ApiResponse(HttpStatus.OK, SUCCESS, calendarEvent);
    }

    public ApiResponse fetchSlots(TxnEntitySearchRequest searchRequest, String tag, String eventType, String title, String categoryType) {

        JsonNode node = fetchCalendarEvents(searchRequest, tag, eventType, title, categoryType, true);
        Type type = new TypeReference<TxnGeneralEntity>() {
        }.getType();
        TxnGeneralEntity txnGeneralEntity = JacksonUtils.fromJson(node.get("result").get("scheduledMeetings").toString(), type); //NOSONAR
//        TxnGeneralEntity txnGeneralEntity = (node.get("result").get("scheduledMeetings").asText(), TxnGeneralEntity.class); //NOSONAR
        List<OccupiedSlot> occupiedSlots = new ArrayList<>();
        ResponseSlot responseSlot = new ResponseSlot();
        if (txnGeneralEntity.getTransEntityRecords().size() == 1 &&
                txnGeneralEntity.getTransEntityRecords().get(0).getTxnNslAttribute().get(0).getValues().isEmpty())
            return new ApiResponse(HttpStatus.OK, SUCCESS, "No Records founds");

        txnGeneralEntity.getTransEntityRecords().forEach(txnGeneralEntityRecord -> {
            OccupiedSlot occupiedSlot = new OccupiedSlot();
            CalendarMetadata metadata = new CalendarMetadata();
            CalendarMetadata md = new CalendarMetadata();
            txnGeneralEntityRecord.getTxnNslAttribute().forEach(attribute -> {

                switch (attribute.getName()) {
                    case "metadata":
                        if (!attribute.getValues().isEmpty())
                            md.setStatus(metadata.build(attribute.getValues().get(0)).getStatus());
                        break;
                    case "startTime":
                        occupiedSlot.setStartTime(attribute.getValues().get(0));
                        break;
                    case "endTime":
                        occupiedSlot.setEndTime(attribute.getValues().get(0));
                        break;
                    case "Title":
                        occupiedSlot.setTitle(attribute.getValues().get(0));
                        break;
                    case "participantList":
                        List<String> participants = attribute.getValues();
                        for (String participant : participants) {
                            occupiedSlot.updateAttendees(participant);
                        }
                        break;
                    case "Organizer":
                        occupiedSlot.updateAttendees(attribute.getValues().get(0));
                        break;
                    case "NSL_ActionButton":
                        occupiedSlot.setGsi(actionButton(attribute.getTxnGeneralEntity().getTransEntityRecords()));
                        break;
                    default:
                        break;
                }
            });
            if (md.getStatus() != CalendarEventStatusEnum.CANCEL)
                occupiedSlots.add(occupiedSlot);
        });
        List<AvailabilitySlot> availabilitySlots = JacksonUtils.fromJson(node.get("result").get("availableSlots").asText(), new TypeReference<List<AvailabilitySlot>>() {
        }.getType()); //NOSONAR
        responseSlot.setOccupiedSlots(occupiedSlots);
        responseSlot.setAvailabilitySlots(availabilitySlots);
        return new ApiResponse(HttpStatus.OK, SUCCESS, responseSlot);
    }

    private JsonNode fetchCalendarEvents(TxnEntitySearchRequest searchRequest, String tag, String eventType, String title, String categoryType, boolean fetchAvailableSlots) {

        StringBuilder uri = new StringBuilder(adaptorProperties.getDynamoNewUrl() + "/calendar/fetch/slots");
        List<String> params = new ArrayList<>();
        if (tag != null)
            params.add("tag=" + tag);
        if (eventType != null)
            params.add("eventType=" + eventType);
        if (title != null)
            params.add("titleName=" + title);
        if (categoryType != null)
            params.add(("categoryType=" + categoryType));
        if (fetchAvailableSlots) {
            uri.append("fetchAvailableSlots=true");
        }
        if (!params.isEmpty()) {
            uri.append("?").append(String.join("&", params));
        }
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uri.toString());
        HttpHeaders headers = new HttpHeaders();
        headers.add(AUTHORIZATION, AppConstant.BEARER + requestScopedAuthenticatedUserBean.getAuthToken());
        headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        headers.add(ACCEPT_LANGUAGE, AppConstant.ACCEPT_LANGUAGE_EN);
        String requestString = JacksonUtils.toJson(searchRequest);
        HttpEntity<String> request = new HttpEntity<>(requestString, headers);
        ResponseEntity<JsonNode> response = restTemplate.postForEntity(builder.toUriString(), request, JsonNode.class);

        if (!response.hasBody() || response.getBody() == null)
            throw new NullPointerException();


        return response.getBody();
    }

    private JobDeleteDto createJobDeleteDto(CalendarEvent calendarEvent) {
        CalendarMetadata calMeta = new CalendarMetadata();
        calMeta = calMeta.build(calendarEvent.getMetadata());
        JobDeleteDto jobDeleteDto = new JobDeleteDto();
        jobDeleteDto.setJobId(calMeta.getJobId());
        jobDeleteDto.setTimeStamp(getDeleteDate(calendarEvent));
        return jobDeleteDto;
    }

    private Date getDeleteDate(CalendarEvent calendarEvent) {
        if (calendarEvent.getRecurrence() == null || calendarEvent.getRecurrence().getFrequency().contains("YEARLY"))
            return DateUtils.addMinutes(calendarEvent.getStartTime(), (-1) * (calendarEvent.getReminder() - 2));
        else if (calendarEvent.getRecurrence().getFrequency().contains("DAILY"))
            return calendarEvent.getEndTime();
        else if (calendarEvent.getRecurrence().getFrequency().contains("WEEKLY"))
            return calendarEvent.getEndTime();
        else if (calendarEvent.getRecurrence().getFrequency().contains("MONTHLY"))
            return calendarEvent.getEndTime();
        else
            return null;
    }

    private List<ActionButton> actionButton(List<TxnGeneralEntityRecord> txnGeneralEntityRecords) {

        List<ActionButton> actionButtonList = new ArrayList<>();
        for (TxnGeneralEntityRecord txnGeneralEntityRecord : txnGeneralEntityRecords) {

            ActionButton action = new ActionButton();

            for (TxnNslAttribute txnNslAttribute : txnGeneralEntityRecord.getTxnNslAttribute()) {
                if (txnNslAttribute.getValues() != null && txnNslAttribute.getName().equals("ButtonName") && !txnNslAttribute.getValues().isEmpty()) {
                    action.setButtonName(txnNslAttribute.getValues().get(0));
                } else if (txnNslAttribute.getValues() != null && txnNslAttribute.getName().equals("GsiId") && !txnNslAttribute.getValues().isEmpty()) {
                    action.setGsiId(txnNslAttribute.getValues().get(0));
                } else if (txnNslAttribute.getValues() != null && txnNslAttribute.getName().equals("GsiMasterId") && !txnNslAttribute.getValues().isEmpty()) {
                    action.setGsiMasterId(txnNslAttribute.getValues().get(0));
                } else if (txnNslAttribute.getValues() != null && txnNslAttribute.getName().equals("BookName") && !txnNslAttribute.getValues().isEmpty()) {
                    action.setBookName(txnNslAttribute.getValues().get(0));
                } else if (txnNslAttribute.getValues() != null && txnNslAttribute.getName().equals("GsiName") && !txnNslAttribute.getValues().isEmpty()) {
                    action.setGsiName(txnNslAttribute.getValues().get(0));
                } else if (txnNslAttribute.getValues() != null && !txnNslAttribute.getValues().isEmpty())
                    action.setBookId(txnNslAttribute.getValues().get(0));
            }
            actionButtonList.add(action);
        }

        return actionButtonList;
    }

    private void sendPushNotification(CalendarEvent event, AuthenticatedUserDetails authenticatedUserDetails) {
        try {

            NotificationDto notificationDtoPush = new NotificationDto();
            Map<String, String> actionableContent = new HashMap<>();
            notificationDtoPush.setTargetUserId(Collections.singletonList(authenticatedUserDetails.getEmailId()));
            notificationDtoPush.setTenantId(authenticatedUserDetails.getTenantId());
            notificationDtoPush.setTitle(event.getTitle());
            notificationDtoPush.setNotificationType("NSL_Calendar");
            Type type = new TypeReference<CalendarMetadata>() {
            }.getType();
            CalendarMetadata meta = JacksonUtils.fromJson(event.getMetadata(), type);
            notificationDtoPush.setNotificationChannels(EnumSet.of(NotificationChannel.PUSH));
            actionableContent.put("buttons", "Accept,Decline");
            actionableContent.put("recordId", meta.getRecordId().toString());
            actionableContent.put("url", "http://nsl-adapter:8203/adapter/calendar/acceptanceStatus?encodedData=${encodedData}&button=${button}");
            notificationDtoPush.setActionableContent(actionableContent);
            notificationDtoPush.setActionable("true");

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + authenticatedUserDetails.getAuthToken());
            headers.set("Content-Type", "application/json");
            HttpEntity<String> entity = new HttpEntity<>(JacksonUtils.toJson(notificationDtoPush), headers);

            LOGGER.info("notification type....{}", notificationDtoPush.getNotificationType());  //NOSONAR
            ResponseEntity<String> responseEntity = restTemplate.postForEntity(adaptorProperties.getSendNotification(), entity, String.class);
            if (responseEntity.getStatusCode().is2xxSuccessful()) {
                LOGGER.info("sent push notification successfully");
            } else {
                LOGGER.warn("failed to send push notification");
            }
        } catch (Exception e) {
            LOGGER.warn("faied to send push notification for calendar {}", e.getMessage());
        }
    }

    public ApiResponse fetchRecords(TxnEntitySearchRequest searchRequest, String tag, String eventType, String title, String categoryType) {

        JsonNode node = fetchCalendarEvents(searchRequest, tag, eventType, title, categoryType, false); //Call TXN service

        Type type = new TypeReference<TxnGeneralEntity>() {
        }.getType();
        TxnGeneralEntity txnGeneralEntity = JacksonUtils.fromJson(node.get("result").get("scheduledMeetings").toString(), type); //NOSONAR


        if (txnGeneralEntity.getTransEntityRecords().size() == 1 &&
                txnGeneralEntity.getTransEntityRecords().get(0).getTxnNslAttribute().get(0).getValues().isEmpty())
            return new ApiResponse(HttpStatus.OK, SUCCESS, "No Records founds");
        return new ApiResponse(HttpStatus.OK, SUCCESS, txnGeneralEntity);
    }

    public ApiResponse acceptanceStatus(String encodedData, String button) {

        ApiResponse apiResponse = new ApiResponse();
        String decodedString = new String(Base64.getDecoder().decode(encodedData), StandardCharsets.UTF_8);
        if (decodedString.isEmpty()) {
            LOGGER.info("Decrypted string is null or empty");
            return null;
        }
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = null;
        try {
            jsonNode = objectMapper.readTree(decodedString);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        StringBuilder uri = new StringBuilder(adaptorProperties.getDynamoNewUrl() + "/calendar/updateAcceptanceStatus");
        uri.append("/").append(jsonNode.get("recordId").asText()).append("/").append(requestScopedAuthenticatedUserBean.getEmailId()).append("/").append(button);
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uri.toString());
        HttpHeaders headers = new HttpHeaders();
        headers.add(AUTHORIZATION, AppConstant.BEARER + requestScopedAuthenticatedUserBean.getAuthToken());
        headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        headers.add(ACCEPT_LANGUAGE, AppConstant.ACCEPT_LANGUAGE_EN);
        HttpEntity<String> request = new HttpEntity<>("", headers);
        ResponseEntity<ApiResponse> response = restTemplate.exchange(builder.toUriString(), HttpMethod.PUT, request, ApiResponse.class);
        if (response.getBody().getStatus() == 200 && !(response.getBody() == null)) {  //NOSONAR
            apiResponse = new ApiResponse(HttpStatus.OK, SUCCESS, null);
        }
        return apiResponse;
    }

    public ApiResponse updateEventWithCategory(String id, String userEmail, String categoryType) {

        StringBuilder uri = new StringBuilder(adaptorProperties.getDynamoNewUrl() + "/calendar/categorise/");
        uri.append(id).append(separator).append(userEmail).append(separator).append(categoryType);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uri.toString());
        HttpHeaders headers = new HttpHeaders();
        headers.add(AUTHORIZATION, AppConstant.BEARER + requestScopedAuthenticatedUserBean.getAuthToken());
        headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
        headers.add(ACCEPT_LANGUAGE, AppConstant.ACCEPT_LANGUAGE_EN);
        HttpEntity<String> request = new HttpEntity<>("", headers);

        ResponseEntity<ApiResponse> response = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, request, ApiResponse.class);
        if (!response.hasBody() || response.getBody() == null)
            throw new NullPointerException();

        return new ObjectMapper().convertValue(response.getBody(), ApiResponse.class);
    }

    public ApiResponse generateSlots(CalendarSlotConfig calendarSlotConfig) {

        try {
            CalendarSlotSummary calendarSlotSummary = calendarSaveSlotsImpl.getCalendarSlotSummary(calendarSlotConfig, requestScopedAuthenticatedUserBean);
            return new ApiResponse(HttpStatus.OK, SUCCESS, calendarSlotSummary);
        } catch (Exception e) {
            LOGGER.error("Exception while generating slots and fetching slot summary : " + e.getMessage(), e);
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, FAILURE, e.getMessage());
        }
    }

    public ApiResponse viewRecords(String recordId) {

        {
            StringBuilder uri = new StringBuilder(adaptorProperties.getDynamoNewUrl() + "/calendar/");
            uri.append(recordId);
            UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uri.toString());
            HttpHeaders headers = new HttpHeaders();
            headers.add(AUTHORIZATION, AppConstant.BEARER + requestScopedAuthenticatedUserBean.getAuthToken());
            headers.add(CONTENT_TYPE, String.valueOf(APPLICATION_JSON));
            headers.add(ACCEPT_LANGUAGE, AppConstant.ACCEPT_LANGUAGE_EN);
            HttpEntity<String> request = new HttpEntity<>("", headers);

            ResponseEntity<JsonNode> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, JsonNode.class);
            if (!response.hasBody() || response.getBody() == null)
                throw new NullPointerException();
            Type type = new TypeReference<TxnGeneralEntityRecord>() {
            }.getType();
            TxnGeneralEntityRecord txnGeneralEntityRecord = JacksonUtils.fromJson(response.getBody().get("result").toString(), type); //NOSONAR
            if (txnGeneralEntityRecord.getTxnNslAttribute().get(0).getValues().isEmpty())
                return new ApiResponse(HttpStatus.OK, SUCCESS, "No Records founds");

            ViewResponse viewResponse = new ViewResponse();
            CalendarMetadata metadata = new CalendarMetadata();
            CalendarMetadata md = new CalendarMetadata();
            txnGeneralEntityRecord.getTxnNslAttribute().forEach(attribute -> {

                switch (attribute.getName()) {
                    case "metadata":
                        if (!attribute.getValues().isEmpty())
                            md.setStatus(metadata.build(attribute.getValues().get(0)).getStatus());
                        break;
                    case "startTime":
                        viewResponse.setStartTime(attribute.getValues().get(0));
                        break;
                    case "endTime":
                        viewResponse.setEndTime(attribute.getValues().get(0));
                        break;
                    case "Title":
                        viewResponse.setTitle(attribute.getValues().get(0));
                        break;
                    case "participantList":
                        List<String> participants = attribute.getValues();
                        for (String participant : participants) {
                            viewResponse.updateAttendees(participant);
                        }
                        break;
                    case "Organizer":
                        viewResponse.updateAttendees(attribute.getValues().get(0));
                        break;
                    case "NSL_ActionButton":
                        viewResponse.setGsi(actionButton(attribute.getTxnGeneralEntity().getTransEntityRecords()));
                        break;
                    case "Event Type":
                        viewResponse.setEventType(attribute.getValues().get(0));
                        break;
                    case "conferenceType":
                        viewResponse.setConferenceType(attribute.getValues().get(0));
                        break;
                    case "meetingUrl":
                        viewResponse.setMeetingUrl(attribute.getValues().get(0));
                        break;
                    case "Location":
                        viewResponse.setLocation(attribute.getValues().get(0));
                        break;
                    default:
                        break;
                }
            });
            return new ApiResponse(HttpStatus.OK, SUCCESS, viewResponse);
        }
    }
}
