package com.nsl.adapter.service.facebook.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dao.FetchConnectionService;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.commons.dto.connections.FacebookAdapterConnectionDto;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.Locale;


@Service
public class FacebookConnectionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(FacebookConnectionService.class);

    private static final ConnectionsType connType = ConnectionsType.FACEBOOK;


    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    AdapterConnectionServiceV3 adapterConnectionServiceV3;

    @Autowired
    FetchConnectionService fetchConnectionService;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    MessageSource messageSource;

    public TxnAdapterConnection saveFacebookConnection(FacebookAdapterConnectionDto connectionDto) {

        if (connectionDto.getAppId() == null || connectionDto.getAppSecret() == null ||
                connectionDto.getConnectionName() == null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_182", null, Locale.ENGLISH) , null);
        }

        connectionDataToolsV3.connectionCheck(ConnectionDtoType.FACEBOOK, connectionDto.getConnectionName(), authBean);

        connectionDto.setAppSecret(connectionDataToolsV3.saveSecret(ConnectionDtoType.FACEBOOK, "appSecret",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getAppSecret()));
        connectionDto.setRefreshToken(connectionDataToolsV3.saveSecret(ConnectionDtoType.FACEBOOK, "refreshToken",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getRefreshToken()));

        LOGGER.info("saving FACEBOOK connection");
        TxnAdapterConnection result = new TxnAdapterConnection();
        result.setConnectionDtoType(ConnectionDtoType.FACEBOOK);
        result.setConnection(connectionDto);
        result = adapterConnnectionsDao.saveConnection(result, authBean);
//        if (result == null)
//            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_182", null, Locale.ENGLISH) , null);

        return result;
    }



    public FacebookAdapterConnectionDto getFacebookConnection(Long id, boolean hide) {
        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.FACEBOOK, id, authBean);
        if (previousConnection==null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }
        return txnToFacebookDto(previousConnection, hide);
    }

    public FacebookAdapterConnectionDto getFacebookConnection(Long id) {
        FacebookAdapterConnectionDto previousConnection = fetchConnectionService.getConnection(ConnectionDtoType.FACEBOOK, id, authBean);
        if (previousConnection==null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }
        previousConnection.setAppSecret(connectionDataToolsV3.getSecret(previousConnection.getAppSecret()));
        previousConnection.setRefreshToken(connectionDataToolsV3.getSecret(previousConnection.getRefreshToken()));
        return previousConnection;
    }

    public TxnAdapterConnection updateFacebookConnection(Long id, FacebookAdapterConnectionDto connectionDto) {
        if(  connectionDto.getAppSecret() == null || connectionDto.getAppId() == null ||
                connectionDto.getConnectionName() == null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.FACEBOOK, id, authBean);
        if (previousConnection==null || !previousConnection.getConnection().getConnectionName().equals(connectionDto.getConnectionName())){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }

        FacebookAdapterConnectionDto prevsDto = (FacebookAdapterConnectionDto) previousConnection.getConnection();
        if (connectionDto.getAppId()!=null){
            prevsDto.setAppId(connectionDto.getAppId());
        }
        if (connectionDto.getRefreshToken()!=null){
            prevsDto.setRefreshToken(connectionDataToolsV3.updateSecret(ConnectionDtoType.FACEBOOK, "refreshToken",
                    connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getRefreshToken()));
        }
        previousConnection.setConnection(prevsDto);
        LOGGER.info("update FACEBOOK connection");
        TxnAdapterConnection result = adapterConnnectionsDao.saveConnection(previousConnection, authBean);
//        if (result == null)
//            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,  messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH) , null);

        return result;
    }

    public FacebookAdapterConnectionDto txnToFacebookDto(TxnAdapterConnection adapterConnection, boolean hide) {
        if (adapterConnection==null){
            return null;
        }
        FacebookAdapterConnectionDto dto = (FacebookAdapterConnectionDto) adapterConnection.getConnection();
        if (hide){
            dto.setAppSecret(null);
            dto.setRefreshToken(null);
        }
        dto.getMetadata().put("dsdId",String.valueOf(adapterConnection.getRecordId()));
        return dto;
    }
}
