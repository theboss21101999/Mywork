package com.nsl.adapter.service.mqtt.serviceImpl;
import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.service.inbound.dto.NSLGsiListDto;
import com.nsl.adapter.service.mqtt.utils.MqttInvokeGSIUtil;
import com.nsl.adapter.service.sftp.connection.AuthenticateUser;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.model.ChangeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class SendMqttMessageToProcessor {
    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    AuthenticateUser authenticateUser;
    @Autowired
    MqttInvokeGSIUtil mqttInvokeGSIUtil;
    private static final Logger LOGGER = LoggerFactory.getLogger(SendMqttMessageToProcessor.class);
    public void processClientMessage(JsonNode MqttMsg , NSLGsiListDto nslGsiListDto){
        LOGGER.debug("processing the mqtt inbound msg to call invoke gsi");
        Map<String, String> map = new HashMap<>();
        map.put("userEmail",nslGsiListDto.getSchedulerRequestDto().getUserEmail());
        map.put("userId", String.valueOf(nslGsiListDto.getSchedulerRequestDto().getUserId()));
        map.put("tenantId",nslGsiListDto.getSchedulerRequestDto().getTenantId());

        AuthenticatedUserDetailsImpl authBean = authenticateUser.getAuthenticatedUser(map);
        ChangeUnit mqttInboundCu = changeUnitDao.getChangeUnitById(nslGsiListDto.getChangeUnit().getId(), authBean);
        for (Long gsiId : nslGsiListDto.getGsiMasterIdList()) {

            mqttInvokeGSIUtil.invokeGsi(gsiId, map, mqttInboundCu, authBean,MqttMsg);
        }
    }
}
