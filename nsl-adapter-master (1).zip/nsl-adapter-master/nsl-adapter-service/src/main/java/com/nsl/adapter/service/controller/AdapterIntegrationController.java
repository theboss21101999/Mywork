package com.nsl.adapter.service.controller;

import com.nsl.adapter.service.config.AdminAuth;
import com.nsl.adapter.service.dto.integration.IntegrationSaveRequestDto;
import com.nsl.adapter.service.dto.integration.JsonEntityDto;
import com.nsl.adapter.service.service.AdapterIntegrationService;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import javax.validation.Valid;
import java.util.Map;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@AdminAuth
@RestController
@CrossOrigin
@RequestMapping(value = "/api/v1")
public class AdapterIntegrationController {

    @Autowired
    AdapterIntegrationService adapterIntegrationService;

    @GetMapping(value = "/integration/{dsdId}")
    public ApiResponse getIntegrationById(@PathVariable String dsdId) throws NSLException {
        IntegrationSaveRequestDto integration = adapterIntegrationService.getIntegrationById(dsdId);
        return new ApiResponse(HttpStatus.OK, SUCCESS, integration);
    }

    @PostMapping(value = "/integration/file", consumes = {"multipart/form-data"})
    public ApiResponse saveIntegrationFile(@Nullable @RequestPart("input") MultipartFile inputEntityFile,
                                       @Nullable @RequestPart("output")  MultipartFile outputEntityFile,
                                       @RequestPart("integration") IntegrationSaveRequestDto integrationSaveRequestDto) throws NSLException {
        String changeUnitName = adapterIntegrationService.saveIntegration(integrationSaveRequestDto, inputEntityFile, outputEntityFile);
        return new ApiResponse(HttpStatus.OK, SUCCESS, changeUnitName);
    }

    @PostMapping(value = "/integration/fileInput", consumes = {"multipart/form-data"})
    public ApiResponse saveIntegrationFileInput(@Valid @RequestPart("input") MultipartFile inputEntityFile,
                                           @RequestPart("integration") IntegrationSaveRequestDto integrationSaveRequestDto) throws NSLException {
        String changeUnitName = adapterIntegrationService.saveIntegration(integrationSaveRequestDto, inputEntityFile, null);
        return new ApiResponse(HttpStatus.OK, SUCCESS, changeUnitName);
    }

    @PostMapping(value = "/integration/fileOutput", consumes = {"multipart/form-data"})
    public ApiResponse saveIntegrationFileOutput(@Valid @RequestPart("output") MultipartFile outputEntityFile,
                                           @RequestPart("integration") IntegrationSaveRequestDto integrationSaveRequestDto) throws NSLException {
        String changeUnitName = adapterIntegrationService.saveIntegration(integrationSaveRequestDto, null, outputEntityFile);
        return new ApiResponse(HttpStatus.OK, SUCCESS, changeUnitName);
    }

    @PostMapping(value = "/integration")
    public ApiResponse saveIntegration(@RequestBody IntegrationSaveRequestDto integration) throws NSLException {
        String changeUnitName = adapterIntegrationService.saveIntegration(integration, null, null);
        return new ApiResponse(HttpStatus.OK, SUCCESS, changeUnitName);
    }


    @PutMapping(value = "/integration", consumes = {"multipart/form-data"})
    public ApiResponse updateIntegration(@RequestPart("integration") IntegrationSaveRequestDto integration,
                                         @Nullable @RequestPart("input") MultipartFile inputEntityFile,
                                         @Nullable @RequestPart("output")  MultipartFile outputEntityFile) throws NSLException {
        String changeUnitName = adapterIntegrationService.updateIntegration(integration, inputEntityFile, outputEntityFile);
        return new ApiResponse(HttpStatus.OK, SUCCESS, changeUnitName);
    }

    @PutMapping(value = "/integration")
    public ApiResponse updateIntegrationJson(@RequestBody IntegrationSaveRequestDto integration) throws NSLException {
        String changeUnitName = adapterIntegrationService.updateIntegration(integration,null,null);
        return new ApiResponse(HttpStatus.OK, SUCCESS, changeUnitName);
    }

    @DeleteMapping(value = "/integration")
    public ApiResponse deleteIntegration(@RequestParam Long changeUnitId) {
        boolean result = adapterIntegrationService.deleteIntegrationById(changeUnitId);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }

    @GetMapping(path = "/entity/extract/{entityId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse extractStructure(@PathVariable("entityId") String id){
        JsonEntityDto result = adapterIntegrationService.extractJson(id);
        return new ApiResponse(HttpStatus.OK,SUCCESS,result);
    }
}
