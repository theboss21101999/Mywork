package com.nsl.adapter.service.kafka.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import javax.annotation.PostConstruct;

@Configuration
public class SFTPDataConfig {

    private static final Logger logger = LoggerFactory.getLogger(SFTPDataConfig.class);

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${kafka.maxPollInterval:3600000}")
    private Integer maxPollInterval;

    @Value("${kafka.maxPollRecords:1000}")
    private Integer maxPollRecords;

    @Value("${kafka.topic.adapters.sftp}")
    private String sftpTopic;

    @Value("${kafka.topic.adapters.sftp.group.id}")
    private String sftpConsumerGroupId;

    @Value("${kafka.topic.adapters.gsi.response:}")
    private String gsiTopic;

    @Value("${kafka.topic.adapters.gsi.response.group.id:}")
    private String gsiConsumerGroupId;

    @Value("${sftp.inbound.kafka.concurrency}")
    private Integer sftpInboundKafkaConcurrency;

    @Value("${sftp.inbound.kafka.concurrency.queue.size}")
    private Integer sftpInboundKafkaConcurrencyQueueSize;

    @PostConstruct
    private void printProperties() {
        logger.info("Loaded properties are {}" , this);
    }

    public Integer getSftpInboundKafkaConcurrency() {
        return sftpInboundKafkaConcurrency;
    }

    public Integer getSftpInboundKafkaConcurrencyQueueSize() {
        return sftpInboundKafkaConcurrencyQueueSize;
    }

    public String getBootstrapServers() {
        return bootstrapServers;
    }

    public Integer getMaxPollInterval() {
        return maxPollInterval;
    }

    public Integer getMaxPollRecords() {
        return maxPollRecords;
    }

    public String getSftpTopic() {
        return sftpTopic;
    }

    public String getSftpConsumerGroupId() {
        return sftpConsumerGroupId;
    }

    public String getGsiTopic() {
        return gsiTopic;
    }

    public String getGsiConsumerGroupId() {
        return gsiConsumerGroupId;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("\nSFTPDataConfig {\n");
        builder.append("bootstrap servers=" + bootstrapServers + "\n");
        builder.append("sftp.topic=" + sftpTopic + "\n");
        builder.append("sftp.topic.group.id=" + sftpConsumerGroupId + "\n");
        builder.append("gsi.topic=" + gsiTopic + "\n");
        builder.append("gsi.topic.group.id=" + gsiConsumerGroupId + "\n");
        builder.append('}');
        return builder.toString();
    }
}
