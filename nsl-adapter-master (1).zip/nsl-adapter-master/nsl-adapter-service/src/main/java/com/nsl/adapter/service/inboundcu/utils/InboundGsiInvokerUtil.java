package com.nsl.adapter.service.inboundcu.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.service.GsiExecutor;
import com.nsl.adapter.commons.utils.FileUploadUtil;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtilV2;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.adapter.commons.utils.entity.XmlToEntityUtil;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.ExtSolutionUtil;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.CULayer;
import com.nsl.logical.model.ChangeDriverData;
import com.nsl.logical.model.GSI;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.SlotItem;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnBaseEntity;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnSlotItem;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.nsl.adapter.service.utils.AppConstant.*;

@Service
public class InboundGsiInvokerUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(InboundGsiInvokerUtil.class);

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    GsiExecutor gsiExecutor;

    @Autowired
    MessageSource messageSource;

    @Autowired
    ExtSolutionUtil extSolutionUtil;

    @Autowired
    FileUploadUtil fileUploadUtil;

    @Autowired
    EntityToJSONUtilV2 entityToJsonUtil;

    public ResponseEntity<Map<String, Object>> invokeGsi(Long gsiMasterId, String version, AuthenticatedUserDetailsImpl bean,
                                                         JsonNode body, String xmlString, List<MultipartFile> files, Map<String, String> headerMap,
                                                         Map<String, String> queryMap) throws NSLException, JsonProcessingException {

        if(version!=null) version = version.substring(1);
        LOGGER.debug("fetching gsi using master Id {}",gsiMasterId);
        GSI gsiMaster = changeUnitDao.getGsiByMasterId(gsiMasterId,version, StatusEnum.PUBLISHED , bean);
        if (gsiMaster == null)
            gsiMaster = changeUnitDao.getGsiByMasterId(gsiMasterId,version, StatusEnum.ARCHIVED , bean);

        Long gsiId = gsiMaster.getId();
        LOGGER.debug("fetching gsi using gsiId {}",gsiId);
        GSI gsi = changeUnitDao.getGsiById(gsiId, bean);
        TriggerCU triggerCu = gsi.getSolutionLogic().get(0);

        Map<String, String> cuSysProps = triggerCu.getCuSystemProperties();

        GeneralEntity bodyEntity = getGeneralEntityByName(triggerCu.getLayers(),cuSysProps.get(REQUESTID));
        GeneralEntity headerEntity = getGeneralEntityByName(triggerCu.getLayers(),cuSysProps.get(HEADERENTITYNAME));
        GeneralEntity queryEntity = getGeneralEntityByName(triggerCu.getLayers(),cuSysProps.get(QUERYPARAMENTITYNAME));
        GeneralEntity fileEntity = getGeneralEntityByName(triggerCu.getLayers(),cuSysProps.get(FILEENTITYNAME));
        ObjectMapper mapper = new ObjectMapper();
        List<ChangeDriverData> entityList = new ArrayList<>();
        try {
            LOGGER.info("Parsing file entity");
            if (fileEntity != null && files != null) {
                JsonNode uploadFileResp= uploadFileResp(files,fileUploadUtil.getDsdFolderPath(gsi, fileEntity, 0),bean);
                entityList.add(JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(fileEntity, uploadFileResp));
            }
            LOGGER.info("Parsing body entity");
            if (bodyEntity != null) {
                if (body!=null)
                    entityList.add(JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(bodyEntity, mapper.readTree(body.toString())));
                else if (xmlString!= null) {
                    entityList.add(XmlToEntityUtil.convertXMLToTxnEntity(bodyEntity,new ByteArrayInputStream(xmlString.getBytes(StandardCharsets.UTF_8))));
                }
            }
            LOGGER.info("Parsing header entity");
            if (headerEntity != null)
                entityList.add(JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(headerEntity, mapper.valueToTree(headerMap)));
            LOGGER.info("Parsing query entity");
            if (queryEntity != null)
                entityList.add(JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(queryEntity, mapper.valueToTree(queryMap)));
        }catch (Exception e){
            LOGGER.error("error during parsing data to entity.. ",e);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "error while parsing data to entity:"
                                                                                            + e.getMessage(), e);
        }

        TxnData txnData = extSolutionUtil.setChangeDriverInTxnData( entityList, LayerType.PHYSICAL);

        LOGGER.info("calling gsiExecutor ..");
        JSONObject response = new JSONObject();
        JSONArray list = new JSONArray();
        JsonNode jsonNode=null;
        try {
            jsonNode = gsiExecutor.executeGsiResponse(gsiId, bean, txnData);
            LOGGER.info("Transaction completed with Transaction id: {} ", jsonNode.get(TRANSID).asText()); //NOSONAR
            LOGGER.debug(jsonNode.toString());
        }catch (Exception e) {
            LOGGER.error("Error while executing GSI", e);
            LOGGER.info("Transaction completed with Transaction id: {} ", jsonNode.get(TRANSID).asText()); //NOSONAR
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error while executing GSI:" + e.getMessage(), e);
        }
        try{
            List<TriggerCU> solutionLogic = gsi.getSolutionLogic();
            TxnData responseTxnData= JacksonUtils.getObjectFromJsonString(jsonNode.get(TXNDATA).toString(),TxnData.class);
            int routCuIndex = responseTxnData.getTriggerCuIndex();

            if(responseTxnData.getTriggerState()!=null && responseTxnData.getTriggerState().equals(COMPLETED) &&
                    solutionLogic.get((routCuIndex)-1).getCuSystemProperties().containsKey(ADAPTER)
                    && solutionLogic.get((routCuIndex)-1).getCuSystemProperties().get(ADAPTER).equals(RESTOUTPUT)){

                TriggerCU triggerCU= solutionLogic.get((routCuIndex)-1);
                GeneralEntity inputGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCU.getLayers(),
                        AppConstant.INFORMATION);


                List<TxnSlotItem> transEntityDetails = GeneralEntityUtils.getTransEntityDetails(responseTxnData.getTxnCULayer(),
                        AppConstant.INFORMATION);
                TxnGeneralEntity txnGeneralEntity = GeneralEntityUtils.getExpectedTxnGeneralEntity(transEntityDetails);
                boolean isMultivalued = triggerCU.getLayers().get(0).getParticipatingItems().get(0).getIsMultiValue();
                LOGGER.info("reading data from information layer");
                if (isMultivalued) {
                    if(jsonNode.get(TXNDATA).get("txnCULayer").get(0).get("txnSlotItems").get(0).get("item").get("DATA").get("transEntityRecords").get(0).get("id")!=null) {
                        JSONArray jsonArray = entityToJsonUtil.getJsonArrayFromGE(txnGeneralEntity, inputGeneralEntity);
                        jsonArray.getJSONObject(0).put("recordId", jsonNode.get(TXNDATA).get("txnCULayer").get(0).get("txnSlotItems").get(0).get("item").get("DATA").get("transEntityRecords").get(0).get("id"));
                        jsonArray.getJSONObject(0).put("entityName", jsonNode.get(TXNDATA).get("txnCULayer").get(0).get("txnSlotItems").get(0).get("item").get("DATA").get("NAME"));
                        jsonArray.getJSONObject(0).put(AppConstant.GSI_NAME,gsi.getName());
                        response.put("response", jsonArray);
                    }
                    else{
                        response.put("response", entityToJsonUtil.getJsonArrayFromGE(txnGeneralEntity, inputGeneralEntity));
                    }
                }
                else {
                    if(jsonNode.get(TXNDATA).get("txnCULayer").get(0).get("txnSlotItems").get(0).get("item").get("DATA").get("transEntityRecords").get(0).get("id")!=null) {
                        JSONObject jsonObject;
                        jsonObject = entityToJsonUtil.getJsonObjectFromGE(txnGeneralEntity, inputGeneralEntity);
                        jsonObject.put("recordId", jsonNode.get(TXNDATA).get("txnCULayer").get(0).get("txnSlotItems").get(0).get("item").get("DATA").get("transEntityRecords").get(0).get("id"));
                        jsonObject.put("entityName", jsonNode.get(TXNDATA).get("txnCULayer").get(0).get("txnSlotItems").get(0).get("item").get("DATA").get("NAME"));
                        jsonObject.put(AppConstant.GSI_NAME,gsi.getName());
                        response.put("response", jsonObject);
                    }
                    else{
                        response.put("response", entityToJsonUtil.getJsonObjectFromGE(txnGeneralEntity, inputGeneralEntity));
                    }
                }
            }else{
                JSONObject response2= new JSONObject();
                response2.put(TRANSACTION_ID,jsonNode.get(TRANSID).asText());
                response2.put(AppConstant.GSI_NAME,gsi.getName());
                list.put(response2);
                response.put(RESPONSESTRING,list);
            }
        } catch (Exception e) {
            LOGGER.debug("Failed to read data from Information layer: ", e);
        }
        LOGGER.debug("invoked Gsi Successfully {}",response);
        return ResponseEntity.status(HttpStatus.OK).body(new ObjectMapper().readValue(response.toString(),Map.class));
    }

    public static GeneralEntity getGeneralEntityByName(List<CULayer> cuLayers, String name) {

        for (CULayer layer : cuLayers) {
            if (null != layer && null != layer.getParticipatingItems()
                    && Objects.equals(layer.getType().getLayerType(), LayerType.PHYSICAL.getLayerType())) {

                for (SlotItem slotItem : layer.getParticipatingItems()) {
                    if (((GeneralEntity) slotItem.getItem()).getName().equals(name)) {
                        LOGGER.debug("fetched general Entity {} with name {}", slotItem.getItem() , name);
                        return (GeneralEntity) slotItem.getItem();
                    }
                }
            }
        }
        return null;
    }


    private JsonNode uploadFileResp(List<MultipartFile> files, String folderPath, AuthenticatedUserDetailsImpl authBean){

        List<String> filesList = new ArrayList<>();

        for (MultipartFile file:files) {
            try {
                File file1 = File.createTempFile(Objects.requireNonNull(file.getOriginalFilename()),""); //NOSONAR
                FileUtils.copyInputStreamToFile(file.getInputStream(), file1);
                JsonNode uploadResponse = fileUploadUtil.uploadSingleFile(file1, folderPath, authBean);
                if (uploadResponse!=null) filesList.add(uploadResponse.toString());
            } catch (IOException e) {
                LOGGER.error("failed to upload file ..{0}",e);
            }
        }
        Map<String,List<String>> dsdResponses = new HashMap<>();
        dsdResponses.put("file",filesList);
        return new ObjectMapper().convertValue(dsdResponses,JsonNode.class);
    }

}