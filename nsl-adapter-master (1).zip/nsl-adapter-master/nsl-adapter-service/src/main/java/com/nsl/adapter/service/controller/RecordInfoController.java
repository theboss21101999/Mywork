package com.nsl.adapter.service.controller;

import com.nsl.adapter.commons.dto.PaginatedConnectionsListDto;
import com.nsl.adapter.commons.dto.PaginatedContextualInfoDto;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.service.ContextualInfoSavingService;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.config.AdminAuth;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@AdminAuth
@RestController
@CrossOrigin
@RequestMapping(value = "/api/record")
public class RecordInfoController {

    @Autowired
    AdapterConnectionServiceV3 adapterConnectionServiceV3;

    @Autowired
    ContextualInfoSavingService contextualInfoSavingService;

    @Autowired
    AuthenticatedUserDetailsImpl authBean;

    @GetMapping(path = "/ContextualInfo")
    public ApiResponse getRecordList(@RequestParam(required = false , defaultValue = "1") Integer pageNumber,
                                     @RequestParam(required = false , defaultValue = "20") Integer pageSize,
                                     @RequestParam(required = false) String query){
        PaginatedContextualInfoDto dto;
        dto=contextualInfoSavingService.getContextualInfoList(pageNumber,pageSize,"NSL_ContextualRecord_Info","",authBean);
        return new ApiResponse(HttpStatus.OK, SUCCESS, dto);
    }

}
