package com.nsl.adapter.service.rest.ssl;

public class SslConfig {

    private String keystorePath = null;
    private String trustStorePath = null;
    private String keystorePassword = null;
    private String trustStorePassword = null;
    private String keyPass = null;
    private String trustAllCertificate = "false";// DEFAULT VALUE
    private String keystoreType = "JKS";// DEFAULT VALUE
    private String keyManagerAlgorithm = null;


    public String getKeystorePath() {
        return keystorePath;
    }

    public void setKeystorePath(String keystorePath) {
        this.keystorePath = keystorePath;
    }

    public String getTrustStorePath() {
        return trustStorePath;
    }

    public void setTrustStorePath(String trustStorePath) {
        this.trustStorePath = trustStorePath;
    }

    public String getKeystorePassword() {
        return keystorePassword;
    }

    public void setKeystorePassword(String keystorePassword) {
        this.keystorePassword = keystorePassword;
    }

    public String getTrustStorePassword() {
        return trustStorePassword;
    }

    public void setTrustStorePassword(String trustStorePassword) {
        this.trustStorePassword = trustStorePassword;
    }

    public String getKeyPass() {
        return keyPass;
    }

    public void setKeyPass(String keyPass) {
        this.keyPass = keyPass;
    }

    public String getTrustAllCertificate() {
        return trustAllCertificate;
    }

    public void setTrustAllCertificate(String trustAllCertificate) {
        this.trustAllCertificate = trustAllCertificate;
    }

    public String getKeystoreType() {
        return keystoreType;
    }

    public void setKeystoreType(String keystoreType) {
        this.keystoreType = keystoreType;
    }

    public String getKeyManagerAlgorithm() {
        return keyManagerAlgorithm;
    }

    public void setKeyManagerAlgorithm(String keyManagerAlgorithm) {
        this.keyManagerAlgorithm = keyManagerAlgorithm;
    }
}
