package com.nsl.adapter.service.controller;

import com.nsl.adapter.commons.dto.RefreshTokenDto;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.RefreshTokenScheduler;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Locale;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/api")
public class TokenNotificationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(TokenNotificationController.class);

    @Autowired
    private MessageSource messageSource;

    @Autowired
    RefreshTokenScheduler refreshTokenScheduler;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @PostMapping(value = "/refreshtoken/email_notification")
    public ApiResponse RefreshTokenNotification(@RequestBody RefreshTokenDto refreshTokenDto) {

        LOGGER.info("Api invoked with ConnectionName : {} ", refreshTokenDto.getConnectionName());

        if (refreshTokenDto.getConnectionType() == null)
            return new ApiResponse(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_19", null, Locale.ENGLISH), null);

        JSONObject jsonObject = refreshTokenScheduler.sendPushNotification(refreshTokenDto, authBean);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
}
