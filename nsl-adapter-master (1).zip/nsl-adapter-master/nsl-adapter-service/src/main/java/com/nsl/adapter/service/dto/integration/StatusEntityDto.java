package com.nsl.adapter.service.dto.integration;

public class StatusEntityDto {
    String name;
    String id;
    String isMultivalue;

    public StatusEntityDto() {
    }

    public StatusEntityDto(String name, String id, String isMultivalue) {
        this.name = name;
        this.id = id;
        this.isMultivalue = isMultivalue;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIsMultivalue() {
        return isMultivalue;
    }

    public void setIsMultivalue(String isMultivalue) {
        this.isMultivalue = isMultivalue;
    }
}
