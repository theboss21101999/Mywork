package com.nsl.adapter.service.controller;

import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.service.dto.Connection;
import com.nsl.adapter.service.service.ImportExportService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@CrossOrigin
@RequestMapping(value = "/import_export")
public class ImportExportController {

    @Autowired
    ImportExportService importExportService;

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @GetMapping(value = "/getConnectionById/{adapterType}/{id}")
    public ApiResponse getConnectionById(@PathVariable("adapterType") AdapterType adapterType,
                                         @PathVariable("id") Long id) {

        Connection connection = importExportService.getConnectionById(adapterType, id);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, connection);
    }

    @GetMapping(value = "/getConnectionByName/{adapterType}/{name}")
    public ApiResponse getConnectionByName(@PathVariable("adapterType") AdapterType adapterType,
                                           @PathVariable("name") String name) {

        Connection connection = importExportService.getConnectionByName(adapterType, name);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, connection);
    }

    @PostMapping(value = "/dummyConnection")
    public ApiResponse createDummyConnection(@RequestBody Connection connection) throws NSLException {

        Connection result = importExportService.createConnection(connection);
        if (result == null)
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, AppConstant.FAILURE, null);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, connection);
    }

    @PostMapping(value = "/metaInfoEntity/{integrationName}")
    public ApiResponse generateAndSaveMetaInfoEntity(@PathVariable("integrationName") String integrationName) {
        String metaInfoEntityId = metaInfoEntityUtils.createMetaInfoEntity(integrationName, authBean);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, metaInfoEntityId);
    }


}
