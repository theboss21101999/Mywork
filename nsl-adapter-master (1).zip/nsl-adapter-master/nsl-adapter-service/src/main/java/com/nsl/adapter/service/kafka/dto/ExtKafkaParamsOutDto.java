package com.nsl.adapter.service.kafka.dto;


public class ExtKafkaParamsOutDto {
    
    private String connectionType;
    private String topic;
    private String zookeeperServer;
    private Integer zookeeperPort;
    private String bootstrapServer;
    private String bootstrapPort;
    private String truststorePassword;
    private String keyPassword;
    private String username;
    private String password;

    public String getConnectionType() {
        return connectionType;
    }

    public void setConnectionType(String connectionType) {
        this.connectionType = connectionType;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getZookeeperServer() {
        return zookeeperServer;
    }

    public void setZookeeperServer(String zookeeperServer) {
        this.zookeeperServer = zookeeperServer;
    }

    public Integer getZookeeperPort() {
        return zookeeperPort;
    }

    public void setZookeeperPort(Integer zookeeperPort) {
        this.zookeeperPort = zookeeperPort;
    }

    public String getBootstrapServer() {
        return bootstrapServer;
    }

    public void setBootstrapServer(String bootstrapServer) {
        this.bootstrapServer = bootstrapServer;
    }

    public String getBootstrapPort() {
        return bootstrapPort;
    }

    public void setBootstrapPort(String bootstrapPort) {
        this.bootstrapPort = bootstrapPort;
    }

    public String getTruststorePassword() {
        return truststorePassword;
    }

    public void setTruststorePassword(String truststorePassword) {
        this.truststorePassword = truststorePassword;
    }

    public String getKeyPassword() {
        return keyPassword;
    }

    public void setKeyPassword(String keyPassword) {
        this.keyPassword = keyPassword;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "ExtKafkaParamsOutDto [bootstrapPort=" + bootstrapPort + ", bootstrapServer=" + bootstrapServer
                + ", connectionType=" + connectionType + ", topic=" + topic + ", zookeeperPort=" + zookeeperPort
                + ", zookeeperServer=" + zookeeperServer + "]";
    }


    
}
