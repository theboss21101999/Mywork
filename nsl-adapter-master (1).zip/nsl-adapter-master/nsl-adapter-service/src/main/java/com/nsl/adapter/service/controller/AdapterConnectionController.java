package com.nsl.adapter.service.controller;

import com.nsl.adapter.commons.dto.Integrations.dto.PaginatedCUsDto;
import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.impl.AdapterConnectionsDynamoDao;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.commons.utils.RestValidations;
import com.nsl.adapter.service.config.AdminAuth;
import com.nsl.adapter.service.kafka.utils.ConnectionToEntity;
import com.nsl.adapter.service.kafka.utils.KafkaConnectionTools;
import com.nsl.adapter.service.rest.service.ConnectionToGeneral;
import com.nsl.adapter.service.rest.utils.ConnectionConstants;
import com.nsl.adapter.service.rest.utils.ConnectionDataTools;
import com.nsl.adapter.service.rest.utils.RestOauthConnection;
import com.nsl.adapter.service.service.AdapterIntegrationServiceV3;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.Locale;
import java.util.Objects;

import static com.nsl.adapter.commons.dto.connections.OAuthGrantType.AUTHORIZATIONCODE;
import static com.nsl.adapter.commons.dto.connections.OAuthGrantType.AUTHORIZATIONCODE_PKCE;
import static com.nsl.adapter.commons.dto.connections.RESTAuthorizationType.OAUTH2;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.KAFKA_CONNECTION;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@AdminAuth
@RestController
@CrossOrigin
@RequestMapping(value = "/api/v1/connect")
public class AdapterConnectionController {
    private static final String INVALID_DATA = "Please send valid Data";
    private static final String DUPLICATE_CONN_NAME ="Connection Name Already Exists";
    private static final String INVALID_AUTH_DETAILS = "Please send valid authentication details";
    private static final String HEADERS_ISSUE = "Issue with the headers or access_Token";
    private static final String INVALID_IP_DETAILS = "Please provide a valid/public base url";
    @Autowired
    RestOauthConnection oauthConnection;
    @Autowired
    ConnectionToGeneral connectionService;

    @Autowired
    ConnectionDataTools connectionDataTools;

    @Autowired
    KafkaConnectionTools kafkaConnectionTools;

    @Autowired
    ConnectionToEntity kafkaConnectionToEntity;

    @Autowired
    private MessageSource messageSource;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;
    @Autowired
    AdapterIntegrationServiceV3 adapterIntegrationServiceV3;
    @Autowired
    AdapterConnectionsDynamoDao adapterConnectionsDynamoDao;

    @Autowired
    RestValidations restValidations;
    @Value("${rest.adapter.security.enabled:true}")
    private String isPrivateIPEnabled;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @PostMapping(path = "/rest", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveRestConnection(@RequestBody RESTAdapterConnectionDto connectionDto) throws NSLException {

        if (!connectionDataTools.validateRestDto(connectionDto)) {
            return new ApiResponse(HttpStatus.BAD_REQUEST, INVALID_DATA, null);
        }
        connectionDataToolsV3.connectionCheck(ConnectionDtoType.REST,connectionDto.getConnectionName(),requestScopedAuthenticatedUserBean);
        if (!connectionDataTools.validateRestCredential(connectionDto.getAuthentication())) {
            return new ApiResponse(HttpStatus.BAD_REQUEST, INVALID_AUTH_DETAILS, null);
        }
        if(Boolean.parseBoolean(isPrivateIPEnabled))
        {
            if (!restValidations.validateBaseUrl(connectionDto.getBaseUrl())) {
                return new ApiResponse(HttpStatus.BAD_REQUEST, INVALID_IP_DETAILS, null);
            }
        }
        String authorizationType = String.valueOf(connectionDto.getAuthentication().getAuthorizationType());
        JSONObject jsonObject = null;
        TxnAdapterConnection result = connectionService.restSaved(connectionDto);
        if(Objects.equals(authorizationType, OAUTH2.toString())){
            if(connectionDto.getAuthentication().getOAuthCredentials().getGrantType() == AUTHORIZATIONCODE || connectionDto.getAuthentication().getOAuthCredentials().getGrantType() == AUTHORIZATIONCODE_PKCE) {
                jsonObject = oauthConnection.getAuthorizationcode(connectionDto, result);
                return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
            }
            else{
                return new ApiResponse(HttpStatus.OK, SUCCESS, result);
            }
        }
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }
    @GetMapping(path = "/rest/refreshToken/{Id}")
    public ApiResponse updateRestConnection(@PathVariable("Id") Long id){
        TxnAdapterConnection result =oauthConnection.getRefreshToken(id);
        return new ApiResponse(HttpStatus.OK,SUCCESS,result);
    }

    @GetMapping(path = "/rest/{attrId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getRestConnection(@PathVariable("attrId") Long attrId) {

        RESTAdapterConnectionDto result = connectionService.getEntityRecordrest(attrId, true);
        if (result != null) {
            return new ApiResponse(HttpStatus.OK, SUCCESS, result);
        }

        return new ApiResponse(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_12 + {" + attrId + "}" + "Paas_Adapter_11", null, Locale.ENGLISH), null);
    }

    @PutMapping(path = "/rest/{attrId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse updateRestConnection(@PathVariable("attrId") Long attrId, @RequestBody RESTAdapterConnectionDto connectionDto) {
        if (connectionDto.getAuthentication() != null) {
            if (!connectionDataTools.validateRestCredential(connectionDto.getAuthentication())) {
                return new ApiResponse(HttpStatus.BAD_REQUEST, INVALID_AUTH_DETAILS, null);
            }
        }
        if(Boolean.parseBoolean(isPrivateIPEnabled)){
            if (!restValidations.validateBaseUrl(connectionDto.getBaseUrl())) {
                return new ApiResponse(HttpStatus.BAD_REQUEST, INVALID_IP_DETAILS, null);
            }
        }
        TxnAdapterConnection result = connectionService.updateRestEntity(attrId, connectionDto);
        String authorizationType = String.valueOf(connectionDto.getAuthentication().getAuthorizationType());
        JSONObject jsonObject = null;
        if(Objects.equals(authorizationType, OAUTH2.toString())){
            if(connectionDto.getAuthentication().getOAuthCredentials().getGrantType() == AUTHORIZATIONCODE || connectionDto.getAuthentication().getOAuthCredentials().getGrantType() == AUTHORIZATIONCODE_PKCE) {
                jsonObject = oauthConnection.getAuthorizationcode(connectionDto, result);
                return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
            }
            else{
                return new ApiResponse(HttpStatus.OK, SUCCESS, result);
            }
        }
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }

    @PostMapping(path = "/kafka", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveKafkaConnection(@RequestBody KafkaConnectionDto connectionDto) throws NSLException {

        if (!kafkaConnectionTools.validateDto(connectionDto))
            return new ApiResponse(HttpStatus.BAD_REQUEST, INVALID_DATA, null);

        if (connectionService.checkConnectionName(KAFKA_CONNECTION, connectionDto.getConnectionName()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, DUPLICATE_CONN_NAME, null);

        if (!kafkaConnectionTools.validateAuthCredentials(connectionDto.getAuthentication()))
            return new ApiResponse(HttpStatus.BAD_REQUEST, INVALID_AUTH_DETAILS, null);

        TxnGeneralEntityRecord result = kafkaConnectionToEntity.saveKafkaConnection(connectionDto);

        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }

    @DeleteMapping(path = "/delete/connection/{connectionId}")
    public ApiResponse getConnectionsList(@RequestParam(required = false , defaultValue = "1") Integer pageNumber,
                                          @RequestParam(required = false , defaultValue = "20") Integer pageSize,
                                          @RequestParam(required = false) String query,
                                          @RequestParam("connectionType") ConnectionDtoType connectionDtoType,
                                          @PathVariable("connectionId") Long connectionId) throws Exception {
        PaginatedCUsDto paginatedCUsDto = adapterIntegrationServiceV3.getConnectionCuList(connectionId.toString(), query, String.valueOf(AdapterType.valueOf(connectionDtoType.toString())), pageNumber, pageSize);
        if (!paginatedCUsDto.getCuDtoList().isEmpty()) {
            return new ApiResponse(HttpStatus.BAD_REQUEST, AppConstant.FAILED, paginatedCUsDto);
        } else {
            boolean result = adapterConnectionsDynamoDao.deleteConnectionById(connectionDtoType, connectionId, requestScopedAuthenticatedUserBean);
            return new ApiResponse(HttpStatus.OK, SUCCESS, result);
        }
    }

}