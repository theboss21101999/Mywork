package com.nsl.adapter.service.linkedin.enums;

public enum LinkedinOperation {
    CREATE_TEXT_SHARE,
    CREATE_ARTICLE_SHARE,
    CREATE_IMAGE_SHARE,
    CREATE_MEDIA_POST,
    GET_POST_ACTIVITY

}
