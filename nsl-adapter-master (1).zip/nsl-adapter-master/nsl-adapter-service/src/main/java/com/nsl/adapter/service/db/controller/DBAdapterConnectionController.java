package com.nsl.adapter.service.db.controller;

import com.mongodb.MongoClient;
import com.nsl.adapter.commons.dto.connections.DBConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.db.service.DBConnectionFactory;
import com.nsl.adapter.service.db.service.DBConnectionService;
import com.nsl.adapter.service.db.util.DatabaseAndDBServerConnectionUtil;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;

import static com.nsl.adapter.service.utils.AppConstant.FAILURE;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class DBAdapterConnectionController {

    @Autowired
    DBConnectionService dbConnectionService;

    @Autowired
    DBConnectionFactory dbConnectionFactory;

    @Autowired
     MessageSource messageSource;

    @Autowired
    DatabaseAndDBServerConnectionUtil databaseAndDBServerConnectionUtil;


    @PostMapping(path = "/db")
    public ApiResponse saveDBConnection(@RequestBody DBConnectionDto connectionDto) throws ClassNotFoundException {
        TxnAdapterConnection result = dbConnectionService.saveDBConnection(connectionDto);
        if (result!=null) {
            return new ApiResponse(HttpStatus.OK, SUCCESS, result);
        }
        return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,FAILURE,result);
    }

    @GetMapping(path = "/db/{Id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getDBConnection(@PathVariable("Id") Long id) {
        DBConnectionDto response = dbConnectionService.getDBConnection(id, false);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @PutMapping(path = "/db/{id}")
    public ApiResponse updateDBConnection(@PathVariable("id") Long id,
                                          @RequestBody DBConnectionDto connectionDto)  {
        TxnAdapterConnection result = dbConnectionService.updateDBConnection(id, connectionDto);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);

    }
    @PostMapping(path = "/db/test")
    public ApiResponse testDbConnection(@RequestBody DBConnectionDto connectionDto) {

        if ((connectionDto.getDb_type().equals("POSTGRES")) && (connectionDto.getDataSourceDriver() != null) && (connectionDto.getDataSourceUrl() != null) && (connectionDto.getUsername() != null) && (connectionDto.getPassword() != null)) {
            try {
               Connection con= databaseAndDBServerConnectionUtil.PostgreSqlDBserverConnection(connectionDto);
                return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, SUCCESS);
            }catch (Exception e){
                return new ApiResponse(HttpStatus.BAD_REQUEST, AppConstant.FAILURE,FAILURE);
            }
            } else if ((connectionDto.getDb_type().equals("MYSQL")) && (connectionDto.getDataSourceDriver() != null) && (connectionDto.getDataSourceUrl() != null) && (connectionDto.getUsername() != null) && (connectionDto.getPassword() != null)) {
            try {
                Connection con=databaseAndDBServerConnectionUtil.MyssqlDBserverConnection(connectionDto);
                return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, SUCCESS);
            }catch (Exception e){
                return new ApiResponse(HttpStatus.BAD_REQUEST, AppConstant.FAILURE,FAILURE);
            }
            } else if ((connectionDto.getDb_type().equals("MONGODB")) && (connectionDto.getDataSourceUrl()!=null)) {
            try {
                MongoClient mongoClient= databaseAndDBServerConnectionUtil.MongoDBServerConnection(connectionDto);
                return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, SUCCESS);
            }catch (Exception e){
                return new ApiResponse(HttpStatus.BAD_REQUEST, AppConstant.FAILURE,FAILURE);
            }
            } else if ((connectionDto.getDb_type().equalsIgnoreCase("SQLSERVER")) && (connectionDto.getDataSourceUrl() != null)) {
            try {
                Connection con = databaseAndDBServerConnectionUtil.SqlServerDBserverConnection(connectionDto);
                return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, SUCCESS);
            } catch (Exception e) {
                return new ApiResponse(HttpStatus.BAD_REQUEST, AppConstant.FAILURE, FAILURE);
            }
        }
        return new ApiResponse(HttpStatus.BAD_REQUEST, AppConstant.FAILURE,FAILURE);

        }

    }



