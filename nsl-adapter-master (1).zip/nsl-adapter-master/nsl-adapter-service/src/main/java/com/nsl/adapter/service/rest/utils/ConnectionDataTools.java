package com.nsl.adapter.service.rest.utils;

import com.nsl.adapter.commons.dto.connections.HawkCredentials;
import com.nsl.adapter.commons.dto.connections.OAuthGrantType;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.RESTCredential;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.datatypes.constants.AppConstants;
import com.nsl.datatypes.primitives.NSLEncryptedText;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

@Service
public class ConnectionDataTools {

    @Autowired
    private NSLEncryptedText nslEncryptedText;

    @Value("${connect.encrypt:true}")
    private boolean encryptionFlag;


    public TxnNslAttribute createNslAttribute(NslAttribute nslAttribute, String value) {
        TxnNslAttribute txnNslAttribute = new TxnNslAttribute();
        txnNslAttribute.setName(nslAttribute.getName());
        txnNslAttribute.setNslAttributeID(nslAttribute.getId());
        List<String> valueList = new ArrayList<String>();
        if (value != null) {
            valueList.add(value);
        }
        txnNslAttribute.setValues(valueList);
        return txnNslAttribute;
    }

    public String encryptText(String data) {
        if (!encryptionFlag) {
            return data;
        }
        Map<String, String> outputMap = nslEncryptedText.encrypt(data, "key", null);
        return outputMap.get(AppConstants.ENCRYPTED_TEXT);
    }

    public String decryptText(String data) {
        if (!encryptionFlag) {
            return data;
        }
        Map<String, String> outputMap = nslEncryptedText.decrypt(data, "key");
        return outputMap.get(AppConstants.DISPLAY_TEXT);
    }




    public Properties createadvancedConfig(TxnNslAttribute attribute) {
        Properties advance = null;
        JSONParser jsonparser = new JSONParser();
        try {
            JSONObject json = (JSONObject) jsonparser.parse(decryptText(attribute.getValues().get(0)));
            advance = JacksonUtils.fromJson(json.toJSONString(), Properties.class);
        } catch (Exception e) {
            return null;
        }

        return advance;
    }

    public boolean validateRestDto(RESTAdapterConnectionDto connectionDto) {
        if (connectionDto.getBaseUrl() == null || connectionDto.getConnectionName() == null || connectionDto.getAuthentication() == null) {
            return false;
        }
        return true;

    }

    public boolean validateRestCredential(RESTCredential restCredential) {
        if (restCredential.getAuthorizationType() == null) {
            return false;
        }
        switch (restCredential.getAuthorizationType()) {
            case PASSWORD:
                if (restCredential.getUsername() == null || restCredential.getPassword() == null) {
                    return false;
                }
                break;
            case OAUTH2:
                if (restCredential.getOAuthCredentials() == null) {
                    return false;
                }
                if (restCredential.getOAuthCredentials().getGrantType() == null) {
                    return false;
                }
                if (restCredential.getOAuthCredentials().getLocation() == null || restCredential.getOAuthCredentials().getAccessTokenUri() == null || restCredential.getOAuthCredentials().getClientId() == null || restCredential.getOAuthCredentials().getClientSecret() == null) {
                    return false;
                }
                if (OAuthGrantType.AUTHORIZATIONCODE == restCredential.getOAuthCredentials().getGrantType()) {
                    if (restCredential.getOAuthCredentials().getAuthorizationUri() == null) {
                        return false;
                    }
                }
                break;
            case APIKEY:
                if (restCredential.getApiKeyCredentials() == null) {
                    return false;
                }
                if (restCredential.getApiKeyCredentials().getKey() == null || restCredential.getApiKeyCredentials().getLocation() == null) {
                    return false;
                }
                break;
            case HAWK:
                HawkCredentials credentials = restCredential.getHawkCredentials();
                if (credentials.getAuthId() == null || credentials.getAuthKey() == null || credentials.getAlgorithm() == null)
                    return false;
            default:
                break;
        }

        return true;
    }

    public RESTCredential cleanRestCredentials(RESTCredential restCredential) {
        if (restCredential == null) {
            return null;
        }
        RESTCredential cred = new RESTCredential();
        cred.setAuthorizationType(restCredential.getAuthorizationType());
        switch (restCredential.getAuthorizationType()) {
            case PASSWORD:
                cred.setUsername(restCredential.getUsername());
                cred.setPassword(restCredential.getPassword());
                break;
            case OAUTH:
            case OAUTH2:
                cred.setOAuthCredentials(restCredential.getOAuthCredentials());
                cred.setUsername(restCredential.getUsername());
                cred.setPassword(restCredential.getPassword());
                break;
            case APIKEY:
                cred.setApiKeyCredentials(restCredential.getApiKeyCredentials());
            case HAWK:
                cred.setHawkCredentials(restCredential.getHawkCredentials());
                break;

            default:
                break;
        }
        return cred;
    }

    public boolean checkEntityRecordByconnectionName(TxnGeneralEntityRecord record, String connectionName) {
        List<TxnNslAttribute> attributeList = record.getTxnNslAttribute();
        for (TxnNslAttribute attribute : attributeList) {
            if (attribute.getName().equals("connectionName")) {
                if (attribute.getValues().get(0).equals(connectionName)) {
                    return true;
                }
            }
        }
        return false;
    }

}

