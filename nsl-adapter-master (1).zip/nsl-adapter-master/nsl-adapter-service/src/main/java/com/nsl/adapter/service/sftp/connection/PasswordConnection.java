package com.nsl.adapter.service.sftp.connection;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.nsl.adapter.commons.dto.connections.SFTPAdapterConnectionDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import java.util.Locale;


public class PasswordConnection extends SFTPConnection{

    private static final Logger LOGGER = LoggerFactory.getLogger(PasswordConnection.class);


    @Autowired
    private MessageSource messageSource;

    @Override
    protected void createConnection(SFTPAdapterConnectionDto sftpAdapterConnectionDto) throws SFTPConnectionException{
        jsch = new JSch();
        try {
            session = jsch.getSession(sftpAdapterConnectionDto.getAuthentication().getUsername(), sftpAdapterConnectionDto.getHost(),
                    sftpAdapterConnectionDto.getPort());
            session.setPassword(sftpAdapterConnectionDto.getAuthentication().getPassword());
            LOGGER.info("session created");
            if(sftpAdapterConnectionDto.getAdvancedConfig()!=null && !sftpAdapterConnectionDto.getAdvancedConfig().isEmpty() ){
                session.setConfig(sftpAdapterConnectionDto.getAdvancedConfig());
            }else {
                java.util.Properties configDefault = new java.util.Properties();
                configDefault.put("StrictHostKeyChecking", "no");
                session.setConfig(configDefault);
            }
            session.connect();
            channel = session.openChannel("sftp");
            channel.connect();
            LOGGER.info("shell channel connected...");
            channelSftp = (ChannelSftp) channel;
            LOGGER.info("SFTP connected");
        } catch (JSchException e) {
            throw new SFTPConnectionException(messageSource.getMessage("Paas_Adapter_192", null, Locale.ENGLISH),e);
        }
    }
}
