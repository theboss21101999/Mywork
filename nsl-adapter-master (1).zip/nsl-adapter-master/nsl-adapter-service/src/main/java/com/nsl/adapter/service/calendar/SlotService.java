package com.nsl.adapter.service.calendar;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.calendar.dto.SchedulerSlotDto;
import com.nsl.adapter.service.calendar.utils.SlotServiceUtils;
import com.nsl.adapter.service.dto.SlotFetchDto;
import com.nsl.externalreservedcus.dto.CalendarAdminSlotConfig;
import com.nsl.externalreservedcus.dto.calender.event.CalendarEvent;
import com.nsl.externalreservedcus.impl.CalendarSaveSlotsImpl;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.nsl.adapter.service.calendar.utils.SlotConstants.*;
import static com.nsl.adapter.service.utils.AppConstant.FAILURE;
import static com.nsl.common.constant.AppConstant.FAILED;
import static com.nsl.common.constant.AppConstant.SUCCESS;

@Service
public class SlotService {

    @Autowired
    SlotServiceUtils slotServiceUtils;

    @Autowired
    AuthenticatedUserDetailsImpl userDetails;

    @Autowired
    CalendarService calendarService;

    @Autowired
    CalendarSaveSlotsImpl calendarSaveSlotsImpl;

    SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, HH:mm");

    private static final Logger LOGGER = LoggerFactory.getLogger(SlotService.class);

    public static Calendar adjustTime(Date startDate) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        cal.add(Calendar.HOUR, -5);
        cal.add(Calendar.MINUTE, -30);
        return cal;
    }

    public ApiResponse rescheduleSlot(String startTime, String endTime, String eventId) throws ParseException {
        CalendarEvent fetchedSlot = slotServiceUtils.fetchSlot(eventId);
        SlotFetchDto slotFetchDto = getSlotFetchDto(fetchedSlot);
        CalendarEvent rescheduleSlot = slotServiceUtils.fetchSlots(startTime, endTime, slotFetchDto);
        if (rescheduleSlot != null) {
            String additionalInfo5 = rescheduleSlot.getAdditionalInfo5();
            String eventType = rescheduleSlot.getEventType();
            if (BOOKED.equals(additionalInfo5)) {
                return new ApiResponse(HttpStatus.CONFLICT, "Slot is not free", null);
            }
            if (!eventType.equals(fetchedSlot.getEventType())) {
                return new ApiResponse(HttpStatus.BAD_REQUEST, "Event type mismatch", null);
            }
            rescheduleSlot.setParticipantList(fetchedSlot.getParticipantList());
            rescheduleSlot.setTitle(fetchedSlot.getTitle());
            rescheduleSlot.setAdditionalInfo1(fetchedSlot.getAdditionalInfo1());
            rescheduleSlot.setAdditionalInfo2(fetchedSlot.getAdditionalInfo2());
            if (eventType.equals(ONETOONE)) {
                rescheduleSlot.setAdditionalInfo5(BOOKED);
            }
            validateCalendarEvent(rescheduleSlot);
            String metadata = rescheduleSlot.getMetadata();
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode jsonNode = null;
            String recordId = "";
            try {
                jsonNode = objectMapper.readTree(metadata);
                recordId = String.valueOf(jsonNode.get("recordId"));

            } catch (Exception e) {
            }
            String subject = "Appointment Confirmation";
            String description = "Appointment confirmed with Appointment ID: " + recordId + "at" + startTime + "with" + fetchedSlot.getOrganizer();
            slotServiceUtils.sendEmailNotification(fetchedSlot.getParticipantList(), description, subject);
            calendarService.saveCalendarEvent(rescheduleSlot, UPDATE);
        } else {
            throw new RuntimeException("No slot available");
        }
        fetchedSlot.setAdditionalInfo5(AVAILABLE);
        fetchedSlot.getParticipantList().clear();
        fetchedSlot.getParticipantList().add(fetchedSlot.getOrganizer());
        calendarService.saveCalendarEvent(fetchedSlot, UPDATE);
        return new ApiResponse(HttpStatus.OK, SUCCESS, fetchedSlot);
    }

    private static SlotFetchDto getSlotFetchDto(CalendarEvent fetchedSlot) {
        SlotFetchDto slotFetchDto = new SlotFetchDto();
        if (!fetchedSlot.getOrganizer().isEmpty()) {
            slotFetchDto.setOrganizer(fetchedSlot.getOrganizer());
        }
        if (!fetchedSlot.getConferenceType().isEmpty()) {
            slotFetchDto.setConferenceType(fetchedSlot.getConferenceType());
        }
        if (!fetchedSlot.getAdditionalInfo4().isEmpty()) {
            slotFetchDto.setAdditionalInfo4(fetchedSlot.getAdditionalInfo4());
        }
        if (!fetchedSlot.getAdditionalInfo2().isEmpty()) {
            slotFetchDto.setAdditionalInfo2(fetchedSlot.getAdditionalInfo2());
        }
        return slotFetchDto;
    }

    protected void validateCalendarEvent(CalendarEvent calendarEvent) {
        if (calendarEvent.getTitle() == null || calendarEvent.getTitle().isEmpty()) {
            throw new NullPointerException();
        }
        if (calendarEvent.getStartTime() == null || calendarEvent.getEndTime() == null) {
            throw new NullPointerException();
        }
        if (calendarEvent.getParticipantList() == null || calendarEvent.getParticipantList().isEmpty()) {
            throw new NullPointerException();
        }
        if (calendarEvent.getOrganizer() == null || calendarEvent.getOrganizer().isEmpty()) {
            throw new NullPointerException();
        }
        if (calendarEvent.getEventType() == null || calendarEvent.getEventType().isEmpty()) {
            throw new NullPointerException();
        }
        if (calendarEvent.getAdditionalInfo1() == null || calendarEvent.getAdditionalInfo1().isEmpty()) {
            throw new NullPointerException();
        }
        if (calendarEvent.getAdditionalInfo2() == null || calendarEvent.getAdditionalInfo2().isEmpty()) {
            throw new NullPointerException();
        }
        if (calendarEvent.getAdditionalInfo3() == null || calendarEvent.getAdditionalInfo3().isEmpty()) {
            throw new NullPointerException();
        }
        if (calendarEvent.getAdditionalInfo4() == null || calendarEvent.getAdditionalInfo4().isEmpty()) {
            throw new NullPointerException();
        }
        if (calendarEvent.getAdditionalInfo5() == null || calendarEvent.getAdditionalInfo5().isEmpty()) {
            throw new NullPointerException();
        }
    }

    public ApiResponse updateSlot(CalendarEvent calendarEvent) {
        String additionalInfo5 = calendarEvent.getAdditionalInfo5();
        if (!isValidAdditionalInfo5(additionalInfo5)) {
            throw new IllegalArgumentException("Invalid value for Status. It should be either 'Available', 'Booked', 'Completed', or 'No show'.");
        }
        Date startDate = adjustTime(calendarEvent.getStartTime()).getTime();
        Date endDate = adjustTime(calendarEvent.getEndTime()).getTime();
        calendarEvent.setStartTime(startDate);
        calendarEvent.setEndTime(endDate);
        calendarService.saveCalendarEvent(calendarEvent, UPDATE);
        return new ApiResponse(HttpStatus.OK, SUCCESS, calendarEvent);
    }

    public boolean isValidAdditionalInfo5(String additionalInfo5) {
        return additionalInfo5 != null &&
                (additionalInfo5.equals("Available") ||
                        additionalInfo5.equals("Booked") ||
                        additionalInfo5.equals("Completed") ||
                        additionalInfo5.equals("No show"));
    }

    public ApiResponse bookSlot(SchedulerSlotDto schedulerSlotDto, String eventId, String desiredStatus) throws NSLException, ParseException, JsonProcessingException {
        CalendarEvent fetchedSlot = slotServiceUtils.fetchSlot(eventId);
        if (fetchedSlot.getMetadata() == null) {
            return new ApiResponse(HttpStatus.NOT_FOUND, "Slot not found", null);
        }
        List<String> participants = new ArrayList<>();
        List<String>participantList = schedulerSlotDto.getParticipantList();
        participants.addAll(participantList);
        if (BOOKED.equals(desiredStatus)) {
            if (!AVAILABLE.equals(fetchedSlot.getAdditionalInfo5())) {
                throw new RuntimeException("Slot is not free.");
            }
            if (ONETOONE.equals(fetchedSlot.getEventType())) {
                if(participantList.isEmpty()){
                    throw new IllegalArgumentException("Enter atleast one participant.");
                }
                if (participantList.size() > 1) {
                    throw new RuntimeException("Participant count exceeded");
                }
                fetchedSlot.setParticipantList(participantList);
                fetchedSlot.setAdditionalInfo5(desiredStatus);
            } else if (GROUP.equals(fetchedSlot.getEventType())) {
                if(participantList.isEmpty()){
                    throw new IllegalArgumentException("Enter atleast one participant.");
                }
                fetchedSlot.getParticipantList().addAll(participantList);
                fetchedSlot.setAdditionalInfo5(AVAILABLE);
            }
        }
        if (CANCEL.equals(desiredStatus)) {
            fetchedSlot.setAdditionalInfo5(AVAILABLE);
            fetchedSlot.getParticipantList().clear();
        }
        if (NOSHOW.equals(desiredStatus)) {
            fetchedSlot.setAdditionalInfo5(NOSHOW);
        }
        if (COMPLETED.equals(desiredStatus)) {
            fetchedSlot.setAdditionalInfo5(COMPLETED);
        }
        if (BOOKED.equals(desiredStatus)) {
            validateCalendarEvent(fetchedSlot);
        }
        String metadata = fetchedSlot.getMetadata();
        ObjectMapper objectMapper = new ObjectMapper();

        JsonNode jsonNode = null;
        String recordId ="";
        try {
            jsonNode = objectMapper.readTree(metadata);
            recordId = String.valueOf(jsonNode.get("recordId"));
        } catch (Exception e) {
        }
        String startTime = dateFormat.format(fetchedSlot.getStartTime());
        String bookingSubject = "Appointment Confirmation";
        String cancelSubject = "Appointment Cancelled";
        String bookingDesc = "Appointment confirmed with Appointment ID: " + recordId + " at " + startTime + " with " + fetchedSlot.getOrganizer();
        String cancelDesc = "Appointment cancelled with Appointment ID: " + recordId + " at " + startTime + " with " + fetchedSlot.getOrganizer();
        calendarService.saveCalendarEvent(fetchedSlot, UPDATE);
        if (BOOKED.equals(desiredStatus)) {
            slotServiceUtils.sendEmailNotification(participants, bookingDesc, bookingSubject);
        }
        if (CANCEL.equals(desiredStatus)) {
            slotServiceUtils.sendEmailNotification(participants, cancelDesc, cancelSubject);
        }
        return new ApiResponse(HttpStatus.OK, "Success", fetchedSlot);
    }


    public ApiResponse removeSlot(SchedulerSlotDto schedulerSlotDto) throws NSLException, ParseException {
        List<String> eventIds = schedulerSlotDto.getEventIds();
        String eventId = eventIds.get(0);
        CalendarEvent slot = slotServiceUtils.fetchSlot(eventId);
        String conferenceType = slot.getConferenceType();
        String Organizer = slot.getOrganizer();
        if (!(userDetails.getEmailId().equals(Organizer)) && userDetails.isTenantAdmin()) {
            return slotServiceUtils.deleteSlot(conferenceType, eventIds);
        } else {
            boolean allSlotsFree = true;
            for (String eventID : eventIds) {
                CalendarEvent event = slotServiceUtils.fetchSlot(eventID);
                if (!BOOKED.equals(event.getAdditionalInfo5())) {
                } else {
                    allSlotsFree = false;
                }
            }
            if (allSlotsFree) {
                return slotServiceUtils.deleteSlot(conferenceType, eventIds);
            } else {
                throw new RuntimeException("Not all slots are free.");
            }
        }
    }

    public ApiResponse getCalendarAdminSlotConfig() {
        try {
            CalendarAdminSlotConfig calendarAdminSlotConfig = calendarSaveSlotsImpl.getCalendarAdminSlotConfig(userDetails);
            return new ApiResponse(HttpStatus.OK, SUCCESS, calendarAdminSlotConfig);
        } catch (NSLException exception) {
            if(LOGGER.isErrorEnabled()) {
                LOGGER.error(exception.getMessage());
            }
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, FAILED, null);
        }
    }

    public ApiResponse saveCalendarAdminSlotConfig(CalendarAdminSlotConfig calendarAdminSlotConfig) {
        try {
            calendarSaveSlotsImpl.saveCalendarAdminSlotConfig(calendarAdminSlotConfig, userDetails);
            return new ApiResponse(HttpStatus.OK, SUCCESS, null);
        } catch (NSLException exception) {
            if(LOGGER.isErrorEnabled()) {
                LOGGER.error(exception.getMessage());
            }
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, FAILED, null);
        }
    }
}