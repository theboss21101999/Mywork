package com.nsl.adapter.service.keymanager.dto;


import java.util.List;
import java.util.Map;

public class PaginatedKeys {
    List<KeyManagerDto> keyManagerDtoList;
    Integer pageNumber;
    Integer currentPageSize;
    Long totalPages;
    Long totalHits;

    public List<KeyManagerDto> getKeyManagerDtoList() {
        return keyManagerDtoList;
    }

    public void setKeyManagerDtoList(List<KeyManagerDto> keyManagerDtoList) {
        this.keyManagerDtoList = keyManagerDtoList;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public Integer getCurrentPageSize() {
        return currentPageSize;
    }

    public void setCurrentPageSize(Integer currentPageSize) {
        this.currentPageSize = currentPageSize;
    }

    public Long getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(Long totalPages) {
        this.totalPages = totalPages;
    }

    public Long getTotalHits() {
        return totalHits;
    }

    public void setTotalHits(Long totalHits) {
        this.totalHits = totalHits;
    }
}
