package com.nsl.adapter.service.service;

import com.nsl.logical.ApiResponse;
import com.nsl.logical.config.AuthenticatedUserDetails;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dto.SlotDataDto;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TxnBaseEntity;
import com.nsl.logical.model.TxnData;


public interface LocationService {

    void saveSlotItem(SlotDataDto slotDataDto, AuthenticatedUserDetails authenticatedUserDetails) throws NSLException;

}
