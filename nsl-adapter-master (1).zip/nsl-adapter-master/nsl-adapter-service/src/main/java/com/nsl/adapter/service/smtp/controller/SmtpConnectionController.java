package com.nsl.adapter.service.smtp.controller;


import com.nsl.adapter.commons.dto.connections.SmtpAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.service.smtp.service.SmtpConnectionService;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class SmtpConnectionController {
    @Autowired
    SmtpConnectionService smtpService;


    @PostMapping(path = "/smtp")
    public ApiResponse saveSmtpConnection (@RequestBody SmtpAdapterConnectionDto connectionDto)  {

        TxnAdapterConnection result = smtpService.saveSmtpConnection(connectionDto);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }

    @GetMapping(path = "/smtp/{Id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getSmtpConnection(@PathVariable("Id") Long id){
       SmtpAdapterConnectionDto response = smtpService.getSmtpConnection(id, false);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }
    @PutMapping(path = "/smtp/{id}")
    public ApiResponse updateSmtpConnection(@PathVariable("id") Long id,
                                            @RequestBody SmtpAdapterConnectionDto connectionDto )
             {
        TxnAdapterConnection result = smtpService.updateSmtpConnection(id, connectionDto);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }
}
