package com.nsl.adapter.service.argo.service;



import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.commons.dto.AdapterScheduleReq;
import com.nsl.adapter.commons.dto.ScheduleInterval;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CronExpressionHelper;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import com.nsl.externalreservedcus.dto.calender.event.CalendarEvent;
import com.nsl.externalreservedcus.dto.calender.event.CalendarMetadata;
import com.nsl.externalreservedcus.dto.calender.event.Recurrence;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.client.RestTemplate;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import static com.nsl.common.constant.AppConstant.SUCCESS;

@Service
public class ArgoSchedulerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ArgoSchedulerService.class);

    @Autowired
    AdaptorProperties adaptorProperties;

    @Autowired
    RestTemplate restTemplateByPassSSL;

    public ApiResponse scheduleJob(CalendarEvent calendarEvent, AuthenticatedUserDetailsImpl authBean)
            throws IOException, NSLException {
        String namespace = getNamespaceFromUrl();
        Map<String, Object> request = createRequestForScheduleJob(calendarEvent, authBean,namespace);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        HttpEntity<?> entity = new HttpEntity<>(request, headers);
        LOGGER.info("Scheduling a job with the following parameters '{}'", request);
        String url = adaptorProperties.getAppSchedulerUrl();
        LOGGER.info("Invoking url {}", url);
        ResponseEntity<Map> responseEntity = restTemplateByPassSSL.postForEntity(
                url, entity, Map.class);
        LOGGER.info("Response from submit api : {}", responseEntity);
        return new ApiResponse(HttpStatus.OK, SUCCESS, responseEntity);
    }

    private String getNamespaceFromUrl() {
        String url = adaptorProperties.getAppSchedulerUrl();
        List<String> list = List.of(url.split("/"));
        return list.get(list.size()-1);
    }

    public ApiResponse deleteJob(String jobId) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        HttpEntity<?> entity = new HttpEntity<>(headers);
        LOGGER.info("Scheduling a job with the jobId '{}'", jobId);
        String url = adaptorProperties.getAppSchedulerUrl() + "/" + jobId;
        LOGGER.info("Invoking url {}", url);
        ResponseEntity<Map> responseEntity = restTemplateByPassSSL.exchange(url, HttpMethod.DELETE, entity, Map.class);
        LOGGER.info("Response from submit api : {}", responseEntity);
        return new ApiResponse(HttpStatus.OK, SUCCESS, responseEntity);
    }

    public void updateJob(CalendarEvent calendarEvent, AuthenticatedUserDetailsImpl authBean) throws IOException, NSLException {
        CalendarMetadata metadata = new CalendarMetadata();
        metadata = metadata.build(calendarEvent.getMetadata());
        String jobId= metadata.getJobId();
        deleteJob(jobId);
        scheduleJob(calendarEvent,authBean);
    }

    private Map<String, Object> createRequestForScheduleJob(CalendarEvent calendarEvent,
                                                            AuthenticatedUserDetailsImpl authBean, String namespace) throws IOException, NSLException {

        Map<String, Object> request = new HashMap<>();

        InputStream inputStream = new ClassPathResource(AppConstant.MERGEDCRONPATH).getInputStream();
        byte[] bdata = FileCopyUtils.copyToByteArray(inputStream);
        AdapterScheduleReq adapterScheduleReq = new AdapterScheduleReq();
        Recurrence recurrence = calendarEvent.getRecurrence();
        if (recurrence != null) {
            if (recurrence.getDay() != null) {
                adapterScheduleReq.setDayOfWeek(recurrence.getDay());
            }
            if (recurrence.getFrequency() != null && !recurrence.getFrequency().contains("YEARLY")) {

                adapterScheduleReq.setInterval(ScheduleInterval.valueOf(recurrence.getFrequency()));
            }
        }
        Date present = calendarEvent.getStartTime();
        Date reminder = present;
        if (calendarEvent.getReminder() != null) {
            reminder = DateUtils.addMinutes(present, (-1) * calendarEvent.getReminder());
        }
        List<String> dateTime = getDateTime(reminder);
        String date = dateTime.get(0);
        String time = dateTime.get(1);
        adapterScheduleReq.setDateOfMonth(date.split(":")[2]);
        adapterScheduleReq.setTime(time);
        String cronExpression;
        if (recurrence != null && recurrence.getFrequency() != null) {
            if (recurrence.getFrequency().contains("YEARLY")) {
                cronExpression = reminder.getMinutes() + " " + reminder.getHours() + " " + date.split(":")[2] +
                        " " + date.split(":")[1] + " " + "*";
            } else if (recurrence.getFrequency().contains("HOUR")) {
                cronExpression = reminder.getMinutes() + " " + "*" + " " + date.split(":")[2] + " " +
                        date.split(":")[1] + " " + "*";
            } else {
                cronExpression = CronExpressionHelper.generateCronExpression(adapterScheduleReq);
            }
        }
        //This is for scheduling a job for one time and need to be deleted after it is triggered
        //Deleting the job after 1st invoke need to implemented
        else if(recurrence==null){
            cronExpression = reminder.getMinutes() + " " + reminder.getHours() + " " + date.split(":")[2] +
                    " " + date.split(":")[1] + " " + "*";
        } else cronExpression = "* * * * *";

        int randomStringlen = 10;
        List<String> notificationChannels = new ArrayList<>();
        notificationChannels.add("EMAIL");
        String jobId=null;
        CalendarMetadata calMeta = new CalendarMetadata();
        calMeta=calMeta.build(calendarEvent.getMetadata());
        if(calMeta.getJobId()==null){
            jobId = ("adapter-"
                    + RandomStringUtils.randomAlphanumeric(randomStringlen)).toLowerCase(Locale.ENGLISH);
            calMeta.setJobId(jobId);
        }
        else {
            jobId =calMeta.getJobId();
        }
        calendarEvent.setMetadata(calMeta.buildString(calMeta));
        String data = new String(bdata, StandardCharsets.UTF_8);
        data = StringUtils.replace(data, "${namespace}", namespace);
        data = StringUtils.replace(data, "${cron_expression}", cronExpression);
        data = StringUtils.replace(data, "${userEmail}", authBean.getEmailId());
        data = StringUtils.replace(data, "${tenantId}", authBean.getTenantId());
        data = StringUtils.replace(data, "${title}", calendarEvent.getTitle());
        data = StringUtils.replace(data, "${content}", calendarEvent.getDescription());
        data = StringUtils.replace(data, "${targetUserId}", JacksonUtils.toJson(calendarEvent.getParticipantList()).replace("\"", "\\\""));
        data = StringUtils.replace(data, "${notificationChannels}",JacksonUtils.toJson(notificationChannels).replace("\"", "\\\""));
        data = StringUtils.replace(data, "${jobName}", jobId);
        request = JacksonUtils.getObjectFromJsonString(data, Map.class);
        return request;
    }

    public List<String> getDateTime(Date reminder) {
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy:MM:dd");
        String time = timeFormat.format(reminder);
        String date = dateFormat.format(reminder);
        List<String> result = new ArrayList<>();
        result.add(date);
        result.add(time);
        return result;
    }


}
