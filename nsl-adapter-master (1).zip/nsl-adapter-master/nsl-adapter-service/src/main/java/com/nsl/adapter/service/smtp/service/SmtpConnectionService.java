package com.nsl.adapter.service.smtp.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.ImapConnection;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.commons.dto.connections.SmtpAdapterConnectionDto;
import com.nsl.adapter.service.enums.SmtpConnection;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.List;
import java.util.Locale;


@Service
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class SmtpConnectionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SmtpConnectionService.class);

    private static final ConnectionDtoType connType = ConnectionDtoType.SMTP;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnectionServiceV3 adapterConnectionServiceV3;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    MessageSource messageSource;


    public SmtpAdapterConnectionDto getSmtpConnection(Long id, boolean hide) {
        TxnAdapterConnection txnGeneralEntityRecord = adapterConnnectionsDao.getConnectionByRecordId(connType,id,authBean);
        return txnToSmtpDto(txnGeneralEntityRecord, hide);
    }

    public TxnAdapterConnection saveSmtpConnection(SmtpAdapterConnectionDto connectionDto) {
        if (connectionDto.getHost() == null || connectionDto.getPassword() == null || connectionDto.getFrom() == null ||
                connectionDto.getUsername() == null ||  connectionDto.getPort() == 0 ||
                connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "invalid input" , null);

        connectionDataToolsV3.connectionCheck(ConnectionDtoType.SMTP, connectionDto.getConnectionName(), authBean);


        connectionDto.setPassword(connectionDataToolsV3.saveSecret(connType,"password",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getPassword()));

        TxnAdapterConnection connection = new TxnAdapterConnection();
        connection.setConnection(connectionDto);
        connection.setConnectionDtoType(connType);

        LOGGER.info("saving Smtp connection");
        return adapterConnnectionsDao.saveConnection(connection ,authBean );
    }


    public TxnAdapterConnection updateSmtpConnection(Long id, SmtpAdapterConnectionDto connectionDto) {
        if (connectionDto.getFrom() == null || connectionDto.getUsername() == null || connectionDto.getHost() == null ||
                connectionDto.getPassword() == null || connectionDto.getPort() == 0 ||
                connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "invalid input" , null);

        LOGGER.info("update SMTP connection");

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(connType, id ,authBean);
        connectionDataToolsV3.connectionNameCheck(previousConnection,connectionDto.getConnectionName());

        connectionDto.setPassword(connectionDataToolsV3.updateSecret(connType,"password",
                connectionDto.getConnectionName(),authBean.getTenantId(),connectionDto.getPassword()));


        previousConnection.setConnection(connectionDto);

        return adapterConnnectionsDao.saveConnection(previousConnection, authBean );

    }
    public SmtpAdapterConnectionDto txnToSmtpDto(TxnAdapterConnection txnEntityRecord, boolean hide) {

        SmtpAdapterConnectionDto connectionDto = (SmtpAdapterConnectionDto) txnEntityRecord.getConnection();
        if (connectionDto == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,
                    messageSource.getMessage("Paas_Adapter_178", null, Locale.ENGLISH) , null);

        if (!hide){
            connectionDto.setPassword(connectionDataToolsV3.getSecret(connectionDto.getPassword()));
        }

        return connectionDto;
    }
}
