package com.nsl.adapter.service.db.service;

import com.nsl.adapter.service.db.enums.DBType;
import com.nsl.adapter.service.exception.ExtAuthException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class DBAdapterFactory {

    @Autowired
    MYSQLDBOperations mysqldbOperations;

    @Autowired
    POSTGRESQLDBOperations postgresqldbOperations;

    @Autowired
    MessageSource messageSource;
    public DBOperations getDBAdapter(DBType dbType){
        switch (dbType){
            case MYSQL:
                return mysqldbOperations;
            case POSTGRES:
                return postgresqldbOperations;
            default:
                break;
        }
        throw new ExtAuthException(String.format(messageSource.getMessage("Paas_Adapter_115", null, Locale.ENGLISH), dbType.toString()));
    }
}
