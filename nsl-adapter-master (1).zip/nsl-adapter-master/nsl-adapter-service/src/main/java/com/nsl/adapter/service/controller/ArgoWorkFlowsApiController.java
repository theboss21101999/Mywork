package com.nsl.adapter.service.controller;

import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.argo.argoApis.ArgoApisService;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;


@RestController
@RequestMapping("/api/v1/argoApi")
public class ArgoWorkFlowsApiController {
    private static final Logger logger = LoggerFactory.getLogger(ArgoWorkFlowsApiController.class);
    @Autowired
    ArgoApisService argoApisService;
    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    //below datafix api call is for internal use only , dont expose it outside to access
//    @PostMapping("/dataFix")
//    public ApiResponse dataFix(@Valid @RequestParam("env") String env) throws NSLException {
//        logger.info("giving a datafix for the argoWorkFlows scheduler");
//        return argoApisService.argoWorkFlowDataFixMethod(env);
//    }
    @GetMapping("/fetch")
    public ApiResponse fetch(@RequestParam(required = false , defaultValue = "1") Integer pageNumber,
                             @RequestParam(required = false , defaultValue = "20") Integer pageSize,
                             @RequestParam(required = false) String adapter_search,
                             @RequestParam(required = false) String cuName_search,
                             @RequestParam(required = false) String jobName) throws NSLException {
        logger.info("Fetch agroApi Data with Pagination");
        return argoApisService.fetch(pageNumber,pageSize,adapter_search,cuName_search,jobName,authBean);
    }
    @PutMapping("/suspend")
    public ApiResponse suspend(@RequestParam String jobName) throws NSLException {
        logger.info("suspend agroApi Data");
        return argoApisService.suspend(jobName);
    }
    @PutMapping("/resume")
    public ApiResponse resume(@RequestParam String jobName) throws NSLException {
        logger.info("resume agroApi Data");
        return argoApisService.resume(jobName);
    }
    @DeleteMapping("/delete")
    public ApiResponse delete(@RequestParam String jobName) throws NSLException {
        logger.info("delete agroApi Data");
        return argoApisService.delete(jobName);
    }

}
