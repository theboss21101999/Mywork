package com.nsl.adapter.service.service;

import com.nsl.adapter.service.dto.CredentialPair;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.commons.enums.ApiKeyLocation;
import com.nsl.adapter.service.rest.utils.RestConstants;
import com.nsl.adapter.service.utils.extapi_auth_credential.ExtAuthCredentials;
import com.nsl.adapter.commons.dto.connections.RESTAuthorizationType;
import com.nsl.adapter.service.utils.extapi_auth_credential.ExtApiAuthCredentialsFactory;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.Properties;
import static com.nsl.adapter.service.utils.AppConstant.*;

@Service
public class AuthenticationService {

    @Autowired
    ExtApiAuthCredentialsFactory authCredentialsFactory;
    /**
     * Public Method.
     */
    public CredentialPair addAuthentication(RESTAdapterConnectionDto restConnectionDto,
                                            Map<String, String> cuSystemProperties, Object reqBody, JSONObject pathObject) throws NSLException {

        if(restConnectionDto == null || RESTAuthorizationType.NONE == restConnectionDto.getAuthentication().getAuthorizationType())
            return null;

        CredentialPair credentialPair = new CredentialPair();
        restConnectionDto.setAdvancedConfig(addConfig(cuSystemProperties,reqBody,pathObject));
        credentialPair.setAuthType(restConnectionDto.getAuthentication().getAuthorizationType());
        ExtAuthCredentials authCredentials = authCredentialsFactory.getExtAuthCredentials(restConnectionDto.getAuthentication().getAuthorizationType());
        return authCredentials.getCredentialPair(restConnectionDto);
    }

    public void addAuthParamsToRequest(CredentialPair authParams, JSONObject queryObject, HttpHeaders httpHeaders) throws JSONException {
        if (authParams == null || authParams.getCredentials() == null || authParams.getCredentials().isEmpty()) return;
        String key = authParams.getCredentials().keySet().toArray()[0].toString();
        String value = authParams.getCredentials().get(key);
        ApiKeyLocation location = authParams.getLocation();
        if (location==ApiKeyLocation.QUERY )
            queryObject.put(key, value);
        else httpHeaders.add(key, value);
    }

    private Properties addConfig(Map<String, String> cuSystemProperties, Object reqBody, JSONObject pathObject) {
        Properties properties = new Properties();
        properties.setProperty(TXN_ID, cuSystemProperties.get(TXN_ID));
        properties.setProperty(METHOD, cuSystemProperties.get(METHOD));
        properties.setProperty(CONTENT_TYPE, cuSystemProperties.getOrDefault(CONTENT_TYPE,"application/json"));
        properties.setProperty(API_URI, cuSystemProperties.get(API_URI));
        properties.setProperty(REQUEST, reqBody.toString());
        properties.put(RestConstants.PathParamObject, pathObject); //NOSONAR

        return properties;
    }

}
