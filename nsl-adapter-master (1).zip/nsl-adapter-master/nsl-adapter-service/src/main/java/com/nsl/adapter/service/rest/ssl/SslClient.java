package com.nsl.adapter.service.rest.ssl;


import com.nsl.adapter.service.dto.SslCertificateDto;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.multipart.MultipartFile;

import javax.net.ssl.SSLContext;
import javax.xml.bind.DatatypeConverter;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.Locale;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

public class SslClient {

    @Autowired
    private MessageSource messageSource;

    private static final Logger LOGGER = LoggerFactory.getLogger(SslClient.class);
    static SslClient _sslClient = null;
    static SSLContext sslContext = null;
    static FileTime keyStore_PrevModifiedTime = null;

    public SslClient(SslConfig config) throws NSLException {
        SslContextConfig sslconfig = new SslContextConfig();
        sslContext = sslconfig.setupSslContext(config);
    }
//
    public SSLContext getSslContext() {
        return sslContext;
    }
//
//    public static SslClient getSSLClient() throws NSLException {
//        if (_sslClient == null || isKeystoreUpdated()) {
//            _sslClient = new SslClient();
//        }
//        return _sslClient;
//    }
//
//    private static boolean isKeystoreUpdated() {
//        boolean isKeystoreUpdated = false;
//
//        try {
//            String fileName = config_.getKeystorePath();
//            Path file = Paths.get(fileName); //NOSONAR
//            BasicFileAttributes attr =
//                    Files.readAttributes(file, BasicFileAttributes.class);
//            FileTime lastModifiedTime = attr.lastModifiedTime();
//            LOGGER.info("lastModifiedTime: " + lastModifiedTime);
//            LOGGER.info("keyStore_PrevModifiedTime: " + keyStore_PrevModifiedTime);
//
//            if (keyStore_PrevModifiedTime == null ||
//                    lastModifiedTime.compareTo(keyStore_PrevModifiedTime) > 0 ||
//                    lastModifiedTime.compareTo(keyStore_PrevModifiedTime) < 0) {
//                isKeystoreUpdated = true;
//                keyStore_PrevModifiedTime = lastModifiedTime;
//            }
//        } catch (IOException e) {
//            LOGGER.error(e.toString());
//        }
//        return isKeystoreUpdated;
//    }

    public SslCertificateDto addCertificateToKeystore(MultipartFile cerFileName,
                                                      String keyStoreFileName,
                                                      String certificateAlias,
                                                      String keyStorePW, boolean force) throws NSLException {
        SslCertificateDto sslCertificateDto = new SslCertificateDto();
        try {
            KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
            char[] password = keyStorePW.toCharArray();

            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            Certificate certs = cf.generateCertificate(cerFileName.getInputStream());

            // Load the keystore contents
            try(InputStream in = Files.newInputStream(Path.of(keyStoreFileName))) {
                keystore.load(in, password);
            }

            // check validation if alias name exists in the keystore..
            boolean isAliasExist = keystore.containsAlias(certificateAlias);
            if (isAliasExist && !force) {
                throw new NSLException(INTERNAL_SERVER, null,
                        messageSource.getMessage("Paas_Adapter_64", null, Locale.ENGLISH),
                        ExceptionSeverity.MINOR);
            }

            // Add the certificate
            keystore.setCertificateEntry(certificateAlias, certs);

            // Save the new keystore contents
            try(OutputStream os = Files.newOutputStream(Path.of(keyStoreFileName))) {
                keystore.store(os, password);
            }

            Date createdDate = keystore.getCreationDate(certificateAlias);
            Date certValidFromDate = ((X509Certificate) keystore.getCertificate(certificateAlias)).getNotBefore();
            Date certExpiryDate = ((X509Certificate) keystore.getCertificate(certificateAlias)).getNotAfter();

            sslCertificateDto.setCertCreatedDate(String.valueOf(createdDate.getTime()));
            sslCertificateDto.setCertValidFromDate(String.valueOf(certValidFromDate.getTime()));
            sslCertificateDto.setCertExpiryDate(String.valueOf(certExpiryDate.getTime()));
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_65", null, Locale.ENGLISH) + e, ExceptionSeverity.MINOR, e);
        }
        return sslCertificateDto;
    }

    public String deleteCertificateFromKeystore(String keyStoreFileName,
                                                String certificateAlias, String keyStorePW) throws NSLException {
        try {
            KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
            char[] password = keyStorePW.toCharArray();
            // Load the keystore contents
            try(InputStream in = Files.newInputStream(Path.of(keyStoreFileName))){
                keystore.load(in, password);
            }

            // check validation if alias name exists in the keystore..
            boolean isAliasExist = keystore.containsAlias(certificateAlias);
            if (!isAliasExist) {
                throw new NSLException(INTERNAL_SERVER, null, messageSource.getMessage("Paas_Adapter_66", null, Locale.ENGLISH),
                        ExceptionSeverity.MINOR);
            }

            keystore.deleteEntry(certificateAlias);

            // Save the new keystore contents
            try(OutputStream os = Files.newOutputStream(Path.of(keyStoreFileName))){
                keystore.store(os, password);
            }
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_67", null, Locale.ENGLISH) + e, ExceptionSeverity.MINOR, e);
        }
        return "Certificate deleted from Keystore.!";
    }

    public String getSha256(MultipartFile cerFileName) throws NSLException {
        String sha256 = null;
        try {
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            Certificate cert = cf.generateCertificate(cerFileName.getInputStream());
            byte[] der = cert.getEncoded();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(der);
            byte[] digest = md.digest();
            sha256 = DatatypeConverter.printHexBinary(digest);

        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_68", null, Locale.ENGLISH) + e, ExceptionSeverity.MINOR, e);
        }
        return sha256;
    }

}
