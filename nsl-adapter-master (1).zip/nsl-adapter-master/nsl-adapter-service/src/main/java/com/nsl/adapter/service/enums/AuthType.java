package com.nsl.adapter.service.enums;

public enum AuthType {
    APIKEY("apiKey"),
    HTTP("http"),
    OAUTH2("oauth2"),
    OPENIDCONNECT("openIdConnect"),
    NONE("none");

    private String value;

    private AuthType(String value) {
        this.value = value;
    }

    public String getAuthType() {
        return this.value;
    }

    public static AuthType fromValue(String val) {
        for (AuthType at : AuthType.values()) {
            if (at.getAuthType().equalsIgnoreCase(val)) {
                return at;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
}
