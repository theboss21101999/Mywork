package com.nsl.adapter.service.adobeSign.enums;

public enum AdobeSignOperation {
        GET_AGREEMENT_INFO,
        SEND_AGREEMENT_URL,
//        SEND_AGREEMENT_TRANSIENT,
        SEND_AGREEMENT_REMINDER
//        CREATE_WEB_FORM;
}
