package com.nsl.adapter.service.rest.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.api.client.auth.oauth2.*;

import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;

import com.nsl.adapter.service.rest.service.ConnectionToGeneral;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.adapter.service.v2.utills.RedisIntegration;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
        import java.io.IOException;
        import java.nio.charset.StandardCharsets;
        import java.util.*;

import static com.nsl.adapter.commons.enums.AdapterType.REST;
import static com.nsl.adapter.commons.dto.connections.OAuthGrantType.*;

import static com.nsl.adapter.service.rest.utils.RestConstants.*;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;
import static org.springframework.security.oauth2.core.endpoint.PkceParameterNames.CODE_VERIFIER;

@Service
public class RestOauthConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(RestOauthConnection.class);


    @Autowired
    ConnectionToGeneral connectionService;
    @Autowired
    RedisIntegration redisIntegration;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    CdmUtils cdmUtils;

    @Autowired
    AdaptorProperties adaptorProperties;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    private MessageSource messageSource;

    Base64.Encoder encoder = Base64.getEncoder();


    public String getStateParam(Long connId, String connName, String tenantId) {
        Map<String, Object> valueMap = new HashMap<>();
        valueMap.put(AppConstant.CONFIG_ENTITY_RECORD_ID, connId.toString());
        valueMap.put(AppConstant.ADAPTER, REST);
        valueMap.put(AppConstant.TENANTID, tenantId);
        valueMap.put(AppConstant.ENV_NAME ,cdmUtils.getEnvironmentNameByTenantId(tenantId));
        valueMap.put(AppConstant.CONNECTION_NAME, connName);
        return encodeData(Objects.requireNonNull(JacksonUtils.toJson(valueMap)));
    }

    public JSONObject getAuthorizationcode(RESTAdapterConnectionDto connectionDto, TxnAdapterConnection result) throws NSLException {

        LOGGER.info("generating redirect url ..");
        try {
            AuthorizationCodeRequestUrl url = new AuthorizationCodeRequestUrl(connectionDto.getAuthentication().getOAuthCredentials().getAuthorizationUri(), connectionDto.getAuthentication().getOAuthCredentials().getClientId());
            url.setRedirectUri(adaptorProperties.getRedirectUrl()).setScopes(connectionDto.getAuthentication().getOAuthCredentials().getScope())
                    .set(PROMPT,CONSENT).set(ACCESS_TYPE,OFFLINE).setResponseTypes(Collections.singleton(CODE));

            String stateParams = getStateParam(result.getRecordId(), connectionDto.getConnectionName(), bean.getTenantId());
            LOGGER.info("appending state params to redirect url {} ", stateParams);
            url.set(STATE, stateParams);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(AppConstant.RESULT, result);
            jsonObject.put(Url, url.build());

            return jsonObject;
        } catch (Exception e) {
            LOGGER.error("exception occurred during generating redirect url: ",e );
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_1", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER,e);
        }
    }

    public TxnAdapterConnection getRefreshToken(Long id) throws NSLException {

        String cacheName = REST + "_" + bean.getTenantId();

        try {
            RESTAdapterConnectionDto connectionDto = connectionService.getEntityRecordrest(id, false);
            String code =redisIntegration.getOAuthCode(cacheName, id.toString());
            LOGGER.info("updating connection with code: {}",code);
            connectionDto.getAuthentication().getOAuthCredentials().setRefreshToken(getRefreshToken(connectionDto, code));
            return connectionService.updateRestEntity(id,connectionDto);
        } catch (Exception e) {
            LOGGER.error("failed to generate refresh Token",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,messageSource.getMessage
                    ("Paas_Adapter_13", null, Locale.ENGLISH) + e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }
    }


    public String getRefreshToken(RESTAdapterConnectionDto connectionDto, String code) throws IOException {
        String baseUri;
        String result;
        RestTemplate restTemplate = new RestTemplate();
        baseUri= connectionDto.getAuthentication().getOAuthCredentials().getAccessTokenUri();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("code",code);
        map.add("grant_type",AUTHORIZATION_CODE);
        map.add("client_id",connectionDto.getAuthentication().getOAuthCredentials().getClientId());
        map.add("client_secret",connectionDataToolsV3.getSecret(connectionDto.getAuthentication().getOAuthCredentials().getClientSecret()));
        map.add("redirect_uri",adaptorProperties.getRedirectUrl());
        if(connectionDto.getAuthentication().getOAuthCredentials().getGrantType() == AUTHORIZATIONCODE_PKCE){
            map.add("code_verifier",CODE_VERIFIER);
        }
        HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(map, headers);

        LOGGER.info("calling  Api");
        ResponseEntity<JsonNode> response = restTemplate.exchange(baseUri,
                HttpMethod.POST, httpEntity, JsonNode.class);
        result = response.getBody().get("refresh_token").asText(); //NOSONAR
        return result;

    }

    private  String encodeData(String value){
        return encoder.encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

}
