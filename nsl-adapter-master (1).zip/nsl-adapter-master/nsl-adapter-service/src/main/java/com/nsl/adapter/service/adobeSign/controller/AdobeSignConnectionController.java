package com.nsl.adapter.service.adobeSign.controller;

import com.nsl.adapter.commons.dto.connections.AdobeSignAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.adobeSign.service.AdobeSignConnectionService;
import com.nsl.adapter.service.adobeSign.utils.AdobeSignOauthConnection;
import com.nsl.adapter.service.utils.AppConstant;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class AdobeSignConnectionController {

    @Autowired
    AdobeSignConnectionService adobeSignConnectionService;

    @Autowired
    AdobeSignOauthConnection adobeSignoauthConnection;

    @PostMapping(path = "/adobe", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveAdobeSignConnection(@RequestBody AdobeSignAdapterConnectionDto connectionDto) {
        TxnAdapterConnection result = adobeSignConnectionService.saveAdobeSignConnection(connectionDto);
        JSONObject jsonObject = adobeSignoauthConnection.getAuthorizationcode(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }

    @GetMapping(path = "/adobe/{Id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getAdobeSignConnection(@PathVariable("Id") Long id) {

        AdobeSignAdapterConnectionDto response = adobeSignConnectionService.getAdobeSignConnection(id, false);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @PutMapping(path = "/adobe/{id}" , consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse updateAdobeSignConnection(@PathVariable("id") Long id,
                                                @RequestBody AdobeSignAdapterConnectionDto connectionDto ) {

        TxnAdapterConnection result = adobeSignConnectionService.updateAdobeSignConnection(id, connectionDto);
        JSONObject jsonObject = adobeSignoauthConnection.getAuthorizationcode(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }

    @GetMapping(path = "/adobe/refreshToken/{Id}")
    public ApiResponse updateAdobeSignToken(@PathVariable("Id") Long id){

        TxnAdapterConnection result =adobeSignoauthConnection.getRefreshToken(id);
        return new ApiResponse(HttpStatus.OK,SUCCESS,result);
    }


}
