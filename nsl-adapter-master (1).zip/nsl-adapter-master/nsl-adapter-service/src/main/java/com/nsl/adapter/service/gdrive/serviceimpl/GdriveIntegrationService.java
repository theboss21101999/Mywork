package com.nsl.adapter.service.gdrive.serviceimpl;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.service.gdrive.utils.GdriveConstants;
import com.nsl.adapter.service.service.IntegrationService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.dsd.store.models.tenant.io.TenantSlotItemInput;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

import static com.nsl.adapter.service.utils.AppConstant.*;
import static com.nsl.adapter.service.v2.utills.EntityConstants.*;

@Service
public class GdriveIntegrationService  implements IntegrationService {

    @Autowired
    SaveBetsService saveBetsService;

    @Autowired
    MessageSource messageSource;

    @Override
    public CUPropsDto getSaveProperties(IntegrationDtoV3 integrationDto) throws NSLException {
        if (validForGdrive(integrationDto.getPropertiesMap(),integrationDto.getOperation()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_195", null, Locale.ENGLISH));

        String fileType;
        fileType=integrationDto.getPropertiesMap().get(AppConstant.FILETYPE);

        CUPropsDto cuPropsDto = new CUPropsDto();
        cuPropsDto.setCuName(integrationDto.getIntegrationName());
        cuPropsDto.setIsMachineCU(Boolean.TRUE);
        cuPropsDto.setCuSystemProps(integrationDto.getPropertiesMap());
        cuPropsDto.setPhysicalLayerItems(physicalLayerEntities(fileType,integrationDto));
        cuPropsDto.setTriggerCESLayerItems(triggerCesLayerEntities(fileType,integrationDto));
        if(integrationDto.getOperation().equals(GdriveConstants.GET_ENTITY)){
            ((TenantCUEntityInput)cuPropsDto.getPhysicalLayerItems().get(0).getItem()).getNslAttributes().get(5).setConditionalPotentiality(Collections.singletonList("PL.SL001.NSL_Gdrive_File_Req.FileType == 'xlsx' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'csv' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'json' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'native' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'xml' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'hl7'"));
            ((TenantCUEntityInput)cuPropsDto.getPhysicalLayerItems().get(0).getItem()).getNslAttributes().get(5).setConditionalPotentialityName(Collections.singletonList("PL.SL001.NSL_Gdrive_File_Req.FileType == 'xlsx' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'csv' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'json' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'native' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'xml' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'hl7'"));
            ((TenantCUEntityInput)cuPropsDto.getPhysicalLayerItems().get(0).getItem()).getNslAttributes().get(4).setConditionalPotentiality(Collections.singletonList("PL.SL001.NSL_Gdrive_File_Req.FileType == 'csv' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'xml' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'json' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'xlsx' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'native' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'hl7'"));
            ((TenantCUEntityInput)cuPropsDto.getPhysicalLayerItems().get(0).getItem()).getNslAttributes().get(4).setConditionalPotentialityName(Collections.singletonList("PL.SL001.NSL_Gdrive_File_Req.FileType == 'csv' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'xml' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'json' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'xlsx' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'native' && PL.SL001.NSL_Gdrive_File_Req.FileType != 'hl7'"));
            ((TenantCUEntityInput) cuPropsDto.getPhysicalLayerItems().get(0).getItem()).getNslAttributes().get(3).setDefaultValue(fileType.toLowerCase());
        }
        return cuPropsDto;
    }

    public List<TenantSlotItemInput> physicalLayerEntities(String fileType, IntegrationDtoV3 integrationDto) throws NSLException {
        List<TenantCUEntityInput> physicalEntity = new ArrayList<>();
        String name;
        switch (integrationDto.getOperation()) {
            case GdriveConstants.VIEW_FILES:
                name=GDRIVE_VIEWFILES_REQ;
                break;
            case GdriveConstants.DELETE_FILE:
            case GdriveConstants.GET_FILE:
                name = GDRIVE_REQ;
                break;
            case GdriveConstants.GET_ENTITY:
                name=GDRIVE_File_REQ;
                break;
            case GdriveConstants.UPLOAD_ENTITY:
                name = GDRIVE_REQ;
                if (AppConstant.NATIVE.equals(fileType)) {
                    physicalEntity.add(saveBetsService.getEntityByName(NSL_Adapter_Native_File));
                } else {
                    physicalEntity.add(saveBetsService.findEntityById(integrationDto.getInputEntityDsdId()));
                }
                break;
            default:
                return null;
       }
        physicalEntity.add(0,saveBetsService.getEntityByName(name));

        return buildSlotItems(physicalEntity);
    }

    public List<TenantSlotItemInput> triggerCesLayerEntities(String fileType, IntegrationDtoV3 integrationDto) throws NSLException {
        List<TenantCUEntityInput> triggerCesEntity = new ArrayList<>();
        String name;
        switch (integrationDto.getOperation()) {
            case GdriveConstants.VIEW_FILES:
                name=GDRIVE_VIEWFILES_RES;
                break;
            case GdriveConstants.GET_FILE://@Deprecated
                name=GDRIVE_GETFILE_RES;
                break;
            case GdriveConstants.DELETE_FILE:
                name = GDRIVE_RES;
                break;
            case GdriveConstants.GET_ENTITY:
                if (AppConstant.NATIVE.equals(fileType))
                    name = NSL_Adapter_Native_File;
                else {
                    triggerCesEntity.add(saveBetsService.findEntityById(integrationDto.getOutputEntityDsdId()));
                    return buildSlotItems(triggerCesEntity);
                }
                break;
            case GdriveConstants.UPLOAD_ENTITY:
                name = GDRIVE_UPLOAD_RES;
                break;
            default:
                return null;

        }
        triggerCesEntity.add(saveBetsService.getEntityByName(name));

        return buildSlotItems(triggerCesEntity);
    }

    @Override
    public void getIntegration(IntegrationDtoV3 integrationDto,CUPropsDto cuPropsDto) {
        if (GdriveConstants.UPLOAD_ENTITY.equalsIgnoreCase(integrationDto.getOperation()))
            integrationDto.setInputEntityDsdId(getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).get(1).getDsdId());
        else if(GdriveConstants.GET_ENTITY.equalsIgnoreCase(integrationDto.getOperation()))
            integrationDto.setOutputEntityDsdId(getParticipatingItems(cuPropsDto.getTriggerCESLayerItems()).get(0).getDsdId());
    }

    @Override
    public CUPropsDto getUpdateProperties(CUPropsDto cuPropsDto, IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto newCUPropsDto = new CUPropsDto();
        String fileType;
        fileType=integrationDto.getPropertiesMap().get(AppConstant.FILETYPE);
        newCUPropsDto.setPhysicalLayerItems(physicalLayerEntities(fileType,integrationDto));
        newCUPropsDto.setTriggerCESLayerItems(triggerCesLayerEntities(fileType,integrationDto));
        newCUPropsDto.setCuSystemProps(integrationDto.getPropertiesMap());

        return newCUPropsDto;
    }
    private static boolean validForGdrive(Map<String, String> propetiesMap, String operation) {
        List<String> propertyList;
        switch (operation) {
            case GdriveConstants.UPLOAD_ENTITY:
                propertyList = Arrays.asList(FILENAME, FILETYPE, ROOT_FOLDER);
                break;
            case GdriveConstants.GET_ENTITY:
                propertyList = Arrays.asList(FILETYPE, ROOT_FOLDER);
                break;
            case GdriveConstants.DELETE_FILE:
            case GdriveConstants.VIEW_FILES:
            case GdriveConstants.GET_FILE:
                propertyList = List.of(ROOT_FOLDER);
                break;
            default:
                return true;
        }
        for (String property : propertyList) {
            if (!propetiesMap.containsKey(property))
                return true;
        }
        return false;

    }

}
