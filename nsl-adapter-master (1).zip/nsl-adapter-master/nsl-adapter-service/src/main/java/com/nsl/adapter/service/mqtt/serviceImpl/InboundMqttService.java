package com.nsl.adapter.service.mqtt.serviceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.service.inbound.dto.NSLGsiListDto;
import com.nsl.adapter.commons.dto.connections.MqttConnectionDto;
import org.eclipse.paho.client.mqttv3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class InboundMqttService {
    @Autowired
    SendMqttMessageToProcessor sendMqttMessageToProcessor;

    @Autowired
    private ObjectMapper objectMapper;
    private static final Logger LOGGER = LoggerFactory.getLogger(InboundMqttService.class);

    public void startMqttClientConnection(MqttConnectionDto mqttConnectionDto,NSLGsiListDto nslGsiListDto) throws MqttException {
            LOGGER.debug("== START SUBSCRIBER ==:");
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setUserName(mqttConnectionDto.getUsername());
            connOpts.setPassword(mqttConnectionDto.getPassword().toCharArray());
            connOpts.setCleanSession(true);
            MqttClient client = new MqttClient("tcp://" + mqttConnectionDto.getHost() + ":" + mqttConnectionDto.getPort(), MqttClient.generateClientId());//NOSONAR
        client.setCallback(new MqttCallback() { //NOSONAR
                    String MESSAGE = "";
                    String acknowledge = "";
                    public void connectionLost(Throwable throwable) {

                        LOGGER.debug("BROKER CONNECTION LOST !");
                    }
                    public void messageArrived(String s, MqttMessage mqttMessage) throws MqttException, JsonProcessingException { //NOSONAR
                        LOGGER.debug("Message arrived from the broker!");
                        MESSAGE=new String(mqttMessage.getPayload()); //NOSONAR
                        JsonNode data = objectMapper.readTree(MESSAGE);
                        LOGGER.info("Message payload : {}",data);
                        sendMqttMessageToProcessor.processClientMessage(data,nslGsiListDto);
                        //Publishing the empty message to make sure not to receive the same message
                        client.publish(mqttConnectionDto.getTopic(),acknowledge.getBytes(),2,true);//NOSONAR
                        client.disconnect();
                    }
                    public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
                        LOGGER.debug("delivery is completed!");
                        //none
                    }
                });
                client.connect(connOpts);
                client.subscribe(mqttConnectionDto.getTopic(), 2);

            LOGGER.info("created and started processor on topic {}", mqttConnectionDto.getTopic());

    }
}
