package com.nsl.adapter.service.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.service.oauth2util.OAuth2RedirectionUtil;
import com.nsl.adapter.commons.dto.connections.OAuthCredentials;
import com.nsl.adapter.service.rest.service.ConnectionToGeneral;
import com.nsl.adapter.service.utils.*;
import com.nsl.logical.config.AuthenticatedUserDetails;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static com.nsl.adapter.service.utils.AppConstant.*;

@Service
public class OAuthRedirectService {
    private static final Logger logger = LoggerFactory.getLogger(OAuthRedirectService.class);

    @Autowired
    ExtSolutionUtil extSolutionUtil;

    @Autowired
    OAuth2RedirectionUtil oAuth2RedirectionUtil;

    @Autowired
    AdaptorProperties adaptorProperties;

    @Autowired
    ConnectionToGeneral connectionService;

    @Autowired
    ChangeUnitDao changeUnitDao;


    /**
     * Public Method.
     */
    public TxnData reservedCuSerice(TriggerCU triggerCu, TxnData transData, AuthenticatedUserDetails userDetails) throws JSONException, NSLException {

        String gsiContextId = transData.getCuContextualId().split("\\.")[0];

        String gsiId = "";
        gsiId = gsiContextId.split("GS")[1];
        GSI gsi = changeUnitDao.getGsiById(Long.valueOf(gsiId), userDetails);

        final TriggerCU restAdapterCU = getExpectedCu(triggerCu,gsi);

        JSONObject entityData = buildEntityData(restAdapterCU);
        String authUrl = getAuthUrl(entityData, transData);
        GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, AppConstant.TRIGGER_CES_LAYER);
        Map<String, String> resultMap = new HashMap<>();
        resultMap.put(tcesGeneralEntity.getNslAttributes().get(0).getName(), authUrl);
        resultMap.put(tcesGeneralEntity.getNslAttributes().get(1).getName(),
                "<a href=\"" + authUrl + "\" target=\"_blank\">Click Here For Authorization</a>");
        JsonNode result = new ObjectMapper().convertValue(resultMap, JsonNode.class);
        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, result);
        transData = extSolutionUtil.setChangeDriverInTxnData(txnGeneralEntity, LayerType.TRIGGERCES);
        return transData;
    }

    private JSONObject buildEntityData(TriggerCU triggerCu) throws JSONException {
        JSONObject entityData = new JSONObject();
//        triggerCu.setCuSystemProperties(CuUtils.hardCode()); //TODO Remove
        Long connectionId = Long.valueOf(triggerCu.getCuSystemProperties().get(AppConstant.CONFIG_ENTITY_RECORD_ID));

        RESTAdapterConnectionDto restAdapterConnectionDto = connectionService.getEntityRecordrest(connectionId);
        OAuthCredentials oAuthCredentials = restAdapterConnectionDto.getAuthentication().getOAuthCredentials();
        entityData.put(AUTH_URL, oAuthCredentials.getAuthorizationUri());
        entityData.put(CLIENT_ID, oAuthCredentials.getClientId());
        entityData.put(CLIENT_SECRET, oAuthCredentials.getClientSecret());
        entityData.put(SCOPE, oAuthCredentials.getScope());
        return entityData;
    }

    private String getAuthUrl(JSONObject entityData, TxnData txnData) throws JSONException {
        String redirectUrl = adaptorProperties.getAppOauthCallbackUrl();
        redirectUrl = urlEncodedData(redirectUrl);
        redirectUrl = redirectUrl + "&state=" + oAuth2RedirectionUtil.getStateParam(txnData);
        String authUrl = entityData.getString(AUTH_URL);
        authUrl = authUrl + "?redirect_uri=" + redirectUrl;
        authUrl = authUrl + "&prompt=consent&response_type=code&client_id="+ entityData.getString(CLIENT_ID);
        authUrl = authUrl + "&scope=" + entityData.getString(SCOPE) + "&access_type=offline&flowName=GeneralOAuthFlow";
        logger.info("authUrl: {}", authUrl);
        return authUrl;
    }

    private String urlEncodedData(String value){

        try{
            value = URLEncoder.encode(value, StandardCharsets.UTF_8);
        }catch (Exception e){
            logger.error("Error in encoding ur", e);
        }
        return value;
    }

    private static TriggerCU getExpectedCu(TriggerCU triggerCu, GSI gsi) throws NSLException {
        TriggerCU result = null;
        if (!(triggerCu.getNextTriggerSet()!=null && !triggerCu.getNextTriggerSet().isEmpty())){
            throw new NSLException(ExceptionCategory.CU_GSI,"No succeeding CU after OAUTH reserved CU",
                    ExceptionSeverity.BLOCKER);
        }
        result = gsi.getSolutionLogic().get(triggerCu.getNextTriggerSet().get(0).getIndex()-1);
        return result;
    }
}
