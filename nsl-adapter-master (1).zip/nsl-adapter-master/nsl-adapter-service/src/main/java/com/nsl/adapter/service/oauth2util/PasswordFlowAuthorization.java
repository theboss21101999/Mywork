package com.nsl.adapter.service.oauth2util;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.dto.CredentialPair;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.OAuthCredentials;
import com.nsl.adapter.service.rest.utils.RestConstants;
import com.nsl.adapter.service.utils.AppConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;


/**
 * This class is for : .
 */
@Component
public class PasswordFlowAuthorization extends OAuth2FlowAuthorization{

    private static final Logger logger = LoggerFactory.getLogger(PasswordFlowAuthorization.class);
    /**
     * This Object is : RestTemplate.
     */
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private MessageSource messageSource;
    @Autowired
    private AdaptorProperties adaptorProperties;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    public CredentialPair getCredentialPair(RESTAdapterConnectionDto connectionDto){
            String baseUri;
            String result;
            OAuthCredentials oauthCredentials = connectionDto.getAuthentication().getOAuthCredentials();
            baseUri= connectionDto.getAuthentication().getOAuthCredentials().getAccessTokenUri();
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            map.add("client_id",oauthCredentials.getClientId());
            map.add("grant_type", RestConstants.PASSWORD);
            map.add("username", connectionDto.getAuthentication().getUsername());
            map.add("password", connectionDataToolsV3.getSecret(connectionDto.getAuthentication().getPassword()));
            HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(map, headers);

            ResponseEntity<JsonNode> response = restTemplate.exchange(baseUri,
                    HttpMethod.POST, httpEntity, JsonNode.class);
            result = response.getBody().get("access_token").asText();//NOSONAR

            CredentialPair pair = new CredentialPair();
            Map<String, String> map1 = new HashMap<>();

            map1.put("Authorization", AppConstant.BEARER+result);
            pair.setLocation(oauthCredentials.getLocation());
            pair.setCredentials(map1);
            return pair;


    }

    @Override
    public String getDefaultGrantType() {
        return "password";
    }


}
