package com.nsl.adapter.service.onedrive.serviceimpl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.nsl.adapter.service.exception.AdapterException;
import com.nsl.adapter.commons.parsers.service.ParserFactoryV2;
import com.nsl.adapter.commons.parsers.service.ParserV2;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import org.apache.commons.io.FileUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import static com.nsl.adapter.service.onedrive.utils.OnedriveConstants.ONEDRIVE_URL;


@Service
public class OnedriveOperations {

    private static final Logger LOGGER = LoggerFactory.getLogger(OnedriveOperations.class);

    @Autowired
    OnedriveService onedriveservice;

    @Autowired
    ParserFactoryV2 parserFactoryV2;

    @Autowired
    RestTemplate restTemplate;


    public JsonNode uploadToOneDrive(GeneralEntity generalEntity, TxnGeneralEntity txnGeneralEntity,
                                     String filename, String folderName, String fileType, TriggerCU triggerCu) throws NSLException, AdapterException {

        LOGGER.info("initializing upload File method :");
        //String destinationLoc="/tmp";
        Boolean isFileExists = Boolean.FALSE;
        LOGGER.info("initializing outbound parsing :");
        ParserV2 parser = parserFactoryV2.getParser(fileType);
        InputStream inputStream = parser.outboundParser(txnGeneralEntity, generalEntity, isFileExists,triggerCu.getCuSystemProperties());
        //String path = destinationLoc + File.separator + filename + "." + FilenameUtils.getName(fileType);
        File file = null;
        try {
            file = File.createTempFile(filename, "." + fileType);//new File(path);     //NOSONAR
            FileUtils.copyInputStreamToFile(inputStream, file);
            String connectionId = triggerCu.getCuSystemProperties().get(AppConstant.CONFIG_ENTITY_RECORD_ID);
            String accessToken = onedriveservice.createObject(Long.valueOf(connectionId));

            String uri;
            if (folderName == null) {
                uri = ONEDRIVE_URL + filename + "." + fileType + ":/content";
            } else {
                uri = ONEDRIVE_URL + folderName + File.separator + filename +  "." + fileType + ":/content";
            }

            String content = Files.readString(Paths.get(file.getAbsolutePath()));     //NOSONAR
            String token = "Bearer " + accessToken;
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.AUTHORIZATION, token);
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            //MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
           // map.add("file", content);
            HttpEntity<String> httpEntity = new HttpEntity<>(content, headers);
            ResponseEntity<JsonNode> response;
            response = restTemplate.exchange(uri, HttpMethod.PUT,
                    httpEntity, JsonNode.class);
            JsonNode jsonnode = response.getBody();
            if (jsonnode != null) {
                JSONObject obj = new JSONObject();
                String id = String.valueOf(jsonnode.get("id"));
                String name = String.valueOf(jsonnode.get("name"));
                String webUrl = String.valueOf(jsonnode.get("webUrl"));
                String size = String.valueOf(jsonnode.get("size"));
                String driveId = String.valueOf(jsonnode.get("parentReference").get("driveId"));
                obj.put("id", id.substring(1, id.length() - 1));
                obj.put("name", name.substring(1, name.length() - 1));
                obj.put("webUrl", webUrl.substring(1, webUrl.length() - 1));
                obj.put("size", size);
                obj.put("driveId", driveId.substring(1, driveId.length() - 1));
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonNode = objectMapper.readTree(obj.toString());
                return jsonNode;
            }
        } catch (Exception e) {

            LOGGER.error("Exception while uploading file to onedrive", e);
            //throw new NSLException("Exception while uploading file to onedrive");
        } finally {
            if (file != null && file.exists())
                file.delete();
        }

        return null;
    }

    public TxnData getEntity(String fileKey, TriggerCU triggerCu) throws AdapterException, NSLException {

        LOGGER.info("initializing get entity method:");
        GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(
                triggerCu, AppConstant.TRIGGER_CES_LAYER);
        Map<String, String> cuSystemProps = triggerCu.getCuSystemProperties();
        boolean isMultivalued = true;
        String connectionId = triggerCu.getCuSystemProperties().get(AppConstant.CONFIG_ENTITY_RECORD_ID);
        String accessToken = onedriveservice.createObject(Long.valueOf(connectionId));
        LOGGER.info("Calling getFile Api..");
        return onedriveservice.getFile(tcesGeneralEntity, fileKey, accessToken, cuSystemProps, isMultivalued);
    }

    public JsonNode deleteFile(String fileKey, TriggerCU triggerCu) throws JsonProcessingException, AdapterException, NSLException {

        LOGGER.info("initializing delete file method");
        String id = null;
        String connectionId = triggerCu.getCuSystemProperties().get(AppConstant.CONFIG_ENTITY_RECORD_ID);
        String accessToken = onedriveservice.createObject(Long.valueOf(connectionId));
        String uri = ONEDRIVE_URL + fileKey;
        String token = "Bearer " + accessToken;
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        LOGGER.info("Calling delete Api ");
        String response = onedriveservice.delete(restTemplate, uri, headers);
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode = objectMapper.readTree(response);
        return jsonNode;
    }

    public JsonNode listFile(TriggerCU triggerCu, String folderName) throws NSLException, AdapterException {

        LOGGER.info("initializing list files method ");
        String uri = ONEDRIVE_URL + folderName + ":/children";
        String connectionId = triggerCu.getCuSystemProperties().get(AppConstant.CONFIG_ENTITY_RECORD_ID);
        String accessToken = onedriveservice.createObject(Long.valueOf(connectionId));
        String token = "Bearer " + accessToken;
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        ResponseEntity<JsonNode> response = restTemplate.exchange(uri, HttpMethod.GET,
                new HttpEntity<Object>(headers), JsonNode.class);
        List files = new ArrayList();
        List files2 = new ArrayList();
        if (response.getBody() != null) {
            List<Object> list = Collections.singletonList(response.getBody().get("value"));     //NOSONAR
            int n = ((ArrayNode) list.get(0)).size();

            for (int i = 0; i < n; i++) {
                files = Collections.singletonList(((ArrayNode) list.get(0)).get(i).get("name"));
                files2.add(files.get(0));
            }
        }

        if (files2 == null || files2.isEmpty()) {
            System.out.println("No files found.");
            return null;
        } else {
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, List> map = new HashMap();
            map.put("FILE_NAME", files2);
            JsonNode jsonNode = objectMapper.convertValue(map, JsonNode.class);
            return jsonNode;
        }
    }


}

