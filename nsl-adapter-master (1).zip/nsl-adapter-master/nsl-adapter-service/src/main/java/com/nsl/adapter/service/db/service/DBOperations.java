package com.nsl.adapter.service.db.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.dto.connections.DBConnectionDto;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import org.springframework.boot.configurationprocessor.json.JSONObject;

import java.sql.SQLException;

public abstract class DBOperations {
    public abstract TxnData getTable(DBConnectionDto connectionDto, String query, TriggerCU triggerCu) throws SQLException;
    public abstract TxnData updateTable(DBConnectionDto connectionDto, JSONObject transObject, TriggerCU triggerCu);
    public abstract JsonNode getJsonNode(DBConnectionDto connectionDto, String query);

}
