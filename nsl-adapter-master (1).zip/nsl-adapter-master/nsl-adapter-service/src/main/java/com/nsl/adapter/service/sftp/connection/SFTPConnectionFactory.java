package com.nsl.adapter.service.sftp.connection;

import com.nsl.adapter.commons.dto.connections.SFTPAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.SFTPCredentialType;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.AppConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.util.Locale;

@Component
public class SFTPConnectionFactory {

    private static final String SUCCESS = "successfully connected";
    private static final String FAILED = "connection not valid";

    @Autowired
    private MessageSource messageSource;

    public ApiResponse testConnection(SFTPAdapterConnectionDto sftpAdapterConnectionDto){
        SFTPCredentialType sftpCredentialType =  sftpAdapterConnectionDto.getAuthentication().getType();
        SFTPConnection sftpConnectionInstance = null;
        try{
            switch (sftpCredentialType) {
                case PASSWORD:
                    PasswordConnection passwordConnection = new PasswordConnection();
                    passwordConnection.createConnection(sftpAdapterConnectionDto);
                    sftpConnectionInstance = passwordConnection;
                    break;
                case KEY:
                    KeyConnection  keyConnection = new KeyConnection();
                    keyConnection.createConnection(sftpAdapterConnectionDto);
                    sftpConnectionInstance =  keyConnection;
                    break;
                case KEYPASSWORD:
                    KeyPasswordConnection keyPasswordConnection = new KeyPasswordConnection();
                    keyPasswordConnection.createConnection(sftpAdapterConnectionDto);
                    sftpConnectionInstance =  keyPasswordConnection;
                    break;
                default:
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_121", null, Locale.ENGLISH));
            }
            if(sftpConnectionInstance.getChannelSftp()!=null && sftpConnectionInstance.getChannelSftp().isConnected())
                return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS,SUCCESS);
            else
                return new ApiResponse(HttpStatus.OK, messageSource.getMessage("Paas_Adapter_96", null, Locale.ENGLISH),FAILED);
        }catch(SFTPConnectionException e){
            return new ApiResponse(HttpStatus.OK, messageSource.getMessage("Paas_Adapter_96", null, Locale.ENGLISH),e.getMessage());
        }


    }


}
