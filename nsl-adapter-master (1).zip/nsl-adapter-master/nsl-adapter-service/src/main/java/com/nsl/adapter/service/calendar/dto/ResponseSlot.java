package com.nsl.adapter.service.calendar.dto;

import java.util.List;


public class ResponseSlot {

    List<OccupiedSlot> occupiedSlots;
    List<AvailabilitySlot>availabilitySlots;

    public List<OccupiedSlot> getOccupiedSlots() {
        return occupiedSlots;
    }

    public void setOccupiedSlots(List<OccupiedSlot> occupiedSlots) {
        this.occupiedSlots = occupiedSlots;
    }

    public List<AvailabilitySlot> getAvailabilitySlots() {
        return availabilitySlots;
    }

    public void setAvailabilitySlots(List<AvailabilitySlot> availabilitySlots) {
        this.availabilitySlots = availabilitySlots;
    }
}
