package com.nsl.adapter.service.Docusign.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.DocusignAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;


@Service
public class DocusignConnectionService {
    private static final Logger LOGGER= LoggerFactory.getLogger(DocusignConnectionService.class);


    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    MessageSource messageSource;


    public TxnAdapterConnection saveDocusignConnection(DocusignAdapterConnectionDto connectionDto)
    {
        if (connectionDto.getAppId() == null || connectionDto.getAppSecret() == null ||
                connectionDto.getConnectionName() == null
                || adapterConnnectionsDao.getConnectionByName(ConnectionDtoType.DOCUSIGN, connectionDto.getConnectionName(), authBean)!=null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_182", null, Locale.ENGLISH) , null);
        }
        connectionDataToolsV3.connectionCheck(ConnectionDtoType.DOCUSIGN,connectionDto.getConnectionName(),authBean);
        String combinedstring=connectionDto.getAppId()+":"+connectionDto.getAppSecret();
        combinedstring= Base64.getEncoder().encodeToString(combinedstring.getBytes(StandardCharsets.UTF_8));

        connectionDto.setAppSecret(connectionDataToolsV3.saveSecret(ConnectionDtoType.DOCUSIGN, "appSecret",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getAppSecret()));
        connectionDto.setEncodedKey(connectionDataToolsV3.saveSecret(ConnectionDtoType.DOCUSIGN, "encodedKey",
                connectionDto.getConnectionName(), authBean.getTenantId(),combinedstring));

        LOGGER.info("saving DOCUSIGN connection");
        TxnAdapterConnection result = new TxnAdapterConnection();
        result.setConnectionDtoType(ConnectionDtoType.DOCUSIGN);
        result.setConnection(connectionDto);
        result = adapterConnnectionsDao.saveConnection(result, authBean);
        return result;
    }

    public DocusignAdapterConnectionDto getDocusignConnection(Long id, boolean hide) {
        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.DOCUSIGN, id, authBean);
        if (previousConnection==null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }
        return txnToDocusignDto(previousConnection, hide);
    }
    public DocusignAdapterConnectionDto txnToDocusignDto(TxnAdapterConnection adapterConnection, boolean hide) {
        if (adapterConnection==null){
            return null;
        }
        DocusignAdapterConnectionDto dto = (DocusignAdapterConnectionDto) adapterConnection.getConnection();
        if (!hide){
            dto.setAppSecret(connectionDataToolsV3.getSecret(dto.getAppSecret()));
            dto.setRefreshToken(connectionDataToolsV3.getSecret(dto.getRefreshToken()));
            dto.setEncodedKey(connectionDataToolsV3.getSecret(dto.getEncodedKey()));
        }
        dto.getMetadata().put("dsdId",String.valueOf(adapterConnection.getRecordId()));
        return dto;
    }

    public TxnAdapterConnection updateDocusignConnection(Long id, DocusignAdapterConnectionDto connectionDto) {
        if(  connectionDto.getAppSecret() == null || connectionDto.getAppId() == null ||
                connectionDto.getConnectionName() == null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.DOCUSIGN, id, authBean);
        connectionDataToolsV3.connectionNameCheck(previousConnection,connectionDto.getConnectionName());
        if (previousConnection==null || !previousConnection.getConnection().getConnectionName().equals(connectionDto.getConnectionName())){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }

        DocusignAdapterConnectionDto prevsDto =(DocusignAdapterConnectionDto) previousConnection.getConnection();
        if (connectionDto.getAppId()!=null){
            prevsDto.setAppId(connectionDto.getAppId());
        }
        if (connectionDto.getRefreshToken()!=null){
            prevsDto.setRefreshToken(connectionDataToolsV3.updateSecret(ConnectionDtoType.DOCUSIGN, "refreshToken",
                    connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getRefreshToken()));
        }

        previousConnection.setConnection(prevsDto);
        LOGGER.info("update DOCUSIGN connection");
        TxnAdapterConnection result = adapterConnnectionsDao.saveConnection(previousConnection, authBean);
        return result;
    }

}
