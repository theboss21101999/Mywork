package com.nsl.adapter.service.inbound.dto;

import com.nsl.adapter.commons.dto.SchedulerRequestDto;
import com.nsl.logical.model.ChangeUnit;
import java.util.List;

public class NSLGsiListDto {
    private SchedulerRequestDto schedulerRequestDto;
    private ChangeUnit changeUnit;
    private List<Long> gsiMasterIdList;
    private String eventId;

    public NSLGsiListDto() {
    }

    public SchedulerRequestDto getSchedulerRequestDto() {
        return schedulerRequestDto;
    }

    public void setSchedulerRequestDto(SchedulerRequestDto schedulerRequestDto) {
        this.schedulerRequestDto = schedulerRequestDto;
    }

    public ChangeUnit getChangeUnit() {
        return changeUnit;
    }

    public void setChangeUnit(ChangeUnit changeUnit) {
        this.changeUnit = changeUnit;
    }

    public List<Long> getGsiMasterIdList() {
        return gsiMasterIdList;
    }

    public void setGsiMasterIdList(List<Long> gsiMasterIdList) {
        this.gsiMasterIdList = gsiMasterIdList;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }
}
