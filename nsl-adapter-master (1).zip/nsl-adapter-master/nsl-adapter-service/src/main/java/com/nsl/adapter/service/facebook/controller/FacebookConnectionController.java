package com.nsl.adapter.service.facebook.controller;

import com.nsl.adapter.commons.dto.connections.FacebookAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.service.facebook.service.FacebookConnectionService;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.facebook.utils.FacebookOauthConnection;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class FacebookConnectionController {

    @Autowired
    FacebookConnectionService facebookConnectionService;

    @Autowired
    FacebookOauthConnection oauthConnection;

    @PostMapping(path = "/facebook", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveFacebookConnection(@RequestBody FacebookAdapterConnectionDto connectionDto) {
        TxnAdapterConnection result = facebookConnectionService.saveFacebookConnection(connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationcode(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
    @GetMapping(path = "/facebook/{Id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getFacebookConnection(@PathVariable("Id") Long id) {

        FacebookAdapterConnectionDto response = facebookConnectionService.getFacebookConnection(id, true);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @PutMapping(path = "/facebook/{id}" , consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse updateFacebookConnection(@PathVariable("id") Long id,
                                                @RequestBody FacebookAdapterConnectionDto connectionDto ) {

        TxnAdapterConnection result = facebookConnectionService.updateFacebookConnection(id, connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationcode(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
    @GetMapping(path = "/facebook/refreshToken/{Id}")
    public ApiResponse updateFacebookToken(@PathVariable("Id") Long id){

        TxnAdapterConnection result =oauthConnection.getRefreshToken(id);
        return new ApiResponse(HttpStatus.OK,SUCCESS,result);
    }
}
