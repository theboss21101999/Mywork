package com.nsl.adapter.service.ciscoWebex.Connection;


import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.ciscoWebex.CiscoOauthConnection;
import com.nsl.adapter.commons.dto.connections.CiscoOauthconnectionDto;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class CiscoAdapterConnectionController {

    @Autowired
    CiscoConnectionService ciscoConnectionService;

    @Autowired
    CiscoOauthConnection oauthConnection;

    @PostMapping(path = "/cisco")
    public ApiResponse saveCiscoConnection(@RequestBody CiscoOauthconnectionDto connectionDto) throws NSLException {

        TxnAdapterConnection result = ciscoConnectionService.ciscoSave(connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationcode(connectionDto,result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }

    @GetMapping(path = "/cisco/{attrId}")
    public ApiResponse getCiscoConnection(@PathVariable("attrId") Long attrId) {

        CiscoOauthconnectionDto result = ciscoConnectionService.getCiscoConnection(attrId, true);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, result);
    }

    @GetMapping(path = "/cisco/refreshToken/{Id}")
    public ApiResponse updateCiscoToken(@PathVariable("Id") Long id) throws NSLException {

        TxnAdapterConnection result =oauthConnection.getRefreshToken(id);
        return new ApiResponse(HttpStatus.OK,SUCCESS,result);
    }

    @PutMapping(path = "/cisco/{id}")
    public ApiResponse updateCiscoConnection(@PathVariable("id") Long id,
                                              @RequestBody CiscoOauthconnectionDto connectionDto ) throws NSLException {

        TxnAdapterConnection result =ciscoConnectionService.updateCiscoEntity(id,connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationcode(connectionDto,result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }


}



