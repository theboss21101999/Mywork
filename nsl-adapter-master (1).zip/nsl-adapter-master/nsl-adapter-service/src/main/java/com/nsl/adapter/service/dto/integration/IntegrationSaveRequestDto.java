package com.nsl.adapter.service.dto.integration;

import java.util.Map;

public class IntegrationSaveRequestDto {

    String configEntityName;
    String adapterType;
    String integrationName;
    Long configEntityRecordId;
    Boolean swaggerEnabled;
    Map<String, String> metadata;
    RestIntegrationReq restIntegrationReq;
    SwaggerIntegrationReq swaggerIntegrationReq;

    public IntegrationSaveRequestDto() {
    }

    public IntegrationSaveRequestDto(String configEntityName, String adapterType, String integrationName, Long configEntityRecordId, Boolean swaggerEnabled, Map<String, String> metadata, RestIntegrationReq restIntegrationReq, SwaggerIntegrationReq swaggerIntegrationReq) {
        this.configEntityName = configEntityName;
        this.adapterType = adapterType;
        this.integrationName = integrationName;
        this.configEntityRecordId = configEntityRecordId;
        this.swaggerEnabled = swaggerEnabled;
        this.metadata = metadata;
        this.restIntegrationReq = restIntegrationReq;
        this.swaggerIntegrationReq = swaggerIntegrationReq;
    }

    public String getConfigEntityName() {
        return configEntityName;
    }

    public void setConfigEntityName(String configEntityName) {
        this.configEntityName = configEntityName;
    }

    public String getAdapterType() {
        return adapterType;
    }

    public void setAdapterType(String adapterType) {
        this.adapterType = adapterType;
    }

    public String getIntegrationName() {
        return integrationName;
    }

    public void setIntegrationName(String integrationName) {
        this.integrationName = integrationName;
    }

    public Long getConfigEntityRecordId() {
        return configEntityRecordId;
    }

    public void setConfigEntityRecordId(Long configEntityRecordId) {
        this.configEntityRecordId = configEntityRecordId;
    }

    public Boolean getSwaggerEnabled() {
        return swaggerEnabled;
    }

    public void setSwaggerEnabled(Boolean swaggerEnabled) {
        this.swaggerEnabled = swaggerEnabled;
    }

    public Map<String, String> getMetadata() {
        return metadata;
    }

    public void setMetadata(Map<String, String> metadata) {
        this.metadata = metadata;
    }

    public RestIntegrationReq getRestIntegrationReq() {
        return restIntegrationReq;
    }

    public void setRestIntegrationReq(RestIntegrationReq restIntegrationReq) {
        this.restIntegrationReq = restIntegrationReq;
    }

    public SwaggerIntegrationReq getSwaggerIntegrationReq() {
        return swaggerIntegrationReq;
    }

    public void setSwaggerIntegrationReq(SwaggerIntegrationReq swaggerIntegrationReq) {
        this.swaggerIntegrationReq = swaggerIntegrationReq;
    }
}
