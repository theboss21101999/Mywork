package com.nsl.adapter.service.service;

import com.nsl.adapter.commons.dto.SchedulerRequestDto;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.inbound.dto.NSLGsiListDto;
import com.nsl.adapter.service.inbound.service.GeneralInboundService;
import com.nsl.adapter.commons.dto.connections.MqttConnectionDto;
import com.nsl.adapter.service.mqtt.service.MqttConnectionService;
import com.nsl.adapter.service.mqtt.serviceImpl.InboundMqttService;

import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;

import javax.annotation.Resource;

@Service
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class MqttInboundService extends InboundIntegrationService{
    private static final Logger LOGGER = LoggerFactory.getLogger(MqttInboundService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;
    @Autowired
    GeneralInboundService generalInboundService;
    @Autowired
    InboundMqttService inboundMqttService;
    @Autowired
    MqttConnectionService mqttConnectionService;


    @Override
    public ApiResponse publishMessage(SchedulerRequestDto schedulerRequestDto) throws NSLException {
        try {
            NSLGsiListDto nslGsiListDto = generalInboundService.getGsiList(schedulerRequestDto);
            Long connectionId = Long.valueOf(nslGsiListDto.getChangeUnit().getCuSystemProperties().get(AppConstant.CONFIG_ENTITY_RECORD_ID));
            MqttConnectionDto mqttConnectionDto = mqttConnectionService.getMqttConnection(connectionId, false);
            inboundMqttService.startMqttClientConnection(mqttConnectionDto,nslGsiListDto);
            LOGGER.info("started the mqtt client with adapter connection name = "+nslGsiListDto.getChangeUnit().getCuSystemProperties().get(AppConstant.CONFIG_ENTITY_RECORD_NAME));
           return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, nslGsiListDto.getEventId());
        } catch (Exception e) {
            LOGGER.error(String.valueOf(e));
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, AppConstant.FAILURE);
        }

    }
}
