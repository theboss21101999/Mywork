package com.nsl.adapter.service.pop3.controller;


import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.commons.dto.connections.PopAdapterDto;
import com.nsl.adapter.service.pop3.service.POP3ConnectionService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@Controller
@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class POP3AdapterConnectionController {

    @Autowired
    POP3ConnectionService pop3ConnectionService;

    @PostMapping(path = "/pop3", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse savePop3Connection(@RequestBody PopAdapterDto connectionDto) {

        TxnAdapterConnection result = pop3ConnectionService.savePOP3Connection(connectionDto);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }

    @GetMapping(path = "/pop3/{attrId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getPop3Connection(@PathVariable("attrId") Long attrId) {

        PopAdapterDto response = pop3ConnectionService.getPOP3Connection(attrId, Boolean.FALSE);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @PutMapping(path = "/pop3/{attrId}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse updatePop3Connection(@PathVariable("attrId") Long attrId, @RequestBody PopAdapterDto connectionDto) {

        TxnAdapterConnection result = pop3ConnectionService.updatePOP3Connection(connectionDto, attrId);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }

}

