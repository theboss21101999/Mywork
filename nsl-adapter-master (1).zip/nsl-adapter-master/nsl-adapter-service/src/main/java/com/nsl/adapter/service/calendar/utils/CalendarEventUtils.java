package com.nsl.adapter.service.calendar.utils;

import com.nsl.externalreservedcus.dto.calender.event.ActionButton;
import com.nsl.logical.model.*;
import com.nsl.externalreservedcus.dto.calender.event.CalendarEvent;
import com.nsl.externalreservedcus.dto.calender.event.Contact;
import com.nsl.externalreservedcus.dto.calender.event.Recurrence;
import com.nsl.externalreservedcus.enums.CalendarEventEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMultipart;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import static com.nsl.externalreservedcus.enums.CalendarEventEnum.valueOf;

@Component
public class CalendarEventUtils {


    @Autowired
    CalendarAttachment calendarAttachment;

    private static final Logger logger = LoggerFactory.getLogger(CalendarEventUtils.class);

    private static final String DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

    public  Map<String, String> buildCalendarEventMap(CalendarEvent calendarEvent, GeneralEntity generalEntity) {

        Map<String, String> eventMap = new HashMap<>();
        for(NslAttribute attribute : generalEntity.getNslAttributes()) {
            try {
                CalendarEventEnum eventEnum = fromString(attribute.getName());
                if (eventEnum == null) {
                    throw new IllegalStateException("Unexpected value: " + valueOf(attribute.getName()));
                }
                switch (eventEnum) {
                    case TITLE:
                        eventMap.put(attribute.getName(), calendarEvent.getTitle());
                        break;
                    case TAG:
                        eventMap.put(attribute.getName(), calendarEvent.getTag());
                        break;
                    case CATEGORY:
                        eventMap.put(attribute.getName(), calendarEvent.getCategory());
                        break;
                    case SUB_CATEGORY:
                        eventMap.put(attribute.getName(), calendarEvent.getSubCategory());
                        break;
                    case EVENT_TYPE:
                        eventMap.put(attribute.getName(), calendarEvent.getEventType());
                        break;
                    case START_TIME:
                        eventMap.put(attribute.getName(), getTime(calendarEvent.getStartTime()));
                        break;
                    case END_TIME:
                        eventMap.put(attribute.getName(), getTime(calendarEvent.getEndTime()));
                        break;
                    case REMINDER:
                        eventMap.put(attribute.getName(), calendarEvent.getReminder().toString());
                        break;
                    case NOTIFICATION_CHANNEL:
                        eventMap.put(attribute.getName(), calendarEvent.getNotificationChannel());
                        break;
                    case DESCRIPTION:
                        eventMap.put(attribute.getName(), calendarEvent.getDescription());
                        break;
                    case LOCATION:
                        eventMap.put(attribute.getName(), calendarEvent.getLocation());
                        break;
                    case CONFERENCE_TYPE:
                        eventMap.put(attribute.getName(), calendarEvent.getConferenceType());
                        break;
                    case MEETING_URL:
                        eventMap.put(attribute.getName(), calendarEvent.getMeetingUrl());
                        break;
                    case ORGANIZER:
                        eventMap.put(attribute.getName(), calendarEvent.getOrganizer());
                        break;
                    case PARTICIPANTLIST:
                        eventMap.put(attribute.getName(), String.join("-", calendarEvent.getParticipantList()));
                        break;
                    case ADDITIONAL_INFO1:
                        eventMap.put(attribute.getName(), calendarEvent.getAdditionalInfo1());
                        break;
                    case ADDITIONAL_INFO2:
                        eventMap.put(attribute.getName(), calendarEvent.getAdditionalInfo2());
                        break;
                    case ADDITIONAL_INFO3:
                        eventMap.put(attribute.getName(), calendarEvent.getAdditionalInfo3());
                        break;
                    case ADDITIONAL_INFO4:
                        eventMap.put(attribute.getName(), calendarEvent.getAdditionalInfo4());
                        break;
                    case ADDITIONAL_INFO5:
                        eventMap.put(attribute.getName(), calendarEvent.getAdditionalInfo5());
                        break;
                    case METADATA:
                        eventMap.put(attribute.getName(), calendarEvent.getMetadata());
                        break;
                    case ATTACHMENT:
                        eventMap.put(attribute.getName(), String.valueOf(getAttachment(calendarEvent.getAttachment())));
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + valueOf(attribute.getName()));
                }
            } catch (Exception e) {
                logger.error("Error in building map");
            }
        }
        return eventMap;
    }

    private  List<String> getAttachment(List<String> attachment) throws MessagingException, JSONException, IOException {

        JSONArray attachmentList = new JSONArray(attachment);
        MimeMultipart multiPart=new MimeMultipart();
        calendarAttachment.addAttachment(attachmentList, multiPart);
        return attachment;
    }

    private static String getTime(Date time) {
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_PATTERN);
        return formatter.format(time);
    }

    public static CalendarEventEnum fromString(String value) {
        for (CalendarEventEnum eventEnum : CalendarEventEnum.values()) {
            if(eventEnum.getValue().equalsIgnoreCase(value))
                return eventEnum;
        }
        return null;
    }

    public static void buildNestedEntity(TxnNslAttribute attribute, NslAttribute nslAttribute, CalendarEvent calendarEvent) {
        TxnGeneralEntity contactTxnEntity = new TxnGeneralEntity();
        GeneralEntity contactEntity = nslAttribute.getGeneralEntity();
        contactTxnEntity.setGeneralEntityID(contactEntity.getId());
        contactTxnEntity.setGeneralEntityMasterId(contactEntity.getMasterId());
        contactTxnEntity.setName(contactEntity.getName());
        attribute.setTxnGeneralEntity(contactTxnEntity);
        if(nslAttribute.getName().equalsIgnoreCase("NSL_Recurrence"))
            contactTxnEntity.setTransEntityRecords(Collections.singletonList(buildRecurrenceRecord(contactEntity, calendarEvent.getRecurrence())));
        if(nslAttribute.getName().equalsIgnoreCase("NSL_ActionButton"))
            contactTxnEntity.setTransEntityRecords(buildActionRecord(contactEntity, calendarEvent.getGsi()));
    }

    private static TxnGeneralEntityRecord buildRecurrenceRecord(GeneralEntity recurrenceEntity, Recurrence recurrence) {
        Map<String, String> recurrenceMap = buildRecurrenceMap(recurrence);
        TxnGeneralEntityRecord recurrenceRecord = new TxnGeneralEntityRecord();
        List<TxnNslAttribute> attributes = new ArrayList<>();
        recurrenceRecord.setGeneralEntityId(recurrenceEntity.getId());
        recurrenceRecord.setGeneralEntityMasterId(recurrenceEntity.getMasterId());
        recurrenceRecord.setTxnNslAttribute(attributes);

        recurrenceEntity.getNslAttributes().forEach(nslAttribute -> {
            TxnNslAttribute attribute = new TxnNslAttribute();
            attributes.add(attribute);
            attribute.setName(nslAttribute.getName());
            attribute.setNslAttributeID(nslAttribute.getId());
            if (recurrenceMap.get(attribute.getName())!=null)
                attribute.setValues(Collections.singletonList(recurrenceMap.get(attribute.getName())));
            else
                attribute.setValues(new ArrayList<>());
        });

        return recurrenceRecord;
    }

    private static List<TxnGeneralEntityRecord> buildActionRecord(GeneralEntity actionEntity, List<ActionButton> action) {

        {
            List<TxnGeneralEntityRecord> actionEntityRecords = new ArrayList<>();
            if (action == null || action.isEmpty()){
                List<TxnNslAttribute> attributes = new ArrayList<>();
                actionEntity.getNslAttributes().forEach(nslAttribute -> {
                    TxnNslAttribute attribute = new TxnNslAttribute();
                    attributes.add(attribute);
                    attribute.setName(nslAttribute.getName());
                    attribute.setNslAttributeID(nslAttribute.getId());
                    attribute.setValues(new ArrayList<>());
                });
               TxnGeneralEntityRecord  txnGeneralEntityRecord = new TxnGeneralEntityRecord();
                txnGeneralEntityRecord.setGeneralEntityId(actionEntity.getId());
                txnGeneralEntityRecord.setGeneralEntityMasterId(actionEntity.getMasterId());
                txnGeneralEntityRecord.setTxnNslAttribute(attributes);
                return Arrays.asList(txnGeneralEntityRecord); //NOSONAR
            }
            action.forEach(gsi -> {
                Map<String, String> actionMap = buildActionMap(gsi);
                TxnGeneralEntityRecord actionEntityRecord = new TxnGeneralEntityRecord();
                List<TxnNslAttribute> attributes = new ArrayList<>();
                actionEntityRecord.setGeneralEntityId(actionEntity.getId());
                actionEntityRecord.setGeneralEntityMasterId(actionEntity.getMasterId());
                actionEntityRecord.setTxnNslAttribute(attributes);
                actionEntity.getNslAttributes().forEach(nslAttribute -> {
                    TxnNslAttribute attribute = new TxnNslAttribute();
                    attributes.add(attribute);
                    attribute.setName(nslAttribute.getName());
                    attribute.setNslAttributeID(nslAttribute.getId());
                    if (actionMap.get(attribute.getName()) != null)
                        attribute.setValues(Collections.singletonList(actionMap.get(attribute.getName())));
                });
                actionEntityRecords.add(actionEntityRecord);
            });
            return actionEntityRecords;
        }
    }

    private static Map<String, String> buildActionMap(ActionButton gsi) {
        Map<String, String> actionMap1 = new HashMap<>();
        actionMap1.put("BookId", gsi.getBookId());
        actionMap1.put("ButtonName", gsi.getButtonName());
        actionMap1.put("GsiId", gsi.getGsiId());
        actionMap1.put("GsiMasterId",gsi.getGsiMasterId());
        actionMap1.put("BookName",gsi.getBookName());
        actionMap1.put("GsiName",gsi.getGsiName());
        return actionMap1;
    }

    private static Map<String, String> buildRecurrenceMap(Recurrence recurrence) {
        Map<String, String> recurrenceMap = new HashMap<>();
        if(recurrence==null)
            return recurrenceMap;

        recurrenceMap.put("Frequency", recurrence.getFrequency());
        recurrenceMap.put("Day", recurrence.getDay());
        recurrenceMap.put("Occurance_type", recurrence.getOccurenceType());
        if(recurrence.getOccurenceOfDay()!=null)
        recurrenceMap.put("Occurance_of_day", recurrence.getOccurenceOfDay().toString());
        if(recurrence.getCount()!=null)
        recurrenceMap.put("Count", recurrence.getCount().toString());
        if(recurrence.getUntil()!=null)
        recurrenceMap.put("Until", getTime(recurrence.getUntil()));
        return recurrenceMap;
    }

    private static List<TxnGeneralEntityRecord> buildContactRecord(GeneralEntity contactEntity, List<Contact> participantList) {
        List<TxnGeneralEntityRecord> contactRecords = new ArrayList<>();
        participantList.forEach(contact -> {
            Map<String, String> contactMap = buildContactMap(contact);
            TxnGeneralEntityRecord contactRecord = new TxnGeneralEntityRecord();
            List<TxnNslAttribute> attributes = new ArrayList<>();
            contactRecord.setGeneralEntityId(contactEntity.getId());
            contactRecord.setGeneralEntityMasterId(contactEntity.getMasterId());
            contactRecord.setTxnNslAttribute(attributes);

            contactEntity.getNslAttributes().forEach(nslAttribute -> {
                TxnNslAttribute attribute = new TxnNslAttribute();
                attributes.add(attribute);
                attribute.setName(nslAttribute.getName());
                attribute.setNslAttributeID(nslAttribute.getId());
                if (contactMap.get(attribute.getName())!=null)
                    attribute.setValues(Collections.singletonList(contactMap.get(attribute.getName())));
                else
                    attribute.setValues(new ArrayList<>());
            });
            contactRecords.add(contactRecord);
        });
        return contactRecords;
    }

    private static Map<String, String> buildContactMap(Contact contact) {
        Map<String, String> contactMap = new HashMap<>();
        contactMap.put("Email", contact.getEmail());
        contactMap.put("name", contact.getName());
        contactMap.put("MobileNumber", contact.getMobile());
        return contactMap;
    }
}
