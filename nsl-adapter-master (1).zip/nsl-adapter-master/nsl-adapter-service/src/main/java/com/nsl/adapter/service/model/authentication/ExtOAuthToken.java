package com.nsl.adapter.service.model.authentication;

import java.io.Serializable;
import java.time.LocalDateTime;


public class ExtOAuthToken implements Serializable {
    private Long id;
    //OAuth2 flow name
    private String oAuthFlowType;

    private Long userId;
    private String tenantId;

    private String apiEndPoint;

    private String httpMethod;
    //Type of OAuth Token. eg. Bearer
    private String tokenType;
    //External Application Server URI
    private String server;
    //Authorization Code if flow type is AUTHORIZATION_CODE_GRANT
    private String authCode;
    //Access Token of OAuth
    private String accessToken;
    //Refresh Token of OAuth
    private String refreshToken;

    private String username;

    private String password;
    //Scope of Token. eg. Profile and Email
    private String scope;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    private LocalDateTime tokenExpiry;

    private boolean isTokenScopeForAllAPI;

    public boolean isTokenScopeForAllAPI() {
        return isTokenScopeForAllAPI;
    }

    public void setTokenScopeForAllAPI(boolean tokenScopeForAllAPI) {
        isTokenScopeForAllAPI = tokenScopeForAllAPI;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public LocalDateTime getTokenExpiry() {
        return tokenExpiry;
    }

    public void setTokenExpiry(LocalDateTime tokenExpiry) {
        this.tokenExpiry = tokenExpiry;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getHttpMethod() {
        return httpMethod;
    }

    public void setHttpMethod(String httpMethod) {
        this.httpMethod = httpMethod;
    }

    public String getoAuthFlowType() {
        return oAuthFlowType;
    }

    public void setoAuthFlowType(String oAuthFlowType) {
        this.oAuthFlowType = oAuthFlowType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getApiEndPoint() {
        return apiEndPoint;
    }

    public void setApiEndPoint(String apiEndPoint) {
        this.apiEndPoint = apiEndPoint;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

}
