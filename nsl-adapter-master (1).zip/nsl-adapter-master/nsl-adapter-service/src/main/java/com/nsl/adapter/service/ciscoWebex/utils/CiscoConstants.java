package com.nsl.adapter.service.ciscoWebex.utils;

public class CiscoConstants {
    public static final String CISCO = "Cisco";
    public static final String CISCO_AUTH_TOKEN = "https://webexapis.com/v1/authorize";
    public static final String CISCO_ACCESS_TOKEN ="https://webexapis.com/v1/access_token";
    public static final String PROMPT="prompt";
    public static final String CONSENT="consent";
    public static final String ACCESS_TYPE="access_type";
    public static final String OFFLINE="offline";
    public static final String CODE="code";
    public static final String AUTHORIZATION_CODE="authorization_code";
    public static final String REFRESH_TOKEN="refresh_token";
    public static final String STATE="state";
    public static final String Url="url";
    public static final String clientId="clientId";
    public static final String clientSecret="clientSecret";
    public static final String scope="scope";
    public static final String connectionName="connectionName";
    public static final String refreshToken="refreshToken";
    public static final String CISCO_MEET = "https://webexapis.com/v1/meetings";
    public static final String CISCO_MEETING_INVITEE = "https://webexapis.com/v1/meetingInvitees";
    public static final String CISCO_ADD_MEETING_INVITEES = "https://webexapis.com/v1/meetingInvitees/bulkInsert";
    public static final String CREATE_EVENT = "CREATE_EVENT";
    public static final String LIST_EVENT = "LIST_EVENT";
    public static final String GET_EVENT = "GET_EVENT";
    public static final String GET_VIDEOCONFERENCE = "GET_VIDEOCONFERENCE";
    public static final String ADD_INVITEES = "ADD_INVITEES";
    public static final String GET_INVITEES = "GET_INVITEES";
    public static final String TITLE = "title";
    public static final String AGENDA = "agenda";
    public static final String START = "start";
    public static final String END = "end";
    public static final String ITEMS = "items";
    public static final String RECURRENCE = "recurrence";
    public static final String EMAIL = "email";
    public static final String INVITEES = "invitees";
    public static final String DELETE_EVENT ="DELETE_EVENT";
    public static final String DESCRIPTION="description";
    public static final String START_DATE="startDate";
    public static final String START_TIME="startTime";
    public static final String END_DATE="endDate";
    public static final String END_TIME="endTime";
    public static final String WEBLINK="webLink";
    public static final String STATUS="status";
    public static final String ID="id";
    public static final String MEETING_NUMBER="meetingNumber";
    public static final String PASSWORD="password";


    private CiscoConstants(){
        throw new IllegalStateException("utility class");
    }
}
