package com.nsl.adapter.service.adobeSign.utils;

public class AdobeSignConstants {
    public static final String REFRESH_TOKEN="refresh_token";
    public static final String ADOBESIGN = "AdobeSign";
    public static final String ADOBESIGN_AUTH_TOKEN = "https://secure.in1.adobesign.com/public/oauth/v2";
    public static final String ADOBESIGN_ACCESS_TOKEN ="https://api.in1.adobesign.com/oauth/v2/token";
    public static final String ADOBESIGN_TOKEN="https://api.in1.adobesign.com/oauth/v2/refresh";

    public static final String ACCESS_TYPE="access_type";
    public static final String OFFLINE="offline";
    public static final String CODE="code";
    public static final String STATE="state";
    public static final String Url="url";
    public static final String AUTHORIZATION_CODE="authorization_code";

    private AdobeSignConstants(){

        throw new IllegalStateException("utility class");
    }
}
