package com.nsl.adapter.service.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.*;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.dto.Connection;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static com.nsl.adapter.commons.enums.ConnectionsType.*;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class ImportExportService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ImportExportService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnectionServiceV3 adapterConnectionServiceV3;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    private MessageSource messageSource;

    @Value("${app.dynamo.table.name.prefix}")
    String envName;

    @Value("${external.s3CopyConnection.url:http://nsl-aiml-service:8204/aiml/api/v1/s3copy}")
    String s3CopyConnectionUrl;

    @Autowired
    RestTemplate restTemplate;

    List<ConnectionsType> dynamoConnections = Arrays.asList(FACEBOOK, AIML, Google, ZOOM, Graph, S3, Cisco, POP3, IMAP, JIRA , REST,TWITTER,SMTP,SFTP, SOAP, ActiveMQ, DOCUSIGN, ADOBESIGN,LINKEDIN, FHIR, RabbitMQ, IBMMQ, FTP, GRPC, JDBC, OPENAPI,DB, GRAPHQL);


    public Connection getConnectionById(AdapterType adapterType, Long id){

        if (adapterType == null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_148", null, Locale.ENGLISH) ,null);

        ConnectionsType connectionType = ConnectionsType.valueOf(adapterType.getConnectionType());
        if (dynamoConnections.contains(connectionType)){ //NOSONAR
            ConnectionDtoType connectionDtoType = ConnectionDtoType.valueOf(connectionType.toString());
            TxnAdapterConnection txnAdapterConnection = adapterConnnectionsDao.getConnectionByRecordId(
                   connectionDtoType , id, authBean);

            if (txnAdapterConnection!=null){
                filterRecord(txnAdapterConnection);
                Connection connection = new Connection();
                connection.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                connection.setAdapterType(adapterType);
                connection.setSourceId(id);
                connection.setConnectionId(id);
                connection.setConnectionData(Base64.getEncoder().encodeToString(JacksonUtils.toJson(txnAdapterConnection).getBytes(StandardCharsets.UTF_8)));
                return connection;
            }
        }else{
            TxnGeneralEntityRecord txnGeneralEntityRecord = adapterConnectionServiceV3.getConnById(connectionType.getEntityName(), id, authBean);
            if (txnGeneralEntityRecord!=null){
                filterTxnGeRecord(adapterType, txnGeneralEntityRecord);
                Connection connection = txnGERecordToConn(txnGeneralEntityRecord);
                if(connection!=null){
                    connection.setSourceId(id);
                    connection.setAdapterType(adapterType);
                    return connection;
                }
            }
        }
        return null;

    }

    private void filterRecord(TxnAdapterConnection txnAdapterConnection) {
        switch (txnAdapterConnection.getConnectionDtoType()){
            case FACEBOOK:
                FacebookAdapterConnectionDto fbDto = new FacebookAdapterConnectionDto();
                fbDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                fbDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                fbDto.setAppId(((FacebookAdapterConnectionDto) txnAdapterConnection.getConnection()).getAppId());
                fbDto.setAppSecret(((FacebookAdapterConnectionDto) txnAdapterConnection.getConnection()).getAppSecret());
                fbDto.setScope(((FacebookAdapterConnectionDto) txnAdapterConnection.getConnection()).getScope());
                txnAdapterConnection.setConnection(fbDto);
                break;
            case LINKEDIN:
                LinkedinAdapterConnectionDto linkedinAdapterConnectionDto = new LinkedinAdapterConnectionDto();
                linkedinAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                linkedinAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                linkedinAdapterConnectionDto.setAppId(((LinkedinAdapterConnectionDto) txnAdapterConnection.getConnection()).getAppId());
                linkedinAdapterConnectionDto.setAppSecret(((LinkedinAdapterConnectionDto) txnAdapterConnection.getConnection()).getAppSecret());
                linkedinAdapterConnectionDto.setScope(((LinkedinAdapterConnectionDto) txnAdapterConnection.getConnection()).getScope());
                txnAdapterConnection.setConnection(linkedinAdapterConnectionDto);
                break;
            case AIML:
                break;
            case Google:
                GoogleOauthDto googleOauthDto = new GoogleOauthDto();
                googleOauthDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                googleOauthDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                googleOauthDto.setScope(((GoogleOauthDto) txnAdapterConnection.getConnection()).getScope());
                googleOauthDto.setClientId(((GoogleOauthDto) txnAdapterConnection.getConnection()).getClientId());
                googleOauthDto.setClientSecret(((GoogleOauthDto) txnAdapterConnection.getConnection()).getClientSecret());
                googleOauthDto.setApplicationName(((GoogleOauthDto) txnAdapterConnection.getConnection()).getApplicationName());
                txnAdapterConnection.setConnection(googleOauthDto);
                break;
            case ZOOM:
                ZoomConnectionDto zoomConnectionDto = new ZoomConnectionDto();
                zoomConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                zoomConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                txnAdapterConnection.setConnection(zoomConnectionDto);
                break;
            case Graph:
                GraphOauthConnectionDto graphOauthConnectionDto = new GraphOauthConnectionDto();
                graphOauthConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                graphOauthConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                graphOauthConnectionDto.setClientId(((GraphOauthConnectionDto) txnAdapterConnection.getConnection()).getClientId());
                graphOauthConnectionDto.setClientSecret(((GraphOauthConnectionDto) txnAdapterConnection.getConnection()).getClientSecret());
                graphOauthConnectionDto.setScope(((GraphOauthConnectionDto) txnAdapterConnection.getConnection()).getScope());
                txnAdapterConnection.setConnection(graphOauthConnectionDto);
                break;
            case S3:
                S3AdapterConnectionDto s3AdapterConnectionDto = new S3AdapterConnectionDto();
                s3AdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                s3AdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                s3AdapterConnectionDto.setAccessKey(((S3AdapterConnectionDto) txnAdapterConnection.getConnection()).getAccessKey());
                s3AdapterConnectionDto.setSecretKey(((S3AdapterConnectionDto) txnAdapterConnection.getConnection()).getSecretKey());
                s3AdapterConnectionDto.setRegion(((S3AdapterConnectionDto) txnAdapterConnection.getConnection()).getRegion());
                txnAdapterConnection.setConnection(s3AdapterConnectionDto);
                break;
            case Cisco:
                CiscoOauthconnectionDto ciscoOauthconnectionDto = new CiscoOauthconnectionDto();
                ciscoOauthconnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                ciscoOauthconnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                ciscoOauthconnectionDto.setClientId(((CiscoOauthconnectionDto) txnAdapterConnection.getConnection()).getClientId());
                ciscoOauthconnectionDto.setClientSecret(((CiscoOauthconnectionDto) txnAdapterConnection.getConnection()).getClientSecret());
                ciscoOauthconnectionDto.setScope(((CiscoOauthconnectionDto) txnAdapterConnection.getConnection()).getScope());
                ciscoOauthconnectionDto.setApplicationName(((CiscoOauthconnectionDto) txnAdapterConnection.getConnection()).getApplicationName());
                txnAdapterConnection.setConnection(ciscoOauthconnectionDto);
                break;
            case POP3:
                PopAdapterDto popAdapterDto = new PopAdapterDto();
                popAdapterDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                popAdapterDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                popAdapterDto.setHost(((PopAdapterDto) txnAdapterConnection.getConnection()).getHost());
                popAdapterDto.setPort(((PopAdapterDto) txnAdapterConnection.getConnection()).getPort());
                popAdapterDto.setStoreType(((PopAdapterDto) txnAdapterConnection.getConnection()).getStoreType());
                popAdapterDto.setPassword(((PopAdapterDto) txnAdapterConnection.getConnection()).getPassword());
                popAdapterDto.setUsername(((PopAdapterDto) txnAdapterConnection.getConnection()).getUsername());
                txnAdapterConnection.setConnection(popAdapterDto);
                break;
            case IMAP:
                ImapConnection imapConnection = new ImapConnection();
                imapConnection.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                imapConnection.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                imapConnection.setHost(((ImapConnection) txnAdapterConnection.getConnection()).getHost());
                imapConnection.setPort(((ImapConnection) txnAdapterConnection.getConnection()).getPort());
                imapConnection.setUsername(((ImapConnection) txnAdapterConnection.getConnection()).getUsername());
                imapConnection.setPassword(((ImapConnection) txnAdapterConnection.getConnection()).getPassword());
                txnAdapterConnection.setConnection(imapConnection);
                break;
            case JIRA:
                JiraAdapterConnectionDto jiraAdapterConnectionDto = new JiraAdapterConnectionDto();
                jiraAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                jiraAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                jiraAdapterConnectionDto.setAppId(((JiraAdapterConnectionDto) txnAdapterConnection.getConnection()).getAppId());
                jiraAdapterConnectionDto.setAppSecret(((JiraAdapterConnectionDto) txnAdapterConnection.getConnection()).getAppSecret());
                jiraAdapterConnectionDto.setScope(((JiraAdapterConnectionDto) txnAdapterConnection.getConnection()).getScope());
                txnAdapterConnection.setConnection(jiraAdapterConnectionDto);
                break;
            case TWITTER:
                TwitterAdapterConnectionDto twitterAdapterConnectionDto = new TwitterAdapterConnectionDto();
                twitterAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                twitterAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                txnAdapterConnection.setConnection(twitterAdapterConnectionDto);
                break;
            case SMTP:
                SmtpAdapterConnectionDto smtpAdapterConnectionDto = new SmtpAdapterConnectionDto();
                smtpAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                smtpAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                smtpAdapterConnectionDto.setHost(((SmtpAdapterConnectionDto) txnAdapterConnection.getConnection()).getHost());
                smtpAdapterConnectionDto.setPort(((SmtpAdapterConnectionDto) txnAdapterConnection.getConnection()).getPort());
                smtpAdapterConnectionDto.setPassword(((SmtpAdapterConnectionDto) txnAdapterConnection.getConnection()).getPassword());
                smtpAdapterConnectionDto.setUsername(((SmtpAdapterConnectionDto) txnAdapterConnection.getConnection()).getUsername());
                txnAdapterConnection.setConnection(smtpAdapterConnectionDto);
                break;
            case SFTP:
                SFTPAdapterConnectionDto sftpAdapterConnectionDto = new SFTPAdapterConnectionDto();
                sftpAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                sftpAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                sftpAdapterConnectionDto.setHost(((SFTPAdapterConnectionDto) txnAdapterConnection.getConnection()).getHost());
                sftpAdapterConnectionDto.setPort(((SFTPAdapterConnectionDto) txnAdapterConnection.getConnection()).getPort());
                sftpAdapterConnectionDto.setAuthentication(((SFTPAdapterConnectionDto) txnAdapterConnection.getConnection()).getAuthentication());
                txnAdapterConnection.setConnection(sftpAdapterConnectionDto);
                break;
            case ActiveMQ:
                ActiveMQAdapterConnectionDto activemqAdapterConnectionDto = new ActiveMQAdapterConnectionDto();
                activemqAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                activemqAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                activemqAdapterConnectionDto.setBrokerURL(((ActiveMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getBrokerURL());
                activemqAdapterConnectionDto.setAuthentication(((ActiveMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getAuthentication());
                txnAdapterConnection.setConnection(activemqAdapterConnectionDto);
                break;
            case RabbitMQ:
                RabbitMQAdapterConnectionDto rabbitMQAdapterConnectionDto = new RabbitMQAdapterConnectionDto();
                rabbitMQAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                rabbitMQAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                rabbitMQAdapterConnectionDto.setHostname(((RabbitMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getHostname());
                rabbitMQAdapterConnectionDto.setPortNumber(((RabbitMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getPortNumber());
                rabbitMQAdapterConnectionDto.setExchange(((RabbitMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getExchange());
                rabbitMQAdapterConnectionDto.setAutoDelete(((RabbitMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getAutoDelete());
                rabbitMQAdapterConnectionDto.setAuthentication(((RabbitMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getAuthentication());
                txnAdapterConnection.setConnection(rabbitMQAdapterConnectionDto);
                break;
            case IBMMQ:
                IBMMQAdapterConnectionDto ibmmqAdapterConnectionDto = new IBMMQAdapterConnectionDto();
                ibmmqAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                ibmmqAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                ibmmqAdapterConnectionDto.setHostname(((IBMMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getHostname());
                ibmmqAdapterConnectionDto.setPort(((IBMMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getPort());
                ibmmqAdapterConnectionDto.setQueueManager(((IBMMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getQueueManager());
                ibmmqAdapterConnectionDto.setChannel(((IBMMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getChannel());
                ibmmqAdapterConnectionDto.setAuthentication(((IBMMQAdapterConnectionDto) txnAdapterConnection.getConnection()).getAuthentication());
                txnAdapterConnection.setConnection(ibmmqAdapterConnectionDto);
                break;
            case DOCUSIGN:
                DocusignAdapterConnectionDto docusignAdapterConnectionDto = new DocusignAdapterConnectionDto();
                docusignAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                docusignAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                docusignAdapterConnectionDto.setAppId(((DocusignAdapterConnectionDto) txnAdapterConnection.getConnection()).getAppId());
                docusignAdapterConnectionDto.setAppSecret(((DocusignAdapterConnectionDto) txnAdapterConnection.getConnection()).getAppSecret());
                docusignAdapterConnectionDto.setAccountId(((DocusignAdapterConnectionDto) txnAdapterConnection.getConnection()).getAccountId());
                docusignAdapterConnectionDto.setScope(((DocusignAdapterConnectionDto) txnAdapterConnection.getConnection()).getScope());
                docusignAdapterConnectionDto.setEncodedKey(((DocusignAdapterConnectionDto) txnAdapterConnection.getConnection()).getEncodedKey());
                txnAdapterConnection.setConnection(docusignAdapterConnectionDto);
                break;
            case ADOBESIGN:
                AdobeSignAdapterConnectionDto adobesignAdapterConnectionDto = new AdobeSignAdapterConnectionDto();
                adobesignAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                adobesignAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                adobesignAdapterConnectionDto.setAppId(((AdobeSignAdapterConnectionDto) txnAdapterConnection.getConnection()).getAppId());
                adobesignAdapterConnectionDto.setAppSecret(((AdobeSignAdapterConnectionDto) txnAdapterConnection.getConnection()).getAppSecret());
                adobesignAdapterConnectionDto.setScope(((AdobeSignAdapterConnectionDto) txnAdapterConnection.getConnection()).getScope());
                txnAdapterConnection.setConnection(adobesignAdapterConnectionDto);
                break;
            case FHIR:
                FhirAdapterConnectionDto fhirAdapterConnectionDto = new FhirAdapterConnectionDto();
                fhirAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                fhirAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                fhirAdapterConnectionDto.setServerUrl(((FhirAdapterConnectionDto) txnAdapterConnection.getConnection()).getServerUrl());
                fhirAdapterConnectionDto.setAuthentication(((FhirAdapterConnectionDto) txnAdapterConnection.getConnection()).getAuthentication());
                txnAdapterConnection.setConnection(fhirAdapterConnectionDto);
                break;
            case FTP:
                FtpAdapterConnectionDto ftpAdapterConnectionDto = new FtpAdapterConnectionDto();
                ftpAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                ftpAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                ftpAdapterConnectionDto.setHost(((FtpAdapterConnectionDto) txnAdapterConnection.getConnection()).getHost());
                ftpAdapterConnectionDto.setPort(((FtpAdapterConnectionDto) txnAdapterConnection.getConnection()).getPort());
                ftpAdapterConnectionDto.setAuthentication(((FtpAdapterConnectionDto) txnAdapterConnection.getConnection()).getAuthentication());
                txnAdapterConnection.setConnection(ftpAdapterConnectionDto);
                break;
            case AS2:
                AS2AdapterConnectionDto as2AdapterConnectionDto = new AS2AdapterConnectionDto();
                as2AdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                as2AdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                as2AdapterConnectionDto.setTargetHostname(((AS2AdapterConnectionDto) txnAdapterConnection.getConnection()).getTargetHostname());
                as2AdapterConnectionDto.setTargetPortNumber(((AS2AdapterConnectionDto) txnAdapterConnection.getConnection()).getTargetPortNumber());
                as2AdapterConnectionDto.setRequestUri(((AS2AdapterConnectionDto) txnAdapterConnection.getConnection()).getRequestUri());
                txnAdapterConnection.setConnection(as2AdapterConnectionDto);
                break;
            case GRPC:
                GrpcAdapterConnectionDto grpcAdapterConnectionDto = new GrpcAdapterConnectionDto();
                grpcAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                grpcAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                grpcAdapterConnectionDto.setHost(((GrpcAdapterConnectionDto) txnAdapterConnection.getConnection()).getHost());
                grpcAdapterConnectionDto.setPort(((GrpcAdapterConnectionDto) txnAdapterConnection.getConnection()).getPort());
                grpcAdapterConnectionDto.setAuthentication(((GrpcAdapterConnectionDto) txnAdapterConnection.getConnection()).getAuthentication());
                txnAdapterConnection.setConnection(grpcAdapterConnectionDto);
                break;
            case JDBC:
                JdbcAdapterConnectionDto jdbcAdapterConnectionDto = new JdbcAdapterConnectionDto();
                jdbcAdapterConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                jdbcAdapterConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                jdbcAdapterConnectionDto.setDataSourceName(((JdbcAdapterConnectionDto) txnAdapterConnection.getConnection()).getDataSourceName());
                jdbcAdapterConnectionDto.setConnectionDetails(((JdbcAdapterConnectionDto) txnAdapterConnection.getConnection()).getConnectionDetails());
                txnAdapterConnection.setConnection(jdbcAdapterConnectionDto);
                break;
            case OPENAPI:
                OpenAPIConnectionDTO openAPIConnectionDTO = new OpenAPIConnectionDTO();
                openAPIConnectionDTO.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                openAPIConnectionDTO.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                openAPIConnectionDTO.setHost(((OpenAPIConnectionDTO) txnAdapterConnection.getConnection()).getHost());
                openAPIConnectionDTO.setOperation(((OpenAPIConnectionDTO) txnAdapterConnection.getConnection()).getOperation());
                openAPIConnectionDTO.setSpecificationUri(((OpenAPIConnectionDTO) txnAdapterConnection.getConnection()).getSpecificationUri());
                txnAdapterConnection.setConnection(openAPIConnectionDTO);
                break;
            case DB:
                DBConnectionDto dbConnectionDto = new DBConnectionDto();
                dbConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                dbConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                dbConnectionDto.setDb_type(((DBConnectionDto) txnAdapterConnection.getConnection()).getDb_type());
                dbConnectionDto.setDataSourceDriver(((DBConnectionDto) txnAdapterConnection.getConnection()).getDataSourceDriver());
                dbConnectionDto.setDataSourceUrl(((DBConnectionDto) txnAdapterConnection.getConnection()).getDataSourceUrl());
                dbConnectionDto.setUsername(((DBConnectionDto) txnAdapterConnection.getConnection()).getUsername());
                dbConnectionDto.setPassword(((DBConnectionDto) txnAdapterConnection.getConnection()).getPassword());
            case GRAPHQL:
                GraphQLConnectionDto graphQLConnectionDto = new GraphQLConnectionDto();
                graphQLConnectionDto.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                graphQLConnectionDto.setConnectionStatus(txnAdapterConnection.getConnection().getConnectionStatus());
                graphQLConnectionDto.setHost(((GraphQLConnectionDto) txnAdapterConnection.getConnection()).getHost());
                graphQLConnectionDto.setAuthentication(((GraphQLConnectionDto) txnAdapterConnection.getConnection()).getAuthentication());
                txnAdapterConnection.setConnection(graphQLConnectionDto);
                break;
            default:
                break;
        }
    }

    private void filterTxnGeRecord(AdapterType adapterType, TxnGeneralEntityRecord txnGeneralEntityRecord) {
        switch (adapterType){
            case REST:
                filterRestRecord(txnGeneralEntityRecord);
                break;
            default:
                break;
        }
    }
    private void filterRestRecord(TxnGeneralEntityRecord txnGeneralEntityRecord){
        for(TxnNslAttribute txnNslAttribute : txnGeneralEntityRecord.getTxnNslAttribute()){
            if (txnNslAttribute.getValues()==null || txnNslAttribute.getValues().isEmpty()){
                continue;
            }
            switch(txnNslAttribute.getName()){
                case "authentication":
                    RESTCredential cred = new RESTCredential();
                    cred.setAuthorizationType(RESTAuthorizationType.NONE);
                    txnNslAttribute.setValues(Collections.singletonList(JacksonUtils.toJson(cred)));
                    break;
                default:
                    break;
            }
        }
    }

    public Connection txnGERecordToConn(TxnGeneralEntityRecord txnGeneralEntityRecord){
        Connection connection =new Connection();
        List<TxnNslAttribute> txnNslAttributes = txnGeneralEntityRecord.getTxnNslAttribute();
        for(TxnNslAttribute txnNslAttribute : txnNslAttributes){
            if(txnNslAttribute.getName().equalsIgnoreCase("connectionName")){
                connection.setConnectionName(txnNslAttribute.getValues().get(0));
                break;
            }
        }
        if(connection.getConnectionName()!=null){
            connection.setConnectionId(txnGeneralEntityRecord.getId());
            connection.setGuId(txnGeneralEntityRecord.getGuid());
            connection.setConnectionData(Base64.getEncoder().encodeToString(JacksonUtils.toJson(txnGeneralEntityRecord).getBytes(StandardCharsets.UTF_8)));
            return connection;
        }
        return null;

    }

    public Connection getConnectionByName(AdapterType adapterType, String name){

        if (adapterType == null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_149", null, Locale.ENGLISH) ,null);

        ConnectionsType connectionType = ConnectionsType.valueOf(adapterType.getConnectionType());

        if (dynamoConnections.contains(connectionType)){
            ConnectionDtoType connectionDtoType = ConnectionDtoType.valueOf(connectionType.toString());
            TxnAdapterConnection txnAdapterConnection = adapterConnnectionsDao.getConnectionByName(
                    connectionDtoType , name, authBean);
            Connection connection = null;
            if (txnAdapterConnection!=null) {
                filterRecord(txnAdapterConnection);
                connection = new Connection();
                connection.setConnectionName(txnAdapterConnection.getConnection().getConnectionName());
                connection.setAdapterType(adapterType);
                connection.setSourceId(txnAdapterConnection.getRecordId());
                connection.setConnectionId(txnAdapterConnection.getRecordId());
                connection.setConnectionData(Base64.getEncoder().encodeToString(JacksonUtils.toJson(txnAdapterConnection).getBytes(StandardCharsets.UTF_8)));
            }
                return connection;
        }else{
            GeneralEntity generalEntity = adapterConnectionServiceV3.getGEByName(connectionType.getEntityName(), authBean);
            List<TxnGeneralEntityRecord> txnGeneralEntityRecord = adapterConnectionServiceV3.getConnByName(generalEntity,"="+name, authBean);
            if (txnGeneralEntityRecord.isEmpty())
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_88", null, Locale.ENGLISH),null);
            Connection connection = txnGERecordToConn(txnGeneralEntityRecord.get(0));
            if(connection!=null){
                connection.setConnectionId(txnGeneralEntityRecord.get(0).getId());
                connection.setAdapterType(adapterType);
            }
            return connection;
        }

    }


    public Connection createConnection(Connection connection) throws NSLException {
        try {
            ConnectionsType connectionType = ConnectionsType.valueOf(connection.getAdapterType().getConnectionType());
            if (dynamoConnections.contains(connectionType)){
                byte[] decodedBytes = Base64.getDecoder().decode(connection.getConnectionData());
                final String decodedString = new String(decodedBytes, StandardCharsets.UTF_8);
                JSONObject json = new JSONObject(decodedString);
                ConnectionDtoType connectionDtoType = ConnectionDtoType.valueOf(json.getString("connectionDtoType"));
                TxnAdapterConnection record = new TxnAdapterConnection();
                record.setConnectionDtoType(connectionDtoType);
                record.setRecordId(json.getLong("recordId"));
                record.setConnection(JacksonUtils.fromJson(json.getJSONObject("connection").toString(), connectionDtoType.getClassType()));
                record.getConnection().setConnectionName(connection.getConnectionName());
                filterSaveRecord(record);
                record = adapterConnnectionsDao.saveConnection(record, authBean);
                LOGGER.info("Entity Id {}", record.getRecordId());
                return connection;
            }else {
                GeneralEntity generalEntity = adapterConnectionServiceV3.getGEByName(connectionType.getEntityName(), authBean);

                if (!adapterConnectionServiceV3.getConnByName(generalEntity, "="+connection.getConnectionName(), authBean).isEmpty())
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_134", null, Locale.ENGLISH) , null);

                byte[] decodedBytes = Base64.getDecoder().decode(connection.getConnectionData());
                final String decodedString = new String(decodedBytes, StandardCharsets.UTF_8);
                TxnGeneralEntityRecord record = JacksonUtils.fromJson(decodedString, TxnGeneralEntityRecord.class);
                Map<String, TxnNslAttribute> attributeMap = new HashMap<>();
                for (TxnNslAttribute attribute : record.getTxnNslAttribute()){
                    if (AppConstants.CONNECTION_NAME.equals(attribute.getName())){
                        attribute.setValues(Collections.singletonList(connection.getConnectionName()));
                    }
                    attributeMap.put(attribute.getName(), attribute);
                }

                List<TxnNslAttribute> attributesList = new ArrayList<>();
                generalEntity.getNslAttributes().forEach(x -> {
                    TxnNslAttribute txnNslAttribute = new TxnNslAttribute();
                    txnNslAttribute.setName(x.getName());
                    txnNslAttribute.setNslAttributeID(x.getId());
                    txnNslAttribute.setValues(attributeMap.containsKey(x.getName())?attributeMap.get(x.getName()).getValues(): new ArrayList<>());
                    attributesList.add(txnNslAttribute);
                });

                TxnGeneralEntityRecord entityRecord = new TxnGeneralEntityRecord();  //Entity Record --> Attributes
                entityRecord.setTxnNslAttribute(attributesList);
                entityRecord.setId(connection.getConnectionId());
                entityRecord.setGuid(connection.getGuId());
                List<TxnGeneralEntityRecord> entityRecordList = new ArrayList<>();
                entityRecordList.add(entityRecord);

                entityRecord = adapterConnectionServiceV3.saveEntityRecord(entityRecordList,generalEntity, authBean,"create");
                LOGGER.info("Entity Id {}", entityRecord.getId());
                if (!Objects.equals(entityRecord.getId(), connection.getConnectionId())){
                    return null;
                }
                return connection;
            }
        } catch (Exception e) {
            LOGGER.error("Exception while creating dummy connection", e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, e.getMessage(),
                    ExceptionSeverity.MINOR, e);
        }
    }

    private void filterSaveRecord(TxnAdapterConnection record) throws NSLException {
        switch (record.getConnectionDtoType()){
            case AIML:
                try {
                    HttpHeaders headers = new HttpHeaders();
                    headers.add(HttpHeaders.ACCEPT_LANGUAGE, "en");
                    headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + authBean.getAuthToken());
                    if (authBean.isSystemUser()) {
                        headers.add("systemUserDetails", authBean.getTenantId().concat(":").concat(authBean.getEmailId()));
                    }
                    AiMlConnectionDto aiMlConnectionDto = (AiMlConnectionDto) record.getConnection();
                    String datasetkey = aiMlConnectionDto.getDatasetKey();
                    String sourceKey = datasetkey;
                    String[] keys = datasetkey.split("/");
                    Map<String, String> params =new HashMap<>();
                    keys[1] = envName;
                    keys[2] = authBean.getTenantId();
                    keys[3] = aiMlConnectionDto.getConnectionName();
                    datasetkey = String.join("/", keys);
                    String destinationKey = datasetkey;

                    params.put("destinationPrefix",destinationKey);
                    params.put("sourcePrefix",sourceKey);
                    if (LOGGER.isInfoEnabled()) {
                        LOGGER.info("is systemuser {}", authBean.isSystemUser());
                        LOGGER.info("this is the body {}", params);
                        LOGGER.info("headers - {}", headers);
                    }
                    HttpEntity<Object> request = new HttpEntity<>(params,headers);
                    ResponseEntity<JsonNode> result = restTemplate.exchange(s3CopyConnectionUrl, HttpMethod.POST, request, JsonNode.class);
                    aiMlConnectionDto.setDatasetKey(datasetkey);
                    record.setConnection(aiMlConnectionDto);
                }
            catch(Exception e){
                LOGGER.error("Exception while copying connection", e);
                throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, e.getMessage(),
                        ExceptionSeverity.MINOR, e);

            }
                break;
            default:
                break;
        }
    }

    private String getDummyValue(NslAttribute x, String connectionName) {
        if (x.getName().equalsIgnoreCase("connectionName")) {
            return connectionName;
        } else if (x.getAttributeType().getType().getName().equalsIgnoreCase("number"))
            return "0";
        return "dummy";
    }

}
