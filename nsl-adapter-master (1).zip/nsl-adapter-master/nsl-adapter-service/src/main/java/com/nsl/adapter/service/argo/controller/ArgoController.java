package com.nsl.adapter.service.argo.controller;

import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.argo.service.ArgoConnectionService;
import com.nsl.adapter.service.argo.service.ArgoSchedulerService;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Locale;

import static com.nsl.common.constant.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/argo")
public class ArgoController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ArgoController.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    ArgoConnectionService argoConnectionService;

    @Autowired
    MessageSource messageSource;

    @Autowired
    ArgoSchedulerService argoSchedulerService;

    @DeleteMapping(value = "/delete")
    public ApiResponse deleteUnwantedJobs() {
        List<String> unwantedJobs =argoConnectionService.getUnwantedJobs(authBean);
        for(String job:unwantedJobs){
            try {
                argoSchedulerService.deleteJob(job);
            } catch (Exception e) {
                LOGGER.error("Exception while deleting job : " +job, e);
            }
        }
        argoConnectionService.deleteJobs(unwantedJobs,authBean);
        return new ApiResponse(HttpStatus.OK, SUCCESS, messageSource.getMessage("Paas_Adapter_113", null, Locale.ENGLISH));
    }

}
