package com.nsl.adapter.service.service;

import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.service.db.service.IntegrationService.MYSQLIntegrationService;
import com.nsl.adapter.service.db.service.IntegrationService.POSTGRESSIntegrationService;
import com.nsl.adapter.service.db.service.IntegrationService.SQLSERVERIntegrationService;
import com.nsl.adapter.service.mft.MFTIntegrationService;
import com.nsl.adapter.service.db.service.IntegrationService.MongoDBIntegrationService;
import com.nsl.adapter.service.gdrive.serviceimpl.GdriveIntegrationService;
import com.nsl.adapter.service.inboundcu.service.RestInboundIntegrationService;
import com.nsl.adapter.service.kafka.service.KafkaIntegrationService;
import com.nsl.adapter.service.mqtt.service.MQTTIntegrationService;
import com.nsl.adapter.service.onedrive.service.OnedriveIntegartionService;
import com.nsl.adapter.service.s3.service.S3IntegrationService;
import com.nsl.adapter.service.sftp.service.SFTPIntegrationService;
import com.nsl.adapter.service.webhook.WebHookIntegrationService;
import com.nsl.integration.activemq.MQIntegrationService;
import com.nsl.integration.as2.As2IntegrationService;
import com.nsl.integration.fhir.FhirIntegrationService;
import com.nsl.integration.ftp.FtpIntegrationService;
import com.nsl.integration.googleSheets.GoogleSheetsIntegrationService;
import com.nsl.integration.graphql.GraphqlIntegrationService;
import com.nsl.integration.grpc.GrpcIntegrationService;
import com.nsl.integration.jdbc.JdbcIntegrationService;
import com.nsl.integration.openapi.OpenAPIIntegrationService;
import com.nsl.integration.soap.SoapIntegrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdapterIntegrationFactory {

    @Autowired
    S3IntegrationService s3IntegrationService;

    @Autowired
    RestInboundIntegrationService restInboundIntegrationService;

    @Autowired
    SFTPIntegrationService sftpIntegrationService;

    @Autowired
    KafkaIntegrationService kafkaIntegrationService;

    @Autowired
    GdriveIntegrationService gdriveIntegrationService;

    @Autowired
    WebHookIntegrationService webHookIntegrationService;

    @Autowired
    MongoDBIntegrationService mongoDBIntegrationService;

    @Autowired
    MFTIntegrationService mftIntegrationService;

    @Autowired
    SoapIntegrationService soapIntegrationService;

    @Autowired
    MQIntegrationService mqIntegrationService;

    @Autowired
    FhirIntegrationService fhirIntegrationService;

    @Autowired
    FtpIntegrationService ftpIntegrationService;

    @Autowired
    OnedriveIntegartionService onedriveIntegartionService;

    @Autowired
    POSTGRESSIntegrationService postgressIntegrationService;

    @Autowired
    MYSQLIntegrationService mysqlIntegrationService;
    @Autowired
    SQLSERVERIntegrationService sqlserverIntegrationService;

    @Autowired
    As2IntegrationService as2IntegrationService;

    @Autowired
    GrpcIntegrationService grpcIntegrationService;

    @Autowired
    JdbcIntegrationService jdbcIntegrationService;


    @Autowired
    OpenAPIIntegrationService openAPIIntegrationService;

    @Autowired
    GraphqlIntegrationService graphqlIntegrationService;

    @Autowired
    GoogleSheetsIntegrationService googleSheetsIntegrationService;

    @Autowired
    MQTTIntegrationService mqttIntegrationService;

    public IntegrationService getIntegrationService(AdapterType adapterType){
        switch (adapterType){
            case S3:
                return s3IntegrationService;
            case RESTINBOUND:
                return restInboundIntegrationService;
            case SFTP:
                return sftpIntegrationService;
            case KAFKA:
                return kafkaIntegrationService;
            case GDRIVE:
                return gdriveIntegrationService;
            case MONGODB:
                return mongoDBIntegrationService;
            case ONEDRIVE:
                return onedriveIntegartionService;
            case WEBHOOK:
                return webHookIntegrationService;
            case MFT:
                return mftIntegrationService;
            case SOAP:
                return soapIntegrationService;
            case ACTIVEMQ,IBMMQ,RABBITMQ:
                return mqIntegrationService;
            case FHIR:
                return fhirIntegrationService;
            case FTP, FTPS:
                return ftpIntegrationService;
            case AS2:
                return as2IntegrationService;
            case GRPC:
                return grpcIntegrationService;
            case POSTGRESS:
                return postgressIntegrationService;
            case MYSQL:
                return mysqlIntegrationService;
            case SQLSERVER:
                return sqlserverIntegrationService;
            case JDBC:
                return jdbcIntegrationService;
            case OPENAPI:
                return openAPIIntegrationService;
            case GRAPHQL:
                return graphqlIntegrationService;
            case GOOGLE_SHEETS:
                return googleSheetsIntegrationService;
            case MQTT:
                return mqttIntegrationService;
            default:
                return null;
        }
    }
}
