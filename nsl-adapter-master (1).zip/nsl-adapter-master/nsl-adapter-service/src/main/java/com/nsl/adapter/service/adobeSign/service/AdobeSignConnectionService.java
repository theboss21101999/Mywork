package com.nsl.adapter.service.adobeSign.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.commons.dto.connections.AdobeSignAdapterConnectionDto;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import javax.annotation.Resource;
import java.util.Locale;


@Service
public class AdobeSignConnectionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AdobeSignConnectionService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    MessageSource messageSource;

    public TxnAdapterConnection saveAdobeSignConnection(AdobeSignAdapterConnectionDto connectionDto) {

        if (connectionDto.getAppId() == null || connectionDto.getAppSecret() == null ||
                connectionDto.getConnectionName() == null
                ||adapterConnnectionsDao.getConnectionByName(ConnectionDtoType.ADOBESIGN, connectionDto.getConnectionName(), authBean)!=null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_182", null, Locale.ENGLISH) , null);
        }

        connectionDataToolsV3.connectionCheck(ConnectionDtoType.ADOBESIGN,connectionDto.getConnectionName(),authBean);

        connectionDto.setAppSecret(connectionDataToolsV3.saveSecret(ConnectionDtoType.ADOBESIGN, "appSecret",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getAppSecret()));
        connectionDto.setRefreshToken(connectionDataToolsV3.saveSecret(ConnectionDtoType.ADOBESIGN, "refreshToken",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getRefreshToken()));

        LOGGER.info("saving ADOBESIGN connection");
        TxnAdapterConnection result = new TxnAdapterConnection();
        result.setConnectionDtoType(ConnectionDtoType.ADOBESIGN);
        result.setConnection(connectionDto);
        result = adapterConnnectionsDao.saveConnection(result, authBean);
        return result;
    }

    public AdobeSignAdapterConnectionDto getAdobeSignConnection(Long id, boolean hide) {
        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.ADOBESIGN, id, authBean);
        if (previousConnection==null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }
        return txnToAdobeSignDto(previousConnection, hide);
    }

    public TxnAdapterConnection updateAdobeSignConnection(Long id, AdobeSignAdapterConnectionDto connectionDto) {
        if (connectionDto.getScope() == null || connectionDto.getAppId() == null ||
                connectionDto.getConnectionName() == null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.ADOBESIGN, id, authBean);
        connectionDataToolsV3.connectionNameCheck(previousConnection,connectionDto.getConnectionName());

//        if (connectionDto.getAppId()!=null){
//            connectionDto.setAppId(connectionDto.getAppId());
//        }

        if (connectionDto.getAppSecret()!=null){
            connectionDto.setAppSecret(connectionDataToolsV3.updateSecret(ConnectionDtoType.ADOBESIGN, "appSecret",
                    connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getAppSecret()));
        }

        if (connectionDto.getRefreshToken()!=null){
            connectionDto.setRefreshToken(connectionDataToolsV3.updateSecret(ConnectionDtoType.ADOBESIGN, "refreshToken",
                    connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getRefreshToken()));
        }

        previousConnection.setConnection(connectionDto);
        LOGGER.info("update ADOBE connection");

        return adapterConnnectionsDao.saveConnection(previousConnection, authBean);
    }

    public AdobeSignAdapterConnectionDto txnToAdobeSignDto(TxnAdapterConnection adapterConnection, boolean hide) {
        if (adapterConnection==null){
            return null;
        }
        AdobeSignAdapterConnectionDto dto = (AdobeSignAdapterConnectionDto) adapterConnection.getConnection();
        if (!hide){
            dto.setAppSecret(connectionDataToolsV3.getSecret(dto.getAppSecret()));
            dto.setRefreshToken(connectionDataToolsV3.getSecret(dto.getRefreshToken()));
        }
        dto.getMetadata().put("dsdId",String.valueOf(adapterConnection.getRecordId()));
        return dto;
    }
}
