package com.nsl.adapter.service.kafka.utils;

import com.nsl.adapter.service.kafka.enums.KafkaParserType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class KafkaParserFactory {
    
    @Autowired
    KafkaJSONParser kafkaJSONParser;

    public KafkaParser createEntity(KafkaParserType dataType){
        switch (dataType) {
            case JSON:
                return kafkaJSONParser;
        }
        return null;
    }
}
