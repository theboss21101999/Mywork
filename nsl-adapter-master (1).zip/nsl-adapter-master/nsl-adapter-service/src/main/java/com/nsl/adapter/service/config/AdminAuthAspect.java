package com.nsl.adapter.service.config;

import com.nsl.common.utils.B2CUserUtil;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.Role;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import javax.annotation.Resource;
import java.util.Locale;

@Aspect
@Component
public class AdminAuthAspect {

    @Autowired
    MessageSource messageSource;

    private static final String ADAPTER_DESIGNER = "adapterDesigner";

    @Resource(name = "requestScopedAuthenticatedUserBean")
    private AuthenticatedUserDetailsImpl userDetails;

    @Pointcut("within(@AdminAuth *)")
    public void checkAdminAuthPC() {
        //Declaration of below method to enable annotation at class level
    }

    @Around("checkAdminAuthPC()")
    public Object checkAdminAuth(ProceedingJoinPoint joinPoint) throws Throwable {

        boolean isAdapterDesigner = false;
        for(Role role : userDetails.getRoles()){
            if (ADAPTER_DESIGNER.equals(role.getName())){
                isAdapterDesigner = true;
                break;
            }
        }

        if(!(userDetails.isSystemAdmin() || isAdapterDesigner) && !B2CUserUtil.isB2CSocialUser(userDetails.getTenantId()))
            throw new NSLException(ErrorType.UNAUTHORIZED,
                    ExceptionCategory.ACCESS_PERMISSION, messageSource.getMessage("Paas_Adapter_114", null, Locale.ENGLISH), null);

        return joinPoint.proceed();
    }
}
