package com.nsl.adapter.service.keymanager.enums;

public enum KmsType {
    SSHKEY,
    SSLCERTIFICATE,
    ENCRYPTIONKEY,
    KEY
}
