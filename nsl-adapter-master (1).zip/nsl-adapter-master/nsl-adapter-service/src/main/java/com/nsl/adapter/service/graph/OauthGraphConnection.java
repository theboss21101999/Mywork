package com.nsl.adapter.service.graph;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl;
import com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest;
import com.google.api.client.auth.oauth2.RefreshTokenRequest;
import com.google.api.client.auth.oauth2.TokenRequest;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.http.BasicAuthentication;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.nsl.adapter.commons.dto.connections.GraphOauthConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.graph.service.GraphConnectionService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.adapter.service.v2.utills.RedisIntegration;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.PersonalConnectionDao;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.PersonalConnection;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import static com.nsl.adapter.service.graph.utils.GraphConstants.*;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class OauthGraphConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(OauthGraphConnection.class);

    @Autowired
    RedisIntegration redisIntegration;

    @Autowired
    GraphConnectionService graphConnectionService;

    @Autowired
    CdmUtils cdmUtils;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    AdaptorProperties adaptorProperties;

    @Autowired
    MessageSource messageSource;

    @Autowired
    PersonalConnectionDao personalConnectionDao;

    Base64.Encoder encoder = Base64.getEncoder();

    public String getStateParam(Long connId, String connName, String tenantId) {
        Map<String, Object> valueMap = new HashMap<>();
        valueMap.put(AppConstant.CONFIG_ENTITY_RECORD_ID, connId.toString());
        valueMap.put(AppConstant.ADAPTER, GRAPH);
        valueMap.put(AppConstant.TENANTID, tenantId);
        valueMap.put(AppConstant.ENV_NAME ,cdmUtils.getEnvironmentNameByTenantId(tenantId));
        valueMap.put(AppConstant.CONNECTION_NAME, connName);
        return encodeData(Objects.requireNonNull(JacksonUtils.toJson(valueMap)));
    }

    public JSONObject getAuthorizationCode(GraphOauthConnectionDto connectionDto,
                                           TxnAdapterConnection result) throws NSLException {

        LOGGER.info("generating redirect url ..");
        try {
            AuthorizationCodeRequestUrl url = new AuthorizationCodeRequestUrl("https://login.microsoftonline.com/" + connectionDto.getTenantId() + "/oauth2/v2.0/authorize",
                                                                                        connectionDto.getClientId());
            url.setRedirectUri(adaptorProperties.getRedirectUrl()).setScopes(connectionDto.getScope())
                        .set(GRANT_TYPE, AUTHORIZATION_CODE).set(ACCESS_TYPE, OFFLINE)
                                                              .setResponseTypes(Collections.singleton(CODE));

            String stateParams = getStateParam(result.getRecordId(), connectionDto.getConnectionName(), bean.getTenantId());

            LOGGER.info("appending state params to redirect url {} ", stateParams);
            url.set(STATE, stateParams);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put(AppConstant.RESULT, result);
            jsonObject.put(Url, url.build());

            return jsonObject;
        }catch (Exception e){
            LOGGER.error("exception occurred during generating redirect url");
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_128", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER);
        }
    }

    public TxnAdapterConnection getRefreshToken(Long id) throws NSLException {

        String cacheName = GRAPH + "_" + bean.getTenantId();
        String code = redisIntegration.getOAuthCode(cacheName, id.toString());
        try {
            GraphOauthConnectionDto connectionDto = graphConnectionService.getGraphConnection(id,false);

            connectionDto.setRefreshToken(getRefreshToken(connectionDto, code));
            return graphConnectionService.updateGraphConnection(id,connectionDto);

        }catch(Exception e){
            LOGGER.error("failed to generate refresh Token {0}" ,e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_142", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER ,e);
        }
    }

    public String getRefreshToken(GraphOauthConnectionDto connectionDto, String code) throws IOException {
        TokenRequest request = new AuthorizationCodeTokenRequest(new NetHttpTransport(), new JacksonFactory(),
                new GenericUrl(GRAPH_REFRESH_TOKEN), code)
                .setRedirectUri(adaptorProperties.getRedirectUrl())
                .setGrantType(AUTHORIZATION_CODE)
                .setClientAuthentication(
                        new BasicAuthentication(connectionDto.getClientId(), connectionDto.getClientSecret()));

        TokenResponse response = request.execute();
        return response.getRefreshToken();
    }

    public String getAccessToken(Long connectionId) throws NSLException {

        GraphOauthConnectionDto connectionDto = graphConnectionService.getGraphConnection(connectionId,false);
        TokenResponse response;
        LOGGER.info("generating access token..");
        try {
            TokenRequest request = new RefreshTokenRequest(new NetHttpTransport(), new JacksonFactory(),
                    new GenericUrl(GRAPH_REFRESH_TOKEN), connectionDto.getRefreshToken());
            request.setClientAuthentication(new BasicAuthentication(connectionDto.getClientId(),
                    connectionDto.getClientSecret())).setGrantType(REFRESH_TOKEN);
            response = request.execute();
        }catch(Exception e){
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    messageSource.getMessage("Paas_Adapter_146", null, Locale.ENGLISH), ExceptionSeverity.BLOCKER ,e);
        }
        return response.getAccessToken();

    }

    public String getAccessToken() throws NSLException {

        TokenResponse response;
        LOGGER.info("generating access token..");
        try {
            PersonalConnection adminconnection = personalConnectionDao.getTenantConnection(bean.getTenantId(), AdapterType.MSTEAMS.toString());
            if (adminconnection==null){
                throw new NSLException(ExceptionCategory.ACCESS_PERMISSION, ExceptionSeverity.BLOCKER, "No client keys present. Please contact Tenant Admin to configure client keys.", null);
            }
            ObjectMapper mapper = new ObjectMapper();
            JsonNode adminNode = mapper.readTree(adminconnection.getConnectionDto());
            PersonalConnection userconnection = personalConnectionDao.getConnection(bean.getUserId(),bean.getTenantId(), AdapterType.MSTEAMS.toString());
            if (userconnection==null){
                throw new NSLException(ExceptionCategory.ACCESS_PERMISSION, ExceptionSeverity.CRITICAL, "Personal connection not created. Please navigate to profile and create.", null);
            }
            JsonNode userNode = mapper.readTree(userconnection.getConnectionDto());
            TokenRequest request = new RefreshTokenRequest(new NetHttpTransport(), new JacksonFactory(),
                    new GenericUrl(GRAPH_REFRESH_TOKEN), userNode.get("refreshToken").asText());
            request.setClientAuthentication(new BasicAuthentication(adminNode.get("clientId").asText(),
                    adminNode.get("clientSecret").asText())).setGrantType(REFRESH_TOKEN);
            response = request.execute();
        }catch(Exception e){
            LOGGER.error("failed to generate access token :" + e.getMessage());
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,messageSource.getMessage("Paas_Adapter_145", null, Locale.ENGLISH)
                    , ExceptionSeverity.BLOCKER ,e);
        }
        return response.getAccessToken();

    }

    private String encodeData(String value){
        return encoder.encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

}
