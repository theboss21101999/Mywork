package com.nsl.adapter.service.onedrive.service;

import com.nsl.adapter.service.exception.AdapterException;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import org.springframework.boot.configurationprocessor.json.JSONException;
import java.io.IOException;

public interface OnedriveReservedCUService {
    TxnData reservedCUService(TriggerCU triggerCu, TxnData transData) throws IOException, JSONException, NSLException, AdapterException;

}
