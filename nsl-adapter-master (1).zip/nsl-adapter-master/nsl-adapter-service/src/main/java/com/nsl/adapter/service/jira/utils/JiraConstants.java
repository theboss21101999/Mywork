package com.nsl.adapter.service.jira.utils;
public final class JiraConstants {

    public static final String REFRESH_TOKEN="refresh_token";

    public static final String ACCESS_TOKEN="access_token";
    public static final String JIRA = "Jira";



    public static final String JIRA_AUTH_TOKEN = "https://auth.atlassian.com/authorize";
    public static final String JIRA_ACCESS_TOKEN ="https://auth.atlassian.com/oauth/token";


    public static final String PROMPT="prompt";


    public static final String CONSENT="consent";

    public static final String ACCESS_TYPE="access_type";


    public static final String GRANT_TYPE="grant_type";

    public static final String OFFLINE="offline";
    public static final String CODE="code";
    public static final String STATE="state";
    public static final String Url="url";
    public static final String AUTHORIZATION_CODE="authorization_code";




    private JiraConstants(){
        throw new IllegalStateException("utility class");
    }
}

