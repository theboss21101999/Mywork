package com.nsl.adapter.service.db.service;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.dto.connections.DBConnectionDto;
import com.nsl.adapter.service.utils.ExtSolutionUtil;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Service
public class MYSQLDBOperations extends DBOperations {
    private static final Logger LOGGER = LoggerFactory.getLogger(MYSQLDBOperations.class);
    @Autowired
    ExtSolutionUtil extSolutionUtil;
    public TxnData getTable(DBConnectionDto connectionDto, String query, TriggerCU triggerCu) {
        JsonNode jsonNode = getJsonNode(connectionDto, query);
        return extSolutionUtil.OutputtoEntityMapping(triggerCu, jsonNode);
    }
    public JsonNode getJsonNode(DBConnectionDto connectionDto, String query) {
        Connection con = null;
        Statement statement = null;
        try {
            Class.forName(connectionDto.getDataSourceDriver());
            con = DriverManager.getConnection(connectionDto.getDataSourceUrl(),
                    connectionDto.getUsername(), connectionDto.getPassword());
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query); //NOSONAR
            ResultSetMetaData md = rs.getMetaData();
            int col = md.getColumnCount();
            List<Map<String, Object>> result = new ArrayList<>();
            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                for (int i = 1; i <= col; i++) {
                    if (md.getColumnTypeName(i).equals("INT"))
                        row.put(md.getColumnName(i), rs.getInt(i));
                    else if (md.getColumnTypeName(i).equals("VARCHAR"))
                        row.put(md.getColumnName(i), rs.getString(i));
                }
                result.add(row);
            }
            System.out.println(result);
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.convertValue(result, JsonNode.class);
        } catch (SQLException | ClassNotFoundException ignored) {
            System.out.println(ignored);
        } finally {
            try {
                assert statement != null;   //NOSONAR
                statement.close();
            } catch (Exception ignored) {
                LOGGER.error(ignored.toString());
            }
            try {
                con.close();
            } catch (Exception ignored) {
                LOGGER.error(ignored.toString());
            }
        }
        return null;
    }
    public TxnData updateTable(DBConnectionDto connectionDto, JSONObject transObject, TriggerCU triggerCu) {
        Connection con = null;
        Statement statement = null;
        try {
            Class.forName(connectionDto.getDataSourceDriver());
            con = DriverManager.getConnection(connectionDto.getDataSourceUrl(),
                    connectionDto.getUsername(), connectionDto.getPassword());
            con.setAutoCommit(false);
            String tableName = triggerCu.getCuSystemProperties().get("tableName");
            Statement st = con.createStatement();
            String columnquery = "SELECT column_name, data_type FROM information_schema.columns WHERE table_name='" + tableName + "'";
            ResultSet rs1 = st.executeQuery(columnquery); //NOSONAR
            Map<String, String> cmap = new HashMap<>();
            Map<String, Integer> cnumber = new HashMap<>();
            Map<Integer, String> rev_cnumber = new HashMap<>();
            int c = 1;
            while (rs1.next()) {
                cmap.put(rs1.getString(1), rs1.getString(2));
                cnumber.put(rs1.getString(1), c);
                rev_cnumber.put(c,rs1.getString(1));
                c++;
            }
            List<String> resultInputBuilder = getQueryBuilderValues(cmap,rev_cnumber);
            String newquery = "insert into " + tableName + " " + resultInputBuilder.get(0) + " values " + resultInputBuilder.get(1);
            PreparedStatement preparedStatement = con.prepareStatement(newquery);  //NOSONAR
           SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());

            for (Map.Entry<String, String> entry : cmap.entrySet()) {
                if (entry.getValue().contains("int")) {
                    preparedStatement.setInt(cnumber.get(entry.getKey()), transObject.optInt(entry.getKey()));
                } else if (entry.getValue().contains("varchar")) {
                    preparedStatement.setString(cnumber.get(entry.getKey()), transObject.optString(entry.getKey()));
                } else if (entry.getValue().contains("timestamp")) {
                    preparedStatement.setString(cnumber.get(entry.getKey()),sdf.format(timestamp));
                }
            }
            int rs = 0;
            try {
                rs = preparedStatement.executeUpdate();
            } catch (Exception e) {
                String result1 = e.toString();
                return mapStringtoOutput(result1, triggerCu);
            }
            String result = (new StringBuilder()).append(rs).append(" row/s affected").toString();
            return mapStringtoOutput(result, triggerCu);
        } catch (SQLException | ClassNotFoundException ignored) {
            System.out.println(ignored);
        } finally {
            try {
                assert statement != null;  //NOSONAR
                statement.close();
            } catch (Exception ignored) {
                LOGGER.error(ignored.toString());
            }
            try {
                con.commit();
                con.close();
            } catch (Exception ignored) {
                LOGGER.error(ignored.toString());
            }
        }
        return null;
    }
    public TxnData mapStringtoOutput(String result, TriggerCU triggerCu) {
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, String> map = new HashMap<>();
        map.put("result", result);
        JsonNode jsonNode = objectMapper.convertValue(map, JsonNode.class);
        return extSolutionUtil.OutputtoEntityMapping(triggerCu, jsonNode);
    }
    public List<String> getQueryBuilderValues(Map<String, String> cmap,Map<Integer, String> rev_cnumber) {
        String input = "(";
        String inputValues = "(";
        StringBuilder inputBuilder = new StringBuilder(input);
        StringBuilder inputValuesBuilder = new StringBuilder(inputValues);
        for (int i=0;i<rev_cnumber.size();i++) {
            inputBuilder.append(rev_cnumber.get(i+1));
            inputBuilder.append(",");
            inputValuesBuilder.append("?");
            inputValuesBuilder.append(",");
        }
        inputBuilder.setCharAt(inputBuilder.length() - 1, ')');
        inputValuesBuilder.setCharAt(inputValuesBuilder.length() - 1, ')');
        List<String> result = new ArrayList<>();
        result.add(inputBuilder.toString());
        result.add(inputValuesBuilder.toString());
        return result;
    }
}