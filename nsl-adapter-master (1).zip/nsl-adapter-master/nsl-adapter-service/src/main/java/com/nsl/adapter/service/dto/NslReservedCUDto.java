package com.nsl.adapter.service.dto;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.http.HttpMethod;
import java.util.ArrayList;
import java.util.List;

public class NslReservedCUDto {

    private String endpointURL;
    private ObjectNode headers;
    private HttpMethod httpMethod;
    private TenantChangeUnitInput changeUnit;
    private List<TenantCUEntityInput> entities = new ArrayList<>();
    private boolean isAuthenticated;
    private boolean isTemplatedApi;
    private String inputTemplate;
    private List<SecurityScheme> securityScheme;
    private JsonNode entityInfo;

    public NslReservedCUDto() {
    }

    public NslReservedCUDto(String endpointURL, ObjectNode headers, HttpMethod httpMethod, TenantChangeUnitInput changeUnit, List<TenantCUEntityInput> entities, boolean isAuthenticated, boolean isTemplatedApi, String inputTemplate, List<SecurityScheme> securityScheme, JsonNode entityInfo) {
        this.endpointURL = endpointURL;
        this.headers = headers;
        this.httpMethod = httpMethod;
        this.changeUnit = changeUnit;
        this.entities = entities;
        this.isAuthenticated = isAuthenticated;
        this.isTemplatedApi = isTemplatedApi;
        this.inputTemplate = inputTemplate;
        this.securityScheme = securityScheme;
        this.entityInfo = entityInfo;
    }

    public String getEndpointURL() {
        return endpointURL;
    }

    public void setEndpointURL(String endpointURL) {
        this.endpointURL = endpointURL;
    }

    public ObjectNode getHeaders() {
        return headers;
    }

    public void setHeaders(ObjectNode headers) {
        this.headers = headers;
    }

    public HttpMethod getHttpMethod() {
        return httpMethod;
    }

    public void setHttpMethod(HttpMethod httpMethod) {
        this.httpMethod = httpMethod;
    }

    public TenantChangeUnitInput getChangeUnit() {
        return changeUnit;
    }

    public void setChangeUnit(TenantChangeUnitInput changeUnit) {
        this.changeUnit = changeUnit;
    }

    public List<TenantCUEntityInput> getEntities() {
        return entities;
    }

    public void setEntities(List<TenantCUEntityInput> entities) {
        this.entities = entities;
    }

    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    public void setAuthenticated(boolean authenticated) {
        isAuthenticated = authenticated;
    }

    public boolean isTemplatedApi() {
        return isTemplatedApi;
    }

    public void setTemplatedApi(boolean templatedApi) {
        isTemplatedApi = templatedApi;
    }

    public String getInputTemplate() {
        return inputTemplate;
    }

    public void setInputTemplate(String inputTemplate) {
        this.inputTemplate = inputTemplate;
    }

    public List<SecurityScheme> getSecurityScheme() {
        return securityScheme;
    }

    public void setSecurityScheme(List<SecurityScheme> securityScheme) {
        this.securityScheme = securityScheme;
    }

    public JsonNode getEntityInfo() {
        return entityInfo;
    }

    public void setEntityInfo(JsonNode entityInfo) {
        this.entityInfo = entityInfo;
    }
}
