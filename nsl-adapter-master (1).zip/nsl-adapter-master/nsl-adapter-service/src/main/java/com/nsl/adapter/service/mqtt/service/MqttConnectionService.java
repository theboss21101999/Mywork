package com.nsl.adapter.service.mqtt.service;

import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.commons.dto.connections.MqttConnectionDto;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.List;

@Service
public class MqttConnectionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MqttConnectionService.class);

    private static final ConnectionsType connType = ConnectionsType.MQTT;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnectionServiceV3 adapterConnectionServiceV3;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;


    public TxnGeneralEntityRecord saveMqttConnection(MqttConnectionDto connectionDto) {

        if (connectionDto.getUsername() == null || connectionDto.getPassword() == null ||
                connectionDto.getHost() == null || connectionDto.getPort() == 0 ||
                connectionDto.getConnectionName() == null || connectionDto.getTopic()==null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "invalid input" , null);

        LOGGER.info("saving MQTT connection");
        TxnGeneralEntityRecord result =  adapterConnectionServiceV3.saveConnection(connType.getEntityName() ,
                JacksonUtils.getValueToTree(connectionDto),authBean );
        if (result == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "failed to create connection" , null);

        return result;
    }


    public MqttConnectionDto getMqttConnection(Long id, boolean hide){

        TxnGeneralEntityRecord txnGeneralEntityRecord = adapterConnectionServiceV3.getConnById(connType.getEntityName(), id ,authBean);
        return txnToMqtt(txnGeneralEntityRecord, hide);
    }

    public TxnGeneralEntityRecord updateMqttConnection(MqttConnectionDto connectionDto, Long connId) {

        if (connectionDto.getUsername() == null || connectionDto.getPassword() == null ||
                connectionDto.getHost() == null || connectionDto.getPort() == 0 ||
                connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "invalid input" , null);

        LOGGER.info("update MQTT connection");
        TxnGeneralEntityRecord result =  adapterConnectionServiceV3.updateConnection(connType.getEntityName() ,
                JacksonUtils.getValueToTree(connectionDto),connId,authBean );
        if (result == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , "failed to update connection" , null);

        return result;
    }

    public MqttConnectionDto txnToMqtt(TxnGeneralEntityRecord record, boolean hide) {
        MqttConnectionDto result = new MqttConnectionDto();
        List<TxnNslAttribute> attributesList = record.getTxnNslAttribute();
        for(TxnNslAttribute attribute : attributesList){
            String value = attribute.getValues().get(0);
            switch (attribute.getName()){
                case "host":
                    result.setHost(value);
                    break;
                case "port":
                    result.setPort(Integer.parseInt(value));
                    break;
                case "connectionName":
                    result.setConnectionName(value);
                    break;
                case "password":
                    result.setPassword(value);
                    break;
                case "username":
                    result.setUsername(value);
                    break;
                case "topic":
                    result.setTopic(value);
                    break;

                default:
                    break;
            }
        }

        return result;
    }
}
