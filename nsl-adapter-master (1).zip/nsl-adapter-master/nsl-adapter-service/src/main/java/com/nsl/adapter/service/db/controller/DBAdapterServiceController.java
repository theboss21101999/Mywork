package com.nsl.adapter.service.db.controller;

import com.nsl.adapter.commons.dto.connections.DBConnectionDto;
import com.nsl.adapter.service.db.service.DBConnectionFactory;
import com.nsl.adapter.service.db.service.DBConnectionService;
import com.nsl.adapter.commons.utils.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.sql.SQLException;
import java.util.List;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;


@RestController
@CrossOrigin
@RequestMapping(value = "/get")
public class DBAdapterServiceController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DBAdapterServiceController.class);

    @Autowired
    DBConnectionService dbConnectionService;

    @Autowired
    DBConnectionFactory dbConnectionFactory;

    @GetMapping(path = "/tables/{Id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getTables(@PathVariable("Id") Long id) throws ClassNotFoundException, SQLException {
        DBConnectionDto connectionDto = dbConnectionService.getDBConnection(id, false);

        List<String> result=dbConnectionFactory.getTables(connectionDto);

        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }


}
