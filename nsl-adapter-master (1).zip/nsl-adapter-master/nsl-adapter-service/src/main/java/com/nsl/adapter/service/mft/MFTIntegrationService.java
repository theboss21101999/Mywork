package com.nsl.adapter.service.mft;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.service.service.IntegrationService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

import static com.nsl.adapter.service.utils.AppConstant.*;
import static com.nsl.adapter.service.v2.utills.EntityConstants.*;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class MFTIntegrationService  implements IntegrationService {

    @Autowired
    SaveBetsService saveBetsService;

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;
    @Override
    public CUPropsDto getSaveProperties(IntegrationDtoV3 integrationDto) throws NSLException {

        if (validate(integrationDto.getPropertiesMap(), integrationDto.getOperation()))
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, "please send valid data", ExceptionSeverity.MAJOR);

        CUPropsDto cuPropsDto = null;
        HashMap<String, String> cuSystemProps = new HashMap<>(integrationDto.getPropertiesMap());

        if (MFT_UPLOAD.equalsIgnoreCase(integrationDto.getOperation())) {
            cuPropsDto = newEntitiesForPUTMethod(integrationDto);
           // add code for upload file here
        }
        else {
            cuPropsDto = newEntitiesForGETMethod(integrationDto);
            String metaInfoEntityId = metaInfoEntityUtils.createMetaInfoEntity(integrationDto.getIntegrationName(), authBean);
            cuSystemProps.put(METAINFO_ENTITY_KEY, metaInfoEntityId);
              }
        if(cuPropsDto!=null) {
            cuPropsDto.setCuSystemProps(cuSystemProps);
            cuPropsDto.setIsMachineCU(Boolean.FALSE);
        }
        return cuPropsDto;
    }
    @Override
    public void getIntegration(IntegrationDtoV3 integrationDto,CUPropsDto cuPropsDto) {


        if(MFT_INBOUND.equalsIgnoreCase(integrationDto.getOperation()))
            integrationDto.setOutputEntityDsdId(getParticipatingItems(cuPropsDto.getTriggerCESLayerItems()).get(0).getDsdId());
    }

    @Override
    public CUPropsDto getUpdateProperties(CUPropsDto cuPropsDto, IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto newCUPropsDto=null;
          if(MFT_INBOUND.equalsIgnoreCase(integrationDto.getOperation()))
            newCUPropsDto = newEntitiesForGETMethod(integrationDto);

        Map<String, String> cuSystemProps = cuPropsDto.getCuSystemProps();
        cuSystemProps.putAll(integrationDto.getPropertiesMap());
        if(newCUPropsDto!=null)
            newCUPropsDto.setCuSystemProps(cuSystemProps);

        return newCUPropsDto;

    }
    private CUPropsDto newEntitiesForPUTMethod(IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto cuPropsDto = new CUPropsDto();
        String fileType = integrationDto.getPropertiesMap().get(AppConstant.FILETYPE);

        TenantCUEntityInput phyEntity1;
        if (AppConstant.NATIVE.equalsIgnoreCase(fileType))
            phyEntity1 = saveBetsService.getEntityByName(NSL_Adapter_Native_File);
        else
            phyEntity1 = saveBetsService.findEntityById(integrationDto.getInputEntityDsdId());

        TenantCUEntityInput phyEntity2 = saveBetsService.getEntityByName(NSL_MFT_SEND_Req);

        TenantCUEntityInput triggerCESEntity1 = saveBetsService.getEntityByName(NSL_MFT_SEND_Res);

        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Arrays.asList(phyEntity1,phyEntity2)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(triggerCESEntity1)));

        return cuPropsDto;
    }

    private static boolean validate(Map<String, String> propertiesMap, String operation) {

        List<String> propertyList;
        if (operation.equalsIgnoreCase(MFT_INBOUND))
            propertyList = Arrays.asList( MFT_FOLDER_PATH, FILEPATTERN, FILETYPE);
        else if (operation.equalsIgnoreCase(MFT_UPLOAD))//post
            propertyList = Arrays.asList( REMOTE_FOLDER, FILENAME, FILETYPE);
        else
            return true;

        for (Object property : propertyList) {
            if (!propertiesMap.containsKey(property.toString()))
                return true;
        }
        return false;
    }
    private CUPropsDto newEntitiesForGETMethod(IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto cuPropsDto = new CUPropsDto();
        String fileType = integrationDto.getPropertiesMap().get(AppConstant.FILETYPE);

        List<TenantCUEntityInput> entity = new ArrayList<>();
        if (AppConstant.NATIVE.equalsIgnoreCase(fileType)) {
            entity.add(saveBetsService.getEntityByName(NSL_Adapter_Native_File));
            entity.add(saveBetsService.getEntityByName(NSL_File_Info));
        }
        else
            entity.add(saveBetsService.findEntityById(integrationDto.getOutputEntityDsdId()));

        cuPropsDto.setPhysicalLayerItems(buildSlotItems(entity));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(entity));

        return cuPropsDto;
    }


}
