package com.nsl.adapter.service.dto;

import org.springframework.boot.configurationprocessor.json.JSONObject;

public class ResourceRequestDto {

    String swaggerUrl;
    JSONObject authObj;

    public ResourceRequestDto() {
    }

    public String getSwaggerUrl() {
        return swaggerUrl;
    }

    public void setSwaggerUrl(String swaggerUrl) {
        this.swaggerUrl = swaggerUrl;
    }

    public JSONObject getAuthObj() {
        return authObj;
    }

    public void setAuthObj(JSONObject authObj) {
        this.authObj = authObj;
    }

}
