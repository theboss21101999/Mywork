package com.nsl.adapter.service.model.authentication;

import java.time.LocalDateTime;


public class ExtOAuthClient {

    private Long id;

    private String server;
    //Registered Client Id of External Application
    private String clientId;
    //Registered Client Secret of External Application
    private String clientSecret;
    private String tokenUrl;
    private String authUrl;
    private String redirectUrl;
    private String tenantId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private boolean isClientDetailRequired = true;
    //Is Client Id part of body or header in TokenEndPoint call
    private boolean isClientIdPartOfAuthorizationInTokenEndPoint;
    //Is Client Secret part of body or header in TokenEndPoint call
    private boolean isClientSecretPartOfAuthorizationInTokenEndPoint;

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public boolean isClientDetailRequired() {
        return isClientDetailRequired;
    }

    public void setClientDetailRequired(boolean clientDetailRequired) {
        isClientDetailRequired = clientDetailRequired;
    }

    public String getTokenUrl() {
        return tokenUrl;
    }

    public void setTokenUrl(String tokenUrl) {
        this.tokenUrl = tokenUrl;
    }

    public String getAuthUrl() {
        return authUrl;
    }

    public void setAuthUrl(String authUrl) {
        this.authUrl = authUrl;
    }

    public boolean isClientIdPartOfAuthorizationInTokenEndPoint() {
        return isClientIdPartOfAuthorizationInTokenEndPoint;
    }

    public void setClientIdPartOfAuthorizationInTokenEndPoint(boolean clientIdPartOfAuthorizationInTokenEndPoint) {
        isClientIdPartOfAuthorizationInTokenEndPoint = clientIdPartOfAuthorizationInTokenEndPoint;
    }

    public boolean isClientSecretPartOfAuthorizationInTokenEndPoint() {
        return isClientSecretPartOfAuthorizationInTokenEndPoint;
    }

    public void setClientSecretPartOfAuthorizationInTokenEndPoint(boolean clientSecretPartOfAuthorizationInTokenEndPoint) {
        isClientSecretPartOfAuthorizationInTokenEndPoint = clientSecretPartOfAuthorizationInTokenEndPoint;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
