package com.nsl.adapter.service.kafka.listener;

import com.nsl.adapter.service.kafka.service.KafkaService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(
        value = "kafka.pipeline.enabled",
        havingValue = "true",
        matchIfMissing = false
)
public class SFTPTopicListener<V> {

	@Autowired
	@Qualifier("sftpInboundKafkaServiceImpl")
	private KafkaService kafkaService;

	private static final Logger LOGGER = LoggerFactory.getLogger(SFTPTopicListener.class);
    @KafkaListener(topics = "${kafka.topic.adapters.sftp}",
			groupId = "${kafka.topic.adapters.sftp.group.id}",
			containerFactory = "adapterContainerFactory")
    public void receiveNotifications(V v, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
									 @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition,
                                     @Header(KafkaHeaders.OFFSET) int offset,
									 @Header(KafkaHeaders.ACKNOWLEDGMENT) Acknowledgment acknowledgment) {

        ConsumerRecord consumerRecord = ((ConsumerRecord) v);
        LOGGER.info("Received payload '{}' from topic '{}' on partition '{}'", consumerRecord.value(), topic, partition);
		kafkaService.processKafkaMessage(consumerRecord);
		acknowledgment.acknowledge();
	}

}
