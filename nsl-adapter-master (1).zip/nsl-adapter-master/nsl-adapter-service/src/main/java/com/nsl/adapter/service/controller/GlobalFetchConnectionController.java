package com.nsl.adapter.service.controller;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/api/v1/connect")
public class GlobalFetchConnectionController {

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @GetMapping(path = "/globalconnection", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getEncodedConnection(@RequestParam("type") ConnectionDtoType type, @RequestParam("recordId") Long recordId) throws NSLException {
        String result = adapterConnnectionsDao.getRawConnection(type, recordId, requestScopedAuthenticatedUserBean);
        if (result==null){
            return new ApiResponse(HttpStatus.BAD_REQUEST, "Record not found", null);
        }
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }
}
