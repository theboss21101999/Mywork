package com.nsl.adapter.service.config;

import com.nimbusds.oauth2.sdk.util.StringUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;
import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

@Configuration
public class SmartLocaleResolver extends AcceptHeaderLocaleResolver {

    @Override
    public Locale resolveLocale(HttpServletRequest request) {
        if (StringUtils.isBlank(request.getHeader("Accept-Language"))) {
            return Locale.getDefault();
        }
        List<Locale.LanguageRange> list = Locale.LanguageRange.parse(request.getHeader("Accept-Language"));
        Locale locale = Locale.lookup(list, LOCALES);
        return locale;
    }

    List<Locale> LOCALES = Arrays.asList(new Locale("en"),
            new Locale("es"),
            new Locale("fr"),
            new Locale("es", "MX"),
            new Locale("zh"),
            new Locale("ja"));
}