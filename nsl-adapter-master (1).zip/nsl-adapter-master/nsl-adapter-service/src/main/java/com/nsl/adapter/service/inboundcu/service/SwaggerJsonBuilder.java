package com.nsl.adapter.service.inboundcu.service;

import com.nsl.adapter.commons.dto.connections.MetaInfoEntityDto;
import com.nsl.adapter.commons.dto.connections.RestInboundDto;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.model.ChangeUnit;
import com.nsl.logical.model.GSI;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TriggerCU;
import io.swagger.v3.core.util.Json;
import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.*;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.parameters.RequestBody;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.responses.ApiResponses;
import io.swagger.v3.oas.models.security.OAuthFlows;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static com.nsl.adapter.service.inboundcu.utils.RestInboundConstants.*;
import static com.nsl.logical.enums.StatusEnum.PUBLISHED;

@Service
public class SwaggerJsonBuilder {

    private static final Logger LOGGER = LoggerFactory.getLogger(SwaggerJsonBuilder.class);

    @Autowired
    AdaptorProperties adaptorProperties;

    @Autowired
    SwaggerBuildSchema swaggerBuildSchema;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Autowired
    CdmUtils cdmUtils;

    public String buildSchema(String cuName){

        ChangeUnit changeUnitMaster = changeUnitDao.getChangeUnitByName(cuName, bean);
        ChangeUnit changeUnit = changeUnitDao.getChangeUnitById(changeUnitMaster.getId(), bean);
        String metaInfoEntityName = changeUnit.getCuSystemProperties().get(AppConstant.METAINFO_ENTITY_KEY);
        MetaInfoEntityDto metaInfoEntity = metaInfoEntityUtils.getMetaInfoEntityDto(metaInfoEntityName , bean);

        Map<String, String> addProps = metaInfoEntity.getAdditionalProperties();

        String version = "";
        ChangeUnit restOutput = null;
        try{

            if (addProps.containsKey("version"))
                version = "/v" + addProps.get("version");
            if (addProps.containsKey("lastCuId")){
                ChangeUnit masterCU = changeUnitDao.getChangeUnitByMasterId( Long.valueOf(addProps.get("lastCuId")),
                                                                            null,StatusEnum.PUBLISHED,bean);
                restOutput = changeUnitDao.getChangeUnitById(masterCU.getId(),bean);
            }
        }catch (Exception e){
            LOGGER.info("error while fetching restOutput CU Id ",e);
        }


        // starting
        String basePath = adaptorProperties.getOpenApiUrl();
        String tenantName = cdmUtils.getEnvironmentNameByTenantId(bean.getTenantId());
        basePath = StringUtils.replace( basePath , AppConstant.TENANT_ID_TEMPLATE , tenantName );

        //creating class
        OpenAPI oai = new OpenAPI().addServersItem(new Server().url(basePath)).info(new Info().title(NSL_API)
                .version(API_Version).contact(new Contact().email(InfoEmail).name(Support).url(NslEmail)));

        //adding paths to class
        LOGGER.info("building Paths");
        Paths paths = buildPaths(changeUnit,version);
        LOGGER.info("paths created {}",paths);
        oai.paths(paths);

        //creating schemas
        LOGGER.info("building Schemas -->>>");
        Map<String, Schema> schemas = swaggerBuildSchema.buildSchemas(changeUnit, restOutput);
        LOGGER.info("Schema generated {}",schemas);

        //adding schemas to class
        Components components = new Components();
        components.schemas(schemas);
        components.addSecuritySchemes(SecurityToken, new SecurityScheme().type(SecurityScheme.Type.OAUTH2).flows(new OAuthFlows()));
        oai.components(components);
        oai.addSecurityItem(new SecurityRequirement().addList(SecurityToken, Arrays.asList("read", "write")));

        //finishing
        String jsonSchema = Json.pretty(oai);
        LOGGER.info("schema file content: {}", jsonSchema);
        return jsonSchema;

    }
    public String buildGSISchema(String gsiName){


        RestInboundDto metaInfoEntity = metaInfoEntityUtils.getGsiMetaInfoEntityDto(gsiName , bean);
        GSI gsi = changeUnitDao.getGsiById(Long.valueOf(metaInfoEntity.getGsiId()), bean);
        ChangeUnit changeUnitMaster = changeUnitDao.getChangeUnitByName(gsi.getSolutionLogic().get(Integer.parseInt("0")).getName(), bean);
        ChangeUnit changeUnit = changeUnitDao.getChangeUnitById(changeUnitMaster.getId(), bean);
        String version = "";
        ChangeUnit restOutput = null;
        try{

            version = "/v" + metaInfoEntity.getGsiVersion();
            String contextualId = metaInfoEntity.getContextualCuId();
            int j= contextualId.indexOf("_");
            Long cuId= Long.valueOf(contextualId.substring(j+1));
//            ChangeUnit masterCU = changeUnitDao.getChangeUnitByMasterId( cuId,null,StatusEnum.PUBLISHED,bean);
            restOutput = changeUnitDao.getChangeUnitById(cuId,bean);

        }catch (Exception e){
            LOGGER.info("error while fetching restOutput CU Id ",e);
        }


        // starting
        String basePath = adaptorProperties.getOpenApiUrl();
        String tenantName = cdmUtils.getEnvironmentNameByTenantId(bean.getTenantId());
        basePath = StringUtils.replace( basePath , AppConstant.TENANT_ID_TEMPLATE , tenantName );

        //creating class
        OpenAPI oai = new OpenAPI().addServersItem(new Server().url(basePath)).info(new Info().title(NSL_API)
                .version(API_Version).contact(new Contact().email(InfoEmail).name(Support).url(NslEmail)));

        //adding paths to class
        LOGGER.info("building Paths");
        Paths paths = buildPaths(changeUnit,version,metaInfoEntity,gsiName);
        LOGGER.info("paths created {}",paths);
        oai.paths(paths);

        //creating schemas
        LOGGER.info("building Schemas -->>>");
        Map<String, Schema> schemas = swaggerBuildSchema.buildSchemas(changeUnit, restOutput,metaInfoEntity);
        LOGGER.info("Schema generated {}",schemas);

        //adding schemas to class
        Components components = new Components();
        components.schemas(schemas);
        components.addSecuritySchemes(SecurityToken, new SecurityScheme().type(SecurityScheme.Type.OAUTH2).flows(new OAuthFlows()));
        oai.components(components);
        oai.addSecurityItem(new SecurityRequirement().addList(SecurityToken, Arrays.asList("read", "write")));

        //finishing
        String jsonSchema = Json.pretty(oai);
        LOGGER.info("schema file content: {}", jsonSchema);
        return jsonSchema;

    }

    private Paths buildPaths(ChangeUnit changeUnits , String version) {
        Paths paths = new Paths();
        paths.addPathItem("/"+changeUnits.getName()+version, reqPathItem(changeUnits));
        paths.addPathItem("/"+changeUnits.getName()+"/instances/{instanceId}",resPathItem());
        return paths;
    }
    private Paths buildPaths(ChangeUnit changeUnits , String version, RestInboundDto metaInfoEntity,String gsiName) {
        Paths paths = new Paths();
        paths.addPathItem("/"+gsiName+version, reqPathItem(changeUnits,metaInfoEntity));
        paths.addPathItem("/"+gsiName+"/instances/{instanceId}",resPathItem());
        return paths;
    }

    private PathItem resPathItem() {

        Operation operation = new Operation();

        PathItem item = new PathItem().description("response path").get(operation);

        operation.responses(new ApiResponses()
                        .addApiResponse(Status_200, new ApiResponse().description(Success)
                                .content(new Content().addMediaType(Application_json, new MediaType()
                                        .schema(new Schema<>().$ref(Components_schema + "/Res." + Status_200)))))
                        .addApiResponse(Status_202, new ApiResponse().description(Success)
                                .content(new Content().addMediaType(Application_json, new MediaType()
                                        .schema(new Schema<>().$ref(Components_schema + "/Res." + Status_202)))))
                        .addApiResponse(Status_401, new ApiResponse().description(Unauthorized)
                                .content(new Content().addMediaType(Application_json, new MediaType()
                                        .schema(new Schema<>().$ref(Components_schema + "/" + Status_401)))))
                        .addApiResponse(Status_500, new ApiResponse().description(Server_Error)
                                .content(new Content().addMediaType(Application_json, new MediaType()
                                        .schema(new Schema<>().$ref(Components_schema + "/" + Status_500)))))
                );
        operation.addParametersItem(new Parameter().in("path").name("instanceId").schema(new StringSchema()));
        return item;
    }

    private PathItem reqPathItem(ChangeUnit changeUnits) {

        Map<String, String> cuSystemProps = changeUnits.getCuSystemProperties();
        String inputEntity = cuSystemProps.get(AppConstant.REQUESTID);

        Operation operation = new Operation();
        PathItem item = new PathItem().description("The execution path").post(operation);


        /** adding default response schemas*/
        operation.responses(new ApiResponses()
                .addApiResponse(Status_200, new ApiResponse().description(Success)
                        .content(new Content().addMediaType(Application_json, new MediaType()
                                .schema(new Schema<>().$ref(Components_schema + "/Req." + Status_200)))))
                .addApiResponse(Status_401, new ApiResponse().description(Unauthorized)
                        .content(new Content().addMediaType(Application_json, new MediaType()
                                .schema(new Schema<>().$ref(Components_schema + "/" + Status_401)))))
                .addApiResponse(Status_500, new ApiResponse().description(Server_Error)
                        .content(new Content().addMediaType(Application_json, new MediaType()
                                .schema(new Schema<>().$ref(Components_schema + "/" + Status_500))))));

        /** adding schema for the request body*/
        Content content = new Content();
        String contentType = cuSystemProps.get(ContentType);
        if( "true".equalsIgnoreCase(cuSystemProps.get(ISFormData)) ) {

            content.addMediaType(Multipart_FormData,new MediaType().schema(new ObjectSchema()));
            if (inputEntity!=null ) {
                String bodyKey;
                if (Application_xml.equals(contentType)) bodyKey = XMlReqBody_Key;
                else  bodyKey = ReqBody_Key;
                Map<String, Encoding> encodingMap = new HashMap<>();
                encodingMap.put(bodyKey,new Encoding().contentType(contentType));
                content.get(Multipart_FormData).encoding(encodingMap).getSchema().addProperties(bodyKey,
                        new Schema<>().$ref(Components_schema + "/" + inputEntity));
            }
            if ("true".equalsIgnoreCase(cuSystemProps.get(FILESUPPORT)))
                content.get(Multipart_FormData).getSchema().addProperties(File_Key ,
                                                        new ArraySchema().items(new BinarySchema().type("string"))
                                                        .description("accepts multiple files with file as the key"));
            operation.requestBody(new RequestBody().content(content));
        } else if ( Application_xml.equals(cuSystemProps.get(ContentType)) ) {
             content.addMediaType(Application_xml, new MediaType().schema(new Schema<>().
                                                            $ref(Components_schema + "/" + inputEntity)));
             operation.requestBody(new RequestBody().content(content));
        } else if (inputEntity!=null) {
            content.addMediaType(Application_json, new MediaType().schema(new Schema<>().
                    $ref(Components_schema + "/" + inputEntity)));
            operation.requestBody(new RequestBody().content(content));
        }


        /** adding header and path params to the schema*/
        if (cuSystemProps.containsKey(AppConstant.HEADERENTITYNAME)) {
            GeneralEntity generalEntity = swaggerBuildSchema.getGeneralEntityByName(changeUnits.getLayers(),
                    cuSystemProps.get(AppConstant.HEADERENTITYNAME));
            addParameters(generalEntity, operation, Header);
        }
        if (cuSystemProps.containsKey(AppConstant.QUERYPARAMENTITYNAME)) {
            GeneralEntity generalEntity = swaggerBuildSchema.getGeneralEntityByName(changeUnits.getLayers(),
                    cuSystemProps.get(AppConstant.QUERYPARAMENTITYNAME));
            addParameters(generalEntity, operation, Query);
        }
        return item;
    }
    private PathItem reqPathItem(ChangeUnit changeUnits,RestInboundDto metaInfoEntity) {

        String inputEntity = metaInfoEntity.getBodyEntityName();

        Operation operation = new Operation();
        PathItem item = new PathItem().description("The execution path").post(operation);


        /** adding default response schemas*/
        operation.responses(new ApiResponses()
                .addApiResponse(Status_200, new ApiResponse().description(Success)
                        .content(new Content().addMediaType(Application_json, new MediaType()
                                .schema(new Schema<>().$ref(Components_schema + "/Req." + Status_200)))))
                .addApiResponse(Status_401, new ApiResponse().description(Unauthorized)
                        .content(new Content().addMediaType(Application_json, new MediaType()
                                .schema(new Schema<>().$ref(Components_schema + "/" + Status_401)))))
                .addApiResponse(Status_500, new ApiResponse().description(Server_Error)
                        .content(new Content().addMediaType(Application_json, new MediaType()
                                .schema(new Schema<>().$ref(Components_schema + "/" + Status_500))))));

        /** adding schema for the request body*/
        Content content = new Content();
        String contentType = metaInfoEntity.getContentType();
        if(metaInfoEntity.isFormData())  {

            content.addMediaType(Multipart_FormData,new MediaType().schema(new ObjectSchema()));
            if (inputEntity!=null ) {
                String bodyKey;
                if (Application_xml.equals(contentType)) bodyKey = XMlReqBody_Key;
                else  bodyKey = ReqBody_Key;
                Map<String, Encoding> encodingMap = new HashMap<>();
                encodingMap.put(bodyKey,new Encoding().contentType(contentType));
                content.get(Multipart_FormData).encoding(encodingMap).getSchema().addProperties(bodyKey,
                        new Schema<>().$ref(Components_schema + "/" + inputEntity));
            }
            if (FILESUPPORT.equals(contentType))
                content.get(Multipart_FormData).getSchema().addProperties(File_Key ,
                        new ArraySchema().items(new BinarySchema().type("string"))
                                .description("accepts multiple files with file as the key"));
            operation.requestBody(new RequestBody().content(content));
        } else if ( Application_xml.equals(contentType))  {
            content.addMediaType(Application_xml, new MediaType().schema(new Schema<>().
                    $ref(Components_schema + "/" + inputEntity)));
            operation.requestBody(new RequestBody().content(content));
        } else if (inputEntity!=null) {
            content.addMediaType(Application_json, new MediaType().schema(new Schema<>().
                    $ref(Components_schema + "/" + inputEntity)));
            operation.requestBody(new RequestBody().content(content));
        }


        /** adding header and path params to the schema*/
        if (metaInfoEntity.getHeaderEntityName()!=null) {
            GeneralEntity generalEntity = swaggerBuildSchema.getGeneralEntityByName(changeUnits.getLayers(),
                    metaInfoEntity.getHeaderEntityName());
            addParameters(generalEntity, operation, Header);
        }
        if (metaInfoEntity.getQueryEntityName()!=null) {
            GeneralEntity generalEntity = swaggerBuildSchema.getGeneralEntityByName(changeUnits.getLayers(),
                    metaInfoEntity.getQueryEntityName());
            addParameters(generalEntity, operation, Query);
        }
        return item;
    }
    private void addParameters(GeneralEntity ge, Operation operation, String path) {
        if (ge == null)
            return;
        for (NslAttribute nslAttribute : ge.getNslAttributes()) {
            Parameter parameter = new Parameter();
            parameter.setName(nslAttribute.getName());
            parameter.in(path);
            parameter.setSchema(new StringSchema());
            operation.addParametersItem(parameter);
        }
    }
}