package com.nsl.adapter.service.graph.utils;

public class GraphConstants {
    public static final String GRAPH = "Graph";
    public static final String GRAPH_AUTH_TOKEN = "https://login.microsoftonline.com/51973d14-5386-4141-af3c-e75bbfe287fa/oauth2/v2.0/authorize";
    public static final String GRAPH_REFRESH_TOKEN = "https://login.microsoftonline.com/common/oauth2/v2.0/token";
    public static final String ACCESS_TYPE="access_type";
    public static final String GRANT_TYPE="grant_type";
    public static final String AUTHORIZATION_CODE="authorization_code";
    public static final String OFFLINE="offline";
    public static final String CODE="code";
    public static final String REFRESH_TOKEN="refresh_token";
    public static final String STATE="state";
    public static final String Url="url";
    public static final String clientId="clientId";
    public static final String clientSecret="clientSecret";

    private GraphConstants(){
        throw new IllegalStateException("utility class");
    }

}

