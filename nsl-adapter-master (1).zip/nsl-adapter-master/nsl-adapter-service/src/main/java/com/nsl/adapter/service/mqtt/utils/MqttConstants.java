package com.nsl.adapter.service.mqtt.utils;

public class MqttConstants {
    public static final String PUBLISHER = "PUBLISHER";
    public static final String SUBSCRIBER = "SUBSCRIBER";

    public static final String USERNAME = "username";

    public static final String PASSWORD = "password";

    public static final String TOPIC = "topic";

    public static final String USER_CONTEXT_KEY = "userContext";

    public static final String TENANT_ID_KEY = "tenantId";

    public static final String USER_ID_KEY = "userId";

    public static final String USER_EMAIL_KEY = "emailId";

    public static final String DATA_KEY = "data";

    public static final String CONNECTION_NAME = "connectionName";

    public static final String HOST = "host";

    public static final String PORT = "port";

    public static final String METHOD_TYPE = "methodType";
    private MqttConstants(){
        throw new IllegalStateException("utility class");
    }
}
