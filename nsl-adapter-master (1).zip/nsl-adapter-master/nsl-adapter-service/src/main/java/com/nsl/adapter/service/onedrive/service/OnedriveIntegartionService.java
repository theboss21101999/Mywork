package com.nsl.adapter.service.onedrive.service;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.service.onedrive.utils.OnedriveConstants;
import com.nsl.adapter.service.service.IntegrationService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CronExpressionHelper;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.dsd.store.models.tenant.io.TenantSlotItemInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.*;

import static com.nsl.adapter.service.utils.AppConstant.*;
import static com.nsl.adapter.service.v2.utills.EntityConstants.NSL_Adapter_Native_File;
import static com.nsl.adapter.service.v2.utills.EntityConstants.ONEDRIVE_DELETE_RES;
import static com.nsl.adapter.service.v2.utills.EntityConstants.ONEDRIVE_LIST_REQ;
import static com.nsl.adapter.service.v2.utills.EntityConstants.ONEDRIVE_LIST_RES;
import static com.nsl.adapter.service.v2.utills.EntityConstants.ONEDRIVE_REQ;
import static com.nsl.adapter.service.v2.utills.EntityConstants.ONEDRIVE_UPLOAD_REQ;
import static com.nsl.adapter.service.v2.utills.EntityConstants.ONEDRIVE_UPLOAD_RES;



@Service
public class OnedriveIntegartionService implements IntegrationService {

    @Autowired
    SaveBetsService saveBetsService;

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Autowired
    MessageSource messageSource;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;



    @Override
    public CUPropsDto getSaveProperties(IntegrationDtoV3 integrationDto) throws NSLException {
        if (validForOnedrive(integrationDto.getPropertiesMap(),integrationDto.getOperation()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_195", null, Locale.ENGLISH));

        HashMap<String, String> cuSystemProps = new HashMap<>(integrationDto.getPropertiesMap());
        String fileType;
        fileType=integrationDto.getPropertiesMap().get(AppConstant.FILETYPE);

        CUPropsDto cuPropsDto = new CUPropsDto();
        cuPropsDto.setCuName(integrationDto.getIntegrationName());
        cuPropsDto.setIsMachineCU(Boolean.TRUE);
        cuPropsDto.setCuSystemProps(integrationDto.getPropertiesMap());
        cuPropsDto.setPhysicalLayerItems(physicalLayerEntities(fileType,integrationDto));
        cuPropsDto.setTriggerCESLayerItems(triggerCesLayerEntities(fileType,integrationDto));
        if (ONEDRIVE_GET_FILE.equalsIgnoreCase(integrationDto.getOperation())) {
            String metaInfoEntityId = metaInfoEntityUtils.createMetaInfoEntity(integrationDto.getIntegrationName(), authBean);
            cuSystemProps.put(METAINFO_ENTITY_KEY, metaInfoEntityId);
            cuSystemProps.put(CRON_EXPRESSION, CronExpressionHelper.generateCronExpression(integrationDto.getScheduleReq()));
            if (integrationDto.getScheduleReq() != null)
                cuSystemProps.put(JOB_DELETE_TIME, integrationDto.getScheduleReq().getEndDate());
            cuPropsDto.setCuSystemProps(cuSystemProps);
        }

        return cuPropsDto;
    }

    public List<TenantSlotItemInput> physicalLayerEntities(String fileType, IntegrationDtoV3 integrationDto) throws NSLException {
        List<TenantCUEntityInput> physicalEntity = new ArrayList<>();
        String name;
        switch (integrationDto.getOperation()) {
            case OnedriveConstants.LIST_FILE:
                name= ONEDRIVE_LIST_REQ;
                break;
            case OnedriveConstants.DELETE_FILE:
            case OnedriveConstants.GET_FILE:
                name=ONEDRIVE_REQ;
                break;
            case OnedriveConstants.UPLOAD_ENTITY:
                name = ONEDRIVE_UPLOAD_REQ;
                if (AppConstant.NATIVE.equals(fileType)) {
                    physicalEntity.add(saveBetsService.getEntityByName(NSL_Adapter_Native_File));
                } else {
                    physicalEntity.add(saveBetsService.findEntityById(integrationDto.getInputEntityDsdId()));
                }
                break;
            default:
                return null;
        }
        physicalEntity.add(0,saveBetsService.getEntityByName(name));

        return buildSlotItems(physicalEntity);
    }

    public List<TenantSlotItemInput> triggerCesLayerEntities(String fileType, IntegrationDtoV3 integrationDto) throws NSLException {
        List<TenantCUEntityInput> triggerCesEntity = new ArrayList<>();
        String name;
        switch (integrationDto.getOperation()) {
            case OnedriveConstants.LIST_FILE:
                name= ONEDRIVE_LIST_RES;
                break;
            case OnedriveConstants.DELETE_FILE:
                name = ONEDRIVE_DELETE_RES;
                break;
            case OnedriveConstants.GET_FILE:
                if (AppConstant.NATIVE.equals(fileType))
                    name = NSL_Adapter_Native_File;
                else {
                    triggerCesEntity.add(saveBetsService.findEntityById(integrationDto.getOutputEntityDsdId()));
                    return buildSlotItems(triggerCesEntity);
                }
                break;
            case OnedriveConstants.UPLOAD_ENTITY:
                name = ONEDRIVE_UPLOAD_RES;
                break;
            default:
                return null;

        }
        triggerCesEntity.add(saveBetsService.getEntityByName(name));

        return buildSlotItems(triggerCesEntity);
    }

    @Override
    public void getIntegration(IntegrationDtoV3 integrationDto,CUPropsDto cuPropsDto) {
        if (OnedriveConstants.UPLOAD_ENTITY.equalsIgnoreCase(integrationDto.getOperation()))
            integrationDto.setInputEntityDsdId(getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).get(1).getDsdId());
        else if(OnedriveConstants.GET_FILE.equalsIgnoreCase(integrationDto.getOperation()))
            integrationDto.setOutputEntityDsdId(getParticipatingItems(cuPropsDto.getTriggerCESLayerItems()).get(0).getDsdId());
    }

    @Override
    public CUPropsDto getUpdateProperties(CUPropsDto cuPropsDto, IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto newCUPropsDto = new CUPropsDto();
        String fileType;
        fileType=integrationDto.getPropertiesMap().get(AppConstant.FILETYPE);
        newCUPropsDto.setPhysicalLayerItems(physicalLayerEntities(fileType,integrationDto));
        newCUPropsDto.setTriggerCESLayerItems(triggerCesLayerEntities(fileType,integrationDto));
        newCUPropsDto.setCuSystemProps(integrationDto.getPropertiesMap());

        return newCUPropsDto;
    }
    private static boolean validForOnedrive(Map<String, String> propetiesMap, String operation) {
        List<String> propertyList;
        switch (operation) {
            case OnedriveConstants.UPLOAD_ENTITY:
                propertyList = Arrays.asList(FILENAME, FILETYPE, FOLDER);
                break;
            case OnedriveConstants.GET_FILE:
            case OnedriveConstants.DELETE_FILE:
                propertyList = List.of(FILE_KEY);
                break;

            case OnedriveConstants.LIST_FILE:
                propertyList = List.of(FOLDER);
                break;
            default:
                return true;
        }
        for (String property : propertyList) {
            if (!propetiesMap.containsKey(property))
                return true;
        }
        return false;

    }

}
