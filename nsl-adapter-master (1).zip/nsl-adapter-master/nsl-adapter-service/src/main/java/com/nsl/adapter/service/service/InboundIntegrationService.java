package com.nsl.adapter.service.service;

import com.nsl.adapter.commons.dto.SchedulerRequestDto;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.logical.exception.NSLException;
import org.springframework.boot.configurationprocessor.json.JSONException;

public abstract class InboundIntegrationService {
    public abstract ApiResponse publishMessage(SchedulerRequestDto schedulerRequestDto) throws JSONException, NSLException;
}
