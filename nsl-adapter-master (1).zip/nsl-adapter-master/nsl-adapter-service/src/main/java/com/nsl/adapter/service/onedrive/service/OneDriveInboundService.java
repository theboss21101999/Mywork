package com.nsl.adapter.service.onedrive.service;

import com.nsl.adapter.commons.dto.connections.MetaInfoEntityDto;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.commons.dto.SchedulerRequestDto;
import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.service.kafka.enums.ConnectionType;
import com.nsl.adapter.service.kafka.listener.SFTPDataConfig;
import com.nsl.adapter.service.kafka.utils.KafkaConstants;
import com.nsl.adapter.service.kafka.utils.KafkaProducerConnectionUtil;
import com.nsl.adapter.service.onedrive.serviceimpl.OneDriveGsiInvokerUtil;
import com.nsl.adapter.service.service.InboundIntegrationService;
import com.nsl.adapter.service.utils.*;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.util.*;


@Component
public class OneDriveInboundService extends InboundIntegrationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(OneDriveInboundService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    SFTPDataConfig sftpDataConfig;

    @Autowired
    EntityToJSONUtil entityToJSONUtil;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    OneDriveGsiInvokerUtil oneDriveGsiInvokerUtil;



    private Map<String, String> cuSystemProp;

    @Override
    public ApiResponse publishMessage(SchedulerRequestDto schedulerRequestDto) throws JSONException, NSLException {

        setAuthorizationBean(schedulerRequestDto);
        String eventId = UUID.randomUUID().toString();
        cuSystemProp = getCuSystemProp(schedulerRequestDto.getName());
        String metaInfoEntityName;
        if (cuSystemProp == null)
            metaInfoEntityName = "";
        else
            metaInfoEntityName = cuSystemProp.get(AppConstant.METAINFO_ENTITY_KEY);
        LOGGER.info("Fetching meta info entity having name {}", metaInfoEntityName);
        MetaInfoEntityDto metaInfoEntity = metaInfoEntityUtils.getMetaInfoEntityDto(metaInfoEntityName , bean);
        LOGGER.info("{} fetched successfully...", metaInfoEntityName);
        LOGGER.info("Fetching latest files from SFTP...");
        List<String> fileList = getFilesFromOnedrive(metaInfoEntity);
        LOGGER.debug("The list of files are - {}", fileList);
        KafkaConnectionDto connectionDto = getKafkaConfig();
        KafkaProducerConnectionUtil kafkaProducerConnectionService = new KafkaProducerConnectionUtil(connectionDto);
        LOGGER.info("Sending {} messages to Kafka..", fileList.size());
        for (String fileName : fileList) {
            String kafkaMessage = augmentMessage(schedulerRequestDto, fileName, eventId);
            kafkaProducerConnectionService.sendMessageTokafka(kafkaMessage, sftpDataConfig.getSftpTopic());
        }
        LOGGER.info("{} messages successfully sent to kafka..", fileList.size());
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, eventId);

    }

    public  List<String> getFilesFromOnedrive(MetaInfoEntityDto metaInfoEntity) throws NSLException {
        Long connectionId = Long.valueOf(cuSystemProp.get("configEntityRecordId"));
        String folderName = cuSystemProp.get(AppConstant.FOLDER);
        return oneDriveGsiInvokerUtil.listFiles(connectionId, folderName,metaInfoEntity,cuSystemProp, bean);
    }



    private KafkaConnectionDto getKafkaConfig() {

        LOGGER.info("Getting Kafka Configuration..");
        KafkaConnectionDto kafkaConnectionDto = new KafkaConnectionDto();
        Properties config = new Properties();
        config.put(KafkaConstants.TOPIC, sftpDataConfig.getSftpTopic());
        config.put(KafkaConstants.CONNECTION_TYPE, ConnectionType.PLAINTEXT.name());
        kafkaConnectionDto.setBootstrapServer(Collections.singletonList(sftpDataConfig.getBootstrapServers()));
        kafkaConnectionDto.setAdvancedConfig(config);
        LOGGER.info("Messages will be sent to topic - {}", sftpDataConfig.getSftpTopic());
        return kafkaConnectionDto;
    }

        private Map<String, String> getCuSystemProp (String name){
            ChangeUnit changeUnit = changeUnitDao.getChangeUnitByName(name, bean);
            ChangeUnit sftpInboundCu = changeUnitDao.getChangeUnitById(changeUnit.getId(), bean);
            return sftpInboundCu.getCuSystemProperties();
        }

        private void setAuthorizationBean (SchedulerRequestDto schedulerRequestDto){
            schedulerRequestDto.setTenantId(bean.getTenantId());
            schedulerRequestDto.setUserId(bean.getUserId());
            schedulerRequestDto.setUserEmail(bean.getEmailId());
        }

        private static String augmentMessage (SchedulerRequestDto schedulerRequestDto, String fileName, String eventId){
            return AppConstant.FILENAME + ":" + fileName + "\r\n" +
                    AppConstant.CUNAME + ":" + schedulerRequestDto.getName() + "\r\n" +
                    AppConstant.USEREMAIL + ":" + schedulerRequestDto.getUserEmail() + "\r\n" +
                    AppConstant.USERID + ":" + schedulerRequestDto.getUserId() + "\r\n" +
                    AppConstant.TENANTID + ":" + schedulerRequestDto.getTenantId() + "\r\n" +
                    AppConstant.EVENT_ID + ":" + eventId + "\r\n";
        }


}