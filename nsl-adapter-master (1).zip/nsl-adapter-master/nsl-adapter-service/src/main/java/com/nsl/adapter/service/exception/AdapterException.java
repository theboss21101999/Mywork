package com.nsl.adapter.service.exception;

public class AdapterException extends Exception{

    public AdapterException(String message) {
        super("Adapter Exception: " + message);
    }

    public AdapterException(String message, Throwable t) {
        super("Adapter Exception: " + message, t);
    }
}
