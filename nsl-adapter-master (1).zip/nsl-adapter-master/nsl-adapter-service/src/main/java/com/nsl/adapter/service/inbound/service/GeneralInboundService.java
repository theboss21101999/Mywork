package com.nsl.adapter.service.inbound.service;

import com.nsl.adapter.commons.dto.SchedulerRequestDto;
import com.nsl.adapter.commons.dto.connections.MetaInfoEntityDto;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.service.inbound.dto.NSLGsiListDto;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.model.ChangeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Map;
import java.util.UUID;

@Component
public class GeneralInboundService {

    private static final Logger LOGGER = LoggerFactory.getLogger(GeneralInboundService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    public NSLGsiListDto getGsiList(SchedulerRequestDto schedulerRequestDto){

        Map<String, String> cuSystemProp = null;
        NSLGsiListDto nslGsiListDto = new NSLGsiListDto();

        nslGsiListDto.setSchedulerRequestDto(setAuthorizationBean(schedulerRequestDto));

        nslGsiListDto.setEventId(UUID.randomUUID().toString());

        ChangeUnit inboundCu = changeUnitDao.getChangeUnitByName(schedulerRequestDto.getName(), authBean);
        nslGsiListDto.setChangeUnit(inboundCu);

        cuSystemProp = inboundCu.getCuSystemProperties();
        String metaInfoEntityName = (cuSystemProp!=null) ? cuSystemProp.get(AppConstant.METAINFO_ENTITY_KEY): "";

        MetaInfoEntityDto metaInfoEntity = metaInfoEntityUtils.getMetaInfoEntityDto(metaInfoEntityName,authBean);
        nslGsiListDto.setGsiMasterIdList(metaInfoEntity.getGsiIdList());
        LOGGER.info("Total number of GSI's present : {}", nslGsiListDto.getGsiMasterIdList().size());

        return nslGsiListDto;

    }

    private SchedulerRequestDto setAuthorizationBean(SchedulerRequestDto schedulerRequestDto) {

            schedulerRequestDto.setTenantId(authBean.getTenantId());
            schedulerRequestDto.setUserId(authBean.getUserId());
            schedulerRequestDto.setUserEmail(authBean.getEmailId());
        return schedulerRequestDto;
    }


}
