package com.nsl.adapter.service.exception;

public class ExtAuthException extends RuntimeException {

	/**
	 * Exception class for ExtAPI
	 */
	private static final long serialVersionUID = 1L;

	public ExtAuthException(String message) {
		super("ExtAuth: " + message);
	}
	
	public ExtAuthException(String message, Throwable t) {
		super("ExtAuth: " + message, t);
	}
}
