package com.nsl.adapter.service.db.service;

import com.nsl.adapter.commons.dto.connections.DBConnectionDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@Service
public class DBConnectionFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(DBConnectionFactory.class);
    public List<String> getTables(DBConnectionDto connectionDto) throws ClassNotFoundException {
        Statement st = null;
        List<String> result = new ArrayList<>();
        Class.forName(connectionDto.getDataSourceDriver());
        try (Connection con = DriverManager.getConnection(connectionDto.getDataSourceUrl(),
                connectionDto.getUsername(), connectionDto.getPassword())) {
            st = con.createStatement();
            ResultSet rs = st.executeQuery("show tables");
            while (rs.next()) {
                result.add(rs.getString(1));
            }
            return result;
        } catch (SQLException ignored) {
            System.out.println(ignored);
        } finally {
            try {
                assert st != null;  //NOSONAR
                st.close();
            } catch (Exception ignored) {
                LOGGER.info(ignored.toString());
            }
        }
        return result;
    }
}
