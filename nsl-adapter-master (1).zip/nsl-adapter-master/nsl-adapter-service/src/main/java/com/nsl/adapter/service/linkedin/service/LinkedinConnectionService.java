package com.nsl.adapter.service.linkedin.service;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.LinkedinAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.enums.ConnectionsType;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.Locale;

@Service
public class LinkedinConnectionService {
    private static final Logger LOGGER = LoggerFactory.getLogger(LinkedinConnectionService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;
    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;
    @Autowired
    MessageSource messageSource;

    public  TxnAdapterConnection saveLinkedinConnection(LinkedinAdapterConnectionDto connectionDto) {

        if (connectionDto.getAppId() == null || connectionDto.getAppSecret() == null ||
                connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_182", null, Locale.ENGLISH) , null);

        connectionDataToolsV3.connectionCheck(ConnectionDtoType.LINKEDIN,connectionDto.getConnectionName(),authBean);

        connectionDto.setAppSecret(connectionDataToolsV3.saveSecret(ConnectionDtoType.LINKEDIN, "appSecret",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getAppSecret()));
        connectionDto.setAccessToken(connectionDataToolsV3.saveSecret(ConnectionDtoType.LINKEDIN, "accessToken",
                connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getAccessToken()));

        LOGGER.info("saving LINKEDIN connection");
        TxnAdapterConnection result = new TxnAdapterConnection();
        result.setConnectionDtoType(ConnectionDtoType.LINKEDIN);
        result.setConnection(connectionDto);
        result = adapterConnnectionsDao.saveConnection(result, authBean);

        return result;
    }

    public LinkedinAdapterConnectionDto getLinkedinConnection(Long id, boolean hide) {
        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.LINKEDIN, id, authBean);
        if (previousConnection == null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }
        return txnToLinkedinDto(previousConnection, hide);
    }



    public TxnAdapterConnection updateLinkedinConnection(Long id, LinkedinAdapterConnectionDto connectionDto) {
        if(  connectionDto.getAppSecret() == null || connectionDto.getAppId() == null ||
                connectionDto.getConnectionName() == null){
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH), null);
        }

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(ConnectionDtoType.LINKEDIN, id, authBean);

        LinkedinAdapterConnectionDto prevsDto = (LinkedinAdapterConnectionDto) previousConnection.getConnection();
        connectionDataToolsV3.connectionNameCheck(previousConnection,connectionDto.getConnectionName());

        if (connectionDto.getAppId()!=null){
            prevsDto.setAppId(connectionDto.getAppId());
        }
        if (connectionDto.getAppSecret()!=null){
            prevsDto.setAppSecret(connectionDataToolsV3.updateSecret(ConnectionDtoType.LINKEDIN, "appSecret",
                    connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getAppSecret()));
        }
        if (connectionDto.getAccessToken()!=null){
            prevsDto.setAccessToken(connectionDataToolsV3.updateSecret(ConnectionDtoType.LINKEDIN, "accessToken",
                    connectionDto.getConnectionName(), authBean.getTenantId(), connectionDto.getAccessToken()));
        }
        previousConnection.setConnection(prevsDto);
        LOGGER.info("update LINKEDIN connection");
        TxnAdapterConnection result = adapterConnnectionsDao.saveConnection(previousConnection, authBean);
        return result;
    }

    public LinkedinAdapterConnectionDto txnToLinkedinDto(TxnAdapterConnection adapterConnection, boolean hide) {
        LinkedinAdapterConnectionDto dto = (LinkedinAdapterConnectionDto) adapterConnection.getConnection();

        if (dto == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,
                    messageSource.getMessage("Paas_Adapter_178", null, Locale.ENGLISH) , null);

        if (!hide){
            dto.setAppSecret(connectionDataToolsV3.getSecret(dto.getAppSecret()));
            dto.setAccessToken(connectionDataToolsV3.getSecret(dto.getAccessToken()));
        }
        dto.getMetadata().put("dsdId",String.valueOf(adapterConnection.getRecordId()));
        return dto;
    }

}
