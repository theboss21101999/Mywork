package com.nsl.adapter.service.kafka.serviceImpl;

import com.nsl.adapter.commons.dto.SchedulerRequestDto;
import com.nsl.adapter.service.kafka.service.KafkaService;
import com.nsl.adapter.service.utils.SchedulerUtil;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.model.GSI;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import java.util.Map;

@Service("sftpInboundGSIKafkaServiceImpl")
public class InboundGSIKafkaServiceImpl implements KafkaService {

    private static final Logger LOGGER = LoggerFactory.getLogger(InboundGSIKafkaServiceImpl.class);

    private static final String USER_CONTEXT_KEY = "userContext";
    private static final String TENANT_ID_KEY = "tenantId";
    private static final String USER_ID_KEY = "userId";
    private static final String USER_EMAIL_KEY = "emailId";
    private static final String DATA_KEY = "data";

    @Autowired
    SchedulerUtil schedulerUtil;

    @Override
    @Async("inboundGsiKafkaExecutor")
    public void processKafkaMessage(ConsumerRecord<?, ?> consumerRecord) {

        try {

            Map<Object, Object> map = JacksonUtils.getObjectFromJsonString(consumerRecord.value().toString(), Map.class);
            GSI gsi = JacksonUtils.getObjectFromJsonString(JacksonUtils.toJson(map.get(DATA_KEY)), GSI.class);

            SchedulerRequestDto schedulerRequestDto = new SchedulerRequestDto();
            schedulerRequestDto.setTenantId((String) ((Map) (map.get(USER_CONTEXT_KEY))).get(TENANT_ID_KEY));
            schedulerRequestDto.setUserId(((Double) ((Map) (map.get(USER_CONTEXT_KEY))).get(USER_ID_KEY)).longValue());
            schedulerRequestDto.setUserEmail((String) ((Map) (map.get(USER_CONTEXT_KEY))).get(USER_EMAIL_KEY));

            schedulerUtil.scheduleJobForInbound(gsi, schedulerRequestDto);

        } catch (Exception e) {
            LOGGER.error("Exception while verifying gsi received from kafka", e);
        }
    }
}
