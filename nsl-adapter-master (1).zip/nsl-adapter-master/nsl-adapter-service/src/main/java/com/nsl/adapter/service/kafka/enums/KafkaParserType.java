package com.nsl.adapter.service.kafka.enums;

public enum KafkaParserType {
    JSON("json");

    private String dataType;

    private KafkaParserType(String dataType) {
        this.dataType = dataType;
    }

    public String getEntityCreationFileType() {
        return this.dataType;
    }

    public static KafkaParserType fromValue(String val) {
        for (KafkaParserType at : KafkaParserType.values()) {
            if (at.getEntityCreationFileType().equalsIgnoreCase(val)) {
                return at;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return String.valueOf(this.dataType);
    }
    
}
