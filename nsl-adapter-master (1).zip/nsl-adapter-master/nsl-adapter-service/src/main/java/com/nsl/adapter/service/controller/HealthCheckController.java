package com.nsl.adapter.service.controller;

import com.nsl.adapter.commons.dto.SchedulerRequestDto;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.SchedulerUtil;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.model.GSI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Locale;


@RestController
@CrossOrigin
public class HealthCheckController {

    @Autowired
    private MessageSource messageSource;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    SchedulerUtil schedulerUtil;

    @GetMapping(value = "/ping", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse healthCheck() {

        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, messageSource.getMessage("Paas_Adapter_20", null, Locale.ENGLISH) );
    }

    @GetMapping(value = "/ping/{Id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse healthCheck(@PathVariable("Id") Long id) {

        SchedulerRequestDto schedulerRequestDto = new SchedulerRequestDto();
        schedulerRequestDto.setTenantId(bean.getTenantId());
        schedulerRequestDto.setUserId(bean.getUserId());
        schedulerRequestDto.setUserEmail(bean.getEmailId());

        GSI gsi = changeUnitDao.getGsiById(id,bean);
        schedulerUtil.scheduleJobForInbound(gsi,schedulerRequestDto);

        return new ApiResponse(HttpStatus.ACCEPTED, AppConstant.SUCCESS, messageSource.getMessage("Paas_Adapter_20", null, Locale.ENGLISH) );
    }
}
