package com.nsl.adapter.service.dto.integration;

import java.util.ArrayList;
import java.util.List;

public class JsonEntityDto {
    String name;
    List<JsonAttributeDto> attributes = new ArrayList<>();

    public JsonEntityDto() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<JsonAttributeDto> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<JsonAttributeDto> attributes) {
        this.attributes = attributes;
    }
}
