package com.nsl.adapter.service.sftp.controller;

import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.service.config.AdminAuth;
import com.nsl.adapter.commons.dto.connections.SFTPAdapterConnectionDto;
import com.nsl.adapter.service.sftp.service.SFTPConnectionService;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@AdminAuth
@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class SFTPAdapterConnectionController {

    @Autowired
    SFTPConnectionService sftpConnectionService;

    @PostMapping(path = "/sftp" )
    public ApiResponse saveSftpConnection(@RequestBody SFTPAdapterConnectionDto connectionDto) throws NSLException {

        TxnAdapterConnection result = sftpConnectionService.saveSftpConn(connectionDto);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, result);
    }

    @GetMapping(path = "/sftp/{connId}")
    public ApiResponse getSftpConnection(@PathVariable("connId") Long connId) throws NSLException{

        SFTPAdapterConnectionDto result = sftpConnectionService.getSftpConn(connId,Boolean.FALSE);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, result);

    }

    @PutMapping(path = "/sftp/{connId}")
    public ApiResponse updateSftpConnection(@PathVariable("connId") Long connId, @RequestBody SFTPAdapterConnectionDto connectionDto) {

        TxnAdapterConnection result = sftpConnectionService.updateSftpConn(connectionDto,connId) ;
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, result);

    }

    @PostMapping(path = "/sftp/test" )
    public ApiResponse testSftpConnection(@RequestBody SFTPAdapterConnectionDto connectionDto) {
        return sftpConnectionService.testConnection(connectionDto);
    }

}