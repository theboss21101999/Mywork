package com.nsl.adapter.service.dto;


import com.nsl.adapter.commons.enums.ApiKeyLocation;
import com.nsl.adapter.commons.dto.connections.RESTAuthorizationType;
import java.util.Map;

public class CredentialPair {
    private ApiKeyLocation location;
    private Map<String, String> credentials;
    private RESTAuthorizationType authType;

    public ApiKeyLocation getLocation() {
        return location;
    }

    public void setLocation(ApiKeyLocation location) {
        this.location = location;
    }

    public Map<String, String> getCredentials() {
        return credentials;
    }

    public void setCredentials(Map<String, String> credentials) {
        this.credentials = credentials;
    }

    public RESTAuthorizationType getAuthType() {
        return authType;
    }

    public void setAuthType(RESTAuthorizationType authType) {
        this.authType = authType;
    }
}
