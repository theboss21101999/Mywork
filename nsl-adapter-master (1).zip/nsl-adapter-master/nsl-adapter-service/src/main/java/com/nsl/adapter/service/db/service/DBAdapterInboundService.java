package com.nsl.adapter.service.db.service;

import com.nsl.adapter.commons.dto.SchedulerRequestDto;
import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.service.kafka.enums.ConnectionType;
import com.nsl.adapter.service.kafka.listener.SFTPDataConfig;
import com.nsl.adapter.service.kafka.utils.KafkaProducerConnectionUtil;
import com.nsl.adapter.service.rest.service.ConnectionToGeneral;
import com.nsl.adapter.service.service.InboundIntegrationService;
import com.nsl.adapter.service.sftp.connection.AuthenticateUser;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.ExtSolutionUtil;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.model.ChangeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import static com.nsl.adapter.service.kafka.utils.KafkaConstants.CONNECTION_TYPE;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.TOPIC;

@Service
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class DBAdapterInboundService extends InboundIntegrationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DBAdapterInboundService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    ExtSolutionUtil extSolutionUtil;

    @Autowired
    ConnectionToGeneral connectionService;

    @Autowired
    AuthenticateUser authenticateUser;

    @Autowired
    SFTPDataConfig sftpDataConfig;


    @Override
    public ApiResponse publishMessage(SchedulerRequestDto schedulerRequestDto) {
        try {
            schedulerRequestDto = setAuthorizationBean(schedulerRequestDto);
            String eventId = UUID.randomUUID().toString();
            KafkaConnectionDto connectionDto = getKafkaConfig();
            KafkaProducerConnectionUtil kafkaProducerConnectionService = new KafkaProducerConnectionUtil(connectionDto);
            String kafkaMessage = augmentMessage(schedulerRequestDto, eventId);
            kafkaProducerConnectionService.sendMessageTokafka(kafkaMessage, sftpDataConfig.getSftpTopic());
            return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, eventId);
        } catch (Exception e) {
            LOGGER.error("Exception occured while publishing messages to kafka : {} ", e.getMessage());
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, AppConstant.FAILURE);
        }
    }

    public KafkaConnectionDto getKafkaConfig() {
        LOGGER.info("Getting Kafka Configuration..");
        KafkaConnectionDto kafkaConnectionDto = new KafkaConnectionDto();
        Properties config = new Properties();
        config.put(TOPIC, sftpDataConfig.getSftpTopic());
        config.put(CONNECTION_TYPE, ConnectionType.PLAINTEXT.name());
        kafkaConnectionDto.setBootstrapServer(Collections.singletonList(sftpDataConfig.getBootstrapServers()));
        kafkaConnectionDto.setAdvancedConfig(config);
        LOGGER.debug("Messages will be sent to topic - {}", sftpDataConfig.getSftpTopic());
        return kafkaConnectionDto;
    }

    public Map<String, String> getCuSystemProp(String cuName) {
        ChangeUnit changeUnit = changeUnitDao.getChangeUnitByName(cuName, requestScopedAuthenticatedUserBean);
        ChangeUnit sftpInboundCu = changeUnitDao.getChangeUnitById(changeUnit.getId(), requestScopedAuthenticatedUserBean);
        return sftpInboundCu.getCuSystemProperties();
    }

    private SchedulerRequestDto setAuthorizationBean(SchedulerRequestDto schedulerRequestDto) {

            schedulerRequestDto.setTenantId(requestScopedAuthenticatedUserBean.getTenantId());
            schedulerRequestDto.setUserId(requestScopedAuthenticatedUserBean.getUserId());
            schedulerRequestDto.setUserEmail(requestScopedAuthenticatedUserBean.getEmailId());

        return schedulerRequestDto;
    }

    private String augmentMessage(SchedulerRequestDto schedulerRequestDto, String eventId) {
        StringBuilder message = new StringBuilder();
        // message.append(AppConstant.FILENAME + ":").append(fileName).append("\r\n");
        message.append(AppConstant.CUNAME + ":").append(schedulerRequestDto.getName()).append("\r\n");
        message.append(AppConstant.USEREMAIL + ":").append(schedulerRequestDto.getUserEmail()).append("\r\n");
        message.append(AppConstant.USERID + ":").append(schedulerRequestDto.getUserId()).append("\r\n");
        message.append(AppConstant.TENANTID + ":").append(schedulerRequestDto.getTenantId()).append("\r\n");
        message.append(AppConstant.EVENT_ID + ":").append(eventId).append("\r\n");
        return message.toString();
    }
}
