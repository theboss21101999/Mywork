package com.nsl.adapter.service.rest.ssl;


import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Locale;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

public class SslContextConfig {

    @Autowired
    private MessageSource messageSource;

    private static final Logger LOGGER = LoggerFactory.getLogger(SslContextConfig.class);


    private TrustManager[] trustAllCerts = null;
    private String keymanageralgorithm = null;

    public SSLContext setupSslContext(SslConfig config_) throws NSLException {
        SSLContext sslContext = null;
        boolean trustall = false;

        try {
            String keyStorePath = config_.getKeystorePath();
            String trustStorePath = config_.getTrustStorePath();
            String keyStorePw = config_.getKeystorePassword();
            String trustStorePw = config_.getTrustStorePassword();
            String keyPass = config_.getKeyPass();
            String trustAllCertificate = config_.getTrustAllCertificate();
            String keystoreType = config_.getKeystoreType();
            keymanageralgorithm = config_.getKeyManagerAlgorithm();

            trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public X509Certificate[] getAcceptedIssuers() {
                            return null; //NOSONAR
                        }

                        public void checkClientTrusted(X509Certificate[] certs, String authType) {} //NOSONAR

                        public void checkServerTrusted(X509Certificate[] certs, String authType) {} //NOSONAR

                    }
            };
            if (trustAllCertificate.equalsIgnoreCase("True")) {
                trustall = true;
            }
            if (keystoreType.equalsIgnoreCase("JKS"))
                sslContext = initializeSSLContext(keyStorePath, keyStorePw, trustStorePath, trustStorePw, keyPass, trustall);
            else
                sslContext = initializeSSLContextP12Cert(keyStorePath, keyStorePw, trustStorePath, trustStorePw, keyPass, trustall);

        } catch (Exception e) {
            LOGGER.error("ConfigException exception occurred while reading the config file : " + e.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_69", null, Locale.ENGLISH) + e, ExceptionSeverity.MINOR, e);
        }
        return sslContext;
    }

    private SSLContext initializeSSLContext(final String keyStorePath, final String pwKeyStore,
                                            final String trustStorePath, final String pwTrustStore,
                                            final String keyPass, final boolean trustall) throws NSLException {
        LOGGER.info(" In initializeSSLContext");
        char[] keyStorePw = pwKeyStore.toCharArray();
        char[] trustStorePw = pwTrustStore.toCharArray();
        char[] keyPw = keyPass.toCharArray();
        SecureRandom secureRandom = new SecureRandom();
        secureRandom.nextInt();
        KeyStore ks = null;
        InputStream fis = null;
        KeyManagerFactory kmf = null;
        KeyStore ts = null;
        InputStream tfis = null;
        SSLContext sslContext = null;

        try {
            ks = KeyStore.getInstance("JKS");
            fis = new FileInputStream(keyStorePath); //NOSONAR
            ks.load(fis, keyStorePw);
            kmf = KeyManagerFactory.getInstance(keymanageralgorithm);
            kmf.init(ks, keyPw);
            ts = KeyStore.getInstance("JKS");
            tfis = new FileInputStream(trustStorePath); //NOSONAR
            ts.load(tfis, trustStorePw);
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(keymanageralgorithm);
            tmf.init(ts);
            LOGGER.info("[initializeSSLContext] Truststore initialized");
            sslContext = SSLContext.getInstance("TLS");

            if (trustall)
                sslContext.init(kmf.getKeyManagers(), trustAllCerts, secureRandom);
            else
                sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), secureRandom);

        } catch (NoSuchAlgorithmException exp) {
            LOGGER.error("NoSuchAlgorithmException exception occurred " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_70", null, Locale.ENGLISH) + exp, ExceptionSeverity.MINOR, exp);
        } catch (CertificateException exp) {
            LOGGER.error("CertificateException exception occurred " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_71", null, Locale.ENGLISH) + exp, ExceptionSeverity.MINOR, exp);
        } catch (IOException exp) {
            LOGGER.error("IOException occurred while reading the key file  " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_72", null, Locale.ENGLISH) + exp, ExceptionSeverity.MINOR, exp);
        } catch (KeyStoreException exp) {
            LOGGER.error("KeyStoreException exception occurred " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_73", null, Locale.ENGLISH)  + exp, ExceptionSeverity.MINOR, exp);
        } catch (KeyManagementException exp) {
            LOGGER.error("KeyManagementException exception occurred " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_74", null, Locale.ENGLISH) + exp, ExceptionSeverity.MINOR, exp);
        } catch (UnrecoverableKeyException exp) {
            LOGGER.error("UnrecoverableKeyException exception occurred " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_75", null, Locale.ENGLISH) + exp, ExceptionSeverity.MINOR, exp);
        } finally {
            if (fis != null)
                try {
                    fis.close();
                } catch (IOException exp) {
                    LOGGER.error("IOException exception occurred " + exp.getMessage());
                }
            if (tfis != null)
                try {
                    tfis.close();
                } catch (IOException exp) {
                    LOGGER.error("Exception occurred " + exp.getMessage());
                }
        }
        if (sslContext == null) {
            LOGGER.error("[initializeSSLContext] sslContext is null");
            LOGGER.error("[initializeSSLContext] verify ssl config");
        }
        return sslContext;
    }

    private SSLContext initializeSSLContextP12Cert(final String keyStorePath, final String pwKeyStore,
                                                   final String trustStorePath, final String pwTrustStore,
                                                   final String keyPass, final boolean trustall) throws NSLException {
        LOGGER.info("In initializeSSLContextP12Cert");
        SSLContext sslContext = null;
        String keystore = keyStorePath;
        String keystorepass = pwKeyStore;
        String truststore = trustStorePath;
        String truststorepass = pwTrustStore;

        try {
            KeyStore clientStore = KeyStore.getInstance("PKCS12");
            clientStore.load(new FileInputStream(keystore), keystorepass.toCharArray()); //NOSONAR

            KeyManagerFactory kmf = KeyManagerFactory.getInstance(keymanageralgorithm);
            kmf.init(clientStore, keystorepass.toCharArray());
            KeyManager[] kms = kmf.getKeyManagers();

            KeyStore trustStore = KeyStore.getInstance("JKS");
            trustStore.load(new FileInputStream(truststore), truststorepass.toCharArray()); //NOSONAR

            TrustManagerFactory tmf = TrustManagerFactory.getInstance(keymanageralgorithm);
            tmf.init(trustStore);
            TrustManager[] tms = tmf.getTrustManagers();
            sslContext = SSLContext.getInstance("TLS");

            if (trustall)
                sslContext.init(kms, trustAllCerts, new SecureRandom());
            else
                sslContext.init(kms, tms, new SecureRandom()); //NOSONAR
        } catch (NoSuchAlgorithmException exp) {
            LOGGER.error("NoSuchAlgorithmException exception occurred " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_167", null, Locale.ENGLISH)  + exp, ExceptionSeverity.MINOR, exp);
        } catch (CertificateException exp) {
            LOGGER.error("CertificateException exception occurred " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_168", null, Locale.ENGLISH)+ exp, ExceptionSeverity.MINOR, exp);
        } catch (IOException exp) {
            LOGGER.error("IOException occurred while reading the key file  " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_169", null, Locale.ENGLISH) + exp, ExceptionSeverity.MINOR, exp);
        } catch (KeyStoreException exp) {
            LOGGER.error("KeyStoreException exception occurred " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_170", null, Locale.ENGLISH) + exp, ExceptionSeverity.MINOR, exp);
        } catch (KeyManagementException exp) {
            LOGGER.error("KeyManagementException exception occurred " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_171", null, Locale.ENGLISH) + exp, ExceptionSeverity.MINOR, exp);
        } catch (UnrecoverableKeyException exp) {
            LOGGER.error("UnrecoverableKeyException exception occurred " + exp.getMessage());
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_172", null, Locale.ENGLISH) + exp, ExceptionSeverity.MINOR, exp);
        }

        if ((sslContext == null)) { //NOSONAR
            LOGGER.error("[initializeSSLContext] sslContext is null");
            LOGGER.error("[initializeSSLContext] verify ssl config");
            LOGGER.error("MyREST application exit with status code -1");
        }
        LOGGER.info("[initializeSSLContextP12Cert] Truststore and KeyStore initialized");
        return sslContext;
    }
}