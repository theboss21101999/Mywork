package com.nsl.adapter.service.s3.utill;

import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.S3AdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.Locale;

@Service
public class S3ConnectionDataTools {

    private static final Logger LOGGER = LoggerFactory.getLogger(S3ConnectionDataTools.class);

    private static final ConnectionDtoType connType = ConnectionDtoType.S3;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;

    @Autowired
    MessageSource messageSource;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    public TxnAdapterConnection saveS3Conn(S3AdapterConnectionDto connectionDto) {

        if ( connectionDto.getSecretKey() == null || connectionDto.getAccessKey() == null
                || connectionDto.getRegion() == null || connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,
                                messageSource.getMessage("Paas_Adapter_184", null, Locale.ENGLISH) , null);

        connectionDataToolsV3.connectionCheck(ConnectionDtoType.S3, connectionDto.getConnectionName(), authBean);

        connectionDto.setSecretKey(connectionDataToolsV3.saveSecret(connType,"secretKey",
                connectionDto.getConnectionName(),authBean.getTenantId(),connectionDto.getSecretKey()));

        TxnAdapterConnection connection = new TxnAdapterConnection();
        connection.setConnectionDtoType(connType);
        connection.setConnection(connectionDto);

        LOGGER.info("saving S3 connection");
        return adapterConnnectionsDao.saveConnection(connection,authBean );
    }

    public TxnAdapterConnection updateS3Conn(S3AdapterConnectionDto connectionDto ,Long connId) {

        if ( connectionDto.getAccessKey() == null || connectionDto.getRegion() == null ||
                                                                        connectionDto.getConnectionName() == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_179", null, Locale.ENGLISH) , null);

        TxnAdapterConnection previousConnection = adapterConnnectionsDao.getConnectionByRecordId(connType, connId ,authBean);
        connectionDataToolsV3.connectionNameCheck(previousConnection,connectionDto.getConnectionName());

        connectionDto.setSecretKey(connectionDataToolsV3.updateSecret(connType,"secretKey",
                connectionDto.getConnectionName(),authBean.getTenantId(),connectionDto.getSecretKey()));

        previousConnection.setConnection(connectionDto);

        return adapterConnnectionsDao.saveConnection(previousConnection, authBean );
    }

    public S3AdapterConnectionDto getS3Conn(Long connId, Boolean hide) {

        TxnAdapterConnection entityRecord = adapterConnnectionsDao.getConnectionByRecordId(connType, connId ,authBean);
        return txnToS3(entityRecord , hide);
    }

    public S3AdapterConnectionDto getS3Conn(Long connId, AuthenticatedUserDetailsImpl authBean) {

        TxnAdapterConnection entityRecord = adapterConnnectionsDao.getConnectionByRecordId(connType, connId ,authBean);
        return txnToS3(entityRecord , Boolean.FALSE);
    }

    public S3AdapterConnectionDto txnToS3(TxnAdapterConnection entityRecord, Boolean hide) {

        S3AdapterConnectionDto connectionDto = (S3AdapterConnectionDto) entityRecord.getConnection();

        if (connectionDto == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,  messageSource.getMessage("Paas_Adapter_83", null, Locale.ENGLISH), null);

        if (!hide)
            connectionDto.setSecretKey(connectionDataToolsV3.getSecret(connectionDto.getSecretKey()));

        return connectionDto;
    }

}
