package com.nsl.adapter.service.exception;

public class ExtAPIException extends RuntimeException {

    /**
     * Exception class for ExtAPI
     */
    private static final long serialVersionUID = 1L;

    public ExtAPIException(String message) {
        super("ExtAPI: " + message);
    }

    public ExtAPIException(String message, Throwable t) {
        super("ExtAPI: " + message, t);
    }
}