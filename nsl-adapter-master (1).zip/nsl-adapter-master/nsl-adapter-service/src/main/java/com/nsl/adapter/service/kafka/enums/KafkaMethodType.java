package com.nsl.adapter.service.kafka.enums;

public enum KafkaMethodType {
    INBOUND,
    OUTBOUND
}
