package com.nsl.adapter.service.inboundcu.service;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.service.service.IntegrationService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.nsl.adapter.service.inboundcu.utils.RestInboundConstants.FILESUPPORT;
import static com.nsl.adapter.service.inboundcu.utils.RestInboundConstants.ISFormData;
import static com.nsl.adapter.service.utils.AppConstant.METAINFO_ENTITY_KEY;
import static com.nsl.adapter.service.v2.utills.EntityConstants.RESTINBOUND_FILE;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class RestInboundIntegrationService implements IntegrationService {

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Autowired
    SaveBetsService saveBetsService;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    MessageSource messageSource;

    @Override
    public CUPropsDto getSaveProperties(IntegrationDtoV3 integrationDto) throws NSLException {

        if (!validate(integrationDto.getPropertiesMap()))
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,messageSource.getMessage("Paas_Adapter_116", null, Locale.ENGLISH), ExceptionSeverity.MAJOR);

        CUPropsDto cuPropsDto = new CUPropsDto();
        HashMap<String, String> cuSystemProps = new HashMap<>(integrationDto.getPropertiesMap());
        List<TenantCUEntityInput> physicalLayerItems = new ArrayList<>();

        if (Boolean.TRUE.toString().equalsIgnoreCase(cuSystemProps.get(FILESUPPORT))) {
            cuSystemProps.put(AppConstant.FILEENTITYNAME,RESTINBOUND_FILE);
            physicalLayerItems.add(saveBetsService.getEntityByName(RESTINBOUND_FILE));
        }

        if (integrationDto.getInputEntityDsdId() != null){
            TenantCUEntityInput requestEntityInput = saveBetsService.findEntityById(integrationDto.getInputEntityDsdId());
            physicalLayerItems.add(requestEntityInput);
            cuSystemProps.put(AppConstant.REQUESTID,requestEntityInput.getName());
        }
        if(cuSystemProps.containsKey(AppConstant.HEADERENTITYID)) {
            TenantCUEntityInput headerEntity = saveBetsService.findEntityById(cuSystemProps.get(AppConstant.HEADERENTITYID));
            physicalLayerItems.add(headerEntity);
            cuSystemProps.put(AppConstant.HEADERENTITYNAME ,headerEntity.getName());

        }
        if(cuSystemProps.containsKey(AppConstant.QUERYPARAMENTITYID)) {
            TenantCUEntityInput queryEntity = saveBetsService.findEntityById(cuSystemProps.get(AppConstant.QUERYPARAMENTITYID));
            physicalLayerItems.add(queryEntity);
            cuSystemProps.put(AppConstant.QUERYPARAMENTITYNAME ,queryEntity.getName());
        }

        String metaInfoEntityId = metaInfoEntityUtils.createMetaInfoEntity(integrationDto.getIntegrationName(), authBean);
        cuSystemProps.put(METAINFO_ENTITY_KEY, metaInfoEntityId);
        cuPropsDto.setPhysicalLayerItems(buildSlotItems(physicalLayerItems));
        cuPropsDto.setCuSystemProps(cuSystemProps);
        cuPropsDto.setIsMachineCU(Boolean.FALSE);
        return cuPropsDto;
    }

    @Override
    public void getIntegration(IntegrationDtoV3 integrationDto, CUPropsDto cuPropsDto) {

        if (!cuPropsDto.getCuSystemProps().containsKey(AppConstant.REQUESTID))
            return;

        getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).forEach( x-> {
            if (x.getName().equals(cuPropsDto.getCuSystemProps().get(AppConstant.REQUESTID)))
                integrationDto.setInputEntityDsdId(x.getDsdId());
        });

    }

    @Override
    public CUPropsDto getUpdateProperties(CUPropsDto cuPropsDto, IntegrationDtoV3 integrationDto) throws NSLException {

        if (!validate(integrationDto.getPropertiesMap()))
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"please send valid data", ExceptionSeverity.MAJOR);

        Map<String, String> propsMap = integrationDto.getPropertiesMap();

        Map<String, String> cuSystemProps = cuPropsDto.getCuSystemProps();
        cuSystemProps.putAll(propsMap);
        List<TenantCUEntityInput> physicalLayerItems = new ArrayList<>();

        if (Boolean.TRUE.toString().equalsIgnoreCase(propsMap.get(FILESUPPORT))) {
            cuSystemProps.put(AppConstant.FILEENTITYNAME,RESTINBOUND_FILE);
            physicalLayerItems.add(saveBetsService.getEntityByName(RESTINBOUND_FILE));
        }else
            cuSystemProps.remove(AppConstant.FILEENTITYNAME);

        if (integrationDto.getInputEntityDsdId() != null){
            TenantCUEntityInput requestEntityInput = saveBetsService.findEntityById(integrationDto.getInputEntityDsdId());
            physicalLayerItems.add(requestEntityInput);
            cuSystemProps.put(AppConstant.REQUESTID,requestEntityInput.getName());
        }else
            cuSystemProps.remove(AppConstant.REQUESTID);

        if(propsMap.containsKey(AppConstant.HEADERENTITYID)) {
            TenantCUEntityInput headerEntity = saveBetsService.findEntityById(propsMap.get(AppConstant.HEADERENTITYID));
            physicalLayerItems.add(headerEntity);
            cuSystemProps.put(AppConstant.HEADERENTITYNAME ,headerEntity.getName());
        }else {
            cuSystemProps.remove(AppConstant.HEADERENTITYNAME);
            cuSystemProps.remove(AppConstant.HEADERENTITYID);
        }

        if(propsMap.containsKey(AppConstant.QUERYPARAMENTITYID)) {
            TenantCUEntityInput queryEntity = saveBetsService.findEntityById(propsMap.get(AppConstant.QUERYPARAMENTITYID));
            physicalLayerItems.add(queryEntity);
            cuSystemProps.put(AppConstant.QUERYPARAMENTITYNAME ,queryEntity.getName());
        }else {
            cuSystemProps.remove(AppConstant.QUERYPARAMENTITYNAME);
            cuSystemProps.remove(AppConstant.QUERYPARAMENTITYID);
        }

        cuPropsDto.setPhysicalLayerItems(buildSlotItems(physicalLayerItems));
        cuPropsDto.setCuSystemProps(cuSystemProps);
        return cuPropsDto;

    }

    private boolean validate(Map<String, String> propertiesMap) {
        return propertiesMap.containsKey(FILESUPPORT) && propertiesMap.containsKey(ISFormData);
    }

}
