package com.nsl.adapter.service.ses.controller;

import com.nsl.adapter.commons.dto.connections.SESConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.ses.service.SesConnectionService;
import com.nsl.adapter.service.utils.AppConstant;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value="/connect")
public class SesConnectionController {

    @Autowired
    SesConnectionService sesConnectionService;

    @PostMapping(path = "/ses" , consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveSesConnection(@RequestBody SESConnectionDto connectionDto) {
        TxnAdapterConnection result = sesConnectionService.saveSesConnection(connectionDto);
        JSONObject jsonObject = new JSONObject(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
    @GetMapping(path = "/ses/{id}")
    public ApiResponse getSesConnection(@PathVariable("id") Long id) {
        SESConnectionDto response = sesConnectionService.getSesConnection(id, false);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @PutMapping(path = "/ses/{id}" , consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse updateSesConnection(@PathVariable("id") Long id,
                                           @RequestBody SESConnectionDto connectionDto ) {
        TxnAdapterConnection result = sesConnectionService.updateSesConnection(id, connectionDto);
        JSONObject jsonObject = new JSONObject(result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }
}