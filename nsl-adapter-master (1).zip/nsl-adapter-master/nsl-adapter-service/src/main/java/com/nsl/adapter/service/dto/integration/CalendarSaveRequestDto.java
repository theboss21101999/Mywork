package com.nsl.adapter.service.dto.integration;

public class CalendarSaveRequestDto {
    String integrationName ;
    String adapterType;
    String methodType;
    String inputEntityId;
    String inputEntityFileType;
    String outputEntityId;
    String outputEntityFileType;
    String configEntityRecordId;
    String uri;
    String webexEntityRecordId;
    String exceptionGsiId;

    public String getIntegrationName() {
        return integrationName;
    }

    public void setIntegrationName(String integrationName) {
        this.integrationName = integrationName;
    }

    public String getAdapterType() {
        return adapterType;
    }

    public void setAdapterType(String adapterType) {
        this.adapterType = adapterType;
    }

    public String getMethodType() {
        return methodType;
    }

    public void setMethodType(String methodType) {
        this.methodType = methodType;
    }

    public String getInputEntityId() {
        return inputEntityId;
    }

    public void setInputEntityId(String inputEntityId) {
        this.inputEntityId = inputEntityId;
    }

    public String getInputEntityFileType() {
        return inputEntityFileType;
    }

    public void setInputEntityFileType(String inputEntityFileType) {
        this.inputEntityFileType = inputEntityFileType;
    }

    public String getOutputEntityId() {
        return outputEntityId;
    }

    public void setOutputEntityId(String outputEntityId) {
        this.outputEntityId = outputEntityId;
    }

    public String getOutputEntityFileType() {
        return outputEntityFileType;
    }

    public void setOutputEntityFileType(String outputEntityFileType) {
        this.outputEntityFileType = outputEntityFileType;
    }

    public String getConfigEntityRecordId() {
        return configEntityRecordId;
    }

    public void setConfigEntityRecordId(String configEntityRecordId) {
        this.configEntityRecordId = configEntityRecordId;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getWebexEntityRecordId() {
        return webexEntityRecordId;
    }

    public void setWebexEntityRecordId(String webexEntityRecordId) {
        this.webexEntityRecordId = webexEntityRecordId;
    }

    public String getExceptionGsiId() {
        return exceptionGsiId;
    }

    public void setExceptionGsiId(String exceptionGsiId) {
        this.exceptionGsiId = exceptionGsiId;
    }
}
