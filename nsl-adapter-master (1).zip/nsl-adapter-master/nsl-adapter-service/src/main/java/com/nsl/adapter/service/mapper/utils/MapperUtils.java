package com.nsl.adapter.service.mapper.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nsl.adapter.commons.utils.AppConstants;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.datatypes.primitives.NSLList;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JsonParser;
import org.springframework.context.MessageSource;
import org.springframework.data.util.StreamUtils;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import static com.nsl.logical.enums.DataType.LIST;
import static com.nsl.logical.enums.ErrorType.VALIDATION;

@Service
public class MapperUtils {
    @Autowired
    private MessageSource messageSource;

    public void setResultInTriggerCES(ObjectNode mapperResult, TxnData transData, TriggerCU triggerCU) throws NSLException {
        Map<String, GeneralEntity> triggerCESGenEntities = new HashMap<>();
        List<TxnCULayer> txnCuLayers = transData.getTxnCULayer();

        GeneralEntityUtils.getTriggerCUGeneralEntities(triggerCU, AppConstants.TRIGGER_CES_LAYER, triggerCESGenEntities);
        List<TxnSlotItem> triggerCesTxnEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnCuLayers, AppConstants.TRIGGER_CES_LAYER);

        for (TxnSlotItem txnSlotItem : triggerCesTxnEntityDetails){
            if(txnSlotItem!= null && txnSlotItem.getItem() instanceof TxnGeneralEntity){
                TxnGeneralEntity txnGeneralEntity = (TxnGeneralEntity) txnSlotItem.getItem();
//              In case of multivalued record, generate multiple  txnGeneralEntityRecord
                if(triggerCESGenEntities.containsKey(txnGeneralEntity.getName()) && mapperResult.has(txnGeneralEntity.getName())){

                            setRecordsInTxnGenEntity(txnGeneralEntity, mapperResult.get(txnGeneralEntity.getName()), triggerCESGenEntities.get(txnGeneralEntity.getName()));
                }
            }
        }
    }

    public void generateTcesLayerIfAbsent(List<TxnCULayer> txnCULayers, TriggerCU triggerCU) {

        List<SlotItem> slotItems = GeneralEntityUtils.getTriggerCUSlotItemsList(triggerCU.getLayers(),AppConstants.TRIGGER_CES_LAYER);

        for (TxnCULayer txnCULayer : txnCULayers){
            if(LayerType.TRIGGERCES == txnCULayer.getType()){
                List<TxnSlotItem> txnSlotItems = GeneralEntityUtils.getTransEntityDetails(txnCULayers, AppConstants.TRIGGER_CES_LAYER);
                if(txnSlotItems.size() != slotItems.size()){
                    throw new NSLException(VALIDATION, ExceptionCategory.RESERVED_CU, String.format(messageSource.getMessage("Paas_Adapter_Mapper_7", null, Locale.ENGLISH)),
                            ExceptionSeverity.MINOR);
                }

                for (int i = 0; i<txnSlotItems.size(); i++){
                    TxnSlotItem txnSlotItem = txnSlotItems.get(i);
                    if (txnSlotItem == null || txnSlotItem.getItem() == null)
                        txnSlotItems.set(i,getTxnSlotItem(slotItems.get(i)));
                }
                return;
            }
        }
        List<TxnSlotItem> txnSlotItems = new ArrayList<>();

        for (SlotItem slotItem : slotItems){
            TxnSlotItem txnSlotItem = getTxnSlotItem(slotItem);
            txnSlotItems.add(txnSlotItem);
        }
        TxnCULayer triggerCESLayer = new TxnCULayer(LayerType.TRIGGERCES, txnSlotItems);
        txnCULayers.add(triggerCESLayer);
    }


    private static TxnSlotItem getTxnSlotItem(SlotItem slotItem) {
        TxnSlotItem txnSlotItem = new TxnSlotItem();
        txnSlotItem.setIsMultiValue(slotItem.getIsMultiValue());
        TxnGeneralEntity txnGeneralEntity = getTxnGeneralEntity(slotItem);
        txnSlotItem.setItem(txnGeneralEntity);
        return txnSlotItem;
    }

    private static TxnGeneralEntity getTxnGeneralEntity(SlotItem slotItem) {
        GeneralEntity generalEntity = (GeneralEntity) slotItem.getItem();
        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity(generalEntity.getName(), generalEntity.getId());
        return txnGeneralEntity;
    }

    private void setRecordsInTxnGenEntity(TxnGeneralEntity txnGeneralEntity, JsonNode attributeValueMap, GeneralEntity generalEntity) throws NSLException{

        List<TxnGeneralEntityRecord> txnGeneralEntityRecords = new ArrayList<>();
        if(attributeValueMap instanceof ObjectNode){
            ArrayNode singletonRecordList = new ObjectMapper().createArrayNode();
            singletonRecordList.add(attributeValueMap);
            attributeValueMap = singletonRecordList;
        }
        // For multi-value record attributeValueMap would be a list of map, so process in a loop
        int recordIdentifier = 0;
        for(JsonNode jsonElement :  attributeValueMap){
            TxnGeneralEntityRecord txnGeneralEntityRecord = setResultInTxnGeneralEntityRecord(generalEntity, jsonElement);
            txnGeneralEntityRecord.setGeneralEntityId(generalEntity.getId());
            txnGeneralEntityRecord.setRecordIdentifier(recordIdentifier);
            txnGeneralEntityRecords.add(txnGeneralEntityRecord);
            recordIdentifier++;
        }
        txnGeneralEntity.setTransEntityRecords(txnGeneralEntityRecords);
    }


    private TxnGeneralEntityRecord setResultInTxnGeneralEntityRecord(GeneralEntity generalEntity, JsonNode attValueMap) throws NSLException{
        TxnGeneralEntityRecord txnGeneralEntityRecord = new TxnGeneralEntityRecord();

        if(generalEntity==null || generalEntity.getNslAttributes()==null || generalEntity.getNslAttributes().isEmpty())
            return txnGeneralEntityRecord;

        List<TxnNslAttribute> txnNslAttributes = new ArrayList<>();
        for(NslAttribute nslAttribute : generalEntity.getNslAttributes()) {
            TxnNslAttribute attribute = new TxnNslAttribute();
            attribute.setName(nslAttribute.getName());
            attribute.setNslAttributeID(nslAttribute.getId());

            if(nslAttribute.getGeneralEntity()==null) {
                setAttributeValue(attribute, attValueMap.get(nslAttribute.getName()), nslAttribute);
            } else{
                GeneralEntity nestedGenEntity = nslAttribute.getGeneralEntity();
                TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity();
                txnGeneralEntity.setGeneralEntityID(nestedGenEntity.getId());
                txnGeneralEntity.setName(nestedGenEntity.getName());
                attribute.setTxnGeneralEntity(txnGeneralEntity);

                JsonNode nestedEntityMap = attValueMap.get(nslAttribute.getName());
                setRecordsInTxnGenEntity(txnGeneralEntity, nestedEntityMap, nestedGenEntity);
            }
            txnNslAttributes.add(attribute);
        }
        txnGeneralEntityRecord.setTxnNslAttribute(txnNslAttributes);

        return txnGeneralEntityRecord;
    }

    private void setAttributeValue(TxnNslAttribute txnNslAttribute, JsonNode attValueMap, NslAttribute nslAttribute) throws NSLException{
        List<String> values = new ArrayList<>();
        if(StringUtils.isNotEmpty(nslAttribute.getDefaultValue())){
            values.add(nslAttribute.getDefaultValue());
        }

        if(attValueMap != null){

            if(attValueMap instanceof ArrayNode && LIST == nslAttribute.getAttributeType().getType()){
                values = new ArrayList<>();
                for(JsonNode jsonElement :  attValueMap){
                    values.add(jsonElement.asText());
                }
            }else if(attValueMap.isValueNode()) {
                if(CollectionUtils.isNotEmpty(values)){
                    values.set(0, attValueMap.asText());
                } else{
                    values.add(attValueMap.asText());
                }
            } else{
                throw new NSLException(VALIDATION, ExceptionCategory.RESERVED_CU, String.format(messageSource.getMessage("Paas_Adapter_Mapper_6", null, Locale.ENGLISH), nslAttribute.getName()),
                        ExceptionSeverity.MINOR);
            }

        }
        txnNslAttribute.setValues(values);
    }

    /*
       Mapper engine return result as array of json objects
       The below function creates a map with entity name as key and the att-value map as value
     */
    public ObjectNode getMapperResponseAsMap(ArrayNode mapperResult) {

        ObjectNode jsonObject = new ObjectMapper().createObjectNode();
        for (JsonNode jsonElement : mapperResult) {
            ObjectNode jsonObj = (ObjectNode) jsonElement;
            Iterator<String> fieldNames = jsonObj.fieldNames();
            if (fieldNames.hasNext()) {
                String key = fieldNames.next();
                JsonNode records = jsonObj.get(key);
                jsonObject.set(key, records);
            }
        }
        return jsonObject;
    }

    public StringBuilder validate(TriggerCU triggerCU, TxnData transData){

        StringBuilder stringBuilder = new StringBuilder();

        List<TxnCULayer> txnCuLayers = transData.getTxnCULayer();
        List<String> layerTypes= Arrays.asList(AppConstants.PHYSICAL_LAYER,AppConstants.INFORMATION_LAYER,AppConstants.TRIGGER_CES_LAYER);

        for(String layerType: layerTypes){
            List<TxnSlotItem> transEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnCuLayers, layerType);
            List<GeneralEntity> genEntities = GeneralEntityUtils.getTriggerCUMultipleGeneralEntities(triggerCU, layerType);
                if(AppConstants.INFORMATION_LAYER.equals(layerType)) {
                    if (!(genEntities.isEmpty() && transEntityDetails.isEmpty())) {
                        stringBuilder.append(messageSource.getMessage("Paas_Adapter_Mapper_3", null, Locale.ENGLISH));
                    }
                } else{
                    if (genEntities.isEmpty()) {
                        stringBuilder.append(String.format(messageSource.getMessage("Paas_Adapter_Mapper_2", null, Locale.ENGLISH), layerType));
                    }

                    Map<String, GeneralEntity> genEntitiesMap = new HashMap<>();
                    GeneralEntityUtils.getTriggerCUGeneralEntities(triggerCU, layerType, genEntitiesMap);
                    if (genEntities.size() != genEntitiesMap.size()) {
                        stringBuilder.append(String.format(messageSource.getMessage("Paas_Adapter_Mapper_4", null, Locale.ENGLISH), layerType));
                    }

                    if(AppConstants.PHYSICAL_LAYER.equals(layerType)){
                        if (transEntityDetails.isEmpty()) {
                            stringBuilder.append(String.format(messageSource.getMessage("Paas_Adapter_Mapper_2", null, Locale.ENGLISH), layerType));
                        }
                        List<TxnSlotItem> multiValuedEntity = transEntityDetails.stream().filter(TxnSlotItem::getIsMultiValue).collect(Collectors.toList());
                        if(multiValuedEntity.size() > 1){
                            stringBuilder.append(String.format(messageSource.getMessage("Paas_Adapter_Mapper_5", null, Locale.ENGLISH), layerType));
                        }
                    }
                }
        }
        return stringBuilder;
    }
}