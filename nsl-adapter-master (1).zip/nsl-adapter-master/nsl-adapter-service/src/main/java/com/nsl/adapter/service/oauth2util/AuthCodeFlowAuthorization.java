package com.nsl.adapter.service.oauth2util;

import com.github.scribejava.core.builder.ServiceBuilder;
import com.github.scribejava.core.oauth.OAuth20Service;
import com.nsl.adapter.commons.dto.connections.OAuthCredentials;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.dto.CredentialPair;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


/**
 * This class is for : AuthCodeFlowAuthorization.
 */
@Component
public class AuthCodeFlowAuthorization extends OAuth2FlowAuthorization {

    private static final Logger logger = LoggerFactory.getLogger(AuthCodeFlowAuthorization.class);
    /**
     * This Object is : .
     */

    /**
     * This Object is : .
     */

    @Autowired
    private AdaptorProperties adaptorProperties;

    /**
     * This Object is : .
     */

    @Autowired
    private MessageSource messageSource;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Override
    public CredentialPair getCredentialPair(RESTAdapterConnectionDto restConnectionDto) throws NSLException {
        OAuthCredentials oauthCredentials = restConnectionDto.getAuthentication().getOAuthCredentials();
        final String clientId = oauthCredentials.getClientId();
        final String clientSecret =connectionDataToolsV3.getSecret(oauthCredentials.getClientSecret());
        final OAuth20Service service = new ServiceBuilder(clientId)
                .apiSecret(clientSecret)
                .callback(adaptorProperties.getAppOauthCallbackUrl())
                .build(new Oauth20Api(oauthCredentials));

        String accessToken = null;
        try {
            accessToken =service.refreshAccessToken(connectionDataToolsV3.getSecret(restConnectionDto.getAuthentication().getOAuthCredentials().getRefreshToken())).getAccessToken();
        } catch (Exception e) {
            throw new NSLException(ErrorType.UNAUTHORIZED, ExceptionCategory.ACCESS_PERMISSION,
                    messageSource.getMessage("Paas_Adapter_56", null, Locale.ENGLISH), ExceptionSeverity.CRITICAL);
        }

        CredentialPair pair = new CredentialPair();
        Map<String, String> map = new HashMap<>();

        map.put("Authorization", AppConstant.BEARER+accessToken);
        pair.setLocation(oauthCredentials.getLocation());
        pair.setCredentials(map);
        return pair;
    }


    @Override
    public String getDefaultGrantType() {
        return "authorization_code";
    }

}
