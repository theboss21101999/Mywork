package com.nsl.adapter.service.kafka.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.service.rest.utils.ConnectionDataTools;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.CreateGeneralEntityCUDao;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.dao.SearchCUDAO;
import com.nsl.logical.dto.search.TxnGeneralEntitySearchRequest;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnNslAttribute;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.nsl.adapter.service.kafka.utils.KafkaConstants.ADVANCED_CONFIG;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.AUTHENTICATION;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.KAFKA_CONNECTION;

@Service
public class ConnectionToEntity {

    @Autowired
    GeneralEntityDao generalEntityDao;

    @Autowired
    private CreateGeneralEntityCUDao createGeneralEntityCUDao;

    @Autowired
    SearchCUDAO searchCUDAO;

    @Autowired
    ConnectionDataTools connectionDataTools;

    @Autowired
    KafkaConnectionTools connectionTools;

    @Autowired
    private MessageSource messageSource;


    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;


    public TxnGeneralEntityRecord saveKafkaConnection(KafkaConnectionDto connection) throws NSLException {

        GeneralEntity generalEntity = generalEntityDao.findByName(KAFKA_CONNECTION, requestScopedAuthenticatedUserBean);

        if (generalEntity==null)
            throw new NSLException(ErrorType.NOT_FOUND,
                    ExceptionCategory.GENERAL_ENTITY, messageSource.getMessage("Paas_Adapter_33", null, Locale.ENGLISH) + KAFKA_CONNECTION, null);

        JsonNode json= JacksonUtils.getValueToTree(connection);
//        Attributes
        List<TxnNslAttribute> attributesList= new ArrayList<TxnNslAttribute>();  //Attributes List
        for (NslAttribute nslAttribute : generalEntity.getNslAttributes()){
            if (json.has(nslAttribute.getName())){
                String text = "";
                if (nslAttribute.getName().equals(AUTHENTICATION) || nslAttribute.getName().equals(ADVANCED_CONFIG)){
                    text = JacksonUtils.toJson(json.get(nslAttribute.getName()));
                    System.out.println(text);
                    text = connectionDataTools.encryptText(text);
                }else {
                    text = json.get(nslAttribute.getName()).asText();
                }
                TxnNslAttribute dataAttribute = connectionDataTools.createNslAttribute(nslAttribute,text);
                attributesList.add(dataAttribute);

            }
        }
//        Entity Record
        TxnGeneralEntityRecord entityRecord = new TxnGeneralEntityRecord();  //Entity Record --> Attributes
        entityRecord.setTxnNslAttribute(attributesList);
        List<TxnGeneralEntityRecord> entityRecordList = new ArrayList<TxnGeneralEntityRecord>();
        entityRecordList.add(entityRecord);
//        General Entity
        TxnGeneralEntity txnGeneralEntity = new TxnGeneralEntity(); //General Entity --> Entity Record --> Attributes
        txnGeneralEntity.setName(generalEntity.getName());
        txnGeneralEntity.setTransEntityRecords(entityRecordList);
        txnGeneralEntity.setGeneralEntityID(generalEntity.getId());
//        Saving
        List<TxnGeneralEntity> generalEntityList= new ArrayList<TxnGeneralEntity>();
        generalEntityList.add(txnGeneralEntity);
        List<TxnGeneralEntityRecord> result = createGeneralEntityCUDao.saveEntities(generalEntityList,requestScopedAuthenticatedUserBean);
        return result.get(0);

    }

    public void setRequestScopedAuthenticatedUserBean(AuthenticatedUserDetailsImpl user){
        this.requestScopedAuthenticatedUserBean = user;
    }

    public KafkaConnectionDto getConnectionById(Long connectionId) {
        GeneralEntity generalEntity = generalEntityDao.findByName(KAFKA_CONNECTION, requestScopedAuthenticatedUserBean);
        if (generalEntity==null){
            return null;
        }
        TxnGeneralEntitySearchRequest dto1= new TxnGeneralEntitySearchRequest();
        dto1.setGeneralEntity(generalEntity);
        List<TxnGeneralEntitySearchRequest> generalEntityList = new ArrayList<>();
        generalEntityList.add(dto1);
        List<TxnGeneralEntityRecord> resultList = searchCUDAO.getEntities(generalEntityList,requestScopedAuthenticatedUserBean);
        for (TxnGeneralEntityRecord txnGeneralEntityRecord : resultList){
            if (txnGeneralEntityRecord.getId().equals(connectionId)){

                return connectionTools.txnToConnection(txnGeneralEntityRecord);
            }
        }
        return null;
    }
}
