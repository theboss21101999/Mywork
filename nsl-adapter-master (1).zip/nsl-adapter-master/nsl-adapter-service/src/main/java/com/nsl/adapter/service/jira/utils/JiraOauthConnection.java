package com.nsl.adapter.service.jira.utils;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.auth.oauth2.*;
import com.google.api.client.http.BasicAuthentication;
import com.google.api.client.http.GenericUrl;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.service.jira.service.JiraConnectionService;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.dao.PersonalConnectionDao;
import com.nsl.logical.model.PersonalConnection;
import org.springframework.http.*;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.nsl.adapter.commons.dto.connections.JiraAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.adapter.service.v2.utills.RedisIntegration;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.Resource;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static com.nsl.adapter.service.graph.utils.GraphConstants.REFRESH_TOKEN;
import static com.nsl.adapter.service.jira.utils.JiraConstants.*;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class JiraOauthConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(JiraOauthConnection.class);

    @Autowired
    JiraConnectionService jiraConnectionService;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    RedisIntegration redisIntegration;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    CdmUtils cdmUtils;

    @Autowired
    AdaptorProperties adaptorProperties;
    @Autowired
    RestTemplate restTemplate;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    PersonalConnectionDao personalConnectionDao;

    Base64.Encoder encoder = Base64.getEncoder();


    public String getStateParam(Long connId, String connName, String tenantId) {
        Map<String, Object> valueMap = new HashMap<>();
        valueMap.put(AppConstant.CONFIG_ENTITY_RECORD_ID, connId.toString());
        valueMap.put(AppConstant.ADAPTER, JIRA);
        valueMap.put(AppConstant.TENANTID, tenantId);
        valueMap.put(AppConstant.ENV_NAME ,cdmUtils.getEnvironmentNameByTenantId(tenantId));
        valueMap.put(AppConstant.CONNECTION_NAME, connName);
        return encodeData(Objects.requireNonNull(JacksonUtils.toJson(valueMap)));
    }

    public JSONObject getAuthorizationcode(TxnAdapterConnection result) throws NSLException {

        LOGGER.info("generating redirect url ..");
        try {
            JiraAdapterConnectionDto connectionDto = (JiraAdapterConnectionDto) result.getConnection();
            AuthorizationCodeRequestUrl url = new AuthorizationCodeRequestUrl(JIRA_AUTH_TOKEN, connectionDto.getAppId());
            url.setRedirectUri(adaptorProperties.getRedirectUrl()).setScopes(connectionDto.getScope())
                    .set(PROMPT,CONSENT).set(ACCESS_TYPE,OFFLINE).setResponseTypes(Collections.singleton(CODE));

            String stateParams = getStateParam(result.getRecordId(), connectionDto.getConnectionName(), bean.getTenantId());
            LOGGER.info("appending state params to redirect url {} ", stateParams);
            url.set(STATE, stateParams);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(AppConstant.RESULT, result);
            jsonObject.put(Url, url.build());

            return jsonObject;
        } catch (Exception e) {
            LOGGER.error("exception occurred during generating redirect url: ",e );
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_1", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER,e);
        }
    }

    public TxnAdapterConnection getRefreshToken(Long id) throws NSLException {

        String cacheName = JIRA + "_" + bean.getTenantId();
        String code = redisIntegration.getOAuthCode(cacheName, id.toString());
        LOGGER.info("updating connection with code: {}",code);
        try {
            JiraAdapterConnectionDto connectionDto =jiraConnectionService.getJiraConnection(id,false);

            connectionDto.setRefreshToken(getRefreshToken(connectionDto, code));
            return jiraConnectionService.updateJiraConnection(id, connectionDto);
        } catch (Exception e) {
            LOGGER.error("failed to generate refresh Token",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,messageSource.getMessage
                    ("Paas_Adapter_13", null, Locale.ENGLISH) + e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }
    }

    public String getRefreshToken(JiraAdapterConnectionDto connectionDto, String code) throws IOException {
        TokenRequest request = new AuthorizationCodeTokenRequest(new NetHttpTransport(), new JacksonFactory(), new GenericUrl(JIRA_ACCESS_TOKEN), code)
                .setRedirectUri(adaptorProperties.getRedirectUrl()).setGrantType(AUTHORIZATION_CODE).set("client_id", connectionDataToolsV3.getSecret(connectionDto.getAppId())).set("client_secret",connectionDataToolsV3.getSecret(connectionDto.getAppSecret()));

        TokenResponse response = request.execute();
        return response.getRefreshToken();
    }

    public String getAccessToken(Long id) throws NSLException {

        JiraAdapterConnectionDto connectionDto = jiraConnectionService.getJiraConnection(id);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add(GRANT_TYPE, JiraConstants.REFRESH_TOKEN);


        UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromUriString(JIRA_ACCESS_TOKEN);
        URI uri = uriComponentsBuilder.queryParam("client_id",connectionDto.getAppId()).queryParam("client_secret",connectionDataToolsV3.getSecret(connectionDto.getAppSecret())).queryParam("refresh_token",connectionDataToolsV3.getSecret(connectionDto.getRefreshToken())).build().toUri();

        HttpEntity<MultiValueMap<String,String>> httpEntity=new HttpEntity<>(map,headers);
        LOGGER.info("calling Api");

        ResponseEntity<JsonNode> response = restTemplate.exchange(uri.toString(), HttpMethod.POST, httpEntity, JsonNode.class);
        if (response.getBody()!= null ) {
            JsonNode result = response.getBody();
            if (result != null) {
                connectionDataToolsV3.updateSecret(ConnectionDtoType.JIRA, "refreshToken", connectionDto.getConnectionName(), bean.getTenantId(), result.get(JiraConstants.REFRESH_TOKEN).asText());
                return result.get(ACCESS_TOKEN).asText();
            }

            else return "result is null";
        }

       else return "Failed to get access Token";
}

    public String getAccessToken() throws NSLException {

        TokenResponse response;
        LOGGER.info("generating access token..");
        try {
            PersonalConnection adminconnection = personalConnectionDao.getTenantConnection(bean.getTenantId(), AdapterType.JIRA.toString());
            if (adminconnection==null){
                throw new NSLException(ExceptionCategory.ACCESS_PERMISSION, ExceptionSeverity.BLOCKER, "No client keys present. Please contact Tenant Admin to configure client keys.", null);
            }
            ObjectMapper mapper = new ObjectMapper();
            JsonNode adminNode = mapper.readTree(adminconnection.getConnectionDto());
            PersonalConnection userconnection = personalConnectionDao.getConnection(bean.getUserId(),bean.getTenantId(), AdapterType.JIRA.toString());
            if (userconnection==null){
                throw new NSLException(ExceptionCategory.ACCESS_PERMISSION, ExceptionSeverity.CRITICAL, "Personal connection not created. Please navigate to profile and create.", null);
            }

            JsonNode userNode = mapper.readTree(userconnection.getConnectionDto());

            TokenRequest request = new RefreshTokenRequest(new NetHttpTransport(), new JacksonFactory(),
                    new GenericUrl(JIRA_ACCESS_TOKEN), userNode.get("refreshToken").asText());
            request.setClientAuthentication(new BasicAuthentication(adminNode.get("appId").asText(),
                    adminNode.get("appSecret").asText())).setGrantType(REFRESH_TOKEN);
            response = request.execute();
        }catch(Exception e){
            LOGGER.error("failed to generate access token :" , e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,messageSource.getMessage("Paas_Adapter_145", null, Locale.ENGLISH) + e.getMessage()
                    , ExceptionSeverity.BLOCKER, e );
        }
        Map<String, String> result = new HashMap<>();
        result.put(AppConstant.REFRESH_TOKEN, response.getRefreshToken());
        PersonalConnection connection = new PersonalConnection();
        connection.setUserId(bean.getUserId());
        connection.setTenantId(bean.getTenantId());
        connection.setIsTenantAdmin(Boolean.FALSE);
        connection.setConnectionType(AdapterType.JIRA.toString());
        connection.setConnectionDto(JacksonUtils.toJson(result));
        personalConnectionDao.saveConnection(connection);
        return response.getAccessToken();

    }

    private  String encodeData(String value){
        return encoder.encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

}