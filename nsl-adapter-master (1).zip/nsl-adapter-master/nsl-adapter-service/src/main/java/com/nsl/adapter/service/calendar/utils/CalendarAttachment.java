package com.nsl.adapter.service.calendar.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.config.AdaptorCommonsProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import javax.mail.util.ByteArrayDataSource;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;


@Component
public class CalendarAttachment {



    private static final Logger LOGGER = LoggerFactory.getLogger(CalendarAttachment.class);



    private static final String BASE_ENCODING ="base64Encoded";

    private static final String BASE_DATA ="b64data";
    private static final String DSD_CONTENT_URL = "contentUrl";
    private static final String ORIGINAL_FILE_NAME = "originalFileName";

    private static final String MIME_TYPE = "mimeType";
    private static final String FILE_NAME = "name";

    @Autowired
    AdaptorCommonsProperties adaptorCommonsProperties;
    private static final ObjectMapper mapper = new ObjectMapper();



    public  void addAttachment(JSONArray attachmentList, MimeMultipart multiPart) throws IOException, JSONException, MessagingException {

        JsonNode fileLoc;
        String contentUrl;
        for (int i = 0; i < attachmentList.length(); i++) {
            String filePath = attachmentList.get(i).toString();
            fileLoc = mapper.readTree(filePath);
            if (fileLoc.has(BASE_ENCODING)) {

                String file = fileLoc.get(BASE_DATA).toString();
                String file_name = fileLoc.get(ORIGINAL_FILE_NAME).toString();
                //byte[] file_decode = Base64.getDecoder().decode(file.getBytes(StandardCharsets.UTF_8));
                MimeBodyPart attachmentBodyPart = new MimeBodyPart();
                DataSource ds;
                InputStream in = new ByteArrayInputStream(file.getBytes(StandardCharsets.UTF_8));
                in = MimeUtility.decode(in, "base64");//NOSONAR
                ds = new ByteArrayDataSource(in, "image/*");
                attachmentBodyPart.setDataHandler(new DataHandler(ds));
                attachmentBodyPart.setFileName(file_name);
                multiPart.addBodyPart(attachmentBodyPart);

            } else {
                contentUrl = fileLoc.get(DSD_CONTENT_URL).asText();
                if(contentUrl!=null && !contentUrl.contains("https")) {
                    contentUrl = adaptorCommonsProperties.getEnvUrl() + contentUrl;
                }
                contentUrl = contentUrl + "?download=true";
                String contentType = fileLoc.get(MIME_TYPE).asText();
                String file_name =  String.valueOf(fileLoc.get(FILE_NAME));
                InputStream input = new URL(contentUrl).openStream();//NOSONAR
                MimeBodyPart attachmentBodyPart = new MimeBodyPart();
                try {
                    attachmentBodyPart.setDataHandler(new DataHandler((new ByteArrayDataSource(input, contentType))));
                } catch (Exception e) {
                    LOGGER.error("Error in downloading the attachment.Sending email without attachment", e);
                }
                attachmentBodyPart.setFileName(file_name);
                multiPart.addBodyPart(attachmentBodyPart);
            }
        }
    }
}
