package com.nsl.adapter.service.service;

import com.nsl.adapter.service.dto.SslCertificateDto;
import com.nsl.adapter.service.rest.ssl.SslClient;
import com.nsl.adapter.service.rest.ssl.SslConfig;
import com.nsl.adapter.service.utils.GeneralUtils;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.Locale;

import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class SslService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SslService.class);

    @Value("${app.keystore.path}")
    private String KEYSTORE_PATH_TEMPLATE;

    @Value("${app.keystore.type}")
    private String KEYSTORE_TYPE;

    @Value("${app.keystore.password}")
    private String KEYSTORE_PASSWORD = "changeit";

    private String KEYSTORE_PATH;

    @Autowired
    GeneralUtils generalUtils;

    @Autowired
    private MessageSource messageSource;

    private SslConfig getSslConfigData() throws NSLException {
        KEYSTORE_PATH = generalUtils.getKeystorePath(KEYSTORE_PATH_TEMPLATE);
        SslConfig ac = new SslConfig();
        ac.setKeystorePath(KEYSTORE_PATH);
        ac.setKeystorePassword(KEYSTORE_PASSWORD);
        ac.setKeyPass(KEYSTORE_PASSWORD);
        ac.setKeystoreType(KEYSTORE_TYPE);
        ac.setTrustAllCertificate("false");
        ac.setKeyManagerAlgorithm("SunX509");
        ac.setTrustStorePath(KEYSTORE_PATH);
        ac.setTrustStorePath(KEYSTORE_PATH);
        ac.setTrustStorePassword(KEYSTORE_PASSWORD);
        return ac;
    }

    public SslCertificateDto addCertificateToKeystore(MultipartFile file, String certificateAlias,
                                                      boolean force) throws NSLException {

            SslCertificateDto response = null;
            String fileExtension = FilenameUtils.getExtension(file.getResource().getFilename());
            certificateAlias = certificateAlias.replaceAll("\\s", "");

            if (!(fileExtension.equalsIgnoreCase("cer") ||
                    fileExtension.equalsIgnoreCase("crt"))) {
                throw new NSLException(INTERNAL_SERVER, null, messageSource.getMessage("Paas_Adapter_91", null, Locale.ENGLISH),
                        ExceptionSeverity.MINOR);
            }

            if (certificateAlias.isEmpty() || certificateAlias == null) {
                throw new NSLException(INTERNAL_SERVER, null, messageSource.getMessage("Paas_Adapter_92", null, Locale.ENGLISH),
                        ExceptionSeverity.MINOR);
            }

            SslClient sslClient = new SslClient(getSslConfigData());

            try {
                response = sslClient.addCertificateToKeystore(file,
                        KEYSTORE_PATH, certificateAlias, KEYSTORE_PASSWORD, force);
            } catch (Exception e) {
                throw new NSLException(INTERNAL_SERVER, null, "SSL",
                        messageSource.getMessage("Paas_Adapter_165", null, Locale.ENGLISH)  + e, ExceptionSeverity.MINOR, e);
            }

            return response;
    }

    public String deleteCertificateFromKeystore(String certificateAlias) throws NSLException {
        String response = null;
        certificateAlias = certificateAlias.replaceAll("\\s", "");

        if (certificateAlias.isEmpty() || certificateAlias == null) {
            throw new NSLException(INTERNAL_SERVER, null, messageSource.getMessage("Paas_Adapter_93", null, Locale.ENGLISH),
                    ExceptionSeverity.MINOR);
        }

        SslClient sslClient = new SslClient(getSslConfigData());

        try {
            response = sslClient.deleteCertificateFromKeystore(
                    KEYSTORE_PATH, certificateAlias, KEYSTORE_PASSWORD);
        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_166", null, Locale.ENGLISH)   + e, ExceptionSeverity.MINOR, e);
        }

        return response;
    }

    public String getSHA256(MultipartFile file) throws NSLException {
        String sha256 = null;
        try {
            SslClient sslClient = new SslClient(getSslConfigData());
            sha256 = sslClient.getSha256(file);

        } catch (Exception e) {
            throw new NSLException(INTERNAL_SERVER, null, "SSL",
                    messageSource.getMessage("Paas_Adapter_94", null, Locale.ENGLISH)   + e, ExceptionSeverity.MINOR, e);
        }

        return sha256;
    }

}