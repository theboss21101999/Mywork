package com.nsl.adapter.service.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.adapter.service.dto.VideoConferenceValidateDto;
import com.nsl.adapter.service.service.VideoConferencingService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.commons.utils.RestApiConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/videoConferencing")
public class VideoConferencingController {
    private static final Logger logger = LoggerFactory.getLogger(VideoConferencingController.class);

    @Autowired
    VideoConferencingService videoConferencingService;

    @Operation(summary = "Generate Meeting Id", description = "This api is called to generate the meeting id.", tags = {""})
    @ApiResponses(value = { @ApiResponse(responseCode = RestApiConstants.OK_CODE, description = RestApiConstants.INVOKE_EVENTS_DESCRIPTION, content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = com.nsl.adapter.commons.utils.ApiResponse.class), examples = {
                    @ExampleObject(name = "generateMeetingId", value = RestApiConstants.GENERATE_MEETING_ID) }) }),
            @ApiResponse(responseCode = RestApiConstants.BAD_REQUEST_CODE, description = RestApiConstants.BAD_REQUEST_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.UNAUTHORIZED_CODE, description = RestApiConstants.UNAUTHORIZED_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.FORBIDDEN_CODE, description = RestApiConstants.FORBIDDEN_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.NOT_FOUND_CODE, description = RestApiConstants.NOT_FOUND_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.INTERNAL_SERVER_ERROR_CODE, description = RestApiConstants.INTERNAL_SERVER_ERROR_DESCRIPTION, content = @Content)})
    @GetMapping("/generateMeetingId")
    public com.nsl.adapter.commons.utils.ApiResponse generateMeetingId(){
       String meetingUrl = videoConferencingService.getMeetingUrl();
       return new com.nsl.adapter.commons.utils.ApiResponse(HttpStatus.OK, AppConstant.SUCCESS,meetingUrl);
    }

    @Operation(summary = "Validate Meeting Id", description = "This api is called to validate the meeting id.", tags = {""})
    @ApiResponses(value = { @ApiResponse(responseCode = RestApiConstants.OK_CODE, description = RestApiConstants.INVOKE_EVENTS_DESCRIPTION, content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = com.nsl.adapter.commons.utils.ApiResponse.class), examples = {
                    @ExampleObject(name = "validateMeetingId", value = RestApiConstants.VALIDATE_MEETING_ID) }) }),
            @ApiResponse(responseCode = RestApiConstants.BAD_REQUEST_CODE, description = RestApiConstants.BAD_REQUEST_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.UNAUTHORIZED_CODE, description = RestApiConstants.UNAUTHORIZED_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.FORBIDDEN_CODE, description = RestApiConstants.FORBIDDEN_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.NOT_FOUND_CODE, description = RestApiConstants.NOT_FOUND_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.INTERNAL_SERVER_ERROR_CODE, description = RestApiConstants.INTERNAL_SERVER_ERROR_DESCRIPTION, content = @Content)})
    @GetMapping("/validateMeetingId")
    public com.nsl.adapter.commons.utils.ApiResponse validateMeetingId(@RequestParam String meetingId) throws JsonProcessingException, ClassNotFoundException {
        VideoConferenceValidateDto videoConferenceValidateDto = videoConferencingService.validateMeetingId(meetingId);
        return new com.nsl.adapter.commons.utils.ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, videoConferenceValidateDto);
    }
}
