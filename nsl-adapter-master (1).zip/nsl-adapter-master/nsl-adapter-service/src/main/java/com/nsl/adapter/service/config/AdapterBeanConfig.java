package com.nsl.adapter.service.config;

import com.nsl.adapter.commons.utils.ThreadBeanUtil;
import java.util.concurrent.Executor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * This class is for : AdapterBeanConfig.
 */
@Configuration
@EnableAsync
public class AdapterBeanConfig {

    /**
     * This Object is : ThreadBeanUtil.
     */
    @Autowired
    ThreadBeanUtil beanUtil;

    @Bean(name = "s3GsiInvokerUtilExecutor")
    public Executor getS3GsiInvokerUtilExecutor()
    {
        return beanUtil.getThread("s3GsiInvokerUtilExecutor-");
    }

    @Bean(name = "DBGsiInvokerUtilExecutor")
    public Executor getDBGsiInvokerUtilExecutor()
    {
        return beanUtil.getThread("DBGsiInvokerUtilExecutor-");
    }

    @Bean(name = "sftpGsiInvokerUtilExecutor")
    public Executor getSftpGsiInvokerUtilExecutor()
    {
        return beanUtil.getThread("SftpGsiInvokerUtilExecutor-");
    }

    @Bean(name = "commonGsiExecutor")
    public Executor getGsiExecutor()
    {
        return beanUtil.getThread("GsiExecutor-");
    }

    @Bean(name = "commonGsiExecutionInitiator")
    public Executor getGsiExecutionInitiator()
    {
        return beanUtil.getThread("GsiExecutionInitiator-");
    }

    @Bean(name = "sftpInboundKafkaExecutor")
    public Executor getSFTPInboundKafkaExecutor()
    {
        return beanUtil.getThread("SFTPInboundKafkaExecutor-");
    }

    @Bean(name = "inboundGsiKafkaExecutor")
    public Executor getInboundGsiKafkaExecutor()
    {
        return beanUtil.getThread("SFTPInboundGsiKafkaExecutor-");
    }

    @Bean(name = "pop3MailReceiver")
    public Executor getPOP3MailReceiver()
    {
        return beanUtil.getThread("POP3MailReceiver-");
    }

    @Bean(name = "imapMailReceiver")
    public Executor getIMAPMailReceiver()
    {
        return beanUtil.getThread("IMAPMailReceiver-");
    }

    @Bean(name = "pop3InvokeAllGsis")
    public Executor getPOP3AllGsiInvoker()
    {
        return beanUtil.getThread("POP3AllGsiInvoker -");
    }

    @Bean(name = "ImapInvokeGsi")
    public Executor getImapInvokeAllGsis()
    {
        return beanUtil.getThread("ImapInvokeGsi -");
    }

    @Bean(name = "ImapDynamicInvokeGsi")
    public Executor getImapDynamicInvokeAllGsis()
    {
        return beanUtil.getThread("ImapDynamicInvokeGsi -");
    }

    @Bean(name = "pop3InvokeGsi")
    public Executor getPOP3GsiInvoker()
    {
        return beanUtil.getThread("POP3GsiInvoker -");
    }
}
