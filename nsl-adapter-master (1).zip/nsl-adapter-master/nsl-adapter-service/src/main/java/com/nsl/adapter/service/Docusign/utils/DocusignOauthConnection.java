package com.nsl.adapter.service.Docusign.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.api.client.auth.oauth2.*;
import com.nsl.adapter.commons.dto.connections.DocusignAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.Docusign.service.DocusignConnectionService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.adapter.service.v2.utills.RedisIntegration;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static com.nsl.adapter.service.Docusign.utils.DocusignConstants.*;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.*;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.Url;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
@RequestMapping(value = "/connection")
public class DocusignOauthConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(DocusignOauthConnection.class);

    @Autowired
    DocusignConnectionService docusignConnectionService;

    @Autowired
    RedisIntegration redisIntegration;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    CdmUtils cdmUtils;

    @Autowired
    AdaptorProperties adaptorProperties;
    @Autowired
    private MessageSource messageSource;
    @Autowired
    RestTemplate restTemplate;

    Base64.Encoder encoder = Base64.getEncoder();


    public String getStateParam(Long connId, String connName, String tenantId) {
        Map<String, Object> valueMap = new HashMap<>();
        valueMap.put(AppConstant.CONFIG_ENTITY_RECORD_ID, connId.toString());
        valueMap.put(AppConstant.ADAPTER, DOCUSIGN);
        valueMap.put(AppConstant.TENANTID, tenantId);
        valueMap.put(AppConstant.ENV_NAME ,cdmUtils.getEnvironmentNameByTenantId(tenantId));
        valueMap.put(AppConstant.CONNECTION_NAME, connName);
        return encodeData(Objects.requireNonNull(JacksonUtils.toJson(valueMap)));
    }

    public JSONObject getAuthorizationcode(TxnAdapterConnection result) throws NSLException {

        LOGGER.info("generating redirect url ..");
        try {
            DocusignAdapterConnectionDto connectionDto = (DocusignAdapterConnectionDto) result.getConnection();
            AuthorizationCodeRequestUrl url = new AuthorizationCodeRequestUrl(DOCUSIGN_AUTH_TOKEN, connectionDto.getAppId());
            url.setRedirectUri(adaptorProperties.getRedirectUrl()).setScopes(connectionDto.getScope())
                    .set(PROMPT,DocusignConstants.CONSENT).set(DocusignConstants.ACCESS_TYPE,DocusignConstants.OFFLINE).setResponseTypes(Collections.singleton(DocusignConstants.CODE));

            String stateParams = getStateParam(result.getRecordId(), connectionDto.getConnectionName(), bean.getTenantId());
            LOGGER.info("appending state params to redirect url {} ", stateParams);
            url.set(DocusignConstants.STATE, stateParams);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(AppConstant.RESULT, result);
            jsonObject.put(Url, url.build());

            return jsonObject;
        } catch (Exception e) {
            LOGGER.error("exception occurred during generating redirect url: ",e );
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_1", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER,e);
        }
    }
    public TxnAdapterConnection getRefreshToken(Long id) throws NSLException {

        String cacheName = DOCUSIGN + "_" + bean.getTenantId();

        String code = redisIntegration.getOAuthCode(cacheName, id.toString());
        LOGGER.info("updating connection with code: {}",code);
        try {
            DocusignAdapterConnectionDto connectionDto =docusignConnectionService.getDocusignConnection(id,false);
            connectionDto.setRefreshToken(getRefreshToken(connectionDto,code));
            return docusignConnectionService.updateDocusignConnection(id, connectionDto);
        } catch (Exception e) {
            LOGGER.error("failed to generate refresh Token",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,messageSource.getMessage
                    ("Paas_Adapter_13", null, Locale.ENGLISH) + e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }
    }


    public String getRefreshToken(DocusignAdapterConnectionDto connectionDto, String code) throws IOException {
        String baseUri;
        JsonNode result;

        baseUri= DOCUSIGN_ACCESS_TOKEN;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.add("Authorization","Basic " + connectionDto.getEncodedKey());
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("code",code);
        map.add("grant_type",DocusignConstants.AUTHORIZATION_CODE);

        HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(map, headers);

        LOGGER.info("calling  Api");
        ResponseEntity<JsonNode> response = restTemplate.exchange(baseUri, HttpMethod.POST, httpEntity, JsonNode.class);
        result = (response.getBody() != null) ? response.getBody() : null;
        if (result != null && result.has("refresh_token")) {
            return result.get("refresh_token").asText();
        } else {
            return null;
        }
    }

    private  String encodeData(String value){
        return encoder.encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

}

