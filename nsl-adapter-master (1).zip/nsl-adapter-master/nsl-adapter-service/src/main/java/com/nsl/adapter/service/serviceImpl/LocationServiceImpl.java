package com.nsl.adapter.service.serviceImpl;

import com.nsl.adapter.service.service.LocationService;
import com.nsl.common.utils.NSLExceptionUtility;
import com.nsl.logical.config.AuthenticatedUserDetails;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.TransactionDataDao;
import com.nsl.logical.dto.SlotDataDto;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import com.nsl.logical.std.logs.Category;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LocationServiceImpl implements LocationService {

    private static final Logger logger = LoggerFactory.getLogger(LocationServiceImpl.class);

    @Autowired
    private TransactionDataDao transactionDataDao;

    @Override
    public void saveSlotItem(SlotDataDto slotDataDto, AuthenticatedUserDetails authenticatedUserDetails) throws NSLException {
        try {
            transactionDataDao.saveSlotData(slotDataDto, authenticatedUserDetails);
        } catch (Exception e) {
            throw new NSLException(ErrorType.INTERNAL_SERVER, ExceptionCategory.TRANSACTION_DATA,
                    ExceptionSubCategory.ID, "DB error in saving TxnData", ExceptionSeverity.BLOCKER, e,
                    Category.NSLDS);
        }
    }
}
