package com.nsl.adapter.service.sftp.connection;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.nsl.adapter.commons.dto.connections.SFTPAdapterConnectionDto;
import com.nsl.adapter.service.keymanager.service.FetchFileService;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.Locale;


public class KeyPasswordConnection extends SFTPConnection{

    private static final Logger LOGGER = LoggerFactory.getLogger(KeyPasswordConnection.class);

    @Autowired
    FetchFileService fetchFileService;

    @Autowired
    private MessageSource messageSource;

    @Override
    protected void createConnection(SFTPAdapterConnectionDto sftpAdapterConnectionDto) throws SFTPConnectionException {
        jsch = new JSch();
        try {
            session = jsch.getSession(sftpAdapterConnectionDto.getAuthentication().getUsername(), sftpAdapterConnectionDto.getHost(),
                    sftpAdapterConnectionDto.getPort());

            Long kmsConnection = Long.valueOf(sftpAdapterConnectionDto.getAuthentication().getSshKey());
            LOGGER.info("fetching key from the KMS Service");
            byte[] bytes1 = fetchFileService.getFileById(kmsConnection);
            File tempKeyFile = writeByte(bytes1);
            jsch.addIdentity(tempKeyFile.toString(),sftpAdapterConnectionDto.getAuthentication().getPassword()); // authenticate using private key
            LOGGER.info("session created");
            if(sftpAdapterConnectionDto.getAdvancedConfig()!=null){
                session.setConfig(sftpAdapterConnectionDto.getAdvancedConfig());
            }else {
                java.util.Properties configDefault = new java.util.Properties();
                configDefault.put("StrictHostKeyChecking", "no");
                session.setConfig(configDefault);
            }
            session.connect();
            channel = session.openChannel("sftp");
            channel.connect();
            LOGGER.info("shell channel connected...");
            channelSftp = (ChannelSftp) channel;
            LOGGER.info("SFTP connected");
        } catch (JSchException | IOException | NSLException e) {
            throw new SFTPConnectionException(messageSource.getMessage("Paas_Adapter_191", null, Locale.ENGLISH),e);
        }
    }

    private File writeByte(byte[] bytes1) throws IOException {
        String tempFileName  = "temp_keyFile";
        File file = File.createTempFile(tempFileName,".txt");
        try (OutputStream os = Files.newOutputStream(file.toPath())) {
            os.write(bytes1);
            LOGGER.info("Successfully created key file."); }
        return file;
    }
}
