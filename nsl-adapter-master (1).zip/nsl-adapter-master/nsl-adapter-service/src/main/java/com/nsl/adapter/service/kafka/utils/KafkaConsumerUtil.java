package com.nsl.adapter.service.kafka.utils;

import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.service.kafka.listener.InboundKafkaListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.stereotype.Service;
import java.util.Map;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.TOPIC;

@Service
public class KafkaConsumerUtil {
    private static final Logger log = LoggerFactory.getLogger(KafkaConsumerUtil.class);

    @Autowired
    InboundKafkaListener inboundKafkaListener;

    public void startOrCreateConsumers(KafkaConnectionDto connection, Map<String, Object> consumerProperties) {

        String topic = String.valueOf(connection.getAdvancedConfig().get(TOPIC));
        log.info("creating kafka consumer for topic {}", topic);
        ConcurrentMessageListenerContainer<String, String> container = null;

        ContainerProperties containerProps = new ContainerProperties(topic);
        containerProps.setPollTimeout(1000);
        containerProps.setGroupId("kafka-adapter-integration-group-id");
        ConsumerFactory<String, String> factory = new DefaultKafkaConsumerFactory<>(consumerProperties);
        container = new ConcurrentMessageListenerContainer<>(factory, containerProps);

        container.setupMessageListener(inboundKafkaListener);

        container.setConcurrency(1); //number of consumers

        if(!connection.getConnectionName().equalsIgnoreCase("testCase"))
            container.start();

        log.info("created and started kafka consumer for topic {}", topic);
    }
}
