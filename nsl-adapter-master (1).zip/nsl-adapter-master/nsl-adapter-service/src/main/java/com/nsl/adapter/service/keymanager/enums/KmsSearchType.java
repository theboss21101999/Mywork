package com.nsl.adapter.service.keymanager.enums;

public enum KmsSearchType {
    name,
    alias
}
