package com.nsl.adapter.service.kafka.utils;

import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.service.kafka.enums.ConnectionType;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import static com.nsl.adapter.service.kafka.enums.ConnectionType.SASL_PLAINTEXT;
import static com.nsl.adapter.service.kafka.enums.ConnectionType.SSL;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.*;

public class KafkaProducerConnectionUtil {

    private static final Logger logger = LoggerFactory.getLogger(KafkaProducerConnectionUtil.class);

    private KafkaTemplate<Integer, String>kafkaTemplate;

    public KafkaTemplate<Integer, String> getKafkaTemplate() {
        return kafkaTemplate;
    }

    public void setKafkaTemplate(KafkaTemplate<Integer, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    private ProducerFactory<Integer, String> producer(KafkaConnectionDto connection){
        Map<String, Object> configProps= new HashMap<>();
        Properties advancedConfig = connection.getAdvancedConfig();
        ConnectionType connectionType = ConnectionType.valueOf(String.valueOf(advancedConfig.get(CONNECTION_TYPE)));

        switch (connectionType){
            case SASL_PLAIN:
                configProps.put(SECURITY_PROTOCOL, SASL_SSL);
                configProps.put(SSL_TRUSTSTORE_LOCATION, advancedConfig.get(TRUSTSTORE_PATH));
                configProps.put(SSL_TRUSTSTORE_PASSWORD, advancedConfig.get(TRUSTSTORE_PASSWORD));
                configProps.put(SSL_KEY_PASSWORD, advancedConfig.get(KEY_PASSWORD));
                configProps.put(SASL_JAAS_CONFIGS, advancedConfig.get(SASL_JAAS_CONFIG));
                break;
            case SSL:
                configProps.put(SECURITY_PROTOCOL, SSL.toString());
                configProps.put(SSL_TRUSTSTORE_LOCATION, advancedConfig.get(TRUSTSTORE_PATH));
                configProps.put(SSL_TRUSTSTORE_PASSWORD, advancedConfig.get(TRUSTSTORE_PASSWORD));
                configProps.put(SSL_KEY_PASSWORD, advancedConfig.get(KEY_PASSWORD));
                break;
            case SASL_PLAINTEXT:
                configProps.put(SECURITY_PROTOCOL, SASL_PLAINTEXT.toString());
                configProps.put(SECURITY_MECHANISM, SECURITY_MECHANISM_SASL_PT);
                configProps.put(SASL_JAAS_CONFIGS, advancedConfig.get(SASL_JAAS_CONFIG));
                break;
            default:
                break;
        }
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, connection.getBootstrapServer().get(0));
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    public KafkaProducerConnectionUtil(KafkaConnectionDto connection){
        ProducerFactory<Integer, String> kafkaProducer = producer(connection);
        setKafkaTemplate(new KafkaTemplate<>(kafkaProducer));  //NOSONAR
    }


    public void sendMessageTokafka(String kafkaMessage,String topic){
        String   value=kafkaMessage;
        ListenableFuture<SendResult<Integer, String>> listenablefuture = kafkaTemplate.send(topic,value);
        listenablefuture.addCallback(new ListenableFutureCallback<SendResult<Integer, String>>() {
            @Override
            public void onFailure(Throwable ex) {
                KafkaFailure(topic, value, ex);
            }

            @Override
            public void onSuccess(SendResult<Integer, String> result) {
                KafkaSuccess(topic, value, result);
            }
        });
    }
    private void KafkaSuccess(String Topic, String value, SendResult<Integer, String> result) {

        logger.info("Message Sent SuccessFully for the Topic: {} and the value is {} , result is {}",Topic, value, result.getRecordMetadata());

    }

    private void KafkaFailure(String Topic, String value, Throwable ex) {
        logger.info("Message Sent SuccessFully for the Topic: {} and the value is {}",Topic, value);

        logger.error("Error Sending the Message and the exception is {}", ex.getMessage());
        logger.error("Error in OnFailure: {}", ex.getMessage());

    }

}
