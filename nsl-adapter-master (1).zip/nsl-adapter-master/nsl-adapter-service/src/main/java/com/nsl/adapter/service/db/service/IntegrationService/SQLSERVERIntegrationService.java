package com.nsl.adapter.service.db.service.IntegrationService;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.service.service.IntegrationService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

import static com.nsl.adapter.service.v2.utills.EntityConstants.*;

@Service
public class SQLSERVERIntegrationService implements IntegrationService {

    @Autowired
    SaveBetsService saveBetsService;

    @Override
    public CUPropsDto getSaveProperties(IntegrationDtoV3 integrationDto) throws NSLException {
        if(!validate(integrationDto.getOperation())){
            throw new NSLException(ErrorType.INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,"please Send valid data", ExceptionSeverity.MAJOR);
        }
        CUPropsDto cuPropsDto = new CUPropsDto();
        HashMap<String,String> cuSystemprops = new HashMap<>(integrationDto.getPropertiesMap());
        if(validate(integrationDto.getOperation())){
            if (integrationDto.getOperation().equals(AppConstant.INSERT)){
                cuPropsDto = newEntitiesForInsertMethod(integrationDto);
            }else if(integrationDto.getOperation().equals(AppConstant.UPDATE)){
                cuPropsDto = newEntitiesForUpdateMethod(integrationDto);
            }else if(integrationDto.getOperation().equals(AppConstant.DELETE)){
                cuPropsDto = newEntitiesForDeleteMethod(integrationDto);
            }else if (integrationDto.getOperation().equals(AppConstant.GET)){
                cuPropsDto = newEntitiesForGETMethod(integrationDto);
            }
        }
        if(!integrationDto.getOperation().equals(AppConstant.INSERT) && !integrationDto.getPropertiesMap().get("isContainQuery").equals("true")){
            cuPropsDto.getPhysicalLayerItems().get(1).setMultiValue(true);
            ((TenantCUEntityInput) cuPropsDto.getPhysicalLayerItems().get(1).getItem()).getNslAttributes().get(2).setConditionalPotentiality(Collections.singletonList("PL.SL002.NSL_DB_Query.Operator != 'IS NOT NULL' && PL.SL002.NSL_DB_Query.Operator != 'IS NULL' || PL.SL002.NSL_DB_Query.Operator == '>' || PL.SL002.NSL_DB_Query.Operator == '<' || PL.SL002.NSL_DB_Query.Operator == '=' || PL.SL002.NSL_DB_Query.Operator == '>=' || PL.SL002.NSL_DB_Query.Operator == '<=' || PL.SL002.NSL_DB_Query.Operator == '<>'"));
            ((TenantCUEntityInput) cuPropsDto.getPhysicalLayerItems().get(1).getItem()).getNslAttributes().get(2).setConditionalPotentialityName(Collections.singletonList("PL.SL002.NSL_DB_Query.Operator != 'IS NOT NULL' && PL.SL002.NSL_DB_Query.Operator != 'IS NULL' || PL.SL002.NSL_DB_Query.Operator == '>' || PL.SL002.NSL_DB_Query.Operator == '<' || PL.SL002.NSL_DB_Query.Operator == '=' || PL.SL002.NSL_DB_Query.Operator == '>=' || PL.SL002.NSL_DB_Query.Operator == '<=' || PL.SL002.NSL_DB_Query.Operator == '<>'"));
        }
        cuPropsDto.setCuSystemProps(cuSystemprops);
        cuPropsDto.setIsMachineCU(Boolean.FALSE);
        return cuPropsDto;
    }

    private CUPropsDto newEntitiesForInsertMethod(IntegrationDtoV3 integrationDto){
        CUPropsDto cuPropsDto = new CUPropsDto();
        TenantCUEntityInput physicallayer1 = saveBetsService.getEntityByName(NSL_SQLSERVER_REQ);
        TenantCUEntityInput physicallayer2 = saveBetsService.findEntityById(integrationDto.getInputEntityDsdId());
        TenantCUEntityInput TriggerCESlayer = saveBetsService.getEntityByName(NSL_SQLSERVER_RES);
        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Arrays.asList(physicallayer1,physicallayer2)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(TriggerCESlayer)));
        return cuPropsDto;
    }

    private CUPropsDto newEntitiesForUpdateMethod(IntegrationDtoV3 integrationDto){
        CUPropsDto cuPropsDto = new CUPropsDto();
        TenantCUEntityInput physicallayer1 = saveBetsService.getEntityByName(NSL_SQLSERVER_REQ);
        TenantCUEntityInput physicallayer2;
        TenantCUEntityInput physicallayer3;
        if(integrationDto.getPropertiesMap().containsKey("isContainQuery") && integrationDto.getPropertiesMap().get("isContainQuery").equals("true")){
            physicallayer2 = saveBetsService.getEntityByName(NSL_DB_QuerySelector_REQ);
            cuPropsDto.setPhysicalLayerItems(buildSlotItems(Arrays.asList(physicallayer1,physicallayer2)));
        }
        else {
            physicallayer2 = saveBetsService.getEntityByName(NSL_DB_QUERY);
            physicallayer3 = saveBetsService.findEntityById(integrationDto.getInputEntityDsdId());
            cuPropsDto.setPhysicalLayerItems(buildSlotItems(Arrays.asList(physicallayer1,physicallayer2,physicallayer3)));
        }
        TenantCUEntityInput TriggerCESLayer = saveBetsService.getEntityByName(NSL_SQLSERVER_RES);
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(TriggerCESLayer)));
        return cuPropsDto;
    }

    private CUPropsDto newEntitiesForDeleteMethod(IntegrationDtoV3 integrationDto){
        CUPropsDto cuPropsDto = new CUPropsDto();
        TenantCUEntityInput physicallayer1 = saveBetsService.getEntityByName(NSL_SQLSERVER_REQ);
        TenantCUEntityInput physicallayer2;
        if(integrationDto.getPropertiesMap().containsKey("isContainQuery") && integrationDto.getPropertiesMap().get("isContainQuery").equals("true")){
            physicallayer2 = saveBetsService.getEntityByName(NSL_DB_QuerySelector_REQ);
        }
        else {
            physicallayer2 = saveBetsService.getEntityByName(NSL_DB_QUERY);
        }
        TenantCUEntityInput TriggerCESLayer = saveBetsService.getEntityByName(NSL_SQLSERVER_RES);
        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Arrays.asList(physicallayer1,physicallayer2)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(TriggerCESLayer)));
        return cuPropsDto;
    }

    private CUPropsDto newEntitiesForGETMethod(IntegrationDtoV3 integrationDto){
        CUPropsDto cuPropsDto = new CUPropsDto();
        TenantCUEntityInput physicallayer1 = saveBetsService.getEntityByName(NSL_SQLSERVER_REQ);
        TenantCUEntityInput physicallayer2;
        if(integrationDto.getPropertiesMap().containsKey("isContainQuery") && integrationDto.getPropertiesMap().get("isContainQuery").equals("true")){
            physicallayer2 = saveBetsService.getEntityByName(NSL_DB_QuerySelector_REQ);
        }
        else {
            physicallayer2 = saveBetsService.getEntityByName(NSL_DB_QUERY);
        }
        TenantCUEntityInput TriggerCESLayer = saveBetsService.findEntityById(integrationDto.getOutputEntityDsdId());
        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Arrays.asList(physicallayer1,physicallayer2)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(TriggerCESLayer)));
        return cuPropsDto;
    }

    @Override
    public void getIntegration(IntegrationDtoV3 integrationDto, CUPropsDto cuPropsDto) {
        if(AppConstant.INSERT.equals(integrationDto.getOperation())){
            integrationDto.setInputEntityDsdId(getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).get(1).getDsdId());
        }else if(AppConstant.UPDATE.equals(integrationDto.getOperation()) && !integrationDto.getPropertiesMap().get("isContainQuery").equals("true")){
            integrationDto.setInputEntityDsdId(getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).get(2).getDsdId());
        }else if(AppConstant.GET.equals(integrationDto.getOperation())){
            integrationDto.setOutputEntityDsdId(getParticipatingItems(cuPropsDto.getTriggerCESLayerItems()).get(0).getDsdId());
        }
    }

    @Override
    public CUPropsDto getUpdateProperties(CUPropsDto cuPropsDto, IntegrationDtoV3 integrationDto) throws NSLException {
        CUPropsDto newCUPropsDto = getSaveProperties(integrationDto);
        HashMap<String,String> cuSystemprops = (HashMap<String, String>) cuPropsDto.getCuSystemProps();
        newCUPropsDto.setCuSystemProps(cuSystemprops);
        return newCUPropsDto;
    }

    private boolean validate(String operation){
        if(operation!=null){
            return true;
        }
        return false;
    }
}
