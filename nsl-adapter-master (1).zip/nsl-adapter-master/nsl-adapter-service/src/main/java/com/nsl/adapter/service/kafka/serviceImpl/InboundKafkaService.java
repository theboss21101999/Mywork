package com.nsl.adapter.service.kafka.serviceImpl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.adapter.service.kafka.dto.InboundMsgReqDto;
import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.adapter.service.kafka.utils.InboundKafkaUtil;
import com.nsl.adapter.service.kafka.utils.KafkaConsumerConnectionUtil;
import com.nsl.adapter.service.kafka.utils.KafkaConsumerUtil;
import com.nsl.adapter.service.kafka.utils.KafkaInvokeGSIUtil;
import com.nsl.logical.model.GSI;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.TENANT_ID_KEY;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.TOPIC;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.USER_CONTEXT_KEY;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.USER_EMAIL_KEY;
import static com.nsl.adapter.service.kafka.utils.KafkaConstants.USER_ID_KEY;

@Service
public class InboundKafkaService {
    private static final Logger LOGGER = LoggerFactory.getLogger(InboundKafkaService.class);

    @Autowired
    InboundKafkaUtil inboundKafkaUtil;

    @Autowired
    KafkaInvokeGSIUtil kafkaInvokeGSIUtil;

    @Autowired
    KafkaConsumerUtil kafkaConsumerUtil;

    Map<String, InboundMsgReqDto> gsiMap = new HashMap<>();

    public void processGSIMessage(Map<Object, Object> map, GSI gsi) {

        try {

        InboundMsgReqDto inboundMsgReqDto = buildInboundMsgReqDto(map, gsi);
        //TODO Add kafka server part
        startClientListener(inboundMsgReqDto);

        } catch (Exception e) {
            LOGGER.error("Exception in processing GSI Message", e);
        }
    }

    private InboundMsgReqDto buildInboundMsgReqDto(Map<Object, Object> map, GSI gsi) {
        InboundMsgReqDto inboundMsgReqDto = new InboundMsgReqDto();
        inboundMsgReqDto.setTenantId((String) ((Map) (map.get(USER_CONTEXT_KEY))).get(TENANT_ID_KEY));
        inboundMsgReqDto.setUserId(((Double) ((Map) (map.get(USER_CONTEXT_KEY))).get(USER_ID_KEY)).longValue());
        inboundMsgReqDto.setUserEmail((String) ((Map) (map.get(USER_CONTEXT_KEY))).get(USER_EMAIL_KEY));
        inboundMsgReqDto.setCuName(InboundKafkaUtil.inboundKafkaGSI(gsi));
        inboundMsgReqDto.setGsiMasterId(gsi.getMasterId());
        return inboundMsgReqDto;
    }

    private void startClientListener(InboundMsgReqDto inboundMsgReqDto) {

        KafkaConnectionDto connection = inboundKafkaUtil.buildKafkaConnectionDto(inboundMsgReqDto);

        String topic = String.valueOf(connection.getAdvancedConfig().get(TOPIC));
        gsiMap.put(topic, inboundMsgReqDto);

        Map<String, Object> consumerProperties = new KafkaConsumerConnectionUtil().buildConsumerProperties(connection);
        kafkaConsumerUtil.startOrCreateConsumers(connection, consumerProperties);
    }

    public void processClientMessage(ConsumerRecord<String, String> consumerRecord) throws JsonProcessingException {
        InboundMsgReqDto inboundMsgReqDto = gsiMap.get(consumerRecord.topic());
        Map<String, String> kafkaMsg = parseKafkaMessage(consumerRecord.value());

        kafkaInvokeGSIUtil.invokeGSI(kafkaMsg, inboundMsgReqDto);
    }

    private Map<String, String> parseKafkaMessage(String kafkaMsg) {
        Map<String, String> map = new HashMap<>();
        map.put("msg", kafkaMsg);
        return map;
    }
}
