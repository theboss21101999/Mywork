package com.nsl.adapter.service.dto;

public class TxnEntityDao {

    private String fileURL;
    private String entityName;
    public TxnEntityDao() {
    }
    public String getFileURL() {
        return fileURL;
    }
    public void setFileURL(String fileURL) {
        this.fileURL = fileURL;
    }
    public String getEntityName() {
        return entityName;
    }
    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }
    @Override
    public String toString() {
        return "TxnEntityDao [entityName=" + entityName + ", fileURL=" + fileURL + "]";
    }
    
}

