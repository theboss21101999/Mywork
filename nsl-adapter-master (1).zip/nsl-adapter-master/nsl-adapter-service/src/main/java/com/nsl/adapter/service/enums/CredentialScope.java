package com.nsl.adapter.service.enums;

public enum CredentialScope {TENANT, USER}
