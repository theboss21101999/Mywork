package com.nsl.adapter.service.secure;

import com.nsl.common.secure.AuthenticatedActiveUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Component
public class AuthenticateClientHttpRequestInterceptor implements ClientHttpRequestInterceptor {

	@Autowired
	private HttpServletRequest request;

	@Override
	public ClientHttpResponse intercept(HttpRequest httpRequest, byte[] bytes,
			ClientHttpRequestExecution clientHttpRequestExecution) throws IOException {
		String token = request.getHeader(AuthenticatedActiveUser.AUTHORIZATION);
		httpRequest.getHeaders().add(AuthenticatedActiveUser.AUTHORIZATION, token);
		return clientHttpRequestExecution.execute(httpRequest, bytes);
	}
}