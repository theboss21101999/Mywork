package com.nsl.adapter.service.controller;

import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.config.AdminAuth;
import com.nsl.adapter.service.keymanager.dto.KeyManagerDto;
import com.nsl.adapter.service.keymanager.dto.KmsConnectionDto;
import com.nsl.adapter.service.keymanager.dto.PaginatedKeys;
import com.nsl.adapter.service.keymanager.enums.KmsSearchType;
import com.nsl.adapter.service.keymanager.enums.KmsType;
import com.nsl.adapter.service.keymanager.service.KeyManagerService;
import com.nsl.adapter.service.keymanager.utils.KeyManagerUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.CreateGeneralEntityCUDao;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.Locale;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@AdminAuth
@RestController
@CrossOrigin
@RequestMapping(value = "/api/v1")
public class KeyManagementController {

    @Autowired
    KeyManagerUtils managerUtils;

    @Autowired
    KeyManagerService managerService;

    @Autowired
    private CreateGeneralEntityCUDao createGeneralEntityCUDao;

    @Autowired
    MessageSource messageSource;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @GetMapping(value = "/keys")
    public ApiResponse getPaginatedKeys(@RequestParam Integer pageNumber, @RequestParam Integer pageSize,
                                        @RequestParam(required = false) KmsType type,
                                        @RequestParam(required = false) String name,
                                        @RequestParam(required = false) String alias,
                                        @RequestParam String sortMethod) throws NSLException {
        if (pageNumber<1 || pageSize<1){
            return new ApiResponse(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_21", null, Locale.ENGLISH),null);
        }
        PaginatedKeys paginatedKeys = managerService.getPaginatedKeys(pageNumber, pageSize, type,
                name, alias, sortMethod);
        return new ApiResponse(HttpStatus.OK, SUCCESS, paginatedKeys);
    }

    @PostMapping(value = "/keys", consumes = {"multipart/form-data"})
    public ApiResponse saveKeyFile(@Valid @RequestPart(name="file") MultipartFile inputFile,
                                                @RequestPart("integration")KeyManagerDto keyManagerDto) throws NSLException{
            if (KmsType.KEY!=keyManagerDto.getKmsType() && inputFile==null){
                return new ApiResponse(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_22", null, Locale.ENGLISH),null);
            }
            if (!managerUtils.isValidForSave(keyManagerDto,false)){
                return new ApiResponse(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_23", null, Locale.ENGLISH),null);
            }
            if (!managerService.checkvalidNameOrAlias(keyManagerDto.getName(), keyManagerDto.getAlias())){
                return new ApiResponse(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_24", null, Locale.ENGLISH),null);
            }
            TxnGeneralEntityRecord record = managerService.saveKmsFile(keyManagerDto,inputFile);
            return new ApiResponse(HttpStatus.OK, SUCCESS, record);
    }

    @PutMapping(value = "/keys/{attrId}", consumes = {"multipart/form-data"})
    public ApiResponse updateKeyFile(@Valid @PathVariable("attrId") Long attrId,
                                     @Nullable @RequestPart("file") MultipartFile inputFile,
                                   @RequestPart("integration")KeyManagerDto keyManagerDto) throws NSLException {

            if (!managerUtils.isValidForSave(keyManagerDto,true)){
                return new ApiResponse(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_150", null, Locale.ENGLISH),null);
            }

            if (!managerService.checkvalidNameAndAlias(keyManagerDto.getName(), keyManagerDto.getAlias(), attrId)){
                return new ApiResponse(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_153", null, Locale.ENGLISH),null);
            }
            TxnGeneralEntityRecord record = managerService.updateKmsFile(keyManagerDto,inputFile,attrId);
            return new ApiResponse(HttpStatus.OK, SUCCESS, record);
    }

    @GetMapping(path = "/keys/{keyType}/{value}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse checkNameorAlias(@PathVariable("value") String name,
                                        @PathVariable("keyType")KmsSearchType type) throws NSLException {
        String inputName = null;
        String inputAlias = null;
        if (KmsSearchType.name == type){
            inputName = name;
        }else {
            inputAlias = name;
        }

        if (managerService.checkvalidNameOrAlias(inputName,inputAlias)){
            return new ApiResponse(HttpStatus.BAD_REQUEST,type.toString()+" already exists",null);
        }

        return new ApiResponse(HttpStatus.OK,type.toString()+" does not exist",null);
    }

    @GetMapping(path = "/keys/{attrId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getRecordById(@PathVariable("attrId") Long attrId) throws NSLException {

        TxnGeneralEntityRecord fetchedEntityRecord = managerUtils.getRecordById(attrId);
        if (fetchedEntityRecord==null){
            return new ApiResponse(HttpStatus.BAD_REQUEST,messageSource.getMessage("Paas_Adapter_25", null, Locale.ENGLISH)+attrId,null);
        }
        KmsConnectionDto dto = managerUtils.getFromNslAtrributes(fetchedEntityRecord.getTxnNslAttribute(),true);
        return new ApiResponse(HttpStatus.OK,SUCCESS,dto);
    }

    @GetMapping(path = "/keys/name/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getSecretIdByName(@PathVariable("name") String name) throws NSLException {
        String result= managerService.getAwsSecretIdByName(name);
        if (result==null){
            return new ApiResponse(HttpStatus.NOT_FOUND,messageSource.getMessage("Paas_Adapter_211", null, Locale.ENGLISH) + " : "+name,null);
        }
        return new ApiResponse(HttpStatus.OK,SUCCESS,result);
    }




}
