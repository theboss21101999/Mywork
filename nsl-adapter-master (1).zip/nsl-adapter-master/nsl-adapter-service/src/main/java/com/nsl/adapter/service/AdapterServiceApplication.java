package com.nsl.adapter.service;

//import com.nsl.adapter.service.config;
import com.nsl.adapter.service.config.SmartLocaleResolver;
import com.nsl.adapter.service.kafka.listener.InboundKafkaListener;
import com.nsl.common.config.NslCommonProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.LocaleResolver;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@ComponentScan(basePackages = {"com.nsl.dataservices", "com.nsl.transaction", "com.nsl.logical", "com.nsl.search",
        "com.nsl","com.nsl.dsd.store.utils"},
        excludeFilters =
        @ComponentScan.Filter(type= FilterType.REGEX,
                pattern="com.nsl.dsd.*"))
@EnableConfigurationProperties(value = NslCommonProperties.class)
@EnableSwagger2
public class AdapterServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdapterServiceApplication.class, args);

    }

    @Bean
    public InboundKafkaListener inboundKafkaListener() {
        return new InboundKafkaListener();
    }

    @Bean
    public LocaleResolver localeResolver() {
        return new SmartLocaleResolver();
    }

    @Bean
    public ResourceBundleMessageSource messageSource() {

        ResourceBundleMessageSource source = new ResourceBundleMessageSource();

        source.setBasenames("messages/messagesRb");
        source.setUseCodeAsDefaultMessage(true);

        return source;

    }

}