package com.nsl.adapter.service.ses.enums;

public enum SesOperation {
    SES_MAIL,
    SES_BULK_MAIL_TEXT,
    SES_BULK_WITH_CSV
}