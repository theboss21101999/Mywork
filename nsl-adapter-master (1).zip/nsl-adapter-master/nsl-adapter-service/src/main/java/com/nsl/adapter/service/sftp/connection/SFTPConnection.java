package com.nsl.adapter.service.sftp.connection;

import com.jcraft.jsch.*;
import com.nsl.adapter.commons.dto.connections.SFTPAdapterConnectionDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class SFTPConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(SFTPConnection.class);

    protected Session session = null;
    protected JSch jsch = null;
    protected Channel channel = null;
    protected ChannelSftp channelSftp = null;

    protected abstract void createConnection(SFTPAdapterConnectionDto sftpAdapterConnectionDto) throws SFTPConnectionException;

    public ChannelSftp getChannelSftp() {
        return channelSftp;
    }

    public void getFile(String src, String dest) throws SftpException {
        channelSftp.get(src, dest);
        LOGGER.info("Downloaded successfully");
    }
}
