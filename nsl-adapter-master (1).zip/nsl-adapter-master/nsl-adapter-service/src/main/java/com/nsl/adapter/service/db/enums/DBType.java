package com.nsl.adapter.service.db.enums;

public  enum DBType {
    MYSQL,
    POSTGRES,

}
