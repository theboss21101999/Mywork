package com.nsl.adapter.service.oauth2util;

import com.nsl.adapter.service.controller.ExternalApiReservedCUController;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

@Service
public class OAuthAccessCodeUtil {
    private static final Logger logger = LoggerFactory.getLogger(OAuthAccessCodeUtil.class);

    Map<String, String> userToAuthCode = new HashMap<>();

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl userDetails;

    @Value("${app.tbui.redirectUrl}")
    private String tbuiRedirectUrl;

    public void saveOAuthCode(String txnId, String code) {

        userToAuthCode.put(txnId, code);
    }

    public String getAuthCodeForUser(String txnId) {
        final String value = userToAuthCode.get(txnId);
        if(value!=null)
            return value;
        logger.error("Auth Code Not Found for txnId: {}", txnId);
        return "Not Found";
    }

}
