package com.nsl.adapter.service.google.utils;

public final class GoogleConstants {
    public static final String GOOGLE = "Google";
    public static final String GOOGLE_AUTH_TOKEN = "https://accounts.google.com/o/oauth2/v2/auth";
    public static final String GOOGLE_REFRESH_TOKEN = "https://accounts.google.com/o/oauth2/token";
    public static final String GOOGLE_ACCESS_TOKEN = "https://oauth2.googleapis.com/token";
    public static final String PROMPT="prompt";
    public static final String CONSENT="consent";
    public static final String ACCESS_TYPE="access_type";
    public static final String OFFLINE="offline";
    public static final String CODE="code";
    public static final String AUTHORIZATION_CODE="authorization_code";
    public static final String REFRESH_TOKEN="refresh_token";
    public static final String STATE="state";
    public static final String Url="url";
    public static final String clientId="clientId";
    public static final String clientSecret="clientSecret";

    private GoogleConstants(){
        throw new IllegalStateException("utility class");
    }
}
