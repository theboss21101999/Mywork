package com.nsl.adapter.service.config;

import com.nsl.adapter.service.secure.AuthenticateClientHttpRequestInterceptor;
import com.nsl.common.constant.SCOPE;
import com.nsl.common.utils.InterfaceAdapter;
import com.nsl.logical.model.ChangeDriver;
import com.nsl.logical.model.ChangeDriverData;
import com.nsl.logical.model.ExtendedProperty;
import com.nsl.logical.model.CULayer;
import com.nsl.logical.model.TxnCULayer;


import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.OAuthFlow;
import io.swagger.v3.oas.models.security.OAuthFlows;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;

import com.nsl.logical.model.TriggerCU;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;


import org.springframework.web.util.DefaultUriBuilderFactory;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.*;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.json.Json;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger.web.SecurityConfigurationBuilder;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import com.nsl.logical.mixin.PageMixin;
import com.nsl.logical.mixin.PageableMixin;
import com.nsl.logical.mixin.SortMixin;
import java.util.List;
import java.util.ArrayList;

import java.util.Collections;
import static com.nsl.common.constant.AppConstant.API_INFO_DESC;
import static com.nsl.common.constant.AppConstant.API_INFO_LICENSE;
import static com.nsl.common.constant.AppConstant.API_INFO_VER;
import static com.nsl.common.constant.AppConstant.NSL_APP;
import static com.nsl.common.constant.AppConstant.OAUTH2;
import static com.nsl.adapter.service.utils.AppConstant.ADAPTER_API_INFO_TITLE;

@Configuration
public class OpenApiConfiguration{


    @Autowired
    private AdaptorProperties adaptorProperties;

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI().info(apiInfo()).components(new Components().addSecuritySchemes("oauth2", securityScheme()))
                .addSecurityItem(new SecurityRequirement().addList("oauth2"));
    }

    private Info apiInfo() {
        return new Info()
                .title(ADAPTER_API_INFO_TITLE)
                .description(API_INFO_DESC)
                .version(API_INFO_VER)
                .license(apiLicence());
    }
    private SecurityScheme securityScheme() {
        return new SecurityScheme()
                .type(SecurityScheme.Type.OAUTH2)
                .flows(securityFlows());

    }
    private OAuthFlows securityFlows() {
        OAuthFlow passwordFlow = new OAuthFlow()
                .tokenUrl(adaptorProperties.getAppOauthSwaggerUrl());
        return new OAuthFlows()
                .password(passwordFlow);
    }
    private License apiLicence() {
        return new License()
                .name(API_INFO_LICENSE)
                .url(adaptorProperties.getAppOauthLicenseUrl());
    }
    @Bean
    SecurityConfiguration security() {
        return SecurityConfigurationBuilder.builder().clientId(adaptorProperties.getAppOauthClientId()).clientSecret(adaptorProperties.getAppOauthclientSecret())
                .appName(NSL_APP).build();
    }
    @Bean("nslRestTemplate")
    public RestTemplate getRestTemplate(AuthenticateClientHttpRequestInterceptor interceptor) {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setInterceptors(Collections.singletonList(interceptor));
        return restTemplate;
    }

    @Bean("RestAdapterTemplate")
    public RestTemplate getRestAdapterTemplate(AuthenticateClientHttpRequestInterceptor interceptor) {
        RestTemplate restTemplate = new RestTemplate();
        FormHttpMessageConverter converter = new FormHttpMessageConverter();
        List<MediaType> mediaTypes = new ArrayList<>();
        mediaTypes.add(MediaType.APPLICATION_FORM_URLENCODED);
        mediaTypes.add(MediaType.MULTIPART_FORM_DATA);
        converter.setSupportedMediaTypes(mediaTypes);
        restTemplate.getMessageConverters().add(converter);
        MappingJackson2HttpMessageConverter jsonConverter = new MappingJackson2HttpMessageConverter();
        mediaTypes = new ArrayList<>();
        mediaTypes.add(MediaType.APPLICATION_PROBLEM_JSON);
//        mediaTypes.add(MediaType.TEXT_HTML);
//        mediaTypes.add(MediaType.valueOf("text/json"));
        jsonConverter.setSupportedMediaTypes(mediaTypes);
        restTemplate.getMessageConverters().add(jsonConverter);
        DefaultUriBuilderFactory defaultUriBuilderFactory = new DefaultUriBuilderFactory();
        defaultUriBuilderFactory.setEncodingMode(DefaultUriBuilderFactory.EncodingMode.VALUES_ONLY);
        restTemplate.setUriTemplateHandler(defaultUriBuilderFactory);
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        BufferingClientHttpRequestFactory bufferingRequestFactory = new BufferingClientHttpRequestFactory(requestFactory);
        restTemplate.setRequestFactory(bufferingRequestFactory);
        return restTemplate;
    }
    @Bean
    public MappingJackson2HttpMessageConverter getMessJacksonHttpMessageConverter() {
        List<MediaType> supportedMediaTypes = new ArrayList<>();
        supportedMediaTypes.add(MediaType.APPLICATION_JSON);
        Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
        builder
                .serializationInclusion(JsonInclude.Include.NON_NULL)
                .serializationInclusion(JsonInclude.Include.NON_EMPTY)
                .mixIn(Page.class, PageMixin.class)
                .mixIn(Pageable.class, PageableMixin.class)
                .mixIn(Sort.class, SortMixin.class);
        builder.featuresToEnable(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL);
        builder.featuresToDisable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter(builder.build());
        converter.setSupportedMediaTypes(supportedMediaTypes);
        return converter;
    }

}
