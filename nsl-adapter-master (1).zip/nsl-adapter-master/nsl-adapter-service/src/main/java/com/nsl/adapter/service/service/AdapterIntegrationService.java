package com.nsl.adapter.service.service;

import com.google.common.reflect.TypeToken;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.serviceImpl.CreateEntityServiceImpl;
import com.nsl.adapter.commons.utils.IRDRUtils;
import com.nsl.adapter.commons.utils.UUIDGenerator;
import com.nsl.adapter.service.dto.integration.IntegrationSaveRequestDto;
import com.nsl.adapter.service.dto.integration.JsonAttributeDto;
import com.nsl.adapter.service.dto.integration.JsonEntityDto;
import com.nsl.adapter.service.dto.integration.RestIntegrationReq;
import com.nsl.adapter.service.dto.integration.StatusEntityDto;
import com.nsl.adapter.service.dto.integration.SwaggerIntegrationReq;
import com.nsl.adapter.service.utils.CuUtils;
import com.nsl.adapter.service.utils.SwaggerParser;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityAttributeInput;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.dsd.store.models.tenant.io.TenantCULayerInput;
import com.nsl.dsd.store.models.tenant.io.TenantChangeUnitInput;
import com.nsl.dsd.store.models.tenant.io.TenantSlotItemInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.ErrorType;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.Agent;
import com.nsl.logical.model.ChangeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.nsl.adapter.service.utils.AppConstant.*;
import static com.nsl.logical.enums.StatusEnum.PUBLISHED;

@Service
public class AdapterIntegrationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdapterIntegrationService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Autowired IRDRUtils irdrUtils;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    SaveBetsService saveBetsService;

    @Autowired
    SwaggerParser swaggerParser;

    @Autowired
    CreateEntityServiceImpl createEntityService;

    @Autowired
    private MessageSource messageSource;

    public String saveIntegration(IntegrationSaveRequestDto integrationSaveRequestDto, @Valid MultipartFile inputEntityFile, @Valid MultipartFile outputEntityFile) throws NSLException {

        checkCUName(integrationSaveRequestDto.getIntegrationName());

        TenantChangeUnitInput changeUnit = getChangeUnit(integrationSaveRequestDto, inputEntityFile, outputEntityFile);

        irdrUtils.setIRDR(changeUnit);

        changeUnit = saveBetsService.saveChangeUnit(changeUnit);
        return changeUnit.getName();
    }

    public boolean deleteIntegrationById(Long changeUnitId) {
        return changeUnitDao.deleteCuById(changeUnitId, requestScopedAuthenticatedUserBean);
    }

    public TenantChangeUnitInput getChangeUnit(IntegrationSaveRequestDto integrationSaveRequestDto, @Valid MultipartFile inputEntityFile, @Valid MultipartFile outputEntityFile) throws NSLException {
        String changeUnitName = integrationSaveRequestDto.getIntegrationName();
        TenantChangeUnitInput changeUnit = new TenantChangeUnitInput();
        changeUnit.setName(changeUnitName);
        changeUnit.setDisplayName(changeUnitName);
        changeUnit.setReserved(true);
        changeUnit.setReservedCUType(EXTERNAL_SOLUTION_PREFIX + integrationSaveRequestDto.getIntegrationName());
        changeUnit.setStatus(StatusEnum.DRAFT);

        TenantCUEntityInput requestGeneralEntity = null;
        TenantCUEntityInput requestGeneralEntity2 = null;
        TenantCUEntityInput responseGeneralEntity = null;
//        String inputEntityName = integrationSaveRequestDto.getIntegrationName() + "_" + REQUEST
//                + "_" + UUIDGenerator.generateType1UUID();
//        String outputEntityName = integrationSaveRequestDto.getIntegrationName() + "_" + RESPONSE
//                + "_" + UUIDGenerator.generateType1UUID();

        if (AdapterType.REST==AdapterType.valueOf(integrationSaveRequestDto.getAdapterType())) {
                if (integrationSaveRequestDto.getSwaggerEnabled()!=null && integrationSaveRequestDto.getSwaggerEnabled()){
                    swaggerParser.swaggerParser(integrationSaveRequestDto);
                }
                else{
                    if (!CuUtils.validateEntities(integrationSaveRequestDto.getRestIntegrationReq())) {
                        throw new NSLException(ErrorType.VALIDATION, ExceptionCategory.VALIDATION, messageSource.getMessage("Paas_Adapter_120", null, Locale.ENGLISH), null);
                    }
//                    if (inputEntityFile != null) {
//                        requestGeneralEntity = createEntityService.convertIntoEntity(integrationSaveRequestDto.getRestIntegrationReq().getInputEntityFileType(), inputEntityFile, inputEntityName);
//                        cuproperties.put(REQUESTID, requestGeneralEntity.getDsdId());
//                        cuproperties.put(REQUESTNAME, requestGeneralEntity.getName());
//                    } else
//                        inputEntityId = integrationSaveRequestDto.getRestIntegrationReq().getInputEntityId();
//                    if (outputEntityFile != null) {
//                        responseGeneralEntity = createEntityService.convertIntoEntity(integrationSaveRequestDto.getRestIntegrationReq().getOutputEntityFileType(), outputEntityFile, outputEntityName);
//                    } else
//                        outputEntityId = integrationSaveRequestDto.getRestIntegrationReq().getOutputEntityId();
//                    headersEntityId = integrationSaveRequestDto.getRestIntegrationReq().getHeaderEntityId();
//                    pathparamsEntityId = integrationSaveRequestDto.getRestIntegrationReq().getPathparamEntityId();
//                    queryparamsEntityId = integrationSaveRequestDto.getRestIntegrationReq().getQueryparamEntityId();
                }
        }else{
            throw new NSLException(ExceptionCategory.VALIDATION, ExceptionSubCategory.TRIGGERCU,
                    "Adapter type not allowed", ExceptionSeverity.CRITICAL, null);
        }
        String inputEntityId = integrationSaveRequestDto.getRestIntegrationReq().getInputEntityId();
        String outputEntityId = integrationSaveRequestDto.getRestIntegrationReq().getOutputEntityId();
        String headersEntityId = integrationSaveRequestDto.getRestIntegrationReq().getHeaderEntityId();
        String pathparamsEntityId = integrationSaveRequestDto.getRestIntegrationReq().getPathparamEntityId();
        String queryparamsEntityId = integrationSaveRequestDto.getRestIntegrationReq().getQueryparamEntityId();
        String headerResponseEntityId = integrationSaveRequestDto.getRestIntegrationReq().getHeaderResponseEntityId();
        if (outputEntityId!=null){
            integrationSaveRequestDto.getRestIntegrationReq().setStatusMap(null);
        }
        Map<String, String> cuproperties = CuUtils.buildCuSystemProps(integrationSaveRequestDto);
        List<TenantSlotItemInput> responseParticipatingItems = new ArrayList<>();
        if (outputEntityId==null && integrationSaveRequestDto.getRestIntegrationReq().getStatusMap()!=null){
            getTriggerCESItems(integrationSaveRequestDto, responseParticipatingItems, cuproperties);
        }else {
            responseGeneralEntity = getCUfromId(outputEntityId,null,null, responseGeneralEntity);
            CuUtils.addSlotItemtoLayer(responseGeneralEntity, responseParticipatingItems, integrationSaveRequestDto.getRestIntegrationReq().getIsOutputMultivalue());
        }

        if(headerResponseEntityId!=null){
            responseGeneralEntity = saveBetsService.findEntityById(headerResponseEntityId);
            CuUtils.addSlotItemtoLayer(responseGeneralEntity, responseParticipatingItems);
        }

        requestGeneralEntity = getCUfromId(inputEntityId, cuproperties, REQUESTNAME, requestGeneralEntity);
        TenantCUEntityInput headersGeneralEntity = getCUfromId(headersEntityId, cuproperties, HEADERENTITYID, null);
        TenantCUEntityInput pathparamsGeneralEntity = getCUfromId(pathparamsEntityId, cuproperties, PATHPARAMENTITYID, null);
        TenantCUEntityInput queryparamsGeneralEntity = getCUfromId(queryparamsEntityId, cuproperties, QUERYPARAMENTITYID, null);

        List<Agent> agents = new ArrayList<>();
        Agent machineAgent = new Agent();
        machineAgent.setAgentType("human");
        agents.add(machineAgent);
        changeUnit.setAgents(agents);

        /*................................................................................*/
        List<TenantSlotItemInput> requestParticipatingItems = new ArrayList<>();

        TenantCULayerInput physicalLayer = new TenantCULayerInput();
        physicalLayer.setType(LayerType.PHYSICAL);

        CuUtils.addSlotItemtoLayer(requestGeneralEntity, requestParticipatingItems, integrationSaveRequestDto.getRestIntegrationReq().getIsInputMultivalue());
        CuUtils.addSlotItemtoLayer(requestGeneralEntity2, requestParticipatingItems);
        CuUtils.addSlotItemtoLayer(headersGeneralEntity, requestParticipatingItems);
        CuUtils.addSlotItemtoLayer(pathparamsGeneralEntity, requestParticipatingItems);
        CuUtils.addSlotItemtoLayer(queryparamsGeneralEntity, requestParticipatingItems);

        physicalLayer.setParticipatingItems(requestParticipatingItems);
        /*................................................................................*/

        TenantCULayerInput triggerCESLayer = new TenantCULayerInput();
        triggerCESLayer.setType(LayerType.TRIGGERCES);

        changeUnit.setCuSystemProperties(cuproperties);

        triggerCESLayer.setParticipatingItems(responseParticipatingItems);
        /*................................................................................*/

        List<TenantCULayerInput> cuLayers = new ArrayList<>();
        cuLayers.add(physicalLayer);
        cuLayers.add(triggerCESLayer);

        changeUnit.setLayers(cuLayers);
        return changeUnit;
    }

    private void getTriggerCESItems(IntegrationSaveRequestDto integrationSaveRequestDto,
                                    List<TenantSlotItemInput> responseParticipatingItems, Map<String, String> cuproperties) throws NSLException {
        Map<String,String> statusMap = new HashMap<>();
        Map<String,String> entityMap = new HashMap<>();
        for (Map.Entry<String, StatusEntityDto> entry : integrationSaveRequestDto.getRestIntegrationReq().getStatusMap().entrySet()){
            if (entityMap.containsKey(entry.getValue().getId())){
                statusMap.put(entry.getKey(), entityMap.get(entry.getValue().getId()));
            }else{
                TenantCUEntityInput responseGeneralEntity = getCUfromId(entry.getValue().getId(), null,null, null);
                CuUtils.addSlotItemtoLayer(responseGeneralEntity, responseParticipatingItems,entry.getValue().getIsMultivalue());
                entityMap.put(entry.getValue().getId(), String.valueOf(responseParticipatingItems.size()-1));
                statusMap.put(entry.getKey(), String.valueOf(responseParticipatingItems.size()-1));
            }
        }
        TenantCUEntityInput responseGeneralEntity = saveBetsService.getEntityByName(REST_STATUS_ENTITY);
        CuUtils.addSlotItemtoLayer(responseGeneralEntity, responseParticipatingItems);
        statusMap.put(STATUS, String.valueOf(responseParticipatingItems.size()-1));
        cuproperties.put(STATUS_MAP, JacksonUtils.toJson(statusMap));
    }

    private IntegrationSaveRequestDto buildIntegration(TenantChangeUnitInput changeUnit) {
        Map<String, String> cuSystemProperties = changeUnit.getCuSystemProperties();
        IntegrationSaveRequestDto integrationSaveRequestDto = new IntegrationSaveRequestDto();
        integrationSaveRequestDto.setIntegrationName(changeUnit.getName());
        Map<String, String> metadata = new HashMap<>();
        //metadata.put(UPDATED_AT, String.valueOf(changeUnit.get()));
        metadata.put(DSD_ID, changeUnit.getDsdId());
        integrationSaveRequestDto.setMetadata(metadata);
        try {
            integrationSaveRequestDto.setAdapterType(cuSystemProperties.get(ADAPTER));
            integrationSaveRequestDto.setConfigEntityName(cuSystemProperties.get(CONFIG_ENTITY_KEY));
            integrationSaveRequestDto.setConfigEntityRecordId(getConfigRecord(cuSystemProperties.get(CONFIG_ENTITY_RECORD_ID)));
            if (cuSystemProperties.containsKey(SWAGGER_URL)) {
                integrationSaveRequestDto.setSwaggerEnabled(Boolean.TRUE);
                integrationSaveRequestDto.setSwaggerIntegrationReq(buildSwaggerIntegration(cuSystemProperties));
            }
            switch (AdapterType.valueOf(integrationSaveRequestDto.getAdapterType())) {
                case REST:
                    integrationSaveRequestDto.setRestIntegrationReq(buildRestIntegration(changeUnit));
                    break;
                default:
                    break;

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return integrationSaveRequestDto;
    }

    private Long getConfigRecord(String s) {
        if (s == null || s.equals("") || s.equalsIgnoreCase("null"))
            return 0L;
        return Long.valueOf(s);
    }

    private RestIntegrationReq buildRestIntegration(TenantChangeUnitInput changeUnit){
        Map<String, String> cuSystemProps = changeUnit.getCuSystemProperties();
        RestIntegrationReq restIntegrationReq = new RestIntegrationReq();
        restIntegrationReq.setUri(cuSystemProps.get(URI));
        restIntegrationReq.setHttpMethod(cuSystemProps.get(METHOD));
        try {
            if (cuSystemProps.containsKey(CONTENTTYPE)){
                restIntegrationReq.setContentType(cuSystemProps.get(CONTENTTYPE));
            }
            if (cuSystemProps.get(REQUESTID)!=null){
                TenantCUEntityInput entity = (TenantCUEntityInput) changeUnit.getLayers().get(0).getParticipatingItems().get(0).getItem();
                restIntegrationReq.setInputEntityId(entity.getDsdId());
                restIntegrationReq.setIsInputMultivalue(String.valueOf(((TenantSlotItemInput) changeUnit.getLayers().get(0).getParticipatingItems().get(0)).isMultiValue()));
            }
            if (cuSystemProps.containsKey(MAPPER) && cuSystemProps.get(MAPPER)!=null){
                restIntegrationReq.setMapper(JacksonUtils.fromJson(cuSystemProps.get(MAPPER), new TypeToken<Map<String, Map<String, String>>>() {}.getType()));
            }
        } catch (Exception ignored) {
            LOGGER.info("error in buildRestIntegration" ,ignored);
        }
        try {
            if (cuSystemProps.containsKey(STATUS_MAP)){
                List<TenantSlotItemInput> items = changeUnit.getLayers().get(1).getParticipatingItems();
                Map<String, StatusEntityDto> statusMap = new HashMap<>();
                Map<String, String> statmap = JacksonUtils.fromJson(cuSystemProps.get(STATUS_MAP),Map.class);
                for (Map.Entry<String, String> entry : statmap.entrySet()){
                    if (!STATUS.equals(entry.getKey())){
                        TenantCUEntityInput entity = (TenantCUEntityInput) items.get(Integer.parseInt(entry.getValue())).getItem();
                        statusMap.put(entry.getKey(), new StatusEntityDto(entity.getName(), entity.getDsdId(), null));
                    }
                }
                restIntegrationReq.setStatusMap(statusMap);
            }else{
                TenantCUEntityInput entity = (TenantCUEntityInput) changeUnit.getLayers().get(1).getParticipatingItems().get(0).getItem();
                restIntegrationReq.setOutputEntityId(entity.getDsdId());
                restIntegrationReq.setIsOutputMultivalue(String.valueOf(((TenantSlotItemInput) changeUnit.getLayers().get(1).getParticipatingItems().get(0)).isMultiValue()));
            }
        } catch (Exception ignored) {
            LOGGER.info("error in buildRestIntegration" ,ignored);
        }
        buildAdditionalRestParams(restIntegrationReq, cuSystemProps);
        return restIntegrationReq;
    }

    private void buildAdditionalRestParams(RestIntegrationReq restIntegrationReq, Map<String, String> cuSystemProps) {
        restIntegrationReq.setHeaderEntityId(cuSystemProps.get(HEADERENTITYDSDID));
        restIntegrationReq.setPathparamEntityId(cuSystemProps.get(PATHPARAMENTITYDSDID));
        restIntegrationReq.setQueryparamEntityId(cuSystemProps.get(QUERYPARAMENTITYDSDID));
    }

    private SwaggerIntegrationReq buildSwaggerIntegration(Map<String, String> cuSystemProperties) {
        SwaggerIntegrationReq swaggerIntegrationReq = new SwaggerIntegrationReq();
        swaggerIntegrationReq.setSwaggerUrl(cuSystemProperties.get(SWAGGER_URL));
        swaggerIntegrationReq.setUri(cuSystemProperties.get(URI));
        swaggerIntegrationReq.setHttpMethod(cuSystemProperties.get(METHOD));
        return swaggerIntegrationReq;
    }

    public String updateIntegration(IntegrationSaveRequestDto integration) throws NSLException {
        String dsdId = null;
        TenantChangeUnitInput changeUnit = null;
        if (integration.getMetadata() != null && integration.getMetadata().containsKey(DSD_ID)) {
            dsdId = integration.getMetadata().get(DSD_ID);
            changeUnit = saveBetsService.findChangeUnitById(dsdId);
            if (changeUnit.getStatus() == PUBLISHED)
                changeUnit = saveBetsService.getEditChangeUnit(dsdId);
            changeUnit.setName(integration.getIntegrationName());
            changeUnit.setCuSystemProperties(CuUtils.buildCuSystemProps(integration));
            changeUnit = saveBetsService.saveChangeUnit(changeUnit);
        } else
            return saveIntegration(integration, null, null);
        return changeUnit.getName();
    }

    public String updateIntegration(IntegrationSaveRequestDto integration,
                                    MultipartFile inputEntityFile, MultipartFile outputEntityFile) throws NSLException {
        String dsdId = null;
        TenantChangeUnitInput changeUnit = null;
        if (integration.getMetadata() != null && integration.getMetadata().containsKey(DSD_ID)) {
            dsdId = integration.getMetadata().get(DSD_ID);
            changeUnit = saveBetsService.findChangeUnitById(dsdId);
            if (changeUnit.getStatus() == PUBLISHED)
                changeUnit = saveBetsService.getEditChangeUnit(dsdId);
            changeUnit.setName(integration.getIntegrationName());
            switch (AdapterType.valueOf(integration.getAdapterType())){
                case REST:
                    updateRestCU(integration, changeUnit, inputEntityFile, outputEntityFile);
                    break;
                default:
                    changeUnit.setCuSystemProperties(CuUtils.buildCuSystemProps(integration));
                    break;
            }
            changeUnit = saveBetsService.saveChangeUnit(changeUnit);
        } else
            return saveIntegration(integration, null, null);
        return changeUnit.getName();
    }

    private void updateRestCU(IntegrationSaveRequestDto integration, TenantChangeUnitInput changeUnit,
                              MultipartFile inputEntityFile, MultipartFile outputEntityFile) throws NSLException {
        if (!CuUtils.validateEntities(integration.getRestIntegrationReq())) {
            throw new NSLException(ErrorType.VALIDATION, ExceptionCategory.VALIDATION, messageSource.getMessage("Paas_Adapter_87", null, Locale.ENGLISH), null);
        }
        Map<String, String> cuproperties = changeUnit.getCuSystemProperties();
        CuUtils.updateCuSystemProps(integration,cuproperties);
        String inputEntityId = null;
        String outputEntityId = null;
        String headersEntityId = null;
        String pathparamsEntityId = null;
        String queryparamsEntityId = null;
        TenantCUEntityInput requestGeneralEntity = null;
        TenantCUEntityInput responseGeneralEntity = null;
        String inputEntityName = integration.getIntegrationName() + "_" + REQUEST
                + "_" + UUIDGenerator.generateType1UUID();
        String outputEntityName = integration.getIntegrationName() + "_" + RESPONSE
                + "_" + UUIDGenerator.generateType1UUID();
        if (integration.getSwaggerEnabled()!=null && integration.getSwaggerEnabled()){
            swaggerParser.swaggerParser(integration);
        }else {
            if (inputEntityFile != null) {
                requestGeneralEntity = createEntityService.convertIntoEntity(integration.getRestIntegrationReq().getInputEntityFileType(), inputEntityFile, inputEntityName,null);
                cuproperties.put(REQUESTID, requestGeneralEntity.getDsdId());
                cuproperties.put(REQUESTNAME, requestGeneralEntity.getName());
            } else
                inputEntityId = integration.getRestIntegrationReq().getInputEntityId();
            if (outputEntityFile != null) {
                responseGeneralEntity = createEntityService.convertIntoEntity(integration.getRestIntegrationReq().getOutputEntityFileType(), outputEntityFile, outputEntityName,null);
            } else
                outputEntityId = integration.getRestIntegrationReq().getOutputEntityId();
            headersEntityId = integration.getRestIntegrationReq().getHeaderEntityId();
            pathparamsEntityId = integration.getRestIntegrationReq().getPathparamEntityId();
            queryparamsEntityId = integration.getRestIntegrationReq().getQueryparamEntityId();
        }
        List<TenantSlotItemInput> responseParticipatingItems = new ArrayList<>();
        if (integration.getRestIntegrationReq().getStatusMap()!=null
                && !integration.getRestIntegrationReq().getStatusMap().keySet().isEmpty()){
            getTriggerCESItems(integration, responseParticipatingItems, cuproperties);
        }else {
            responseGeneralEntity = getCUfromId(outputEntityId,null,null, responseGeneralEntity);
            CuUtils.addSlotItemtoLayer(responseGeneralEntity, responseParticipatingItems);
        }

        requestGeneralEntity = getCUfromId(inputEntityId, cuproperties, REQUESTNAME, requestGeneralEntity);
        TenantCUEntityInput headersGeneralEntity = getCUfromId(headersEntityId, cuproperties, HEADERENTITYID, null);
        TenantCUEntityInput pathparamsGeneralEntity = getCUfromId(pathparamsEntityId, cuproperties, PATHPARAMENTITYID, null);
        TenantCUEntityInput queryparamsGeneralEntity = getCUfromId(queryparamsEntityId, cuproperties, QUERYPARAMENTITYID, null);
        List<TenantSlotItemInput> requestParticipatingItems = new ArrayList<>();
        TenantCULayerInput physicalLayer = new TenantCULayerInput();
        physicalLayer.setType(LayerType.PHYSICAL);

        CuUtils.addSlotItemtoLayer(requestGeneralEntity, requestParticipatingItems);
        CuUtils.addSlotItemtoLayer(headersGeneralEntity, requestParticipatingItems);
        CuUtils.addSlotItemtoLayer(pathparamsGeneralEntity, requestParticipatingItems);
        CuUtils.addSlotItemtoLayer(queryparamsGeneralEntity, requestParticipatingItems);

        physicalLayer.setParticipatingItems(requestParticipatingItems);


        TenantCULayerInput triggerCESLayer = new TenantCULayerInput();
        triggerCESLayer.setType(LayerType.TRIGGERCES);

        triggerCESLayer.setParticipatingItems(responseParticipatingItems);

        List<TenantCULayerInput> cuLayers = new ArrayList<>();
        cuLayers.add(physicalLayer);
        cuLayers.add(triggerCESLayer);

        changeUnit.setLayers(cuLayers);
        changeUnit.setCuSystemProperties(cuproperties);


    }

    public IntegrationSaveRequestDto getIntegrationById(String dsdId) throws NSLException {
        TenantChangeUnitInput changeUnit = saveBetsService.findChangeUnitById(dsdId);
        return buildIntegration(changeUnit);
    }

    private TenantCUEntityInput getCUfromId(String dsdId, Map<String, String> cuproperties, String propertyName, TenantCUEntityInput entityInput ) throws NSLException {
        if (dsdId!=null){
            entityInput = saveBetsService.findEntityById(dsdId);
            if (cuproperties != null){
                cuproperties.put(propertyName,entityInput.getName());
            }

        }
        return entityInput;
    }

    public void checkCUName(String integration) {
        ChangeUnit changeUnit = changeUnitDao.getChangeUnitByName(integration, requestScopedAuthenticatedUserBean);
        if(changeUnit!=null && changeUnit.getId()!=null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    messageSource.getMessage("Paas_Adapter_7", null, Locale.ENGLISH) + integration, null);
    }

    public JsonEntityDto extractJson(String dsdId){
        if (dsdId==null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_206", null, Locale.ENGLISH), null);
        }
        TenantCUEntityInput entityInput;
        try{
            entityInput = saveBetsService.findEntityById(dsdId);
        }catch (NSLException e){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_207", null, Locale.ENGLISH), null);
        }

        return extractJsonFromEntity(entityInput, "");
    }

    private JsonEntityDto extractJsonFromEntity(TenantCUEntityInput entityInput, String prefix){
        JsonEntityDto dto = new JsonEntityDto();
        dto.setName(entityInput.getName());
        String currentPrefix = "".equals(prefix)?prefix:prefix+".";
        for (TenantCUEntityAttributeInput attributeInput : entityInput.getNslAttributes()){
            JsonAttributeDto attributeDto = new JsonAttributeDto();
            attributeDto.setName(attributeInput.getName());
            attributeDto.setPath(currentPrefix+attributeInput.getName());
            if (attributeInput.getGeneralEntity()!=null){
                attributeDto.setEntity(extractJsonFromEntity(attributeInput.getGeneralEntity(), attributeDto.getPath()));
            }
            dto.getAttributes().add(attributeDto);
        }
        return dto;
    }

}