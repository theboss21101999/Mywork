package com.nsl.adapter.service.jira.enums;

public enum JiraOperation {
    REGISTER_WEBHOOK,
    CREATE_ISSUE,
    UPDATE_ISSUE,
    DELETE_ISSUE,
    GET_ISSUE,
    CREATE_FILTER,
    DELETE_FILTER,
    ADD_COMMENT,
    DELETE_COMMENT,
    UPDATE_COMMENT,
    GET_COMMENT,
    CREATE_PROJECT,
    DELETE_PROJECT

}


