package com.nsl.adapter.service.kafka.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.dto.connections.KafkaConnectionDto;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.TxnGeneralEntity;

public interface KafkaParser {

    JsonNode callOutBoundKafka(TxnGeneralEntity txnGeneralEntity, GeneralEntity inputGeneralEntity, KafkaConnectionDto connection);

    JsonNode callInBoundKafka(GeneralEntity tcesGeneralEntity,KafkaConnectionDto connection);
}
