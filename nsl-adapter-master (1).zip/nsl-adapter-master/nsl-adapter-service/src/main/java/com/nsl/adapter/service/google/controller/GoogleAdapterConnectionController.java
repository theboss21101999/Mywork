package com.nsl.adapter.service.google.controller;

import com.nsl.adapter.commons.dto.connections.GoogleOauthDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.google.OauthConnection;
import com.nsl.adapter.service.google.service.GoogleConnectionService;
import com.nsl.logical.exception.NSLException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class GoogleAdapterConnectionController {

    @Autowired
    GoogleConnectionService googleConnectionService;

    @Autowired
    OauthConnection oauthConnection;

    @Autowired
    private MessageSource messageSource;

    @PostMapping(path = "/google")
    public ApiResponse saveGoogleConnection(@RequestBody GoogleOauthDto connectionDto) throws NSLException {

        TxnAdapterConnection result = googleConnectionService.saveGoogleConnection(connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationcode(connectionDto,result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);
    }

    @GetMapping(path = "/google/{Id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getGoogleConnection(@PathVariable("Id") Long id){

        GoogleOauthDto result = googleConnectionService.getGoogleConnection(id,true);
        return new ApiResponse(HttpStatus.OK, SUCCESS,result);
    }

    @GetMapping(path = "/google/refreshToken/{Id}")
    public ApiResponse updateGoogleToken(@PathVariable("Id") Long id) throws NSLException {

        TxnAdapterConnection result =oauthConnection.getRefreshToken(id);
        return new ApiResponse(HttpStatus.OK,SUCCESS,result);
    }

    @PutMapping(path = "/google/{id}")
    public ApiResponse updateGoogleConnection(@PathVariable("id") Long id,
                                              @RequestBody GoogleOauthDto connectionDto ) throws NSLException {

        TxnAdapterConnection result =googleConnectionService.updateGoogleConnection(id,connectionDto);
        JSONObject jsonObject = oauthConnection.getAuthorizationcode(connectionDto,result);
        return new ApiResponse(HttpStatus.OK, SUCCESS, jsonObject);

    }


}



