package com.nsl.adapter.service.facebook.utils;

import org.springframework.beans.factory.annotation.Value;

public final class FacebookConstants {

    public static final String REFRESH_TOKEN="refresh_token";
    public static final String FACEBOOK = "Facebook";
    public static final String FACEBOOK_AUTH_TOKEN = "https://www.facebook.com/v15.0/dialog/oauth";
    public static final String FACEBOOK_ACCESS_TOKEN ="https://graph.facebook.com/v15.0/oauth/access_token";
    public static final String PAGENAME = "pageName";
    public static final String GROUPNAME = "groupName";
    public static final String PROMPT="prompt";
    public static final String CONSENT="consent";
    public static final String ACCESS_TYPE="access_type";
    public static final String OFFLINE="offline";
    public static final String CODE="code";
    public static final String STATE="state";
    public static final String Url="url";
    public static final String AUTHORIZATION_CODE="authorization_code";
    public static final String PAGE_GET_ALL_COMMENTS = "PAGE_GET_ALL_COMMENTS";
    public static final String CREATE_PAGE_POST = "CREATE_PAGE_POST";
    public static final String GET_PAGE_POSTS = "GET_PAGE_POSTS";
    public static final String CREATE_GROUP_POST = "CREATE_GROUP_POST";
    public static final String GET_GROUP_POSTS = "GET_GROUP_POSTS";
    public static final String PAGE_COMMENT = "PAGE_COMMENT";
    public static final String PAGE_COMMENT_REPLY = "PAGE_COMMENT_REPLY";
    public static final String PAGE_USER_REACTION = "PAGE_USER_REACTION";
    public static final String PAGE_GET_COMMENTS = "PAGE_GET_COMMENTS";

    public static final String COMMENT_ID = "commentId";
    public static final String COMMENT_DATA = "comment";
    public static final String CREATED_TIME = "createdTime";
    public static final String COMMENT_LIST = "NSL_Facebook_Comments";

    public static final String POST_LIST = "NSL_Facebook_Posts";
    public static final String POST_DATA = "post";
    public static final String POST_ID ="postId";
    private FacebookConstants(){
        throw new IllegalStateException("utility class");
    }
}
