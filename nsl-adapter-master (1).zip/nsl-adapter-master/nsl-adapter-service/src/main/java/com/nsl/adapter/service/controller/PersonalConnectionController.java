package com.nsl.adapter.service.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.PersonalConnectionUtils;
import com.nsl.common.constant.AppConstant;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.PersonalConnectionDao;
import com.nsl.logical.model.PersonalConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping(value = "/api/v1/personal")
public class PersonalConnectionController {

    private static final Logger LOGGER = LoggerFactory.getLogger(PersonalConnectionController.class);

    private static final String INVALID_DATA = "Please send valid Data";
    private static final String RECORD_NOT_FOUND = "Record not found.";

    @Autowired
    PersonalConnectionDao personalConnectionDao;

    @Autowired
    PersonalConnectionUtils connectionUtils;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @PostMapping(path = "/connections", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveConnection(@RequestBody Object dto, @Valid @RequestParam("type") AdapterType type){
        try {
            return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS,
                    personalConnectionDao.saveConnection(connectionUtils.createConnection(dto, type)));

        }catch (Exception e){
            LOGGER.error("Error while saving/updating connection : ", e);
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
        }
    }

    @GetMapping(path = "/connections", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getConnection(@Nullable @RequestParam("type") AdapterType type){
        try {
            Object obj = null;
            if (type==null){
                List<PersonalConnection> connections = personalConnectionDao.getConnections(authBean.getUserId(),
                        authBean.getTenantId());
                connectionUtils.hideDto(connections);
                obj = connections;
            }else {
                PersonalConnection connection = authBean.isTenantAdmin()?
                        personalConnectionDao.getTenantConnection(authBean.getTenantId(), type.toString()):
                        personalConnectionDao.getConnection(authBean.getUserId(), authBean.getTenantId(), type.toString());
                if (connection==null){
                    return new ApiResponse(HttpStatus.BAD_REQUEST, RECORD_NOT_FOUND, null);
                }
                obj = JacksonUtils.fromJson(connection.getConnectionDto(), Object.class);
            }
            return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, obj);

        }catch (Exception e){
            LOGGER.error("Error while Fetching connection(s) : ", e);
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
        }
    }

    @DeleteMapping(path = "/connections", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse deleteConnection(@Nullable @RequestParam("type") AdapterType type){
        try {
            String obj = null;
            if (type==null){
                personalConnectionDao.deleteAllConnections(authBean.getUserId(), authBean.getTenantId());
            }else {
                personalConnectionDao.deleteConnection(authBean.getUserId(), authBean.getTenantId(), type.toString());
            }
            return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, obj);

        }catch (Exception e){
            LOGGER.error("Error while Fetching connection(s) : ", e);
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
        }
    }

    @GetMapping(value = "/login/auth")
    public ApiResponse fetchOauthLogin(@Valid @RequestParam("type") AdapterType type){
        try{
            String uri = connectionUtils.getLoginUrl(type);
            Map<String, String> result = new HashMap<>();
            result.put(com.nsl.adapter.service.utils.AppConstant.URL, uri);
            return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, result);
        } catch (Exception e) {
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, AppConstant.FAILED, e.getMessage());
        }
    }

    @PostMapping(value = "/oauth/code")
    public ApiResponse saveAuthCode(@RequestParam("code") String code, @RequestParam("state") String state){
        try{
            byte[] decodedBytes = Base64.getDecoder().decode(state);
            final String decodedString = new String(decodedBytes, StandardCharsets.UTF_8);
            HashMap valueMap = new ObjectMapper().readValue(decodedString, HashMap.class); //NOSONAR
            if (valueMap.containsKey(com.nsl.adapter.service.utils.AppConstant.USE_PERSONAL) && valueMap.get(com.nsl.adapter.service.utils.AppConstant.USE_PERSONAL).equals("true")){
                connectionUtils.saveRefreshToken(valueMap, code);
                return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, null);
            }
            return new ApiResponse(HttpStatus.BAD_REQUEST, AppConstant.FAILED, null);
        } catch (Exception e) { //NOSONAR
            LOGGER.error("Error while creating and saving refresh token : ", e);
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, AppConstant.FAILED, e.getMessage());
        }
    }

}
