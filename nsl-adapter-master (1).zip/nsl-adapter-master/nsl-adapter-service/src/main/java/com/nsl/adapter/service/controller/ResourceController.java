package com.nsl.adapter.service.controller;

import com.nsl.adapter.service.config.AdminAuth;
import com.nsl.adapter.service.dto.ResourceRequestDto;
import com.nsl.adapter.service.dto.SwaggerCategoryDto;
import com.nsl.adapter.service.dto.SwaggerResourceDto;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.SwaggerParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import javax.validation.Valid;
import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@AdminAuth
@RestController
@CrossOrigin
@RequestMapping(value = "/api/v1/resource")
public class ResourceController {

    @Autowired
    SwaggerParser parser;

    @PostMapping(value = "/swagger-resources")
    public ApiResponse getResourcesForSwagger(@Valid @RequestBody ResourceRequestDto resourceRequestDto) {
        SwaggerResourceDto response = parser.getResourcesForSwagger(resourceRequestDto);
        return new ApiResponse(HttpStatus.OK, SUCCESS, response);
    }

    @GetMapping(value = "/categories")
    public ApiResponse getCategoriesForSwagger(@RequestParam String swaggerUrl) {
        SwaggerCategoryDto response = parser.getCategoriesForSwagger(swaggerUrl);
        return new ApiResponse(HttpStatus.OK, SUCCESS, response);
    }
}
