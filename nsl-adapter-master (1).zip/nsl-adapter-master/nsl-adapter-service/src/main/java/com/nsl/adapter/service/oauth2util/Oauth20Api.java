package com.nsl.adapter.service.oauth2util;

import com.github.scribejava.apis.openid.OpenIdJsonTokenExtractor;
import com.github.scribejava.core.builder.api.DefaultApi20;
import com.github.scribejava.core.extractors.DeviceAuthorizationJsonExtractor;
import com.github.scribejava.core.extractors.TokenExtractor;
import com.github.scribejava.core.model.OAuth2AccessToken;

import com.nsl.adapter.commons.dto.connections.OAuthCredentials;
public class Oauth20Api extends DefaultApi20 {
    private final OAuthCredentials oAuthCredentials;
    public Oauth20Api(OAuthCredentials oAuthCredentials) {
        this.oAuthCredentials = oAuthCredentials;
    }

    public String getAccessTokenEndpoint() {
        return this.oAuthCredentials.getAccessTokenUri();
    }

    protected String getAuthorizationBaseUrl() {
        return this.oAuthCredentials.getAuthorizationUri();
    }

    public TokenExtractor<OAuth2AccessToken> getAccessTokenExtractor() {
        return OpenIdJsonTokenExtractor.instance();
    }

    public String getRevokeTokenEndpoint() {
        return super.getRevokeTokenEndpoint();
    }

    public String getDeviceAuthorizationEndpoint() {
        return super.getDeviceAuthorizationEndpoint();
    }

    public DeviceAuthorizationJsonExtractor getDeviceAuthorizationExtractor() {
        return super.getDeviceAuthorizationExtractor();
    }
}
