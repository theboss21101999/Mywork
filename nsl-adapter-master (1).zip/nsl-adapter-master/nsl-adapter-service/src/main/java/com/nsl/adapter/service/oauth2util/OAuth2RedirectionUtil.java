package com.nsl.adapter.service.oauth2util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.dto.RedirectionDto;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.model.Book;
import com.nsl.logical.model.TxnData;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Component
public class OAuth2RedirectionUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(OAuth2RedirectionUtil.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    private AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Autowired
    private ChangeUnitDao changeUnitRdfDao;

    @Autowired
    private AdaptorProperties adaptorProperties;

    @Autowired
    CdmUtils cdmUtility;

    Base64.Encoder encoder = Base64.getEncoder();
    Base64.Decoder decoder = Base64.getDecoder();

    public String getStateParam(TxnData txnData){

        String state = null;

        try {

            String gsiId = txnData.getCuContextualId().split("\\.")[0].split("GS")[1];
            String txnId = txnData.getTransactionId();
            Book book = changeUnitRdfDao.getBookByGsiId(Long.valueOf(gsiId), requestScopedAuthenticatedUserBean);
            Map<String, Object> valueMap = new HashMap<>();
            valueMap.put(AppConstant.GSI_ID, gsiId);
            valueMap.put(AppConstant.BOOK_ID, book.getId());
            valueMap.put(AppConstant.TXN_ID, txnId);
            valueMap.put(AppConstant.ENV_NAME, cdmUtility.getEnvironmentNameByTenantId(requestScopedAuthenticatedUserBean.getTenantId()));
            state = encodeData(JacksonUtils.toJson(valueMap));

        }catch (Exception e){
            LOGGER.error("Exception while generating state param for auth url");
        }

        return state;
    }

    public RedirectionDto decodeState(String state) {

        RedirectionDto redirectionDto = new RedirectionDto();
        Map<String, Object> valueMap;
        try {
            byte[] decodedBytes = Base64.getDecoder().decode(state);
            final String decodedString = new String(decodedBytes, StandardCharsets.UTF_8);
            valueMap = new ObjectMapper().readValue(decodedString, HashMap.class);

            redirectionDto.setTxnId((String) valueMap.get(AppConstant.TXN_ID));
            redirectionDto.setRedirectUrl(generateCDUIRedirectUrl(valueMap));
        }catch (Exception e){
            LOGGER.error("Exception while decoding state param", e);
        }

        return redirectionDto;
    }

    private String generateCDUIRedirectUrl(Map<String, Object> valueMap) {

        String redirectUrl = adaptorProperties.getAppRedirectCDUIUrl();
        String envName = (String) valueMap.get(AppConstant.ENV_NAME);
        if(!envName.contains("localhost"))
            redirectUrl = StringUtils.replace(redirectUrl, AppConstant.ENV_NAME_TEMPLATE, urlEncodedData(envName));

        Map<String, Object> uiVariablesMap = new HashMap<>();
        uiVariablesMap.put(AppConstant.GSI_ID, valueMap.get(AppConstant.GSI_ID));
        uiVariablesMap.put(AppConstant.BOOK_ID, valueMap.get(AppConstant.BOOK_ID));

        String uiVariables = urlEncodedData(encodeData(JacksonUtils.toJson(uiVariablesMap)));
        redirectUrl = StringUtils.replace(redirectUrl, AppConstant.UI_VARIABLE_TEMPLATE, uiVariables);

        return redirectUrl;
    }

    private String encodeData(String value){

        return encoder.encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private String urlEncodedData(String value){
        String result=null;
        try{
            result = URLEncoder.encode(value, StandardCharsets.UTF_8);
        }catch (Exception e){
            LOGGER.error("Error in encoding url", e);
        }
        return result;
    }

}
