package com.nsl.adapter.service.controller;


import com.nsl.adapter.service.service.LocationService;
import com.nsl.logical.ApiResponse;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dto.SlotDataDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@CrossOrigin
@RestController
@RequestMapping(value = "/location")
public class LocationController {

    private static final Logger logger = LoggerFactory.getLogger(LocationController.class);
    @Autowired
    private LocationService locationService;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    private AuthenticatedUserDetailsImpl authenticatedUserDetails;

    @PostMapping(value = "/save/slotData", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveSlotItem(@RequestBody SlotDataDto slotDataDto) {
        ApiResponse apiResponse = new ApiResponse();
        try{
            locationService.saveSlotItem(slotDataDto, authenticatedUserDetails);
            apiResponse.setStatus(HttpStatus.OK.value());
            apiResponse.setMessage("save slotItem Data is successfully");
        } catch (Exception ex) {
            logger.error("error in saving slotItem Data", ex);
            apiResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            apiResponse.setMessage("Error in saving slotItem Data");
        }
        return apiResponse;
    }
}
