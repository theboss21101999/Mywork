package com.nsl.adapter.service.calendar.dto;

import com.nsl.externalreservedcus.dto.calender.event.ActionButton;
import java.util.ArrayList;
import java.util.List;

public class OccupiedSlot {

    private String startTime;
    private String endTime;
    private String title;
    private List<String> attendes=new ArrayList<>();
    private List<ActionButton> gsi = new ArrayList<>();

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getAttendes() {
        return attendes;
    }

    public void setAttendes(List<String> attendes) {
        this.attendes = attendes;
    }

    public List<ActionButton> getGsi() {
        return gsi;
    }

    public void setGsi(List<ActionButton> gsi) {
        this.gsi = gsi;
    }

    public void updateAttendees(String attende){
        this.attendes.add(attende);
    }

}
