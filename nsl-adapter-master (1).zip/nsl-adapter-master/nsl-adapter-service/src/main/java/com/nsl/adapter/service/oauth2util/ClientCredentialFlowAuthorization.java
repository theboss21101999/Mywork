package com.nsl.adapter.service.oauth2util;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.dto.CredentialPair;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.OAuthCredentials;
import com.nsl.adapter.service.rest.utils.RestConstants;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;



/**
 * This class is for : ClientCredentialFlowAuthorization.
 */
@Service
public class ClientCredentialFlowAuthorization extends OAuth2FlowAuthorization {

    private static final Logger logger = LoggerFactory.getLogger(ClientCredentialFlowAuthorization.class);

    /**
     * This Object is : AdaptorProperties.
     */
    @Autowired
    private AdaptorProperties adaptorProperties;
    /**
     * This Object is : RestTemplate.
     */
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private MessageSource messageSource;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;



    @Override
    public CredentialPair getCredentialPair(RESTAdapterConnectionDto connectionDto) throws NSLException {
        String baseUri;
        String result;
        OAuthCredentials oauthCredentials = connectionDto.getAuthentication().getOAuthCredentials();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("client_id",oauthCredentials.getClientId());
        map.add("grant_type", RestConstants.CLIENT_CREDENTIALS);
        map.add("client_secret",connectionDataToolsV3.getSecret(oauthCredentials.getClientSecret()));
        HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(map, headers);

        baseUri= connectionDto.getAuthentication().getOAuthCredentials().getAccessTokenUri();
        ResponseEntity<JsonNode> response = restTemplate.exchange(baseUri,
                HttpMethod.POST, httpEntity, JsonNode.class);
        result = response.getBody().get("access_token").asText(); //NOSONAR

        CredentialPair pair = new CredentialPair();
        Map<String, String> map1 = new HashMap<>();

        map1.put("Authorization", AppConstant.BEARER+result);
        pair.setLocation(oauthCredentials.getLocation());
        pair.setCredentials(map1);
        return pair;


    }
    @Override
    public String getDefaultGrantType() {
        return "client_credentials";
    }


}