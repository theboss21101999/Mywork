package com.nsl.adapter.service.oauth2util;

import com.nsl.adapter.service.dto.CredentialPair;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.logical.exception.NSLException;


public abstract class OAuth2FlowAuthorization {
    /**
     * Public Method.
     */
    public abstract CredentialPair getCredentialPair(RESTAdapterConnectionDto restConnectionDto) throws NSLException;
    /**
     * Public Method.
     */
//    public abstract ExtOAuthToken getAccessToken(ExtOAuthToken extAppOAuthToken, ExtOAuthClient extAppAuthentication);
//    /**
//     * Public Method.
//     */
//    public abstract ExtOAuthToken refreshAccessToken(ExtOAuthToken extAppOAuthToken, ExtOAuthClient extAppAuthentication);
    /**
     * Public Method.
     */
    public abstract String getDefaultGrantType();
    /**
     * Public Method.
     */

}
