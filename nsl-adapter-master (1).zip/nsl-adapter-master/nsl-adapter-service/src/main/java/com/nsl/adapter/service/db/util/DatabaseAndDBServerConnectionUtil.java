package com.nsl.adapter.service.db.util;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.nsl.adapter.commons.dto.connections.DBConnectionDto;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

@Component
public class DatabaseAndDBServerConnectionUtil {
    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(DatabaseAndDBServerConnectionUtil.class);
    public MongoClient MongoDBServerConnection(DBConnectionDto dbConnectionDto){
        try {
            LOGGER.info("Connecting To Mongo Server ...");
            MongoClient mongoClient = new MongoClient(new MongoClientURI(dbConnectionDto.getDataSourceUrl()));
            List<String> dbs = mongoClient.getDatabaseNames();
            LOGGER.info("Mongo Server Connection Successful");
            return mongoClient;
        }
        catch (Exception e){
            LOGGER.error("Mongo server connection failed reason"+e.getMessage());
            throw new RuntimeException();//NOSONAR
        }
    }
    public Connection MyssqlDBserverConnection(DBConnectionDto connectionDto) {
        try {
            Class.forName(connectionDto.getDataSourceDriver());
            LOGGER.info("Connecting To Mysql Server ...");
            Connection con = DriverManager.getConnection(connectionDto.getDataSourceUrl(),
                    connectionDto.getUsername(), connectionDto.getPassword());
            LOGGER.info("Mysql Server Connection Successful");
            return con;
        }
        catch (Exception e){
            LOGGER.error("Mysql server connection failed reason"+e.getMessage());
            throw new RuntimeException();//NOSONAR

        }

    }
    public Connection PostgreSqlDBserverConnection(DBConnectionDto connectionDto) {
        try {
            Class.forName(connectionDto.getDataSourceDriver());
            LOGGER.info("Connecting To Postgresql Server ...");
            Connection con = DriverManager.getConnection(connectionDto.getDataSourceUrl(),
                    connectionDto.getUsername(), connectionDto.getPassword());
            LOGGER.info("Postgresql Server Connection Successful");
            return con;
        }
        catch (Exception e){
            LOGGER.error("Postgresql server connection failed reason"+e.getMessage());
            throw new RuntimeException();//NOSONAR
        }

    }
    public Connection SqlServerDBserverConnection(DBConnectionDto connectionDto) {
        try {
            Class.forName(connectionDto.getDataSourceDriver());
            LOGGER.info("Connecting To SQL Server DB Server ...");
            Connection con = DriverManager.getConnection(connectionDto.getDataSourceUrl(),
                    connectionDto.getUsername(), connectionDto.getPassword());
            LOGGER.info("Sql Server DB Server Connection Successful");
            return con;
        }
        catch (Exception e){
            LOGGER.error("Sql Server DB server connection failed reason"+e.getMessage());
            throw new RuntimeException();//NOSONAR

        }

    }
}