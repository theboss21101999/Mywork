package com.nsl.adapter.service.sftp.connection;

public class SFTPConnectionException extends Exception{

    public SFTPConnectionException(){
    }

    public SFTPConnectionException(String message) {
        super(message);
    }
    public SFTPConnectionException(String message, Exception cause) {
        super(message, cause);
    }

}
