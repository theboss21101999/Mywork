package com.nsl.adapter.service.enums;


public enum OAuthFlowType {

    AUTHORIZATION_CODE("AUTHORIZATION_CODE"),
    IMPLICIT("IMPLICIT"),
    CLIENT_CREDENTIAL("CLIENT_CREDENTIAL"),
    PASSWORD("PASSWORD");

    private String flow;

    private OAuthFlowType(String flow) {
        this.flow = flow;
    }

    public String getFlow() {
        return this.flow;
    }

    public static OAuthFlowType fromValue(String val) {
        for (OAuthFlowType b : OAuthFlowType.values()) {
            if (b.getFlow().equalsIgnoreCase(val)) {
                return b;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return String.valueOf(this.getFlow());
    }

}
