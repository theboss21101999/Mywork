package com.nsl.adapter.service.mqtt.controller;


import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.commons.dto.connections.MqttConnectionDto;
import com.nsl.adapter.service.mqtt.service.MqttConnectionService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;

@RestController
@CrossOrigin
@RequestMapping(value = "/connect")
public class MqttConnectionController {

    @Autowired
    MqttConnectionService mqttConnectionService;


    @PostMapping(path = "/mqtt",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse saveMqttConnection(@RequestBody MqttConnectionDto connectionDto)  {
        TxnGeneralEntityRecord result = mqttConnectionService.saveMqttConnection(connectionDto);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }

    @GetMapping(path = "/mqtt/{connectionId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse getMqttConnection(@PathVariable("connectionId") Long connectionId) {
        MqttConnectionDto response = mqttConnectionService.getMqttConnection(connectionId, false);
        return new ApiResponse(HttpStatus.OK, AppConstant.SUCCESS, response);
    }

    @PutMapping(path = "/mqtt/{connectionId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ApiResponse updateMqttConnection(@PathVariable("connectionId") Long connectionId, @RequestBody MqttConnectionDto connection) {
        TxnGeneralEntityRecord result = mqttConnectionService.updateMqttConnection(connection, connectionId);
        return new ApiResponse(HttpStatus.OK, SUCCESS, result);
    }


}
