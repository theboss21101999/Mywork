package com.nsl.adapter.service.rest;


import com.nsl.adapter.commons.dto.connections.HawkCredentials;
import com.nsl.adapter.commons.dto.connections.RESTAdapterConnectionDto;
import com.nsl.adapter.commons.enums.ApiKeyLocation;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.commons.utils.UUIDGenerator;
import com.nsl.adapter.service.dto.CredentialPair;
import com.nsl.adapter.service.utils.extapi_auth_credential.ExtAuthCredentials;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.enums.ExceptionSubCategory;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;

import static com.nsl.adapter.service.rest.utils.RestConstants.*;
import static com.nsl.adapter.service.utils.AppConstant.API_URI;
import static com.nsl.adapter.service.utils.AppConstant.CONTENT_TYPE;
import static com.nsl.adapter.service.utils.AppConstant.METHOD;
import static com.nsl.adapter.service.utils.AppConstant.REQUEST;

@Service
public class HawkAuthentication implements ExtAuthCredentials {

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    private static final Logger LOGGER = LoggerFactory.getLogger(HawkAuthentication.class);

    @Override
    public CredentialPair getCredentialPair(RESTAdapterConnectionDto restAdapterConnectionDto) throws NSLException {

        HawkCredentials hawkAuth = restAdapterConnectionDto.getAuthentication().getHawkCredentials();
        Properties properties = restAdapterConnectionDto.getAdvancedConfig();

        String method = properties.getProperty(METHOD);
        String urlString = properties.getProperty(API_URI);
        try {
            URL url = new URL(urlString);

            JSONObject pathObject = (JSONObject) properties.get(PathParamObject);
            String resource = url.getFile();
            if (pathObject != null ) {
                Iterator<String> qkeys = pathObject.keys();
                while (qkeys.hasNext()) {
                    String key = qkeys.next();
                    resource = resource.replace("{" + key+ "}",pathObject.get(key).toString());
                }
            }

            String host = url.getHost();
            String contentType = properties.getProperty(CONTENT_TYPE);
            String requestBody = properties.getProperty(REQUEST);
            String nonce = UUIDGenerator.generateRandomString(6);
            String timestamp = String.valueOf(Instant.now().getEpochSecond());

            String hash;
            if (hawkAuth.isPayloadHash())
                hash = getBodyHash(contentType, requestBody, hawkAuth.getAlgorithm());
            else hash = "\n";

            String payload = String.join("\n", "hawk.1.header", timestamp, nonce, method, resource, host, "443", hash, "\n");

            String mac = getHmac(connectionDataToolsV3.getSecret(hawkAuth.getAuthKey()), payload, hawkAuth.getAlgorithm());
            String header = "Hawk " +
                    id + "=\"" + hawkAuth.getAuthId() + "\", " +
                    ts + "=\"" + timestamp + "\", " +
                    Nonce + "=\"" + nonce + "\", " +
                    MAC +"=\"" + mac + "\"";

            if (hawkAuth.isPayloadHash()) {
                header = header + "," + Hash + "=\"" + hash + "\"";
            }

            CredentialPair credentialPair = new CredentialPair();
            Map<String, String> map = new HashMap<>();
            credentialPair.setLocation(ApiKeyLocation.HEADER);
            map.put("Authorization", header);

            credentialPair.setCredentials(map);
            return credentialPair;

        }catch (NSLException e){
            throw e;
        }catch (Exception e) {
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.BASIC_CU, "Error while generating " +
                    "Hawk Authentication header" + e.getMessage(), ExceptionSeverity.CRITICAL, e);
        }
    }

    private static String getHmac(String secret, String payload, String algorithm) throws NoSuchAlgorithmException, InvalidKeyException {

        String hmacAlgorithm;
        if (sha256.equals(algorithm))
            hmacAlgorithm = HmacSHA256;
        else if (sha512.equals(algorithm))
            hmacAlgorithm = HmacSHA512;
        else if (sha1.equals(algorithm))
            hmacAlgorithm = HmacSHA1;
        else
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.BASIC_CU, "invalid hashing algorithm"
                    , ExceptionSeverity.CRITICAL, null);

        LOGGER.info("mac hash {}", payload);

        Mac sha256_HMAC = Mac.getInstance(hmacAlgorithm);
        SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), hmacAlgorithm);
        sha256_HMAC.init(secret_key);
        byte[] macBytes = sha256_HMAC.doFinal(payload.getBytes(StandardCharsets.UTF_8));

        return new String(java.util.Base64.getEncoder().encode(macBytes), StandardCharsets.UTF_8);
    }

    private static String getBodyHash(String contentType, String requestBody, String algorithm) throws NoSuchAlgorithmException {

        String hmacAlgorithm;
        if (sha256.equals(algorithm))
            hmacAlgorithm = SHA_256;
        else if (sha512.equals(algorithm))
            hmacAlgorithm = SHA_512;
        else if (sha1.equals(algorithm))
            hmacAlgorithm = SHA_1;
        else
            throw new NSLException(ExceptionCategory.PROCESS, ExceptionSubCategory.BASIC_CU, "invalid hashing algorithm"
                    , ExceptionSeverity.CRITICAL, null);

        String payload = "hawk.1.payload\n" +
                contentType + "\n" +
                requestBody + "\n";

        LOGGER.info("payload hash {}", payload);
        MessageDigest sha256 = MessageDigest.getInstance(hmacAlgorithm);
        byte[] hashBytes = sha256.digest(payload.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(hashBytes);
    }

}
