package com.nsl.adapter.service.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Configuration
@ConfigurationProperties
public class AdaptorProperties {

    private static final Logger logger = LoggerFactory.getLogger(AdaptorProperties.class);

    private Map<String, String> logging;

    private Map<String, String> app;

    private Map<String, String> access;

    private Map<String, String> spring;

    @Value("${sftp.adapter.gsi.execution.url}")
    private String executionUrl;

    @Value("${sftp.adapter.system.user.token.url}")
    private String sysUserTokenUrl;

    @Value("${dynamoNew.store.enabled:false}")
    private boolean dynamoNewEnabled;

    public void setLogging(Map<String, String> logging) {
        this.logging = logging;
    }

    public void setApp(Map<String, String> app) {
        this.app = app;
    }



    public void setAccess(Map<String, String> access) {
        this.access = access;
    }

    public void setSpring(Map<String, String> spring) {
        this.spring = spring;
    }

    @PostConstruct
    public void printLogs() {

        if (logger.isInfoEnabled()) {
            logger.info("logging values added from application properties " + this.toString());
        }
    }

    public String getOpenApiUrl(){
        return app.get("restinbound.openapi3.url");
    }

    public String getsecmccUrl(){
        return app.get("restinbound.secmcc.url");
    }

    public String gettransactionsUrl(){
        return app.get("restinbound.transactions.url");
    }

    public String getRedirectUrl(){ return app.get("connection.redirectUrl"); }

    public String getPersonalConnUrl(){ return app.get("personal.connection.redirect"); }



    public String getOauthRedirect(){ return app.get("oauth.redirect"); }


    public String getAppOauthSwaggerUrl() {
        return app.get("oauth.swagger.url");
    }

    public String getAppOauthClientId() {
        return app.get("oauth.clientId");
    }

    public String getAppOauthclientSecret() {
        return app.get("oauth.clientSecret");
    }

    public String getAppOauthTestUserName() {
        return app.get("oauth.test.username");
    }

    public String getAppOauthTestPassword() {
        return app.get("oauth.test.password");
    }

    public String getAppOauthGrantType() {
        return app.get("oauth.grant.type");
    }

    public String getAppOauthLicenseUrl() {
        return app.get("oauth.licenseURL");
    }

    public String getAppExtSolnsUrl() {
        return app.get("extsolns.versioning.url");
    }

    public String getAppExtSolnsTimeout() {
        return app.get("extsolns.versioning.timeout.seconds");
    }

    public String getGerritVersioningExecutionMaxThreads() {
        return app.get("extsolns.versioning.max.threads");
    }

    public String getAppDsdSingleFileUploadUrl() {
        return app.get("dsd-files-store-url-single");
    }

    public String getAppDsdMultiFilesUploadUrl() {
        return app.get("dsd-files-store-url-multi");
    }



    public String getTxnUrl() {
        return app.get("txn.url");
    }

    public String getCoreUrl() {
        return app.get("core.url");
    }

    public String getEnvUrl() {
        return app.get("env.url");
    }
    public String getAppCdmTenantEnvUrl() {
        return app.get("iam.cdm.tenant.env.url");
    }

    public String getAppOauthCallbackUrl() {
        return app.get("adapter.callBackUrl");
    }

    public String getAppRedirectCDUIUrl() {
        return app.get("redirect.cdui.url");
    }

    public String getAppRedirectTbuiUrl() {
        return app.get("tbui.redirectUrl");
    }

    public String getAppSFTPInboundInvokeUrl() {
        return app.get("sftp.inbound.trigger.url");
    }

    public String getAppSchedulerUrl() {
        return app.get("scheduler.url");
    }

    public String getFilesAdapterServiceInboundUrl() {
        return app.get("filesAdapter.inbound.job.url");
    }

    public String getEmailAdapterServiceInboundUrl() {
        return app.get("emailAdapter.inbound.job.url");
    }

    public String getAdapterServiceInboundUrl() {
        return app.get("adapter.inbound.job.url");
    }

    public String getReservedEntitySeedUrl() {
        return app.get("adapter.reserved.entity.seed.url");
    }

    public String getGsiExecutionUrl() {
        return executionUrl;
    }

    public String getGsiSystemUrl() {
        return sysUserTokenUrl;
    }

    public String getSuperAdmin() {
        return app.get("pass.super.admin");
    }

    public String getSuperAdminEmail() {
        return app.get("pass.super.admin.email");
    }

    public String getCertKeyStorePath() {
        return app.get("keystore.path");
    }

    public String getAimlDynamicUrl(){
        return app.get("aiml.dynamic.url");
    }

    public String getCertKeyStoreType() {
        return app.get("keystore.type");
    }

    public String getArgoExtsolnsUrl(){return app.get("argo.extsolns.url"); }

    public Boolean getDynamoNewEnabled() {
        return dynamoNewEnabled;
    }

    public String getDynamoNewUrl(){
        return app.get("dynamoNew.store.url");
    }

    public String getSendNotification(){
        return app.get("send.notification.url");
    }

    public String getEmailNotification(){return  app.get("app.send.email.notification.url");}

    public String getWebhookUrl() {
        return app.get("webhook.url");
    }
    public String getArgoSchedulerUrl() {
        return app.get("argoApi.url");
    }

    public List<String> getNslOpenApiPathStart(){

        List<String> openAPisPathStart = new ArrayList<>();
        String openAPisPathStartString = app.get("nsl.open.apis.path.start");
        if(openAPisPathStartString != null){
            openAPisPathStart= Arrays.asList((openAPisPathStartString.split(",")));
        }

        return openAPisPathStart;
    }

    @Override
    public String toString() {
        return "AdaptorProperties [logging=" + logging + ", app=" + app + ", access="
                + access + ", spring=" + spring +"]";
    }


}
