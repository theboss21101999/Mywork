package com.nsl.adapter.service.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.dto.ExecuteAdaptorRequestDto;
import com.nsl.adapter.commons.dto.GsiInvocationDto;
import com.nsl.adapter.commons.service.GsiExecutor;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.dto.RedirectionDto;
import com.nsl.adapter.commons.dto.SchedulerRequestDto;
import com.nsl.adapter.service.oauth2util.OAuth2RedirectionUtil;
import com.nsl.adapter.service.oauth2util.OAuthAccessCodeUtil;
import com.nsl.adapter.service.service.ExternalApiReservedCUService;
import com.nsl.adapter.service.service.InboundAdapterFactory;
import com.nsl.adapter.service.service.InboundIntegrationService;
import com.nsl.adapter.service.stripe.utils.StripeConstants;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.GeneralUtils;
import com.nsl.adapter.commons.utils.RestApiConstants;
import com.nsl.adapter.service.v2.utills.RedisIntegration;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.GSI;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import io.swagger.v3.oas.annotations.Hidden;
import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import javax.annotation.Resource;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static com.nsl.adapter.service.utils.AppConstant.SUCCESS;


/** @author Keshav **/
@RestController
@CrossOrigin
@RequestMapping(value = "/api")
public class ExternalApiReservedCUController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExternalApiReservedCUController.class);

    @Autowired
    ExternalApiReservedCUService externalApiReservedCUService;

    @Autowired
    OAuthAccessCodeUtil saveOAuthCodeUtil;

    @Autowired
    RedisIntegration redisIntegration;

    @Autowired
    OAuth2RedirectionUtil oAuth2RedirectionUtil;

    @Autowired
    InboundAdapterFactory inboundAdapterFactory;

    @Autowired
    AdaptorProperties adaptorProperties;

    @Autowired
    ChangeUnitDao changeUnitDao;

    @Autowired
    GeneralUtils generalUtils;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    GsiExecutor gsiExecutor;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Operation(summary = "Execute External Api Reserved CU Service ", description = "This api is called to execute external api reserved cu service using ExecuteAdaptorRequestDto.", tags = {"" })
    @ApiResponses(value = { @ApiResponse(responseCode = RestApiConstants.OK_CODE, description = RestApiConstants.EXECUTE_EXTERNAL_API_RESERVED_CU_SERVICE_DESCRIPTION, content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = com.nsl.adapter.commons.utils.ApiResponse.class), examples = {
                    @ExampleObject(name = "executeExternalApiReservedCUService", value = RestApiConstants.EXECUTE_EXTERNAL_API_RESERVED_CU_SERVICE) }) }),
            @ApiResponse(responseCode = RestApiConstants.BAD_REQUEST_CODE, description = RestApiConstants.BAD_REQUEST_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.UNAUTHORIZED_CODE, description = RestApiConstants.UNAUTHORIZED_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.FORBIDDEN_CODE, description = RestApiConstants.FORBIDDEN_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.NOT_FOUND_CODE, description = RestApiConstants.NOT_FOUND_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.INTERNAL_SERVER_ERROR_CODE, description = RestApiConstants.INTERNAL_SERVER_ERROR_DESCRIPTION, content = @Content)})
    @PostMapping(value = "/ext_api", consumes="application/json", produces = MediaType.APPLICATION_JSON_VALUE)
    public com.nsl.adapter.commons.utils.ApiResponse execute(@RequestBody ExecuteAdaptorRequestDto executeAdaptorRequestDto) throws NSLException {
        try {
            LOGGER.info("||||||||||||||||||||||| Recieved execute call for end point - /ext_api |||||||||||||||||||||||");
            TxnData transData = externalApiReservedCUService.execute(executeAdaptorRequestDto, requestScopedAuthenticatedUserBean);
            return new com.nsl.adapter.commons.utils.ApiResponse(HttpStatus.OK, SUCCESS, transData);
        }catch(NSLException e){
            LOGGER.error("exception in extapi reservedCu controller {}",e.getMessage());
            return new com.nsl.adapter.commons.utils.ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,e.getMessage(),e);
        }
    }

    @Operation(summary = "Invoke Events", description = "This api is called to invoke events using SchedulerRequestDto.", tags = {""})
    @ApiResponses(value = { @ApiResponse(responseCode = RestApiConstants.OK_CODE, description = RestApiConstants.INVOKE_EVENTS_DESCRIPTION, content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = com.nsl.adapter.commons.utils.ApiResponse.class), examples = {
                    @ExampleObject(name = "invokeEvents", value = RestApiConstants.INVOKE_EVENTS) }) }),
            @ApiResponse(responseCode = RestApiConstants.BAD_REQUEST_CODE, description = RestApiConstants.BAD_REQUEST_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.UNAUTHORIZED_CODE, description = RestApiConstants.UNAUTHORIZED_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.FORBIDDEN_CODE, description = RestApiConstants.FORBIDDEN_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.NOT_FOUND_CODE, description = RestApiConstants.NOT_FOUND_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.INTERNAL_SERVER_ERROR_CODE, description = RestApiConstants.INTERNAL_SERVER_ERROR_DESCRIPTION, content = @Content)})
    @PostMapping(value = "/v1/reservedcu/events")
    public com.nsl.adapter.commons.utils.ApiResponse invokeEvents(@RequestBody SchedulerRequestDto schedulerRequestDto) {
        LOGGER.debug("Api invoked with CU name : {}", schedulerRequestDto.getName());
        if (schedulerRequestDto.getAdapter() == null) {
            return new com.nsl.adapter.commons.utils.ApiResponse(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_19", null, Locale.ENGLISH) , null);
        }
        InboundIntegrationService inboundIntegrationService = inboundAdapterFactory.getInboundIntegrationAdapter(schedulerRequestDto.getAdapter());
        try {
            return inboundIntegrationService.publishMessage(schedulerRequestDto);
       }
        catch (JSONException | NSLException e) {
            LOGGER.error("failed to invoke",e);
            return new com.nsl.adapter.commons.utils.ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,e.getMessage(),e);
        }

    }

    @GetMapping(value = "/redirect/auth")
    public ResponseEntity<JsonNode> fetchOAuthCode(@RequestParam("code") String code, @RequestParam("state") String state) throws URISyntaxException {

        LOGGER.info("Callback received for OAuth2");
        RedirectionDto redirectionDto = oAuth2RedirectionUtil.decodeState(state);
        saveOAuthCodeUtil.saveOAuthCode(redirectionDto.getTxnId(), code);
        LOGGER.debug("TXN Id : {} Redirecting to : {}", redirectionDto.getTxnId(), redirectionDto.getRedirectUrl());
        URI url = new URI(redirectionDto.getRedirectUrl());
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setLocation(url);
        return new ResponseEntity<>(httpHeaders, HttpStatus.SEE_OTHER);
    }

    @GetMapping(value = "/redirect/oAuth")
    public ResponseEntity<JsonNode> fetchGoogleOAuthCode( @RequestParam("code") String code, @RequestParam("state") String state ) {

        try {

            byte[] decodedBytes = Base64.getDecoder().decode(state);
            final String decodedString = new String(decodedBytes, StandardCharsets.UTF_8);
            HashMap valueMap = new ObjectMapper().readValue(decodedString, HashMap.class);
            String uri;
            if (valueMap.containsKey(AppConstant.USE_PERSONAL) && valueMap.get(AppConstant.USE_PERSONAL).equals("true")){
                uri = adaptorProperties.getPersonalConnUrl()
                        .replace(AppConstant.TENANT_ID_TEMPLATE, valueMap.get(AppConstant.ENV_NAME).toString())
                        .replace(AppConstant.STATE_TEMPLATE, state)
                        .replace(AppConstant.CODE_TEMPLATE, code);
            }else {
                redisIntegration.saveOAuthCode(valueMap, code);
                Base64.Encoder encoder = Base64.getEncoder();
                String state1 = JacksonUtils.toJson(valueMap);
                assert state1 != null;

                String redirectUrl = adaptorProperties.getOauthRedirect();
                redirectUrl = StringUtils.replace(redirectUrl, AppConstant.TENANT_ID_TEMPLATE, (String)valueMap.get(AppConstant.ENV_NAME));
                uri = redirectUrl+encoder.encodeToString(state1.getBytes(StandardCharsets.UTF_8));
            }


            URI url = new URI(uri); //NOSONAR
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.setLocation(url); //NOSONAR
            return new ResponseEntity<>(httpHeaders, HttpStatus.SEE_OTHER);

        }catch(Exception e){
            LOGGER.error("failed to redirect back",e);
            return null;
        }
    }

    @GetMapping(value = "/redirect/stripe/{encodedData}")
    public ResponseEntity<JsonNode> stripeRedirect(@RequestParam("code") String code,
                                                    @PathVariable("encodedData") String encodedString){
        try{
            HashMap<String, Object> dataMap = GeneralEntityUtils.decodeString(encodedString);
            HashMap<String, Object> valueMap = GeneralEntityUtils.decodeString(code);
            Map<String, String> map = new HashMap<>();
            String gsiId = (String) dataMap.get(AppConstant.GSI_ID);
            String txnId = (String) dataMap.get(AppConstant.TXN_ID);
            String entityId = (String) dataMap.get(AppConstant.ENTITY_ID);
            String tenantId = (String) dataMap.get(AppConstant.TENANTID);
            String attributeId = (String) dataMap.get(AppConstant.ATTRIBUTE_ID);
            if (dataMap.containsKey(AppConstant.BOOK_ID)){
                map.put(AppConstant.BOOK_ID ,(String) dataMap.get(AppConstant.BOOK_ID));
            }
            map.put(AppConstant.GSI_ID, gsiId);
            String encoded = Base64.getEncoder().encodeToString(JacksonUtils.toJson(map).getBytes(StandardCharsets.UTF_8));
            String sessionId = generalUtils.getFromRedis((String) valueMap.get(StripeConstants.STRIPE_CODE),
                    (String) valueMap.get(StripeConstants.STRIPE_CACHE));
            String redirectionBaseurl = adaptorProperties.getAppRedirectTbuiUrl();
            if (dataMap.containsKey(AppConstant.REFERER) && dataMap.get(AppConstant.REFERER)!=null){
                String swapper = (String) dataMap.get(AppConstant.REFERER);
                String domain = swapper.split("/")[2];
                String[] mainUrl = redirectionBaseurl.split("/");
                mainUrl[2] = domain;
                redirectionBaseurl = String.join("/", mainUrl);
            }else {
                redirectionBaseurl = StringUtils.replace(redirectionBaseurl,
                        AppConstant.TENANT_ID_TEMPLATE,tenantId);
            }
            String uri = redirectionBaseurl +
                    GeneralEntityUtils.urlEncodedData(encoded) + "/" +
                    txnId + "/" +
                    entityId + "/" +
                    attributeId + "?query=" + GeneralEntityUtils.urlEncodedData(sessionId) +
                    "&mode=" + GeneralEntityUtils.urlEncodedData((String) valueMap.get(StripeConstants.STRIPE_MODE)); //NOSONAR

            URI url = new URI(uri); //NOSONAR
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.setLocation(url); //NOSONAR
            return new ResponseEntity<>(httpHeaders, HttpStatus.SEE_OTHER);
        }catch (Exception e){
            LOGGER.error("failed to redirect back",e);
            return null;
        }
    }

    @Operation(summary = "Invoke GSI", description = "This api is called to invoke GSI's using GSIInvocaionRequestDto.", tags = {""})
    @ApiResponses(value = { @ApiResponse(responseCode = RestApiConstants.OK_CODE, description = RestApiConstants.INVOKE_EVENTS_DESCRIPTION, content = {
            @Content(mediaType = "application/json", schema = @Schema(implementation = com.nsl.adapter.commons.utils.ApiResponse.class), examples = {
                    @ExampleObject(name = "invokeGsi", value = RestApiConstants.INVOKE_GSI) }) }),
            @ApiResponse(responseCode = RestApiConstants.BAD_REQUEST_CODE, description = RestApiConstants.BAD_REQUEST_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.UNAUTHORIZED_CODE, description = RestApiConstants.UNAUTHORIZED_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.FORBIDDEN_CODE, description = RestApiConstants.FORBIDDEN_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.NOT_FOUND_CODE, description = RestApiConstants.NOT_FOUND_DESCRIPTION, content = @Content),
            @ApiResponse(responseCode = RestApiConstants.INTERNAL_SERVER_ERROR_CODE, description = RestApiConstants.INTERNAL_SERVER_ERROR_DESCRIPTION, content = @Content)})
    @PostMapping(value = "/v1/gsi/execute")
    public com.nsl.adapter.commons.utils.ApiResponse invokeEvents(@RequestBody GsiInvocationDto gsiInvocationDto,
                                                                  @RequestParam(required = false, defaultValue = "true") boolean async) {
        if (gsiInvocationDto.getInformationLayer() == null && gsiInvocationDto.getPhysicalLayer()==null) {
            return new com.nsl.adapter.commons.utils.ApiResponse(HttpStatus.BAD_REQUEST, messageSource.getMessage("Paas_Adapter_19", null, Locale.ENGLISH) , null);
        }
        LOGGER.debug("Api invoked with GSI id : {}", gsiInvocationDto.getGsiId());
        try {
            GSI gsiMaster = changeUnitDao.getGsiByMasterId(gsiInvocationDto.getGsiId(), null, StatusEnum.PUBLISHED,
                    requestScopedAuthenticatedUserBean);
            LOGGER.debug("GSI with master id {} fetched successfully..", gsiMaster.getName());
            GSI gsi = changeUnitDao.getGSI(gsiMaster.getId(), requestScopedAuthenticatedUserBean);
            TriggerCU triggerCu = gsi.getSolutionLogic().get(0);
            TxnData txnData = GeneralEntityUtils.getTxnDataFromGsiInvocationDto(triggerCu, gsiInvocationDto);
            String transactionId = null;
            if (async){
                HttpHeaders headers = gsiExecutor.getHeaders(requestScopedAuthenticatedUserBean.getTenantId(),
                        requestScopedAuthenticatedUserBean.getEmailId());
                JSONObject transactionObject = gsiExecutor.getTransactionId(gsi.getId(), headers);
                JSONObject responseResult = (JSONObject) transactionObject.get("result");
                transactionId = JacksonUtils.getObjectFromJsonString(responseResult.get("transId").toString(), String.class);
                gsiExecutor.executeGsiPostTransactionId(gsi.getId(), headers, txnData, transactionObject);
            }else {
                transactionId = gsiExecutor.executeGsiAsync(gsi.getId(), requestScopedAuthenticatedUserBean.getTenantId(),
                        requestScopedAuthenticatedUserBean.getEmailId(), txnData);
            }
            return new com.nsl.adapter.commons.utils.ApiResponse(HttpStatus.OK, SUCCESS, transactionId);
        }
        catch (JsonProcessingException | NSLException e) {
            LOGGER.error("failed to invoke",e);
            return new com.nsl.adapter.commons.utils.ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,e.getMessage(),e);
        }

    }
}
