package com.nsl.adapter.service.s3.service;

import com.nsl.adapter.commons.dto.CUPropsDto;
import com.nsl.adapter.commons.service.SaveBetsService;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.commons.dto.Integrations.dto.IntegrationDtoV3;
import com.nsl.adapter.service.service.IntegrationService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CronExpressionHelper;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

import static com.nsl.adapter.service.utils.AppConstant.*;
import static com.nsl.adapter.service.v2.utills.EntityConstants.*;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class S3IntegrationService implements IntegrationService {

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Autowired
    SaveBetsService saveBetsService;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    MessageSource messageSource;

    @Override
    public CUPropsDto getSaveProperties(IntegrationDtoV3 integrationDto) throws NSLException {

        if (validate(integrationDto.getPropertiesMap(),integrationDto.getOperation()))
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,messageSource.getMessage("Paas_Adapter_195", null, Locale.ENGLISH), ExceptionSeverity.MAJOR);

        CUPropsDto cuPropsDto;
        HashMap<String, String> cuSystemProps = new HashMap<>(integrationDto.getPropertiesMap());

        if (AppConstant.S3_PUT.equalsIgnoreCase(integrationDto.getOperation()))
            cuPropsDto = newEntitiesForPUTMethod(integrationDto);
        else {
            cuPropsDto = newEntitiesForGETMethod(integrationDto);
            String metaInfoEntityId = metaInfoEntityUtils.createMetaInfoEntity(integrationDto.getIntegrationName(), authBean);
            cuSystemProps.put(METAINFO_ENTITY_KEY, metaInfoEntityId);
            cuSystemProps.put(CRON_EXPRESSION,
                    CronExpressionHelper.generateCronExpression(integrationDto.getScheduleReq()));
            if (integrationDto.getScheduleReq() != null)
               cuSystemProps.put(JOB_DELETE_TIME, integrationDto.getScheduleReq().getEndDate());
        }

        cuPropsDto.setCuSystemProps(cuSystemProps);
        cuPropsDto.setIsMachineCU(Boolean.FALSE);
        return cuPropsDto;
    }

    @Override
    public void getIntegration(IntegrationDtoV3 integrationDto,CUPropsDto cuPropsDto) {

        if (AppConstant.S3_PUT.equalsIgnoreCase(integrationDto.getOperation()))
            integrationDto.setInputEntityDsdId(getParticipatingItems(cuPropsDto.getPhysicalLayerItems()).get(0).getDsdId());
        else
            integrationDto.setOutputEntityDsdId(getParticipatingItems(cuPropsDto.getTriggerCESLayerItems()).get(0).getDsdId());
    }

    @Override
    public CUPropsDto getUpdateProperties(CUPropsDto cuPropsDto, IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto newCUPropsDto;
        if (AppConstant.S3_PUT.equalsIgnoreCase(integrationDto.getOperation()))
            newCUPropsDto = newEntitiesForPUTMethod(integrationDto);
        else
            newCUPropsDto = newEntitiesForGETMethod(integrationDto);

        Map<String, String> cuSystemProps = cuPropsDto.getCuSystemProps();
        cuSystemProps.putAll(integrationDto.getPropertiesMap());
        newCUPropsDto.setCuSystemProps(cuSystemProps);
        return newCUPropsDto;
    }

    private static boolean validate(Map<String, String> propetiesMap, String operation) {

        List<String> propertyList;
        if (operation.equals(S3_GET))
            propertyList = Arrays.asList(BUCKETNAME, FOLDER, FILENAME, FILETYPE, ARCHIVE_FILE, DELETE_FILE, ARCHIVE_FOLDER);
        else if (operation.equals(S3_PUT))
            propertyList = Arrays.asList(BUCKETNAME, FOLDER, FILENAME, FILETYPE);
        else
            return true;

        for (Object property : propertyList) {
            if (!propetiesMap.containsKey(property))
                return true;
        }
        return false;
    }

    private CUPropsDto newEntitiesForPUTMethod(IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto cuPropsDto = new CUPropsDto();
        String fileType = integrationDto.getPropertiesMap().get(AppConstant.FILETYPE);

        TenantCUEntityInput phyEntity1;
        if (AppConstant.NATIVE.equalsIgnoreCase(fileType))
            phyEntity1 = saveBetsService.getEntityByName(NSL_Adapter_Native_File);
        else
            phyEntity1 = saveBetsService.findEntityById(integrationDto.getInputEntityDsdId());

        TenantCUEntityInput phyEntity2 = saveBetsService.getEntityByName(S3_ADAPTER_PUT_REQ);

        TenantCUEntityInput triggerCESEntity1 = saveBetsService.getEntityByName(NATIVE_GET_RES);

        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Arrays.asList(phyEntity1,phyEntity2)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(triggerCESEntity1)));

        return cuPropsDto;
    }

    private CUPropsDto newEntitiesForGETMethod(IntegrationDtoV3 integrationDto) throws NSLException {

        CUPropsDto cuPropsDto = new CUPropsDto();
        String fileType = integrationDto.getPropertiesMap().get(AppConstant.FILETYPE);

        TenantCUEntityInput entity;
        if (AppConstant.NATIVE.equalsIgnoreCase(fileType))
            entity = saveBetsService.getEntityByName(NSL_Adapter_Native_File);
        else
            entity = saveBetsService.findEntityById(integrationDto.getOutputEntityDsdId());

        cuPropsDto.setPhysicalLayerItems(buildSlotItems(Collections.singletonList(entity)));
        cuPropsDto.setTriggerCESLayerItems(buildSlotItems(Collections.singletonList(entity)));

        return cuPropsDto;
    }

}
