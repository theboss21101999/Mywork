package com.nsl.adapter.service.kafka.enums;

public enum ConnectionType {
    SSL,
    SASL_PLAINTEXT,
    SASL_PLAIN,
    PLAINTEXT;

}
