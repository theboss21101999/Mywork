package com.nsl.adapter.service.service;

import com.nsl.adapter.commons.dto.ExecuteAdaptorRequestDto;
import com.nsl.adapter.commons.enums.AdapterType;
import com.nsl.adapter.service.db.service.DBReservedCUService;
import com.nsl.adapter.service.kafka.service.KafkaReservedCUService;
import com.nsl.adapter.service.mapper.service.MapperReservedCUService;
import com.nsl.adapter.service.mqtt.service.MqttReservedCUService;
import com.nsl.adapter.service.onedrive.service.OnedriveReservedCUService;
import com.nsl.adapter.service.smtp.service.SmtpReservedCUService;
import com.nsl.adapter.service.stage.service.StageReservedCUService;
import com.nsl.adapter.service.stripe.service.StripeReservedCuService;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetails;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import java.util.Locale;
import java.util.Map;

import static com.nsl.adapter.service.utils.AppConstant.ADAPTER;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;
import static com.nsl.logical.std.logs.ErrorType.EXEC_RESERVED_CU_ERROR;

@Service
//@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ExternalApiReservedCUService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExternalApiReservedCUService.class);

    @Autowired
    RestReservedCuService restReservedCuService;

    @Autowired
    KafkaReservedCUService kafkaReservedCUService;

    @Autowired
    StripeReservedCuService stripeReservedCuService;

    @Autowired
    SmtpReservedCUService smtpReservedCUService;

    @Autowired
    DBReservedCUService dbReservedCUService;

    @Autowired
    StageReservedCUService stageReservedCUService;


    @Autowired
    OnedriveReservedCUService onedriveReservedCUService;

    @Autowired
    CHRestReservedCUService chRestReservedCUService;
    @Autowired
    MqttReservedCUService mqttReservedCUService;
    @Autowired
    MapperReservedCUService mapperReservedCUService;

    @Autowired
    private MessageSource messageSource;

    public TxnData execute(ExecuteAdaptorRequestDto executeExtSolsRequestDto, AuthenticatedUserDetails authenticatedUserDetails) throws NSLException {

        LOGGER.info("||||||||||||||||||||||| execute method in externalapireservedcuservice |||||||||||||||||||||||");
        TriggerCU triggerCu = null;
        TxnData transData = null;

        try {
            triggerCu = JacksonUtils.readTypeWrappedTCuJsonString(executeExtSolsRequestDto.getTriggerCU());
            transData = JacksonUtils.getObjectFromJsonString(executeExtSolsRequestDto.getTransData(), TxnData.class);

            if (triggerCu == null || transData == null)
                throw new RuntimeException();
        } catch (Exception e) {
            LOGGER.error("Exception while getting TriggerCU and TXNData from request", e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,
                    EXEC_RESERVED_CU_ERROR, ExceptionSeverity.BLOCKER);
        }
        Map<String, String> cuSystemProps = triggerCu.getCuSystemProperties();
        String adapterType = cuSystemProps.get(ADAPTER);
        try {
            if ("CHAssociateSearch".equalsIgnoreCase(cuSystemProps.get("AdapterReservedCuType"))){
                return chRestReservedCUService.reservedCUService(triggerCu, transData);
            }
        }catch (NSLException e) {
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception while executing extsolns reserved cu", e);
        }
        try {
            AdapterType adapter = AdapterType.valueOf(adapterType);
            switch (adapter) {

                case KAFKA:
                    return kafkaReservedCUService.reservedCUService(triggerCu, transData);
                case REST:
                    return restReservedCuService.reservedCUService(triggerCu, transData, authenticatedUserDetails);
                case STRIPE:
                    return stripeReservedCuService.reservedCUService(triggerCu, transData);
                case SMTP:
                    return smtpReservedCUService.reservedCUService(triggerCu, transData);
                case DB:
                    return dbReservedCUService.reservedCUService(triggerCu, transData);
                case STAGE:
                    return stageReservedCUService.reservedCUService(triggerCu, transData);
                case ONEDRIVE:
                    return onedriveReservedCUService.reservedCUService(triggerCu, transData);
                case MQTT:
                    return mqttReservedCUService.reservedCUService(triggerCu,transData);
                case MAPPER:
                    return mapperReservedCUService.reservedCUService(triggerCu, transData);
                case RESTINBOUND:
                case RESTOUTPUT:
                case WEBHOOK:
                    return transData;

                default:
                    throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_147", null, Locale.ENGLISH),
                            ExceptionSeverity.MINOR);
            }
        } catch (NSLException e) {
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception while executing extsolns reserved cu", e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, e.getMessage(),
                    ExceptionSeverity.MINOR, e);
        }
    }
}