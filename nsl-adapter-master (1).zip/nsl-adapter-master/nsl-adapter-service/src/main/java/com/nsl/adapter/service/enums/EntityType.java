package com.nsl.adapter.service.enums;

public enum EntityType{
    TARGET,
    SOURCE
}
