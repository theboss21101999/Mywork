package com.nsl.adapter.service.serviceImpl;

import com.amazonaws.util.StringUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.nsl.adapter.service.dto.VideoConferenceValidateDto;
import com.nsl.adapter.service.service.VideoConferencingService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.common.config.ApiResponse;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dto.search.OperationType;
import com.nsl.logical.dto.search.SearchOperatorType;
import com.nsl.logical.dto.search.SearchQuery;
import com.nsl.logical.dto.search.TxnEntitySearchRequest;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnNslAttribute;
import org.apache.commons.codec.binary.Hex;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import javax.annotation.Resource;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
public class VideoConferencingServiceImpl implements VideoConferencingService {

    @Value("${video.conferencing.host.url}")
    private String videoConferencingHostUrl;
    @Value("${video.conferencing.scheduled.meeting.id.prefix}")
    private String meetingIdPrefix;

    @Value("${entity.search.api.url}")
    private String entitySearchAPIUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    CdmUtils cdmUtility;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authenticatedUserDetails;

    @Override
    public String getMeetingUrl() {
        SecureRandom secRandom = new SecureRandom();

        byte[] result = new byte[16];
        secRandom.nextBytes(result);
        String randomString =  Hex.encodeHexString(result);
        String meetingId = meetingIdPrefix + System.currentTimeMillis() + "" + randomString;
        String tenantId = cdmUtility.getEnvironmentNameByTenantId(authenticatedUserDetails.getTenantId());
        String redirectionUrl= StringUtils.replace(videoConferencingHostUrl, AppConstant.TENANT_ID_TEMPLATE,tenantId);
        return redirectionUrl+ "/"+ meetingId;
    }

    @Override
    public VideoConferenceValidateDto validateMeetingId(String meetingId) throws JsonProcessingException, ClassNotFoundException {
        String email = authenticatedUserDetails.getEmailId();
        if(meetingId.startsWith(meetingIdPrefix)){
            // Fetch the NSL_CalendarEvent entity for the given meeting id
            TxnEntitySearchRequest txnEntitySearchRequest = new TxnEntitySearchRequest();
            txnEntitySearchRequest.setOutputEntityName("NSL_CalendarEvent");
            txnEntitySearchRequest.setOffset(0);
            txnEntitySearchRequest.setLimit(300);
            SearchQuery searchQuery = new SearchQuery();
            searchQuery.setSearchQueryDepth(0);
            searchQuery.setOperationType(OperationType.AND);

            String meetingUrl = videoConferencingHostUrl + "/" + meetingId;
            SearchQuery searchQuery4 = new SearchQuery();
            searchQuery4.setFieldName("NSL_CalendarEvent.meetingUrl");
            searchQuery4.setSearchQueryDepth(0);
            searchQuery4.setSearchOperatorType(SearchOperatorType.EQUALS);
            searchQuery4.setValues(Collections.singletonList(meetingUrl));

            List<SearchQuery> list = new ArrayList<>();
            list.add(searchQuery4);
            searchQuery.setQueries(list);
            txnEntitySearchRequest.setSearchQuery(searchQuery);

            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.set("Accept-Language","en");
            httpHeaders.set("Authorization","Bearer "+authenticatedUserDetails.getAuthToken());

            HttpEntity<TxnEntitySearchRequest> request =
                    new HttpEntity<TxnEntitySearchRequest>(txnEntitySearchRequest, httpHeaders);

            ResponseEntity<ApiResponse> responseEntityStr = restTemplate.
                    postForEntity(entitySearchAPIUrl+"?configEntityName=NSL_CalendarEvent_Configuration&entityNameMapping=NSL_CalendarEvent", request, ApiResponse.class);
            VideoConferenceValidateDto videoConferenceValidateDto = new VideoConferenceValidateDto();

            String jsonInString = JacksonUtils.toJson(Objects.requireNonNull(responseEntityStr.getBody()).getResult());     //NOSONAR
            TxnGeneralEntity txnGeneralEntity = JacksonUtils.fromJson(jsonInString,TxnGeneralEntity.class);

            if(txnGeneralEntity.getTransEntityRecords() != null && !txnGeneralEntity.getTransEntityRecords().isEmpty()){
                // Check for user based on email
                for(TxnNslAttribute txnNslAttribute:txnGeneralEntity.getTransEntityRecords().get(0).getTxnNslAttribute()){
                    if(txnNslAttribute.getName().equals("participantList")){
                        List<String> values = txnNslAttribute.getValues();
                        for(String value:values){
                            if(value.equals(email)){
                                videoConferenceValidateDto.setStatus(1);
                                videoConferenceValidateDto.setMessage("Success");
                                return videoConferenceValidateDto;
                            }
                        }
                    }

                    else if (txnNslAttribute.getName().equals("Organizer")){
                        List<String> values = txnNslAttribute.getValues();
                        for(String value:values){
                            if(value.equals(email)){
                                videoConferenceValidateDto.setStatus(1);
                                videoConferenceValidateDto.setMessage("Success");
                                return videoConferenceValidateDto;
                            }
                        }
                    }
                }
                videoConferenceValidateDto.setMessage("Not invited!!!");
                videoConferenceValidateDto.setStatus(0);
            }else{
                // If entity records not found, status = 0
                videoConferenceValidateDto.setStatus(0);
                videoConferenceValidateDto.setMessage("Invalid meeting link");
            }
            return videoConferenceValidateDto;
        }else{
            // instant meetings
            VideoConferenceValidateDto videoConferenceValidateDto = new VideoConferenceValidateDto();
            videoConferenceValidateDto.setStatus(1);
            videoConferenceValidateDto.setMessage("Instant meeting id");
            return videoConferenceValidateDto;
        }
    }
}
