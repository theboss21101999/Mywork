package com.nsl.adapter.service.kafka.service;

import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnData;

public interface KafkaReservedCUService {

    TxnData reservedCUService(TriggerCU triggerCu,TxnData transData);
    
}

/*
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.service.kafka.dto.ExtKafkaParamsOutDto;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.commons.utils.entity.EntityToJSONUtil;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.service.utils.JSONToEntityUtil;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.GeneralEntityDao;
import com.nsl.logical.dao.SearchCUDAO;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.model.ChangeDriverData;
import com.nsl.logical.model.GeneralEntity;
import com.nsl.logical.model.NslAttribute;
import com.nsl.logical.model.TriggerCU;
import com.nsl.logical.model.TxnCULayer;
import com.nsl.logical.model.TxnData;
import com.nsl.logical.model.TxnGeneralEntity;
import com.nsl.logical.model.TxnGeneralEntityRecord;
import com.nsl.logical.model.TxnSlotItem;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;


@Service
public class KafkaReservedCUService {
    private static final Logger logger = LoggerFactory.getLogger(KafkaReservedCUService.class);

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl requestScopedAuthenticatedUserBean;

    @Autowired
    EntityToJSONUtil entityToJSONUtil;
    
    @Autowired
    GeneralEntityDao generalEntityDao;
  
    @Autowired
    @Qualifier("generalEntityDataRdfDao")
    private SearchCUDAO searchCUDAO;

    
    public TxnData reservedCUService(TriggerCU triggerCu,TxnData transData){
      String kafkaType=triggerCu.getCuSystemProperties().get(AppConstant.METHODTYPE);
      ExtKafkaParamsOutDto extKafkaParamsOutDto = new ExtKafkaParamsOutDto();
      try{
        if(kafkaType.equalsIgnoreCase("OUTBOUND")){  
            List<TxnCULayer> txnCuLayers = transData.getTxnCULayer();
            List<TxnSlotItem> transEntityDetails = null;
            transEntityDetails = GeneralEntityUtils.getTransEntityDetails(txnCuLayers, AppConstant.PHYSICAL_LAYER);
 
            TxnGeneralEntity txnGeneralEntity = GeneralEntityUtils.getExpectedTxnGeneralEntity(transEntityDetails);
            GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, AppConstant.TRIGGER_CES_LAYER);
            GeneralEntity inputGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, AppConstant.PHYSICAL_LAYER);
         
            TxnGeneralEntityRecord configEntityRecord = getConfigEntity(triggerCu);
            // need to setup confgiguration form configEntityRecord
            String connectionType=triggerCu.getCuSystemProperties().get("ConnectionType");
            String topic=triggerCu.getCuSystemProperties().get("Topic");
            extKafkaParamsOutDto.setConnectionType(connectionType);
            extKafkaParamsOutDto.setTopic(topic);
            JsonNode result=callOutBoundKafka(txnGeneralEntity,inputGeneralEntity,extKafkaParamsOutDto);
            txnGeneralEntity = JSONToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, result);
            transData = setChangeDriverInTxnData(txnGeneralEntity);
        }else if(kafkaType.equalsIgnoreCase("INBOUND")){  
            GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, AppConstant.TRIGGER_CES_LAYER);
                
            TxnGeneralEntityRecord configEntityRecord = getConfigEntity(triggerCu);
            // need to setup confgiguration form configEntityRecord
            String connectionType=triggerCu.getCuSystemProperties().get("ConnectionType");
            String topic=triggerCu.getCuSystemProperties().get("Topic");
            extKafkaParamsOutDto.setConnectionType(connectionType);
            extKafkaParamsOutDto.setTopic(topic);
            String kafkaMessage=callInBoundKafka(tcesGeneralEntity,extKafkaParamsOutDto);
            ObjectMapper mapper = new ObjectMapper();
            JsonNode request = mapper.readTree(kafkaMessage);
            TxnGeneralEntity txnGeneralEntity = JSONToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, request);
            transData = setChangeDriverInTxnData(txnGeneralEntity);
        }
        return transData;
      }catch(Exception e){
          logger.info("error - {}",e);
          return null;
      }
    }

    public JsonNode callOutBoundKafka(TxnGeneralEntity txnGeneralEntity,GeneralEntity inputGeneralEntity,ExtKafkaParamsOutDto extKafkaParamsOutDto ){

        String messageType="json";
        try{
            if(messageType.equalsIgnoreCase("json")){
                JSONObject transObject;
                Map<String, NslAttribute> dataTypeMap = new HashMap<>();
                entityToJSONUtil.getDataTypeMap(dataTypeMap, inputGeneralEntity,"");
                transObject = entityToJSONUtil.createRequestForRestAdapter(dataTypeMap,txnGeneralEntity,inputGeneralEntity,"");
                String kafkaMessage=transObject.toString();
                KafkaProducerConnectionService kafkaProducerConnectionService = new KafkaProducerConnectionService(extKafkaParamsOutDto);
                kafkaProducerConnectionService.sendMessageTokafka(kafkaMessage,extKafkaParamsOutDto.getTopic());
                String responseJson = "{ \"message\" : \"Sent Data Successfully\" } ";
                ObjectMapper objectMapper = new ObjectMapper();
                JsonNode jsonNode = objectMapper.readTree(responseJson);
                return jsonNode;
            }
        }catch(Exception e){
                logger.info("error - {}",e);
                return null;
        }
            return null;
    }
        
    public String callInBoundKafka(GeneralEntity tcesGeneralEntity,ExtKafkaParamsOutDto extKafkaParamsOutDto) {
        String messageType="json";
        String kafkaMessage=null;
        try{
            if(messageType.equalsIgnoreCase("json")){
                KafkaConsumerConnectionService kafkaConsumerConnectionService = new KafkaConsumerConnectionService();
                //reading only one record as of now
                kafkaMessage=kafkaConsumerConnectionService.createandrunConsumer(extKafkaParamsOutDto).get(0);      
            }
        }catch(Exception e){
            logger.info("exception -{}",e);
        }
        return kafkaMessage;
    }

}
*/
