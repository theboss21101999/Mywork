package com.nsl.adapter.service.exception;

public class ExtAPINotFoundException extends RuntimeException {

    /**
     * Exception class for ExtAPI
     */
    private static final long serialVersionUID = 1L;

    public ExtAPINotFoundException(String message) {
        super("ExtAPI: " + message);
    }

    public ExtAPINotFoundException(String message, Throwable t) {
        super("ExtAPI: " + message, t);
    }
}

