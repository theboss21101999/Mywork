package com.nsl.adapter.service.controller;

import com.nsl.adapter.commons.serviceImpl.CreateEntityServiceImpl;
import com.nsl.adapter.commons.utils.ApiResponse;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.dsd.store.models.tenant.io.TenantCUEntityInput;
import com.nsl.logical.exception.NSLException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.validation.Valid;

import java.util.Map;

import static com.nsl.adapter.service.keymanager.enums.KmsSearchType.name;

/**
 * This class is for : .
 */
@RestController
@RequestMapping("/api/v1/converters")
public class SaveEntityController {

    private static final Logger logger = LoggerFactory.getLogger(SaveEntityController.class);
    /**
     * This Object is : .
     */
    @Autowired
    private CreateEntityServiceImpl createEntity;

    @PostMapping("/File")
    public ApiResponse saveEntity(@Valid @RequestParam("FileType") String fileType,
                                  @Valid @RequestParam("entityName") String entityName,
                                  @Valid @RequestParam("File")  MultipartFile file,@RequestPart(name = "Properties",required = false) Map<String,Object> Properties) throws NSLException {
        logger.info("creating entity");
        TenantCUEntityInput createdEnity = createEntity.convertIntoEntity(fileType,file,entityName,Properties);

        if(createdEnity!=null)
            return new ApiResponse(HttpStatus.OK,AppConstant.SUCCESS,createdEnity);
        else
            return new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR,AppConstant.FAILURE,createdEnity);
    }

}

