package com.nsl.adapter.service.retry;

import org.apache.http.NoHttpResponseException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class RetryConfig {

    @Bean
    public RetryTemplate retryTemplate(){
        RetryTemplate retryTemplate = new RetryTemplate();

        ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
        backOffPolicy.setMultiplier(2);
        backOffPolicy.setInitialInterval(1000);
        backOffPolicy.setMaxInterval(3000);
        retryTemplate.setBackOffPolicy(backOffPolicy);

        Map<Class<? extends Throwable>, Boolean> map= new HashMap<>();
        map.put(IOException.class,Boolean.TRUE);
        map.put(HttpClientErrorException.TooManyRequests.class,Boolean.TRUE);
        map.put(HttpServerErrorException.InternalServerError.class,Boolean.FALSE);
        map.put(HttpServerErrorException.ServiceUnavailable.class,Boolean.TRUE);
        map.put(HttpServerErrorException.GatewayTimeout.class,Boolean.TRUE);
        map.put(ResourceAccessException.class,Boolean.TRUE);

        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy(3, map);
        retryTemplate.setRetryPolicy(retryPolicy);

        return retryTemplate;
    }
}
