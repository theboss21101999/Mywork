package com.nsl.adapter.service.rest.utils;


public class ConnectionConstants {
    public static final String REST_CONNECTION ="NSL_Rest_Connection";
    public static final String SFTP_CONNECTION = "NSL_SFTP_Connection";
    public static final String SMTP_CONNECTION = "NSL_SMTP_Connection";
    public static final String DB_CONNECTION="NSL_DB_Connection";
    public static final String WEBEX_CONNECTION="NSL_Webex_Connection";
    public static final String FACEBOOK_CONNECTION = "NSL_Facebook_Connection";
    public static final String GRAPH_CONNECTION = "NSL_Graph_Connection";
    public static final String MQTT_CONNECTION="NSL_Mqtt_Connection";
}
