package com.nsl.adapter.service.calendar.dto;


import java.util.List;


public class SchedulerSlotDto {
    private List<String> participantList;
    private List<String> eventIds;

    public List<String> getParticipantList() {
        return participantList;
    }

    public void setParticipantList(List<String> participantList) {
        this.participantList = participantList;
    }

    public List<String> getEventIds() {
        return eventIds;
    }

    public void setEventIds(List<String> eventIds) {
        this.eventIds = eventIds;
    }
}
