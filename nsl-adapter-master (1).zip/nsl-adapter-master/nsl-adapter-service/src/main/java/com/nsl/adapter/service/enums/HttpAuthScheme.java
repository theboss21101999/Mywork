package com.nsl.adapter.service.enums;

public enum HttpAuthScheme {
    BASIC("Basic"),
    BEARER("Bearer");

    private String scheme;

    HttpAuthScheme(String scheme) {
        this.scheme = scheme;
    }

    public String getScheme() {
        return this.scheme;
    }

    public static HttpAuthScheme fromValue(String val) {
        for (HttpAuthScheme at : HttpAuthScheme.values()) {
            if (at.getScheme().equalsIgnoreCase(val)) {
                return at;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return this.getScheme();
    }
}
