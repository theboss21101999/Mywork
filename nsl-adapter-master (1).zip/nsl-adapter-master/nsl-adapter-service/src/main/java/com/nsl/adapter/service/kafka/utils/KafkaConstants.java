package com.nsl.adapter.service.kafka.utils;

public class KafkaConstants {

    public KafkaConstants() {}

    public static final String KAFKA_CONNECTION = "NSL_Kafka_Connection";
    public static final String AUTHENTICATION = "authentication";
    public static final String ADVANCED_CONFIG = "advancedConfig";

    public static final String KAFKA_OUTBOUND = "outbound";
    public static final String KAFKA_INBOUND = "inbound";

    public static final String METHOD_TYPE = "methodType";
    public static final String JSON = "json";
    public static final String SASL_SSL = "SASL_SSL";

    public static final String BOOTSTRAP_SERVER = "bootstrapServer";
    public static final String PARTITION = "partition";
    public static final String CONNECTION_NAME = "connectionName";

    public static final String AUTH_TYPE = "authType";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";

    public static final String CONNECTION_TYPE = "connectionType";
    public static final String TOPIC = "topic";
    public static final String SERIALIZER = "serializer";
    public static final String SASL_JAAS_CONFIG = "saslJaasConfig";
    public static final String TRUSTSTORE_PATH = "truststorePath";
    public static final String TRUSTSTORE_PASSWORD = "truststorePassword";
    public static final String KEY_PASSWORD = "keyPassword";

    public static final String SECURITY_PROTOCOL = "security.protocol";
    public static final String SSL_TRUSTSTORE_LOCATION = "ssl.truststore.location";
    public static final String SSL_TRUSTSTORE_PASSWORD = "ssl.truststore.password";
    public static final String SSL_KEY_PASSWORD = "ssl.key.password";
    public static final String SASL_JAAS_CONFIGS = "sasl.jaas.config";
    public static final String SECURITY_MECHANISM = "security.mechanism";
    public static final String SECURITY_MECHANISM_SASL_PT = "SCRAM-SHA-512";

    public static final String RESPONSE_JSON = "{ \"response\" : \"Sent Data Successfully\" } ";

    public static final String USER_CONTEXT_KEY = "userContext";
    public static final String TENANT_ID_KEY = "tenantId";
    public static final String USER_ID_KEY = "userId";
    public static final String USER_EMAIL_KEY = "emailId";
    public static final String DATA_KEY = "data";

}
