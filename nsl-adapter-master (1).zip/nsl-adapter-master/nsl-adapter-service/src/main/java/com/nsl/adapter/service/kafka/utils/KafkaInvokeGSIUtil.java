package com.nsl.adapter.service.kafka.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.adapter.commons.service.GsiExecutor;
import com.nsl.adapter.service.kafka.dto.InboundMsgReqDto;
import com.nsl.adapter.service.sftp.connection.AuthenticateUser;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.ExtSolutionUtil;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.commons.utils.entity.JsonToEntityUtil;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.LayerType;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;

@Service
public class KafkaInvokeGSIUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(KafkaInvokeGSIUtil.class);

    @Autowired
    AuthenticateUser authenticateUser;

    @Autowired
    ExtSolutionUtil extSolutionUtil;

    @Autowired
    GsiExecutor gsiExecutor;

    @Autowired
    ChangeUnitDao changeUnitDao;

    public void invokeGSI(Map<String, String> kafkaMsg, InboundMsgReqDto inboundMsgReqDto) throws JsonProcessingException {

        AuthenticatedUserDetailsImpl authenticatedUser = authenticateUser.getAuthenticatedUser(inboundMsgReqDto.getUserId(), inboundMsgReqDto.getTenantId());
        LOGGER.info("Fetching GSI..");
        GSI gsiMaster = changeUnitDao.getGsiByMasterId(inboundMsgReqDto.getGsiMasterId(), null,
                StatusEnum.PUBLISHED, authenticatedUser);
        Long gsiId = gsiMaster.getId();
        LOGGER.info("GSI with master id {} fetched successfully..", gsiMaster.getName());
        GSI  gsi = changeUnitDao.getGSI(gsiId, authenticatedUser);
        TriggerCU triggerCu = getKafkaCU(gsi, inboundMsgReqDto.getCuName());
        GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu, AppConstant.PHYSICAL_LAYER);
        JsonNode kafkaJson = new ObjectMapper().readTree(kafkaMsg.get("msg"));
        TxnGeneralEntity txnGeneralEntity = JsonToEntityUtil.getTriggerTxnGeneralEntityWithData(tcesGeneralEntity, kafkaJson);
        TxnData txnData = extSolutionUtil.setChangeDriverInTxnData(txnGeneralEntity, LayerType.PHYSICAL);
        gsiExecutor.executeGsi(gsiId, inboundMsgReqDto.getTenantId(), inboundMsgReqDto.getUserEmail(), txnData);

    }

    private TriggerCU getKafkaCU(GSI gsi, String cuName) {
        for(TriggerCU triggerCU : gsi.getSolutionLogic()) {
            if(triggerCU.getName().equalsIgnoreCase(cuName))
                return triggerCU;
        }
        return null;
    }

}
