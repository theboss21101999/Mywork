package com.nsl.adapter.service.onedrive.serviceimpl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.nsl.adapter.commons.dto.connections.MetaInfoEntityDto;
import com.nsl.adapter.commons.utils.MetaInfoEntityUtils;
import com.nsl.adapter.commons.utils.entity.GeneralEntityUtils;
import com.nsl.adapter.service.exception.AdapterException;
import com.nsl.adapter.commons.service.GsiExecutor;
import com.nsl.adapter.service.onedrive.service.OnedriveGenericParser;
import com.nsl.adapter.service.sftp.connection.AuthenticateUser;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.dao.ChangeUnitDao;
import com.nsl.logical.enums.StatusEnum;
import com.nsl.logical.exception.NSLException;
import com.nsl.logical.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.context.MessageSource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;

import static com.nsl.adapter.service.onedrive.utils.OnedriveConstants.ONEDRIVE_URL;


@Service
public class OneDriveGsiInvokerUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(OneDriveGsiInvokerUtil.class);

    @Autowired
    ChangeUnitDao changeUnitDao;


    @Autowired
    AuthenticateUser authenticateUser;

    @Autowired
    MetaInfoEntityUtils metaInfoEntityUtils;

    @Autowired
    OnedriveService onedriveService;

    @Autowired
    OnedriveGenericParser onedriveGenericParser;

    @Autowired
    GsiExecutor gsiExecutor;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    private MessageSource messageSource;




    public void invokeGsi(Long gsiMasterId, Map<String, String> msg, ChangeUnit cu, AuthenticatedUserDetailsImpl authBean) throws JSONException, AdapterException, NSLException {
        try {
            String tenantId = msg.get(AppConstant.TENANTID);
            String userEmail = msg.get(AppConstant.USEREMAIL);
            String fileName = msg.get(AppConstant.FILENAME);

            LOGGER.info("Fetching GSI..");
            GSI gsiMaster = changeUnitDao.getGsiByMasterId(gsiMasterId, null,
                    StatusEnum.PUBLISHED, authenticateUser.getAuthenticatedUser(msg));
            Long gsiId = gsiMaster.getId();
            LOGGER.info("GSI with master id {} fetched successfully..", gsiMaster.getName());
            GSI gsi = changeUnitDao.getGSI(gsiId, authenticateUser.getAuthenticatedUser(msg));
            TriggerCU triggerCu = gsi.getSolutionLogic().get(0);
            GeneralEntity tcesGeneralEntity = GeneralEntityUtils.getTriggerCUGeneralEntity(triggerCu,
                    AppConstant.PHYSICAL_LAYER);
            Map<String, String> cuSystemProps = getModifiedCuSystemProp(cu.getCuSystemProperties(),
                    msg.get(AppConstant.CUNAME), fileName);
            boolean isMultivalued = triggerCu.getLayers().get(0).getParticipatingItems().get(0).getIsMultiValue();
            List<TxnData> txnDatas = onedriveGenericParser.onedriveinbound(tcesGeneralEntity, cuSystemProps,
                    isMultivalued, cuSystemProps, authBean);

            for (TxnData txnData : txnDatas) {
                gsiExecutor.executeGsi(gsiId, tenantId, userEmail, txnData);
            }

        } catch (NSLException e) {
            LOGGER.error("Exception occurred while invoking GSI in thread {} : {}",
                    Thread.currentThread().getName(), e.getMessage());
        }
    }


    private static Map<String, String> getModifiedCuSystemProp(Map<String, String> cuSystemProp,
                                                               String cuName, String fileName) {
        cuSystemProp.put(AppConstant.FILENAME, fileName);
        cuSystemProp.put(AppConstant.DSD_LOCATION, getDSDLocation(cuName));
        return cuSystemProp;
    }

    private static String getDSDLocation(String cuName) {
        String date = LocalDate.now().toString();
        return cuName + "," + date;
    }

    public List<String> listFiles(Long connectionId, String folderName, MetaInfoEntityDto metaInfoEntity, Map<String,String> cuSystemProp, AuthenticatedUserDetailsImpl bean) throws NSLException {

        LOGGER.info("initializing list files method ");
        String uri = ONEDRIVE_URL + folderName + ":/children";
        String accessToken = onedriveService.createObject(connectionId);
        String token = "Bearer " + accessToken;
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, token);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        ResponseEntity<JsonNode> response = restTemplate.exchange(uri, HttpMethod.GET,
                new HttpEntity<>(headers), JsonNode.class);
        ArrayNode nodeArr = null;
        if (response.getBody() != null) {
            nodeArr = (ArrayNode) response.getBody().get("value");     //NOSONAR
        }
        Long cutoffTimeStamp = 0L;
        long nearestTime = 0;
        Long lastRunTime = null;
        if (!Boolean.parseBoolean(cuSystemProp.get(AppConstant.DELETE_FILE)))
            lastRunTime = metaInfoEntity.getLastRunStartTime();
        if (lastRunTime != null )
            cutoffTimeStamp = lastRunTime;

        List<String> transactionFileNames = new ArrayList<>();

        if (nodeArr != null) {
            for (JsonNode node : nodeArr) {

                String lastModifiedDateTime = node.get("lastModifiedDateTime").asText();
                lastModifiedDateTime = lastModifiedDateTime.substring(0, lastModifiedDateTime.length() - 1);
                String fileName = node.get("name").asText();
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
                Date date = null;
                long lastModifiedDateTimeInEpoch = 0;
                try {
                    date = df.parse(lastModifiedDateTime);
                    lastModifiedDateTimeInEpoch = date.getTime();
                } catch (ParseException e) {
                    LOGGER.error("ParseException caught!");
                }

                LOGGER.info("lastModifiedDateTimeInEpoch : " + lastModifiedDateTimeInEpoch);

                if (fileName.endsWith(cuSystemProp.get(AppConstant.FILETYPE))) {


                    if (lastModifiedDateTimeInEpoch > cutoffTimeStamp)
                        transactionFileNames.add(folderName + "/" + fileName);

                    if (nearestTime < lastModifiedDateTimeInEpoch)
                        nearestTime = lastModifiedDateTimeInEpoch;
                }
            }

            cutoffTimeStamp = nearestTime;
            metaInfoEntity.setLastRunStartTime(cutoffTimeStamp);
            metaInfoEntityUtils.updateMetaInfoEntity(metaInfoEntity, bean);
            return transactionFileNames;
        }
        return null;
    }

    }

