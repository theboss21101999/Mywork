package com.nsl.adapter.service.calendar.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.adapter.service.utils.CalendarEventUtils;
import com.nsl.externalreservedcus.dto.calender.event.CalendarEvent;
import com.nsl.externalreservedcus.enums.CalendarEventEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.nsl.adapter.service.calendar.utils.SlotConstants.*;


@Component
public class SlotJsonUtils {
    private final DateFormat formatter = new SimpleDateFormat(DATE_PATTERN);
    private static final Logger LOGGER = LoggerFactory.getLogger(SlotJsonUtils.class);

    public CalendarEvent convertJsonNodeToCalendarEventList(JsonNode jsonNode) throws ParseException {
        CalendarEvent calendarEvent = new CalendarEvent();
        if (jsonNode == null) {
            return calendarEvent;
        }
        for (JsonNode eventData : jsonNode) {
            if (eventData.get(PAYLOAD) == null) continue;

            JsonNode attributeList = eventData.get(PAYLOAD).get(TXN_NSL_ATTRIBUTE);
            CalendarEvent event = new CalendarEvent();

            for (JsonNode node : attributeList) {
                CalendarEventEnum attributeName = CalendarEventUtils.fromString(node.get(NAME).asText());

                if (attributeName == null) {
                    if (LOGGER.isErrorEnabled())
                        LOGGER.error("Unexpected Value: " + node.get(NAME).asText());
                    continue;
                }
                setCalendarEventValues(attributeName, node, event);
            }
            calendarEvent= event;
        }
        return calendarEvent;
    }

    private void setCalendarEventValues(CalendarEventEnum attributeName,
                                        JsonNode node,
                                        CalendarEvent event) throws ParseException {
        String value;
        List<String> values;
        switch (attributeName.getValue()) {
            case TITLE:
                event.setTitle(getValue(node));
                break;

            case START_TIME: {
                event.setStartTime((value = getValue(node)) != null
                        ? formatter.parse(value) : null);
                break;
            }
            case END_TIME: {
                event.setEndTime((value = getValue(node)) != null
                        ? formatter.parse(value) : null);
                break;
            }
            case PARTICIPANT_LIST: {
                 values = getValues(node);
                if (values != null) {
                    ArrayList<String> participantList = new ArrayList<>(values);
                    event.setParticipantList(participantList);
                } else {
                    event.setParticipantList(null);
                }
                break;
            }
            case EVENT_TYPE: {
                event.setEventType(getValue(node));
                break;
            }
            case ORGANIZER_ENUM_VALUE: {
                event.setOrganizer(getValue(node));
                break;
            }
            case CONFERENCE_TYPE: {
                event.setConferenceType(getValue(node));
                break;
            }
            case ADDITIONAL_INFO_1: {
                event.setAdditionalInfo1(getValue(node));
                break;
            }
            case ADDITIONAL_INFO_2: {
                event.setAdditionalInfo2(getValue(node));
                break;
            }
            case ADDITIONAL_INFO_3: {
                event.setAdditionalInfo3(getValue(node));
                break;
            }
            case ADDITIONAL_INFO_4: {
                event.setAdditionalInfo4(getValue(node));
                break;
            }
            case ADDITIONAL_INFO_5: {
                event.setAdditionalInfo5(getValue(node));
                break;
            }
            case METADATA: {
                event.setMetadata(getValue(node));
            }
            default:
        }
    }

    public String getValue(JsonNode node) {
        JsonNode nodeValue;
        return (nodeValue = node.get(VALUES).get(0)) != null ?
                nodeValue.asText() : null;
    }

    public List<String> getValues(JsonNode node) {
        JsonNode valuesNode = node.get(VALUES);
        if (valuesNode != null && valuesNode.isArray()) {
            List<String> valuesList = new ArrayList<>();
            for (JsonNode valueNode : valuesNode) {
                valuesList.add(valueNode.asText());
            }
            return valuesList;
        }
        return null;
    }


}
