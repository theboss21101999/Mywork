package com.nsl.adapter.service.kafka.listener;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.SeekToCurrentErrorHandler;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer2;
import java.util.HashMap;
import java.util.Map;



@EnableKafka
@Configuration
@ConditionalOnProperty(
        value="kafka.pipeline.enabled",
        havingValue = "true",
        matchIfMissing = false
)
public class SFTPKafkaConfig {

    @Autowired
    private SFTPDataConfig dataConfig;

    public ConsumerFactory consumerFactory(String groupId) {
        Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, getBootstrapConfig());
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        config.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        config.put(ErrorHandlingDeserializer2.VALUE_DESERIALIZER_CLASS, StringDeserializer.class);
        config.put(ErrorHandlingDeserializer2.KEY_DESERIALIZER_CLASS, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer2.class);
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer2.class);
        config.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, dataConfig.getMaxPollInterval());
        config.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, dataConfig.getMaxPollRecords());
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean(name ="adapterContainerFactory")
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer> adapterContainerFactory() {

        return createKafkaListenerContainerFactory(dataConfig.getSftpTopic(), dataConfig.getSftpConsumerGroupId());
    }

    @Bean(name ="adapterGsiContainerFactory")
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer> adapterGsiContainerFactory() {

        return createKafkaListenerContainerFactory(dataConfig.getGsiTopic(), dataConfig.getGsiConsumerGroupId());
    }

    private KafkaListenerContainerFactory<ConcurrentMessageListenerContainer> createKafkaListenerContainerFactory(String topicName, String groupId) {

        int partitions = kafkaTemplate().partitionsFor(topicName).size();
        ConcurrentKafkaListenerContainerFactory factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.getContainerProperties().setSyncCommits(true);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        factory.setConcurrency(partitions);
        factory.setConsumerFactory(consumerFactory(groupId));
        factory.setErrorHandler(new SeekToCurrentErrorHandler());

        return factory;
    }

    @Bean(name="kafkaTemplateSFTP")
    public KafkaTemplate kafkaTemplate() {
        return new KafkaTemplate(producerFactory());
    }

    public ProducerFactory producerFactory() {
        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, getBootstrapConfig());
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(config);
    }

    private String getBootstrapConfig() {
        return dataConfig.getBootstrapServers();
    }
}
