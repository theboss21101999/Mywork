package com.nsl.adapter.service.db.service;


import com.nsl.adapter.commons.dao.AdapterConnnectionsDao;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.enums.ConnectionDtoType;
import com.nsl.adapter.commons.service.AdapterConnectionServiceV3;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.commons.dto.connections.DBConnectionDto;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import javax.annotation.Resource;
import java.util.Locale;

@Service
public class DBConnectionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DBConnectionService.class);

    private static final ConnectionDtoType connType = ConnectionDtoType.DB;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl authBean;

    @Autowired
    AdapterConnectionServiceV3 adapterConnectionServiceV3;

    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    MessageSource messageSource;

    @Autowired
    AdapterConnnectionsDao adapterConnnectionsDao;


    public TxnAdapterConnection saveDBConnection(DBConnectionDto connectionDto) {
        connectionDataToolsV3.connectionCheck(ConnectionDtoType.DB, connectionDto.getConnectionName(), authBean);

        String password = connectionDto.getPassword();
        if(password!=null){
            connectionDto.setPassword(connectionDataToolsV3.saveSecret(connType,"password",connectionDto.getConnectionName(),authBean.getTenantId(),password));
        }
        TxnAdapterConnection result = new TxnAdapterConnection();
        result.setConnectionDtoType(connType);
        result.setConnection(connectionDto);
        LOGGER.info("saving "+connectionDto.getDb_type()+" DB connection");
        result = adapterConnnectionsDao.saveConnection(result,authBean);
        if (result == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, messageSource.getMessage("Paas_Adapter_183", null, Locale.ENGLISH), null);
        return result;
    }

    public DBConnectionDto getDBConnection(Long id, boolean hide) {

        TxnAdapterConnection txnAdapterConnection = adapterConnnectionsDao.getConnectionByRecordId(connType,id,authBean);
        return txnToDB(txnAdapterConnection, hide);
    }

    public DBConnectionDto getDBConnection(Long connId, AuthenticatedUserDetailsImpl authBean) {

        TxnAdapterConnection entityRecord = adapterConnnectionsDao.getConnectionByRecordId(connType,connId,authBean);
        return txnToDB(entityRecord , false);
    }
    public TxnAdapterConnection updateDBConnection(Long id, DBConnectionDto connectionDto) {
        TxnAdapterConnection previousconnection = adapterConnnectionsDao.getConnectionByRecordId(connType,id,authBean);
        String password = connectionDto.getPassword();
        if(password!=null){
            password = connectionDataToolsV3.updateSecret(connType,"password",connectionDto.getConnectionName(),authBean.getTenantId(),password);
        }
        connectionDto.setPassword(password);
        previousconnection.setConnection(connectionDto);
        LOGGER.info("Updating DB Connection");
        TxnAdapterConnection result = adapterConnnectionsDao.saveConnection(previousconnection,authBean);
        return result;
    }
    public DBConnectionDto txnToDB(TxnAdapterConnection record, boolean hide) {
        if (record == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR , messageSource.getMessage("Paas_Adapter_189", null, Locale.ENGLISH)  , null);
        DBConnectionDto  connectionDto =  (DBConnectionDto) record.getConnection();
        if (connectionDto == null)
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR ,  messageSource.getMessage("Paas_Adapter_83", null, Locale.ENGLISH), null);

        if(!hide){
           connectionDto.setPassword(connectionDataToolsV3.getSecret(connectionDto.getPassword()));
       }
       return connectionDto;
    }



}