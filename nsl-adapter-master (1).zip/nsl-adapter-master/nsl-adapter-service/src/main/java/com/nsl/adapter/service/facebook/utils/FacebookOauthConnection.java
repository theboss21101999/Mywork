package com.nsl.adapter.service.facebook.utils;

import com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl;
import com.google.api.client.auth.oauth2.AuthorizationCodeTokenRequest;
import com.google.api.client.auth.oauth2.TokenRequest;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.nsl.adapter.commons.dto.connections.FacebookAdapterConnectionDto;
import com.nsl.adapter.commons.dto.connections.TxnAdapterConnection;
import com.nsl.adapter.commons.utils.ConnectionDataToolsV3;
import com.nsl.adapter.service.config.AdaptorProperties;
import com.nsl.adapter.service.facebook.service.FacebookConnectionService;
import com.nsl.adapter.service.utils.AppConstant;
import com.nsl.adapter.service.utils.CdmUtils;
import com.nsl.adapter.service.v2.utills.RedisIntegration;
import com.nsl.common.utils.JacksonUtils;
import com.nsl.logical.config.AuthenticatedUserDetailsImpl;
import com.nsl.logical.enums.ExceptionCategory;
import com.nsl.logical.enums.ExceptionSeverity;
import com.nsl.logical.exception.NSLException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import static com.nsl.adapter.service.facebook.utils.FacebookConstants.ACCESS_TYPE;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.AUTHORIZATION_CODE;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.CODE;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.CONSENT;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.FACEBOOK;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.FACEBOOK_ACCESS_TOKEN;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.FACEBOOK_AUTH_TOKEN;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.OFFLINE;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.PROMPT;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.STATE;
import static com.nsl.adapter.service.facebook.utils.FacebookConstants.Url;
import static com.nsl.logical.enums.ErrorType.INTERNAL_SERVER;

@Service
public class FacebookOauthConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(FacebookOauthConnection.class);

    @Autowired
    FacebookConnectionService facebookConnectionService;
    @Autowired
    ConnectionDataToolsV3 connectionDataToolsV3;

    @Autowired
    RedisIntegration redisIntegration;

    @Resource(name = "requestScopedAuthenticatedUserBean")
    AuthenticatedUserDetailsImpl bean;

    @Autowired
    CdmUtils cdmUtils;

    @Autowired
    AdaptorProperties adaptorProperties;

    @Autowired
    private MessageSource messageSource;

    Base64.Encoder encoder = Base64.getEncoder();


    public String getStateParam(Long connId, String connName, String tenantId) {
        Map<String, Object> valueMap = new HashMap<>();
        valueMap.put(AppConstant.CONFIG_ENTITY_RECORD_ID, connId.toString());
        valueMap.put(AppConstant.ADAPTER, FACEBOOK);
        valueMap.put(AppConstant.TENANTID, tenantId);
        valueMap.put(AppConstant.ENV_NAME ,cdmUtils.getEnvironmentNameByTenantId(tenantId));
        valueMap.put(AppConstant.CONNECTION_NAME, connName);
        return encodeData(Objects.requireNonNull(JacksonUtils.toJson(valueMap)));
    }

    public JSONObject getAuthorizationcode(TxnAdapterConnection result) throws NSLException {

        LOGGER.info("generating redirect url ..");
        try {
            FacebookAdapterConnectionDto connectionDto = (FacebookAdapterConnectionDto) result.getConnection();
            AuthorizationCodeRequestUrl url = new AuthorizationCodeRequestUrl(FACEBOOK_AUTH_TOKEN, connectionDto.getAppId());
            url.setRedirectUri(adaptorProperties.getRedirectUrl()).setScopes(connectionDto.getScope())
                    .set(PROMPT,CONSENT).set(ACCESS_TYPE,OFFLINE).setResponseTypes(Collections.singleton(CODE));

            String stateParams = getStateParam(result.getRecordId(), connectionDto.getConnectionName(), bean.getTenantId());
            LOGGER.info("appending state params to redirect url {} ", stateParams);
            url.set(STATE, stateParams);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(AppConstant.RESULT, result);
            jsonObject.put(Url, url.build());

            return jsonObject;
        } catch (Exception e) {
            LOGGER.error("exception occurred during generating redirect url: ",e );
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU, messageSource.getMessage("Paas_Adapter_1", null, Locale.ENGLISH),
                    ExceptionSeverity.BLOCKER,e);
        }
    }

    public TxnAdapterConnection getRefreshToken(Long id) throws NSLException {

        String cacheName = FACEBOOK + "_" + bean.getTenantId();

        String code = redisIntegration.getOAuthCode(cacheName, id.toString());
        LOGGER.info("updating connection with code: {}",code);
        try {
            FacebookAdapterConnectionDto connectionDto =facebookConnectionService.getFacebookConnection(id,false);
            connectionDto.setRefreshToken(getRefreshToken(connectionDto, code));
            return facebookConnectionService.updateFacebookConnection(id, connectionDto);
        } catch (Exception e) {
            LOGGER.error("failed to generate refresh Token",e);
            throw new NSLException(INTERNAL_SERVER, ExceptionCategory.RESERVED_CU,messageSource.getMessage
                    ("Paas_Adapter_13", null, Locale.ENGLISH) + e.getMessage(), ExceptionSeverity.BLOCKER, e);
        }
    }

    public String getRefreshToken(FacebookAdapterConnectionDto connectionDto, String code) throws IOException {
        TokenRequest request = new AuthorizationCodeTokenRequest(new NetHttpTransport(), new JacksonFactory(), new GenericUrl(FACEBOOK_ACCESS_TOKEN), code)
                .setRedirectUri(adaptorProperties.getRedirectUrl()).setGrantType(AUTHORIZATION_CODE).set("client_id",connectionDto.getAppId()).set("client_secret",connectionDataToolsV3.getSecret(connectionDto.getAppSecret()));

        TokenResponse response = request.execute();
        return response.getAccessToken();
    }


    private  String encodeData(String value){
        return encoder.encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

}
