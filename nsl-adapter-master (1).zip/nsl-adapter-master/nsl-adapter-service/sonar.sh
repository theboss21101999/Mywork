export branch=$(git branch 2> /dev/null | sed -e '/^[^*]/d' -e 's/* \(.*\)/\1/')
echo $branch
mvn clean install sonar:sonar -Dsonar.branch.name=$branch -Dsonar.host.url=https://sonarqube.nslhub.com -Dsonar.login=squ_ff3473b533c895d9ae1f4e9665c61f7cb5f03a03 -Dsonar.projectKey=Nsl-Adapter -Dsonar.projectName=com.nsl:nsl-adapter-service -Dsonar.language=java -Dsonar.sources=src/main/java -Dsonar.tests=src/test/java -Dsonar.dynamicAnalysis=reuseReports -Dsonar.junit.reportsPath=/target/test-reports -Dsonar.java.coveragePlugin=jacoco -Dsonar.jacoco.reportPath=/target/site/jacoco/index.html
