package kafka_topic.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyShort;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class NovusAdiminUtilsTest {
	
	@Mock
	AdminClientUtils adminClientUtils;
	
	@InjectMocks
	NovusAdiminUtils novusAdiminUtils;
	
	@BeforeEach
    void setUp() {
		MockitoAnnotations.openMocks(this);
    }
	
	@Test
    void validString_Test() {
		//validString_Test
        String validTopic = "my-valid-topic";
        Boolean actualValue = NovusAdiminUtils.isValidTopicName(validTopic);
        assertEquals(true, actualValue);
        //invalidString_Test
        String validTopic1 = "invalid@topic";
        Boolean actualValue1 = NovusAdiminUtils.isValidTopicName(validTopic1);
        assertEquals(false, actualValue1);
        //containCapitalLetterString_Test
        String validTopic2 = "my-valid-topiC";
        Boolean actualValue2 = NovusAdiminUtils.isValidTopicName(validTopic2);
        assertEquals(false, actualValue2);
        //startingWith_HifunString_Test
        String validTopic3 = "-my-valid-topic";
        Boolean actualValue3 = NovusAdiminUtils.isValidTopicName(validTopic3);
        assertEquals(false, actualValue3);
        //startingWith_UnderScoreString_Test
        String validTopic4 = "_my-valid-topic";
        Boolean actualValue4 = NovusAdiminUtils.isValidTopicName(validTopic4);
        assertEquals(false, actualValue4);
        //emptyString_Test
        String validTopic5 = "";
        Boolean actualValue5 = NovusAdiminUtils.isValidTopicName(validTopic5);
        assertEquals(false, actualValue5);
        //nullValue_Test
        Boolean actualValue6 = NovusAdiminUtils.isValidTopicName(null);
        assertEquals(false, actualValue6);
    }
	
	@Test
    void checkListOfTopic_Test() throws ExecutionException, InterruptedException {
		Set<String> topics = new HashSet<>();
		topics.add("topic1");
		topics.add("topic2");
		when(adminClientUtils.listKafkaTopics(any())).thenReturn(topics);
        Set<String> result = novusAdiminUtils.getListKafkaTopics();
        assertEquals(2, result.size());
	}
	
	@Test
	void createTopic_test() {
		when(adminClientUtils.createKafkaTopic(anyString(),any(),anyInt(),anyShort())).thenReturn("Topic created successfully");
		String actualMsg = novusAdiminUtils.createTopic("topic1");
		assertEquals("Topic created successfully", actualMsg);
	}

}
