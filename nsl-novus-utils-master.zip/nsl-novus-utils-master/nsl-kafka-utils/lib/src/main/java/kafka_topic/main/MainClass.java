package kafka_topic.main;

import java.util.List;
import java.util.concurrent.ExecutionException;

import com.google.gson.Gson;

import kafka_topic.utils.ConnectorsUtils;
import kafka_topic.utils.NovusAdiminUtils;

public class MainClass {
	
	private static Gson gson = new Gson();

	public static void main(String[] args) throws ExecutionException, InterruptedException {
		System.out.println("Hello");
//		String validTopic = "my-valid-topic";
//        String invalidTopic = "invalid@topic";
//        String invalidTopic1 = "my-valid-topiC";
//        String invalidTopic2 = "-my-valid-topic";
//        String invalidTopic3 = "_my-valid-topic";
//        
//        System.out.println(NovusAdiminUtils.isValidTopicName(validTopic));
//        System.out.println(NovusAdiminUtils.isValidTopicName(invalidTopic));
//        System.out.println(NovusAdiminUtils.isValidTopicName(invalidTopic1));
//        System.out.println(NovusAdiminUtils.isValidTopicName(invalidTopic2));
//        System.out.println(NovusAdiminUtils.isValidTopicName(invalidTopic3));
//        
        NovusAdiminUtils utils = new NovusAdiminUtils();
//        utils.createTopic(validTopic);
        utils.getListKafkaTopics();
////        utils.accessVlaue();
//		ConnectorsUtils connectorsUtils = new ConnectorsUtils();
//		List<String> connectors = connectorsUtils.getAllConnectorsName();
//		for (String string : connectors) {
//			System.out.println(string);
//		}
//		Object object = connectorsUtils.getConnectorStatusByName("transaction-scylladb-sink-connector");
//		System.out.println(gson.toJson(object));
	}

}
