package kafka_topic.utils;

import java.io.InputStream;
import java.util.Collections;
import java.util.Properties;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.ListTopicsOptions;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.errors.TopicExistsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NovusAdiminUtils {

	private static final Pattern TOPIC_NAME_PATTERN = Pattern.compile("[a-z0-9.\\-]+");
	private static final Pattern INVALID_START_PATTERN = Pattern.compile("[._\\-].*");
	private static final Logger logger = LoggerFactory.getLogger(NovusAdiminUtils.class);

	private String bootstrapServers;
	private int numPartitions;
	private short replicationFactor;
	
	private AdminClientUtils adminClientUtils = new AdminClientUtils();
	
	public NovusAdiminUtils() {
		Properties properties = new Properties();
		try (InputStream input = NovusAdiminUtils.class.getClassLoader().getResourceAsStream("gradle.properties")) {
			if (input == null) {
				logger.warn("unable to find config.properties file");
				return;
			}
			properties.load(input);

			bootstrapServers = properties.getProperty("bootstrapServers");
			numPartitions = Integer.parseInt(properties.getProperty("numPartitions"));
			replicationFactor = Short.parseShort(properties.getProperty("replicationFactor"));

		} catch (Exception e) {
			throw new RuntimeException("Getting error on accessing gradle.properties file", e);
		}
	}

	public static boolean isValidTopicName(String topicName) {
		return topicName != null && !INVALID_START_PATTERN.matcher(topicName).matches()
				&& TOPIC_NAME_PATTERN.matcher(topicName).matches();
	}

	public String createTopic(String topicName) {
		Properties properties = new Properties();
		properties.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		String message = adminClientUtils.createKafkaTopic(topicName, properties, numPartitions, replicationFactor);
		return message;
	}

	public Set<String> getListKafkaTopics() throws ExecutionException, InterruptedException {

		Properties properties = new Properties();
		properties.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		Set<String> topics = adminClientUtils.listKafkaTopics(properties);
		Set<String> sortedSet = new TreeSet<>(topics);
		for (String topic : sortedSet) {
			System.out.println(topic);
		}
		return sortedSet;
	}

}
