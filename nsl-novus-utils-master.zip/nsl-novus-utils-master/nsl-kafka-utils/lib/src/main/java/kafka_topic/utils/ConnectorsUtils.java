package kafka_topic.utils;

import java.util.ArrayList;
import java.util.List;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import kafka_topic.enums.HttpMethod;
import kafka_topic.model.ApiRequest;
import kafka_topic.model.ApiResponse;

public class ConnectorsUtils {
	
	private Gson gson = new Gson();
	private GetProperties properties = new GetProperties();
	private static final String GET_CONNECTORS = "/connectors";
	private static final String GET_CONNECTORS_CONFIG_BYNAME = "/connectors/{name}/config";
	private static final String GET_CONNECTORS_STATUS_BYNAME = "/connectors/{name}/status";
	private static final String PAUSE_CONNECTORS_BYNAME = "/connectors/{name}/pause";
	private static final String RESUME_CONNECTORS_BYNAME = "/connectors/{name}/resume";
	private static final String RESTART_CONNECTORS_BYNAME = "/connectors/{name}/restart";
	private static final String GET_TASKS_OF_CONNECTORS_BYNAME = "/connectors/{name}/tasks";
	private static final String GET_TOPIC_OF_CONNECTORS_BYNAME = "/connectors/{name}/restart";
	
	public List<String> getAllConnectorsName(){
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS;
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                List<String> connectors = gson.fromJson(responseBody,
          	          new TypeToken<ArrayList<String>>() {}.getType());
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list of ConnectorsName failed ", e);
		}
		return null;
	}
	
	public Object getAllConnectorsStatus(){
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS + "?expand=status";
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list of ConnectorsStatus failed ", e);
		}
		return null;
	}
	
	public Object getAllConnectorsInfo() {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS + "?expand=info";
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list of ConnectorsInfo failed ", e);
		}
		return null;
	}
	
	public Object getAllConnectorsStatusInfo() {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS +"?expand=status&expand=info";
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list of ConnectorsStatusAndInfo failed ", e);
		}
		return null;
	}
	
	public Object getConnectorByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS + name;
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get Connector ByName failed ", e);
		}
		return null;
	}
	
	public Object getConnectorConfigByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS_CONFIG_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get Connector Config ByName failed ", e);
		}
		return null;
	}
	
	public Object getConnectorStatusByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS_STATUS_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get Connector Status ByName failed ", e);
		}
		return null;
	}
	
	//not tested
	public Object createConnector(Object connector) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS;
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.POST, apiUrl, gson.toJson(connector)));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("create Connector failed ", e);
		}
		return null;
	}
	
	//not tested
	public Object UpdateConnectorConfigByName(Object connector, String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS_CONFIG_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.PUT, apiUrl, gson.toJson(connector)));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Update Connector Config ByName failed ", e);
		}
		return null;
	}
	
	public String pauseConnectorByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + PAUSE_CONNECTORS_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.PUT, apiUrl));
            if (response.getStatus() == 202) { 
                return "Successful Pause Connector "+ name;
            }
		} catch (Exception e) {
			throw new RuntimeException("Pause Connector failed ", e);
		}
		return null;
	}
	
	public String resumeConnectorByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + RESUME_CONNECTORS_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.PUT, apiUrl));
            if (response.getStatus() == 202) { 
                return "Successful Resume Connector " + name;
            }
		} catch (Exception e) {
			throw new RuntimeException("Resume Connector failed ", e);
		}
		return null;
	}
	
	public String restartConnectorInstanceByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + RESTART_CONNECTORS_BYNAME.replace("{name}", name) + "?includeTasks=false&onlyFailed=false";
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.POST, apiUrl));
            if (response.getStatus() == 202) { 
                return "Successful Restart Connector " + name;
            }
		} catch (Exception e) {
			throw new RuntimeException("Restart Connector failed ", e);
		}
		return null;
	}
	
	public Object restartConnectorInstanceAndTaskInstanceByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + RESTART_CONNECTORS_BYNAME.replace("{name}", name) + "?includeTasks=true&onlyFailed=true";
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.POST, apiUrl));
            if (response.getStatus() == 202) { 
            	String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Restart Connector failed ", e);
		}
		return null;
	}
	
	public List<Object> getAllTaskConnectorsByName(String name){
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_TASKS_OF_CONNECTORS_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                List<Object> connectors = gson.fromJson(responseBody,
          	          new TypeToken<ArrayList<Object>>() {}.getType());
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list Task assign to Connectors failed ", e);
		}
		return null;
	}
	
	public Object getAllTopicOfConnectorsByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_TOPIC_OF_CONNECTORS_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                List<Object> connectors = gson.fromJson(responseBody,
          	          new TypeToken<ArrayList<Object>>() {}.getType());
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list Topic assign to Connectors failed ", e);
		}
		return null;
	}

}
