package kafka_topic.utils;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;

import kafka_topic.model.ApiRequest;
import kafka_topic.model.ApiResponse;

public class APIUtils {
	private final HttpClient httpClient = HttpClient.newHttpClient();
	
	private HttpRequest buildHttpRequest(ApiRequest request) {
        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(request.getApiUrl()))
                .timeout(java.time.Duration.ofSeconds(10));

        switch (request.getMethod()) {
            case GET:
                builder.GET();
                break;
            case POST:
                builder.header("Content-Type", "application/json");
                builder.POST(BodyPublishers.ofString(request.getRequestBody()));
                break;
            case PUT:
                builder.header("Content-Type", "application/json");
                builder.PUT(BodyPublishers.ofString(request.getRequestBody()));
                break;
            case DELETE:
                builder.DELETE();
                break;
            default:
                throw new IllegalArgumentException("Unsupported HTTP method: " + request.getMethod());
        }

        return builder.build();
    }
	
	public ApiResponse send(ApiRequest request) {
        try {
            HttpRequest httpRequest = buildHttpRequest(request);
            HttpResponse<String> httpResponse = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            return new ApiResponse(httpResponse.statusCode(), httpResponse.body());
        } catch (Exception e) {
            System.out.println("Error in API request: " + e.getMessage());
            throw new RuntimeException("Error in API request",e);
        }
    }
	
//	private static void handleResponse(String requestType, HttpResponse<String> response) {
//		System.out.println(requestType + " Response Code: " + response.statusCode());
//		System.out.println(requestType + " Response Body: " + response.body());
//		
//		// Retrieve and print response headers
//		HttpHeaders headers = response.headers();
//		headers.map().forEach((k, v) -> System.out.println(k + ":" + v));
//	}
	
//	private static void getRequest(String url) {
//		try {
//			HttpRequest getRequest = HttpRequest.newBuilder()
//					.uri(URI.create(url))
//					.header("Content-Type", "application/json")
//					.timeout(java.time.Duration.ofSeconds(10))
//					.build();
//			
//			HttpResponse<String> getResponse = httpClient.send(getRequest, HttpResponse.BodyHandlers.ofString());
//			
//			handleResponse("Synchronous GET", getResponse);
//			
//		} catch (Exception e) {
//			System.out.println("Error in synchronous GET request: " + e.getMessage());
//		}
//	}
//	
//	private static void postRequest(String url, String requestBody) {
//        try {
//            HttpRequest postRequest = HttpRequest.newBuilder()
//                    .uri(URI.create(url))
//                    .header("Content-Type", "application/json")
//                    .timeout(java.time.Duration.ofSeconds(10))
//                    .POST(BodyPublishers.ofString(requestBody))
//                    .build();
//
//            HttpResponse<String> postResponse = httpClient.send(postRequest, HttpResponse.BodyHandlers.ofString());
//
//            handleResponse("Synchronous POST", postResponse);
//
//        } catch (Exception e) {
//            System.out.println("Error in synchronous POST request: " + e.getMessage());
//        }
//    }
//	
//	
//	private static void putRequest(String url, String requestBody) {
//        try {
//            HttpRequest putRequest = HttpRequest.newBuilder()
//                    .uri(URI.create(url))
//                    .header("Content-Type", "application/json")
//                    .timeout(java.time.Duration.ofSeconds(10))
//                    .PUT(BodyPublishers.ofString(requestBody))
//                    .build();
//
//            HttpResponse<String> putResponse = httpClient.send(putRequest, HttpResponse.BodyHandlers.ofString());
//
//            handleResponse("Synchronous PUT", putResponse);
//
//        } catch (Exception e) {
//            System.out.println("Error in synchronous PUT request: " + e.getMessage());
//        }
//    }
//	
//	private static void deleteRequest(String url) {
//        try {
//            HttpRequest deleteRequest = HttpRequest.newBuilder()
//                    .uri(URI.create(url))
//                    .timeout(java.time.Duration.ofSeconds(10))
//                    .DELETE()
//                    .build();
//
//            HttpResponse<String> deleteResponse = httpClient.send(deleteRequest, HttpResponse.BodyHandlers.ofString());
//
//            handleResponse("Synchronous DELETE", deleteResponse);
//
//        } catch (Exception e) {
//            System.out.println("Error in synchronous DELETE request: " + e.getMessage());
//        }
//    }
}
