package kafka_topic.enums;

public enum HttpMethod {
	GET, POST, PUT, DELETE
}
