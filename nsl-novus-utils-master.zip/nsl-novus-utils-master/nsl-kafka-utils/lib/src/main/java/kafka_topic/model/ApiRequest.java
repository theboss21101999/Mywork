package kafka_topic.model;

import java.util.HashMap;
import java.util.Map;

import kafka_topic.enums.HttpMethod;

public class ApiRequest {
	private HttpMethod method;
	private String apiUrl;
	private String requestBody;
	private Map<String, String> headers;
	private int timeout;
	
	public ApiRequest(HttpMethod method, String apiUrl) {
		this(method, apiUrl, null, 10);
	}
	
	public ApiRequest(HttpMethod method, String apiUrl, String requestBody) {
		this(method, apiUrl, requestBody, 10);
	}
	
	public ApiRequest(HttpMethod method, String apiUrl, String requestBody, int timeout) {
        this.method = method;
        this.apiUrl = apiUrl;
        this.requestBody = requestBody;
        this.timeout = timeout;
    }

	public HttpMethod getMethod() {
		return method;
	}

	public void setMethod(HttpMethod method) {
		this.method = method;
	}

	public String getApiUrl() {
		return apiUrl;
	}

	public void setApiUrl(String apiUrl) {
		this.apiUrl = apiUrl;
	}

	public String getRequestBody() {
		return requestBody;
	}

	public void setRequestBody(String requestBody) {
		this.requestBody = requestBody;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}

	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}
}
