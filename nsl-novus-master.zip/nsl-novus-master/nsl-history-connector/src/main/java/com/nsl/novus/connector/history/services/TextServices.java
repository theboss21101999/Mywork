package com.nsl.novus.connector.history.services;

import org.apache.kafka.connect.sink.SinkRecord;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class TextServices {

    // List of Java keywords
    private static final Set<String> keywords = Set.of(
            "abstract", "continue", "for", "new", "switch",
            "assert", "default", "goto", "package", "synchronized",
            "boolean", "do", "if", "private", "this",
            "break", "double", "implements", "protected", "throw",
            "byte", "else", "import", "public", "throws",
            "case", "enum", "instanceof", "return", "transient",
            "catch", "extends", "int", "short", "try",
            "char", "final", "interface", "static", "void",
            "class", "finally", "long", "strictfp", "volatile",
            "const", "float", "native", "super", "while"
    );

    /*
        * Map of valid special characters allowed in mysql table name or column name
        * to the corresponding set of characters to replaced in the resulting name
        * which will be used as a field name in the java file/ class name.
     */
    public static final Map<Character, String> specialCharacters = Map.ofEntries(
            Map.entry(' ', "SPACE"),
            Map.entry('"', "QUOTE"),
            Map.entry('\'', "APOS"),
            Map.entry('@', "AT"),
            Map.entry('%', "PERC"),
            Map.entry('&', "AMP"),
            Map.entry('(', "OP"),
            Map.entry(')', "CP"),
            Map.entry('{', "OCB"),
            Map.entry('}', "CCB"),
            Map.entry('[', "OSB"),
            Map.entry(']', "CSB"),
            Map.entry('|', "PIPE"),
            Map.entry(';', "SC"),
            Map.entry(':', "COLON"),
            Map.entry('=', "EQUAL"),
            Map.entry(',', "COMMA"),
            Map.entry('.', "DOT"),
            Map.entry('*', "AST"),
            Map.entry('/', "SLASH"),
            Map.entry('\\', "BS"),
            Map.entry('!', "EXCL"),
            Map.entry('?', "QUES"),
            Map.entry('^', "CARAT"),
            Map.entry('~', "TILDE"),
            Map.entry('-', "MINUS"),
            Map.entry('+', "PLUS")
    );

    public static List<String> extractTopicName(SinkRecord record){
        String topic = record.topic();
        String[] topicParts = topic.split("\\.");
        StringBuilder clazz= new StringBuilder();
        for(int i=2;i<topicParts.length-1;i++){
            clazz.append(topicParts[i]).append(".");
        }
        clazz.append(topicParts[topicParts.length-1]);

        return List.of(topicParts[0],topicParts[1],clazz.toString());
    }

    public static String getValidClassName(String nameOfClass){
        nameOfClass = convertToValidJavaVariableName(nameOfClass);
        return capitalizeFirstLetter(nameOfClass);
    }

    public static String convertToValidJavaVariableName(String originalName) {
        StringBuilder sb = new StringBuilder();
        boolean isFirstChar = true;
        boolean afterSplChar = false;
        for (int i = 0; i < originalName.length(); i++) {
            char c = originalName.charAt(i);

            if (Character.isLetterOrDigit(c) || c == '_') {
                if (isFirstChar && Character.isDigit(c)) {
                    sb.append("_");
                }
                if(isFirstChar && Character.isLetter(c)) sb.append(Character.toLowerCase(c));
                else if(afterSplChar && Character.isLetter(c)) sb.append(Character.toUpperCase(c));
                else sb.append(c);
                isFirstChar = false;
                afterSplChar = false;
            }
            else if(specialCharacters.containsKey(c)){
                sb.append(specialCharacters.get(c));
                afterSplChar = true;
            }
        }

        String result = sb.toString().replaceAll("_+", "_");

        if (isJavaKeyword(result)) {
            result = "_" + result;
        }

        return result;
    }

    /*
        * this method converts any character not matching the regex [a-zA-z_]
        * with _ and if first character is a digit prepends with _
     */
    public static String convertToValidAvroFieldName(String fieldName){
        StringBuilder sb = new StringBuilder();
        boolean isFirst = true;

        for(int i=0;i<fieldName.length();i++){
            char c = fieldName.charAt(i);
            if(Character.isLetterOrDigit(c) || c=='_'){
                if(isFirst && Character.isDigit(c)) sb.append("_");
                sb.append(c);
                isFirst=false;
            }
            else sb.append("_");
        }
        return sb.toString();
    }

    //method to check if the given word is of java keyword
    private static boolean isJavaKeyword(String str) {
        return keywords.contains(str);
    }

    //capitalize the first letter of the word
    public static String capitalizeFirstLetter(String input) {
        return input.substring(0, 1).toUpperCase() + input.substring(1);
    }
}
