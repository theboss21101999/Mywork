package com.nsl.novus.connector.history.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.nsl.novus.connector.history.dto.TableHierarchyConfigDataDto;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MongoServices {

    private static final Logger log = LoggerFactory.getLogger(MongoServices.class);

    public static MongoDatabase makeDBConnection(String connectionString) {
        // Create a MongoClient
        try {
            MongoClient mongoClient = MongoClients.create(connectionString);
            // Connect to the "javersHistory" database
            MongoDatabase database = mongoClient.getDatabase("javers-history");

            log.info("{}",String.format("Connected to MongoDB: %s",database.getName()));

            return database;

        } catch (Exception e) {
            log.error("{}",String.format("Error connecting to MongoDB: %s",e.getMessage()));
            return null;
        }
    }

    public static Document getHierarchicalData(MongoDatabase db, String tableName,String databaseName){
        MongoCollection<Document> collection = db.getCollection("hierarchy_entity_config");
        Document query = new Document();
        query.append("name",tableName);
        query.append("database",databaseName);
        return collection.find(query).first();
    }

    public static TableHierarchyConfigDataDto documentDeserializer(Document document){
        ObjectMapper om = new ObjectMapper();
        return om.convertValue(document, TableHierarchyConfigDataDto.class);
    }

}
