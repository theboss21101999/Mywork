package com.nsl.novus.connector.history;

import java.util.*;

import org.apache.kafka.common.config.Config;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.connect.connector.Task;
import org.apache.kafka.connect.sink.SinkConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HistorySinkConnector extends SinkConnector {

  private static final Logger log = LoggerFactory.getLogger(HistorySinkConnector.class);
  public static String VERSION = "1.0";

  public static final String CONFIG_CONNECTION_GROUP = "Directory Path";
  public static final String CONFIG_NAME_DIRECTORY_PATH = "plugin.path";
  public static final String CONFIG_DOCUMENTATION_DIRECTORY_PATH = "The absolute path to get the .class files.";
  public static final String CONFIG_DISPLAY_DIRECTORY_PATH = "Classes Directory Location";

  public static final String CONFIG_NAME_CONNECTION_URI = "mongodb.connection.string";
  public static final String CONFIG_DOCUMENTATION_CONNECTION_URI = "The mongoDB connection URI.";
  public static final String CONFIG_DISPLAY_CONNECTION_URI = "Mongodb Connection URI";

  private static final String classname = HistorySinkTask.class.getName();

  private Map<String, String> configProps;


  /*
  * The user need to configure the two properties when registering the connector which are
  * "plugin.path" used to locate the compiled classes and lock files of all the entities
  * "mongodb.connection.string" mongo url to store javers snapshots and to get hierarchical table config
   */
  @Override
  public void start(Map<String, String> props) {
    log.trace("[{}] Entry {}.start, props={}", Thread.currentThread().getId(), classname, props);

    configProps = props;
    for (final Map.Entry<String, String> entry : props.entrySet()) {
      String value;
      if (entry.getKey().toLowerCase().contains("password")) {
        value = "[hidden]";
      }
      else {
        value = entry.getValue();
      }
      log.debug("Connector props entry {} : {}", entry.getKey(), value);
    }

    log.trace("[{}]  Exit {}.start", Thread.currentThread().getId(), classname);
  }

  @Override
  public List<Map<String, String>> taskConfigs(int maxTasks) {
    log.trace("[{}] Entry {}.taskConfigs, maxTasks={}", Thread.currentThread().getId(), classname, maxTasks);

    List<Map<String, String>> taskConfigs = new ArrayList<>();
    for (int i = 0; i < maxTasks; i++) {
      taskConfigs.add(configProps);
    }

    log.trace("[{}]  Exit {}.taskConfigs, retval={}", Thread.currentThread().getId(), classname, taskConfigs);
    return taskConfigs;
  }

  @Override
  public void stop() {
    log.info("Stopping History Connector.");
  }

  @Override
  public ConfigDef config() {
    ConfigDef config = new ConfigDef();
    config.define(CONFIG_NAME_DIRECTORY_PATH,
            ConfigDef.Type.STRING,
            ConfigDef.NO_DEFAULT_VALUE,
            ConfigDef.Importance.HIGH,
            CONFIG_DOCUMENTATION_DIRECTORY_PATH,
            CONFIG_CONNECTION_GROUP,
            1,
            ConfigDef.Width.LONG,
            CONFIG_DISPLAY_DIRECTORY_PATH);
    config.define(CONFIG_NAME_CONNECTION_URI,
            ConfigDef.Type.STRING,
            ConfigDef.NO_DEFAULT_VALUE,
            ConfigDef.Importance.HIGH,
            CONFIG_DOCUMENTATION_CONNECTION_URI,
            "Connection",
            1,
            ConfigDef.Width.LONG,
            CONFIG_DISPLAY_CONNECTION_URI);

    return config;
  }

  @Override
  public Class<? extends Task> taskClass() {
    return HistorySinkTask.class;
  }

  @Override
  public String version() {
    return VERSION;
  }

  @Override
  public Config validate(Map<String, String> connectorConfigs){

    return super.validate(connectorConfigs);
  }

}
