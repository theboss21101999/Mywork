package com.nsl.novus.connector.history;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Collection;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.nsl.novus.connector.history.dto.ParentTableData;
import com.nsl.novus.connector.history.dto.TableHierarchyConfigDataDto;
import com.nsl.novus.connector.history.services.MongoServices;
import com.nsl.novus.connector.history.services.TextServices;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.connect.data.Field;
import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.sink.SinkRecord;
import org.apache.kafka.connect.sink.SinkTask;
import org.bson.Document;
import org.javers.core.Javers;
import org.javers.core.JaversBuilder;
import org.javers.core.metamodel.object.CdoSnapshot;
import org.javers.repository.jql.QueryBuilder;
import org.javers.repository.mongo.MongoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.client.MongoDatabase;

/**
 * Task class for Javers History Sink Connector.
 */
public class HistorySinkTask extends SinkTask {

  private static final Logger log = LoggerFactory.getLogger(HistorySinkTask.class);

  private  NslClassLoader nslClassLoader;
  private Javers javers;
  private String classesDir;
  public  MongoDatabase database;

  @Override
  public void start(Map<String, String> settings) {
    //Loader Instantiation to load remote class files
    classesDir = context.configs().get("plugin.path");
    //add File Separator if there isn't.
    classesDir = classesDir.endsWith(File.separator) ? classesDir : classesDir+File.separator;
    nslClassLoader = new NslClassLoader(Path.of(classesDir,"classes"), this.getClass().getClassLoader());

    //Database Connection Instantiation
    String connectionString = context.configs().get("mongodb.connection.string");
    database = MongoServices.makeDBConnection(connectionString);
    MongoRepository mongoRepository = new MongoRepository(database);

    //Javers instantiation
    javers = JaversBuilder.javers().registerJaversRepository(mongoRepository).build();

  }

  @Override
  public void put(Collection<SinkRecord> records) {
    if(!records.isEmpty()) log.info("Received messages {}", records.size());

    for (SinkRecord record : records) {
      if(record.value()!=null){
          log.info("message {}:`{}`", record.value().getClass(), record.value());

        // Main Method
        taskHandler(record);
      }
      else{
        log.error("Null Record detected");
      }
    }
  }


  public void taskHandler(SinkRecord record){
    //Reading Record value
    Object value = record.value();
    if(value instanceof Struct) {
      Struct valueStruct = (Struct) value;
      Struct afterDataStruct = (Struct) valueStruct.get("after");
      Struct beforeDataStruct = (Struct) valueStruct.get("before");

      /*
        * Extract the metadata which are
        * topic prefix (which is mentioned as a config property of mysql connector)
        * database name
        * table name (first letter capital and valid java Class name)
        * since topic.prefix + database + table = Correct identifier to load the class
        * which then is used to instantiate an object to make a javers snapshot
       */
      List<String> topicMetaData = TextServices.extractTopicName(record);
      String topicPrefix = topicMetaData.get(0);
      String databaseName = topicMetaData.get(1);
      String tableHeading = topicMetaData.get(2);
      String validClassName = TextServices.getValidClassName(tableHeading);
      String clazz = String.join(".",topicPrefix,databaseName,validClassName);

      try{
        /*
        * Checking if there are any relations registered for the entity of the current record
        * i.e, whether the current entity has any parent entities
         */
        Document document = MongoServices.getHierarchicalData(database,tableHeading,databaseName);
        TableHierarchyConfigDataDto tableHierarchyConfigData=null;
        if(document!=null && !document.isEmpty()){
          tableHierarchyConfigData = MongoServices.documentDeserializer(document);
        }
        else{
          log.info("Hierarchical Relation is not present");
        }

        String action="";
        Struct dataStruct=null;

        //Insert
        if(afterDataStruct!=null && beforeDataStruct==null){
          action="CREATE";
          dataStruct=afterDataStruct;
          log.info("Instance is created");
          Map<String,Object> afterDataMap = createdataMap(afterDataStruct);

          Object entityObject = createObject(afterDataMap,clazz);
          javers.commit("author", entityObject);
        }
        //Update
        else if(beforeDataStruct!=null && afterDataStruct!=null){
          action="UPDATE";
          dataStruct=afterDataStruct;
          log.info("Instance is updated");
          Map<String,?> afterDataMap = createdataMap(afterDataStruct);

          Object entityObject = createObject(afterDataMap,clazz);
          javers.commit("author",entityObject);

        }
        //Delete
        else if(beforeDataStruct!=null){
          action="DELETE";
          dataStruct=beforeDataStruct;
          log.info("Instance is deleted");
          Map<String,?> beforeDataMap = createdataMap(beforeDataStruct);

          Object entityObject = createObject(beforeDataMap,clazz);
          javers.commitShallowDelete("author", entityObject);

        }
        // Update the parent entity record if the current entity is nested.
        if(tableHierarchyConfigData!=null && dataStruct!=null) {
          updateParentSnapshotVersion(
                  javers,
                  action,
                  clazz,
                  tableHierarchyConfigData,
                  dataStruct,
                  topicPrefix
          );
        }
      } catch (ClassNotFoundException e) {
        throw new RuntimeException(e);
      }

    }
  }

  // Convert the struct data into a map with fieldName as key and its value as value
  public Map<String, Object> createdataMap(Struct dataStruct){
    Map<String,Object> dataMap = new HashMap<>();

    for(Field field : dataStruct.schema().fields()){
      String fieldName = field.name();
      Object fieldValue = dataStruct.get(fieldName);
      dataMap.put(fieldName,fieldValue);
    }
    return dataMap;
  }

  public  Object createObject(Map<String,?>dataMap,String clazz) {
    String lockFile = clazz.replace(".", File.separator)+".lock";
    try (FileChannel channel = FileChannel.open(Path.of(classesDir,"src",lockFile), StandardOpenOption.WRITE);
         FileLock lock = channel.tryLock()){

      if(lock!=null) {
        var entityClass = nslClassLoader.loadClass(clazz);
        var method = entityClass.getMethod("create", Map.class);
        return method.invoke(null, dataMap);
      }
      else{
        throw new IOException("Unable to obtain file lock of :"+classesDir+lockFile);
      }
    }
    catch (IOException | IllegalAccessException | NoSuchMethodException | InvocationTargetException | ClassNotFoundException e) {
      log.error("",e);
      return null;
    }
  }

  public void updateParentSnapshotVersion(
          Javers javers, String action,
          String childClass,
          TableHierarchyConfigDataDto tableMetaData,
          Struct dataStruct,
          String topicPrefix) throws ClassNotFoundException
  {
    // PrimaryKey value of the current record
    Object primaryId = dataStruct.get(TextServices.convertToValidAvroFieldName(tableMetaData.getPrimaryKeyColumn()));

    //Bump Up every Parent Entity Snapshot
    for( ParentTableData parentTableData:tableMetaData.getParentTables() ){

      //Getting Parent Class to load
      String clazzName = String.join(".",topicPrefix,parentTableData.getDatabase(),TextServices.getValidClassName(parentTableData.getName()));

      Class<?> clazz = nslClassLoader.loadClass(clazzName);

      //Getting the exact snapshot of the parent entity to bump up the version
      String fieldName = TextServices.convertToValidAvroFieldName(parentTableData.getForeignKeyColumn());
      Object id = dataStruct.get(fieldName);

      //Getting the Latest snapshot of the corresponding  Parent Entity
      List<CdoSnapshot> snapshots = javers.findSnapshots(QueryBuilder.byInstanceId(id,clazz).limit(1).build());

      if(!snapshots.isEmpty()){
        Object obj = getObjFromSnapshot(snapshots.get(0),clazzName);
        try{
          Class<?> parentClass = obj.getClass();
          Method getterMethod = parentClass.getMethod("get_ChangedChildEntityLog");
          List<String> list = (List<String>) getterMethod.invoke(obj);
          if(list==null) list = new ArrayList<>();
          list.add(action+"|"+childClass+"|"+primaryId);
          Method setterMethod = parentClass.getMethod("set_ChangedChildEntityLog",List.class);
          setterMethod.invoke(obj,list);
          javers.commit("author",obj);

        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
      }
      else{
        log.error("Snapshots not found. May be due to wrong className/fieldName: {},{}",clazzName,fieldName);
      }
    }
  }

  public Object getObjFromSnapshot(CdoSnapshot snapshot,String clazz)
  {
    Object childObject = null;

    String lockFile = clazz.replace(".", File.separator) + ".lock";
    try (FileChannel channel = FileChannel.open(Path.of(classesDir, "src", lockFile), StandardOpenOption.WRITE);
         FileLock lock = channel.tryLock()) {
      if (lock != null) {
        var entityClass = nslClassLoader.loadClass(clazz);
        var method = entityClass.getMethod("create", CdoSnapshot.class);
        childObject = method.invoke(null, snapshot);
      } else {
        throw new IOException("Unable to obtain file lock of :" + classesDir + lockFile);
      }

    } catch (IOException | IllegalAccessException | NoSuchMethodException | InvocationTargetException |
             ClassNotFoundException e) {
      log.error("", e);
    }

    return childObject;
  }

  @Override
  public Map<TopicPartition, OffsetAndMetadata> preCommit(
    Map<TopicPartition, OffsetAndMetadata> currentOffsets
  ) {
    return currentOffsets;
  }

  @Override
  public void stop() {
    close();
  }

  void close() {
  }

  @Override
  public String version() {
    return HistorySinkConnector.VERSION;
  }
}
