package com.nsl.novus.connector.history.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ParentTableData {

	@JsonIgnore
	private String _id;
	private String name;
	private String foreignKeyColumn;
	private String database;

	public String get_id() {
		return _id;
	}

	public void set_id(String id) {
		this._id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getForeignKeyColumn() {
		return foreignKeyColumn;
	}

	public void setForeignKeyColumn(String foreignKeyColumn) {
		this.foreignKeyColumn = foreignKeyColumn;
	}

	public String getDatabase() {
		return database;
	}

	public void setDatabase(String database) {
		this.database = database;
	}
}

