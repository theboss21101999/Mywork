package com.nsl.novus.connector.history;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class NslClassLoader extends ClassLoader {

  private final String classesDir;
  public NslClassLoader(Path classesDir, ClassLoader parent) {
    super(parent);
    this.classesDir = classesDir.toString();
  }

  @Override
  protected Class<?> findClass(String name) throws ClassNotFoundException {

    var fileName = name.replace('.', File.separatorChar) + ".class";

    byte[] bytes = new byte[0];

    try
    {
        bytes = Files.readAllBytes(Path.of(classesDir, fileName));
    }
    catch (IOException e) {
      throw new RuntimeException(e);
    }

    var entityClass = defineClass(name, bytes, 0, bytes.length);
    resolveClass(entityClass);
    return entityClass;

  }

}

