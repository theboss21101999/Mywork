package com.nsl.novus.connector.history.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.List;


public class TableHierarchyConfigDataDto {
	@JsonProperty("_id")
	@JsonIgnore
	private ObjectId _id;
	@JsonProperty("_class")
	@JsonIgnore
	private String _class;
	private String id;
	private String name;
	private String primaryKeyColumn;
	private String database;
	@JsonProperty("parentTables")
	private List<ParentTableData> parentTables = new ArrayList<ParentTableData>();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String childTable) {
		this.name = childTable;
	}

	public String getPrimaryKeyColumn() {
		return primaryKeyColumn;
	}

	public void setPrimaryKeyColumn(String primaryKeyColumn) {
		this.primaryKeyColumn = primaryKeyColumn;
	}

	public String getDatabase() {
		return database;
	}

	public void setDatabase(String database) {
		this.database = database;
	}

	public List<ParentTableData> getParentTables() {
		return parentTables;
	}
	public void setParentTables(List<ParentTableData> parentTables) {
		this.parentTables = parentTables;
	}
}
