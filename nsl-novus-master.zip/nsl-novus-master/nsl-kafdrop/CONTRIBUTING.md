# Introduction

All contributions are more than welcomed. Contributions may close an issue, fix a bug (reported or not reported), add new design blocks, improve the existing code, add new feature, and so on. In the interest of fostering an open and welcoming environment, we as contributors and maintainers pledge to making participation in our project and our community a harassment-free experience for everyone.

# Coding style

For code contributions, please respect the coding style as documented in [.editorconfig](.editorconfig). We are in the process of setting up automated checks on this.
