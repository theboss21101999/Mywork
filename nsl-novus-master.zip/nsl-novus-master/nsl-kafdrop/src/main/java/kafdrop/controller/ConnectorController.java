package kafdrop.controller;

import com.nsl.novus.model.ConnectorListResponse;
import com.nsl.novus.model.ConnectorRegisterResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import kafdrop.model.AddConnectorRequest;
import kafdrop.model.APIResponse;
import kafdrop.service.ConnectorService;
import org.apache.kafka.common.errors.InvalidRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Tag(name = "connector-controller", description = "Connector Controller")
@Controller
@RequestMapping("/connectors")
public class ConnectorController {

  @Autowired
  ConnectorService connectorService;

  @Operation(summary = "registerConnectors", description = "This API is for registering all connectors of a particular env present in nsl-novus library. " +
    "The request body is mandatory which contains connector registry url and environment name(env). All the connector register json within that env folder will get executed and registration status along with message will be given as output.")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Success"),
    @ApiResponse(responseCode = "500", description = "Internal Server Error")})
  @PostMapping("/add")
  public ResponseEntity<APIResponse> registerConnectorEnv(@RequestBody AddConnectorRequest addConnectorRequest) {
    try {
      ConnectorListResponse connectorApiResponse = new ConnectorListResponse();
      connectorApiResponse = connectorService.registerConnectorEnv(addConnectorRequest.getConnectorsServiceHost(), addConnectorRequest.getEnv());
      APIResponse apiResponse = new APIResponse("Success", connectorApiResponse, HttpStatus.CREATED.value());
      return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);
    }catch (InvalidRequestException ir) {
      APIResponse apiResponse = new APIResponse(ir.getMessage(), null, HttpStatus.BAD_REQUEST.value());
      return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
    }
    catch (Exception e){
      APIResponse apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.INTERNAL_SERVER_ERROR.value());
      return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @PostMapping
  public ResponseEntity<APIResponse> registerConnector(@RequestParam String connectorsServiceHost, @RequestBody String connector) {
    try {
      ConnectorRegisterResponse connectorApiResponse = connectorService.registerConnector(connectorsServiceHost, connector);
      APIResponse apiResponse = new APIResponse("Success", connectorApiResponse, HttpStatus.CREATED.value());
      return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);
    } catch (Exception e) {
      APIResponse apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.INTERNAL_SERVER_ERROR.value());
      return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Operation(summary = "deleteAllConnectors", description = "This API is for deleting all connectors for a particular connector registry. " +
    "The request parameter is mandatory which contains connector registry url. All the connector will be de-registered and status along with message will be given as output.")
  @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "Success"),
    @ApiResponse(responseCode = "500", description = "Internal Server Error")})
  @DeleteMapping
  public ResponseEntity<APIResponse> deleteAllConnectors(@RequestParam String connectorsServiceHost){
    try {
      List<String> deleteResponse = connectorService.deleteAllConnectors(connectorsServiceHost);
      APIResponse apiResponse = new APIResponse("Success", deleteResponse, HttpStatus.OK.value());
      return new ResponseEntity<>(apiResponse, HttpStatus.OK);
    }catch (Exception e){
      APIResponse apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.INTERNAL_SERVER_ERROR.value());
      return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @DeleteMapping("/{connectorName}")
  public ResponseEntity<APIResponse> deleteConnectorByName(@RequestParam String connectorsServiceHost, @PathVariable String connectorName){
    try {
      String deleteResponse = connectorService.deleteConnectorByName(connectorsServiceHost, connectorName);
      APIResponse apiResponse = new APIResponse("Success", deleteResponse, HttpStatus.OK.value());
      return new ResponseEntity<>(apiResponse, HttpStatus.OK);
    }catch (Exception e){
      APIResponse apiResponse = new APIResponse(e.getMessage(), null, HttpStatus.INTERNAL_SERVER_ERROR.value());
      return new ResponseEntity<>(apiResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

}
