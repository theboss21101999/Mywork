package kafdrop.config;

public final class KafkaConfigurationException extends RuntimeException {
  KafkaConfigurationException(Throwable cause) {
    super(cause);
  }
}
