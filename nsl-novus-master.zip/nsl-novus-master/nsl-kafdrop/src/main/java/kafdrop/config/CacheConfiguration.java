package kafdrop.config;

import kafdrop.util.CacheStore;
import org.apache.kafka.common.PartitionInfo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Configuration
public class CacheConfiguration {

  @Bean
  public CacheStore<Map<String, List<PartitionInfo>>> getAllCache(){
    return new CacheStore<Map<String, List<PartitionInfo>>>(2, TimeUnit.HOURS);
  }
}
