package kafdrop.util;

public enum KeyFormat {
  DEFAULT, AVRO
}
