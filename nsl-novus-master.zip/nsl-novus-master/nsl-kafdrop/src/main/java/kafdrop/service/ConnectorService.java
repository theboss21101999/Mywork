package kafdrop.service;

import com.nsl.novus.model.ConnectorListResponse;
import com.nsl.novus.model.ConnectorRegisterResponse;
import com.nsl.novus.utils.ConnectorsUtils;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ConnectorService {

  ConnectorsUtils connectorsUtils = new ConnectorsUtils();

  public ConnectorListResponse registerConnectorEnv(String connectorsServiceHost, String env) throws IOException {
    ConnectorListResponse connectorListResponse = new ConnectorListResponse();
    connectorListResponse = connectorsUtils.createConnectorsEnv(connectorsServiceHost, env);
    return connectorListResponse;
  }

  public ConnectorRegisterResponse registerConnector(String connectorsServiceHost, String connector){
    return connectorsUtils.createConnector(connectorsServiceHost, connector);
  }

  public List<String> deleteAllConnectors(String connectorServiceHost){
    return connectorsUtils.deleteAllConnectors(connectorServiceHost);
  }
  public String deleteConnectorByName(String connectorServiceHost, String connectorName){
    return connectorsUtils.deleteConnectorByName(connectorServiceHost, connectorName);
  }
}
