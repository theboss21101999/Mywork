package kafdrop.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

  @Bean
  public InMemoryUserDetailsManager inMemoryUserDetailsManager(){
    UserDetails admin = User.builder().username("admin").password(encoder().encode("admin@123")).build();

    return new InMemoryUserDetailsManager(admin);
  }

  @Bean
  public PasswordEncoder encoder() {
    return new BCryptPasswordEncoder();
  }

  @Bean
  public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
    http.httpBasic(Customizer.withDefaults())
      .authorizeHttpRequests(authorize ->
        authorize
          .requestMatchers("/login").permitAll()
          .requestMatchers("/resources/**, /static/**").permitAll()
          .requestMatchers("/style.css").permitAll()
          .requestMatchers("/images/**").permitAll()
          .anyRequest()
          .authenticated()
      )
      .csrf(AbstractHttpConfigurer::disable)
      .formLogin(form ->
        form
          .loginPage("/login")
          .loginProcessingUrl("/autUser")
          .permitAll()
      )
      .logout(logout ->
        logout
          .logoutUrl("/logout")
          .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
          .logoutSuccessUrl("/login?logout")
          .permitAll()
        );

    return http.build();
  }
}
