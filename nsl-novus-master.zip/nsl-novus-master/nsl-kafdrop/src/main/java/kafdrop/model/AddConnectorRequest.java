package kafdrop.model;

public class AddConnectorRequest {
  String connectorsServiceHost;
  String env;

  public String getConnectorsServiceHost() {
    return connectorsServiceHost;
  }

  public void setConnectorsServiceHost(String connectorsServiceHost) {
    this.connectorsServiceHost = connectorsServiceHost;
  }

  public String getEnv() {
    return env;
  }

  public void setEnv(String env) {
    this.env = env;
  }
}
