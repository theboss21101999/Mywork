package kafdrop.model;

public record APIResponse(String message, Object result, Integer status) {

}
