package com.nsl.novus.javers.history.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.nsl.novus.ApiResponse;
import com.nsl.novus.NslClassLoader;
import com.nsl.novus.javers.history.service.JaversHistoryService;
import java.nio.file.Path;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JaversHistoryController {

  @Autowired
  private JaversHistoryService historyService;
  @Value("${generated.entity.classes.directory}")
  private String entityClassesDirectory;

  private NslClassLoader nslClassLoader;
  //TODO check if it is thread-safe
  private ObjectMapper objectMapper = new ObjectMapper();

  @PostConstruct
  void init() {
    nslClassLoader = new NslClassLoader(Path.of(entityClassesDirectory),
        this.getClass().getClassLoader());
    objectMapper.registerModule(new JavaTimeModule());
  }

  @GetMapping("/{entityClassName}/{id}")
  public ApiResponse getSnapshots(@PathVariable final String entityClassName, @PathVariable String id)
      throws ClassNotFoundException {

    var entityClass = nslClassLoader.loadClass(entityClassName);
    var snapshots = historyService.getSnapshots(entityClass, id);
    return new ApiResponse(HttpStatus.OK, "Success", objectMapper.valueToTree(snapshots));

  }

}
