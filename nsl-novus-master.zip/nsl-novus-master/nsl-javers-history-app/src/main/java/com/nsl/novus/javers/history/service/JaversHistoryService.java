package com.nsl.novus.javers.history.service;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.nsl.novus.javers.history.EntitySnapshot;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.PostConstruct;
import org.javers.core.Javers;
import org.javers.core.JaversBuilder;
import org.javers.core.graph.Cdo;
import org.javers.core.metamodel.object.CdoSnapshot;
import org.javers.repository.jql.JqlQuery;
import org.javers.repository.jql.QueryBuilder;
import org.javers.repository.mongo.MongoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class JaversHistoryService {

  @Autowired
  private MongoClient mongoClient;
  @Value("${mongodb.name}")
  private String mongodbName;

  private Javers javers;

  @PostConstruct
  void init() {
    MongoDatabase mongoDb = mongoClient.getDatabase(Objects.requireNonNull(mongodbName));
    MongoRepository mongoRepository = new MongoRepository(mongoDb);
    javers = JaversBuilder.javers().registerJaversRepository(mongoRepository)
        //.registerValue(RuleUpsertDto.class, new RuleUpsertDtoComparator())
        .build();
  }

  public List<EntitySnapshot> getSnapshots(final Class<?> entityClass, Object id) {

    var query = QueryBuilder.byInstanceId(id, entityClass).build();
    var snapshots = javers.findSnapshots(query);
    return createSnapshots(snapshots);

  }

  public List<CdoSnapshot> getSnapshots(final Object entity, final long version) {
    JqlQuery query = QueryBuilder.byInstance(entity).withVersion(version).build();
    return javers.findSnapshots(query);
  }

  public Optional<CdoSnapshot> getSnapshot(final Class<?> entityClass, final Long id) {
    return javers.getLatestSnapshot(id, entityClass);
  }

  public void commitShallowDelete(final String author, final Object entity) {
    javers.commitShallowDelete(author, entity);
  }

  public void commit(final String author, final Object entity) {
    javers.commit(author, entity);
  }


  private List<EntitySnapshot> createSnapshots(List<CdoSnapshot> snapshots) {

    var entitySnapshots = new ArrayList<EntitySnapshot>(snapshots.size());
    snapshots.forEach(snapshot -> {
      entitySnapshots.add(createSnapshot(snapshot));
    });

    return entitySnapshots;
  }

  private EntitySnapshot createSnapshot(CdoSnapshot snapshot) {

    var stateMap = new HashMap<String, Object>();
    for(String propertyName : snapshot.getState().getPropertyNames()){
      stateMap.put(propertyName, snapshot.getPropertyValue(propertyName));
    }
    return new EntitySnapshot(snapshot.getCommitMetadata(), stateMap, snapshot.getType(),
        snapshot.getChanged(), snapshot.getVersion());

  }

}
