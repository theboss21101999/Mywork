package com.nsl.novus.javers.history;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaversHistoryApplication {

  public static void main(String[] args) {
    SpringApplication.run(JaversHistoryApplication.class, args);
  }

}

