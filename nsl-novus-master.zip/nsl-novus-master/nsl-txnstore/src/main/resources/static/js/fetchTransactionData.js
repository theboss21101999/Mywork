$(document).ready(function () {
    $('#fetchTransactionForm').submit(function (event) {
        event.preventDefault(); // Prevent the default form submit

        var transactionId = $('#transactionId').val();
        var tenantId = $('#tenantId').val();

        $.ajax({
            type: 'GET',
            url: '/api/fetch/transactionData',
            data: {
                transactionId: transactionId,
                tenantId: tenantId
            },
            success: function (response) {
                var resultHtml = '';

                if (response.status === 200) {
                    resultHtml += '<div class="alert alert-success">';
                    resultHtml += '<p>' + response.message + '</p>';

                    var txnResult = response.result;

                    if (txnResult) {
                        resultHtml += '<table class="table">';
                        resultHtml += '<thead><tr><th>Field</th><th>Value</th></tr></thead>';
                        resultHtml += '<tbody>';

                        // Display tenantId and transactionId first
                        resultHtml += '<tr><td>Tenant ID</td><td>' + txnResult.tenantId + '</td></tr>';
                        resultHtml += '<tr><td>Transaction ID</td><td>' + txnResult.transactionId + '</td></tr>';

                        // Format date/time fields
                        resultHtml += '<tr><td>Start Time</td><td>' + formatValue(txnResult.data.startTime) + '</td></tr>';
                        resultHtml += '<tr><td>End Time</td><td>' + formatValue(txnResult.data.endTime) + '</td></tr>';
                        resultHtml += '<tr><td>Created At</td><td>' + formatValue(txnResult.data.createdAt) + '</td></tr>';
                        resultHtml += '<tr><td>Updated At</td><td>' + formatValue(txnResult.data.updatedAt) + '</td></tr>';

                        // Iterate through all fields in data and display them
                        Object.keys(txnResult.data).forEach(function (key) {
                            if (!['startTime', 'endTime', 'createdAt', 'updatedAt'].includes(key)) {
                                var value = txnResult.data[key];
                                resultHtml += '<tr><td>' + key + '</td><td>' + (value !== null && typeof value === 'object' ? JSON.stringify(value) : formatValue(value)) + '</td></tr>';
                            }
                        });

                        resultHtml += '</tbody></table>';
                    } else {
                        resultHtml += '<p>No data found</p>';
                    }

                    resultHtml += '</div>';
                } else {
                    resultHtml += '<div class="alert alert-danger">';
                    resultHtml += '<p>' + response.message + '</p>';
                    resultHtml += '</div>';
                }

                $('#resultSection').html(resultHtml); // Update the result section
            },
            error: function (error) {
                console.error('Error fetching data:', error);
                var errorHtml = '<div class="alert alert-danger">';
                errorHtml += '<p>Unexpected error occurred while fetching data.</p>';
                errorHtml += '<p>' + error.responseText + '</p>';
                errorHtml += '</div>';

                $('#resultSection').html(errorHtml); // Update the result section with error
            }
        });
    });
});

// Function to format the value (handling null and date/time properly)
function formatValue(value) {
    if (value === null || value === undefined) {
        return 'null';
    } else if (typeof value === 'string' && (value.toLowerCase().includes('at') || value.toLowerCase().includes('time'))) {
        return new Date(value).toLocaleString(); // Format date/time values
    }
        return value;
    }
}
