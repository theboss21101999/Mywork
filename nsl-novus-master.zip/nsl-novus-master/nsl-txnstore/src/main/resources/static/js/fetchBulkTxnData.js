$(document).ready(function () {
    var currentSearchIndex = 0;
    var searchResults = [];

    // Function to update the search statistics display
    function updateSearchStats() {
        $('#searchStats').text((searchResults.length ? (currentSearchIndex + 1) : 0) + ' of ' + searchResults.length + ' results');
    }

    // Function to highlight all matches of the search text in the JSON content
    function highlightAllMatches(text) {
        var jsonContent = $('#jsonContent');
        // Remove previous highlights
        jsonContent.html(jsonContent.html().replace(/(<mark class="highlight.*?">|<\/mark>)/gim, ''));
        if (text) {
            var pattern = new RegExp(text, 'gi');
            // Highlight all matches
            jsonContent.html(jsonContent.html().replace(pattern, function(matched) {
                return '<mark class="highlight">' + matched + '</mark>';
            }));
            searchResults = $('.highlight');
            if (searchResults.length) {
                currentSearchIndex = 0;
                $(searchResults[currentSearchIndex]).addClass('current');
                scrollToCurrent();
            }
            updateSearchStats();
        } else {
            searchResults = [];
            updateSearchStats();
        }
    }

    // Function to scroll to the current highlighted match
    function scrollToCurrent() {
        if (searchResults.length) {
            var modalBody = $('.modal-body');
            var currentElement = $(searchResults[currentSearchIndex]);
            modalBody.animate({
                scrollTop: currentElement.offset().top - modalBody.offset().top + modalBody.scrollTop(),
                scrollLeft: currentElement.offset().left - modalBody.offset().left + modalBody.scrollLeft()
            }, 200);
        }
    }

    // Event handler for input event on search input
    $('#searchInput').on('input', function () {
        var searchText = $(this).val();
        highlightAllMatches(searchText);
    });

    // Event handler for previous search button click
    $('#prevSearch').click(function() {
        if (searchResults.length) {
            $(searchResults[currentSearchIndex]).removeClass('current');
            currentSearchIndex = (currentSearchIndex - 1 + searchResults.length) % searchResults.length;
            $(searchResults[currentSearchIndex]).addClass('current');
            scrollToCurrent();
            updateSearchStats();
        }
    });

    // Event handler for next search button click
    $('#nextSearch').click(function() {
        if (searchResults.length) {
            $(searchResults[currentSearchIndex]).removeClass('current');
            currentSearchIndex = (currentSearchIndex + 1) % searchResults.length;
            $(searchResults[currentSearchIndex]).addClass('current');
            scrollToCurrent();
            updateSearchStats();
        }
    });

    // Initialize Tagify on the transactionIds input
    var input = document.querySelector('#transactionIds');
    var tagify = new Tagify(input);

    // Event handler for form submission to fetch bulk transaction data
    $('#fetchBulkTxnForm').submit(function (event) {
        event.preventDefault(); // Prevent the default form submit

        var transactionIds = tagify.value.map(tag => tag.value); // Get all transaction IDs as an array
        var tenantId = $('#tenantId').val();

        console.log("Transaction IDs:", transactionIds);
        console.log("Tenant ID:", tenantId);

        // Perform AJAX request to fetch data
        $.ajax({
            type: 'GET',
            url: '/api/fetch/bulk/txnData',
            traditional: true, // Ensures array data is sent correctly
            data: {
                transactionIds: transactionIds.join(','), // Convert array to comma-separated string
                tenantId: tenantId
            },
            success: function (response) {
                console.log("API Response:", response);
                var resultHtml = '';

                if (response.status === 200 || response.status === 206) { // Handle partial success
                    resultHtml += '<div class="alert alert-success">';
                    resultHtml += '<p>' + response.message + '</p>';

                    resultHtml += '<table class="table table-striped">';
                    resultHtml += '<thead><tr><th>Transaction ID</th><th>Tenant ID</th><th>Data</th><th>Actions</th></thead><tbody>';

                    var txnResults = response.result;

                    if (txnResults && txnResults.length > 0) {
                        txnResults.forEach(function (txnResult, index) {
                            var jsonDataStr = JSON.stringify(txnResult.data, null, 2);
                            resultHtml += '<tr>';
                            resultHtml += '<td>' + txnResult.transactionId + '</td>';
                            resultHtml += '<td>' + txnResult.tenantId + '</td>';
                            resultHtml += '<td><div class="json-viewer" id="json-renderer-' + txnResult.transactionId + '"></div></td>';
                            resultHtml += '<td>';
                            resultHtml += '<button class="btn btn-info btn-sm view-json-btn" data-json="' + encodeURIComponent(jsonDataStr) + '">View</button>';
                            resultHtml += '</td>';
                            resultHtml += '</tr>';
                        });
                    } else {
                        resultHtml += '<tr><td colspan="4">No data found</td></tr>';
                    }

                    resultHtml += '</tbody></table></div>';
                } else {
                    resultHtml += '<div class="alert alert-danger">';
                    resultHtml += '<p>' + response.message + '</p>';
                    resultHtml += '</div>';
                }

                $('#resultSection').html(resultHtml); // Update the result section

                // Use JSON Viewer plugin to display JSON data with the top node collapsed
                txnResults.forEach(function (txnResult) {
                    $('#json-renderer-' + txnResult.transactionId).jsonViewer(txnResult.data, { collapsed: true });
                });

                // Attach event listener to the view buttons
                $('.view-json-btn').click(function () {
                    var jsonDataStr = decodeURIComponent($(this).data('json'));
                    $('#jsonContent').text(jsonDataStr);
                    $('#jsonModal').modal('show');
                });
            },
            error: function (error) {
                console.error('Error fetching data:', error);
                var errorHtml = '<div class="alert alert-danger">';
                errorHtml += '<p>Unexpected error occurred while fetching data.</p>';
                errorHtml += '<p>' + error.responseText + '</p>';
                errorHtml += '</div>';

                $('#resultSection').html(errorHtml); // Update the result section with error
            }
        });
    });


 // Copy to clipboard function
 async function copyToClipboard(textToCopy) {
    // Navigator clipboard API needs a secure context (HTTPS)
    if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(textToCopy);
    } else {
        // Use the 'out of viewport hidden text area' trick
        const textArea = document.createElement("textarea");
        textArea.value = textToCopy;

        // Move the textarea out of the viewport so it's not visible
        textArea.style.position = "absolute";
        textArea.style.left = "-999999px";

        document.body.prepend(textArea);
        textArea.select();

        try {
            document.execCommand('copy');
        } catch (error) {
            console.error(error);
        } finally {
            textArea.remove();
        }
    }
}



// Handles click event for copying JSON content to clipboard
$('#copyJsonButton').click(async function () {
 var jsonContent = $('#jsonContent').text();
 try {
     await copyToClipboard(jsonContent);
     alert('Copied to clipboard');
 } catch (err) {
     console.error('Error copying data to clipboard: ', err);
 }
});
});
