package com.nsl.novus.txnstore.repository;

import com.datastax.oss.driver.api.core.DriverException;
import com.nsl.novus.txnstore.dto.TxnResult;
import com.nsl.novus.txnstore.exceptions.DataNotFoundException;
import org.springframework.dao.DataAccessException;

import java.util.List;
import java.util.Map;

/**
 * Repository interface to define methods for interacting with ScyllaDB.
 */
public interface ScyllaDBRepository {
    TxnResult fetchTransactionData(final String transactionId, final String tenantId) throws DriverException, DataAccessException,DataNotFoundException;
    TxnResult fetchTxnData(final String transactionId,final String tenantId) throws DriverException, DataAccessException,DataNotFoundException;
    Map<String, Object> fetchBulkTxnData(final List<String> transactionIds, final String tenantId) throws DriverException, DataAccessException,DataNotFoundException;
    Map<String, Object>  fetchBulkTransactionData(final List<String> transactionIds,final String tenantId) throws DriverException, DataAccessException ,DataNotFoundException;
}
