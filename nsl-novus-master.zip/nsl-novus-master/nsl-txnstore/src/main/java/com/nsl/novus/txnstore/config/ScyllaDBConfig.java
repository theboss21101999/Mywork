package com.nsl.novus.txnstore.config;

import com.datastax.oss.driver.api.core.CqlSession;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.InetSocketAddress;

/**
 * Configuration class for ScyllaDB connection.
 * This class is responsible for setting up the connection to ScyllaDB using the CqlSession.
 * These values are injected from the application.properties using @Value.
 */
@Configuration
public class ScyllaDBConfig {

    /**
     * The contact point (hostname or IP address) of the ScyllaDB instance.
     */
    @Value("${scylladb.contactPoint}")
    private String contactPoint;

    /**
     * The port number on which ScyllaDB is listening.
     */
    @Value("${scylladb.port}")
    private int port;

    /**
     * The local datacenter name for the ScyllaDB cluster.
     */
    @Value("${scylladb.localDatacenter}")
    private String localDatacenter;

    /**
     * The keyspace to connect to within the ScyllaDB cluster.
     */
    @Value("${scylladb.keyspace}")
    private String keyspace;

    /**
     * The CqlSession instance used to interact with ScyllaDB.
     */
    private CqlSession cqlSession;

    /**
     * Creates and initializes a CqlSession instance.
     * @return the initialized CqlSession.
     */
    @Bean
    public CqlSession cqlSession() {
        this.cqlSession = CqlSession.builder()
                .addContactPoint(new InetSocketAddress(contactPoint, port))
                .withLocalDatacenter(localDatacenter)
                .withKeyspace(keyspace)
                .build();
        return cqlSession;
    }

    /**
     * Closes the CqlSession when the Spring application context is being destroyed.
     */
    @PreDestroy
    public void close() {
        if (cqlSession != null) {
            cqlSession.close();
        }
    }
}
