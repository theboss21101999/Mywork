package com.nsl.novus.txnstore.service;

import com.datastax.oss.driver.api.core.DriverException;
import com.nsl.novus.txnstore.dto.TxnResult;
import com.nsl.novus.txnstore.exceptions.DataNotFoundException;
import org.springframework.dao.DataAccessException;

import java.util.List;
import java.util.Map;

/**
 * Service interface for ScyllaDB operations.
 */
public interface ScyllaDBService {

    TxnResult getTransactionData(final String transactionId, final String tenantId) throws DriverException, DataAccessException, DataNotFoundException;
    TxnResult getTxnData(final String transactionId, final String tenantId) throws DriverException, DataAccessException,DataNotFoundException;
    Map<String, Object> getBulkTxnData(final List<String> transactionIds, final String tenantId) throws DriverException, DataAccessException,DataNotFoundException;
    Map<String, Object>  getBulkTransactionData(final List<String> transactionIds,final String tenantId) throws DriverException, DataAccessException,DataNotFoundException;
}
