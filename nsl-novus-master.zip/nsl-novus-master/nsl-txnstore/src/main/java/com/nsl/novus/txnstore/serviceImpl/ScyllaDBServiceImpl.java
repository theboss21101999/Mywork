package com.nsl.novus.txnstore.serviceImpl;

import com.datastax.oss.driver.api.core.DriverException;
import com.nsl.novus.txnstore.dto.TxnResult;
import com.nsl.novus.txnstore.exceptions.DataNotFoundException;
import com.nsl.novus.txnstore.repository.ScyllaDBRepository;
import com.nsl.novus.txnstore.service.ScyllaDBService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Implementation of ScyllaDBService.
 * This class provides service methods to fetch transaction data from ScyllaDB using repository.
 */
@Service
public class ScyllaDBServiceImpl implements ScyllaDBService {
    @Autowired
    private ScyllaDBRepository scyllaDBRepository;

/**
 * Fetches transaction data from ScyllaDB for the specified transaction ID and tenant ID.
 */
    @Override
    public TxnResult getTransactionData(final String transactionId, final String tenantId) throws DriverException, DataAccessException,DataNotFoundException {
        return scyllaDBRepository.fetchTransactionData(transactionId, tenantId);
    }

/**
 * Fetches txn data from ScyllaDB for the specified transaction ID and tenant ID.
 */
    @Override
    public TxnResult getTxnData(final String transactionId,final String tenantId) throws DriverException, DataAccessException,DataNotFoundException {
        return scyllaDBRepository.fetchTxnData(transactionId, tenantId);
    }

/**
 * Fetches bulk txn datas from ScyllaDB for all the specified transaction IDs and tenant ID.
 */
    @Override
    public Map<String, Object> getBulkTxnData(final List<String> transactionIds, final String tenantId) throws DriverException, DataAccessException,DataNotFoundException {
        return scyllaDBRepository.fetchBulkTxnData(transactionIds, tenantId);
    }

    /**
     * Fetches bulk transaction datas from ScyllaDB for all the specified transaction IDs and tenant ID.
     */
    @Override
    public Map<String, Object>  getBulkTransactionData(final List<String> transactionIds,final String tenantId) throws DriverException, DataAccessException, DataNotFoundException {
        return scyllaDBRepository.fetchBulkTransactionData(transactionIds, tenantId);
    }
}
