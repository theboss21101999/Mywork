package com.nsl.novus.txnstore.repository.Impl;

import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.DriverException;
import com.datastax.oss.driver.api.core.cql.BoundStatement;
import com.datastax.oss.driver.api.core.cql.PreparedStatement;
import com.datastax.oss.driver.api.core.cql.ResultSet;
import com.datastax.oss.driver.api.core.cql.Row;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.novus.txnstore.dto.TxnResult;
import com.nsl.novus.txnstore.exceptions.DataNotFoundException;
import com.nsl.novus.txnstore.repository.ScyllaDBRepository;
import jakarta.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * Implementation of ScyllaDBRepositoryImpl.
 * This class contains the logic to interact with the ScyllaDB and fetch the required data.
 */
@Repository
public class ScyllaDBRepositoryImpl implements ScyllaDBRepository {

    private static final Logger log = LoggerFactory.getLogger(ScyllaDBRepositoryImpl.class);
    ObjectMapper objectMapper = new ObjectMapper();
    @Autowired
    private CqlSession cqlSession;

    @Value("${scylladb.keyspace}")
    private String keyspace;

    private PreparedStatement fetchTransactionStmt;
    private PreparedStatement fetchTxnDataStmt;

    @PostConstruct
    public void init() {
        fetchTransactionStmt = cqlSession.prepare(
                "SELECT data FROM " + keyspace + ".nsl_transaction WHERE id = ? AND tenant_id = ? ALLOW FILTERING"
        );
        fetchTxnDataStmt = cqlSession.prepare(
                "SELECT data FROM " + keyspace + ".nsl_txn_data WHERE trans_id = ? AND tenant_id = ? ALLOW FILTERING"
        );
    }
    /**
     * Fetches transaction data from the 'nsl_transaction' table.
     *
     * @param transactionId the ID of the transaction.
     * @param tenantId      the ID of the tenant.
     * @return the TxnResult consisting of transactionId, tenantId, and the data.
     * @throws DataNotFoundException if no data found for the specified transactionId and tenantId.
     * @throws DriverException       if an error occurs with the ScyllaDB driver.
     * @throws DataAccessException  if an error occurs accessing data.
     */
    @Override
    public TxnResult fetchTransactionData(final String transactionId, final String tenantId) throws DriverException, DataAccessException,DataNotFoundException {
        try {
            BoundStatement boundStatement = fetchTransactionStmt.bind(transactionId, tenantId);
            ResultSet resultSet = cqlSession.execute(boundStatement);
            Row row = resultSet.one();
            if (row != null) {
                String data = row.getString("data");
                JsonNode jsonNode = objectMapper.readTree(data);
                return new TxnResult(tenantId, transactionId, jsonNode);
            } else {
                log.warn("No data found for transaction id {} and tenant id {} in nsl_transaction", transactionId, tenantId);
                throw new DataNotFoundException("No data found for transaction id " + transactionId + " and tenant id " + tenantId + " in nsl_transaction");
            }
        } catch (DataNotFoundException e){
            throw e;
        } catch (DriverException e) {
            log.error("DriverException while fetching the data for transaction id {} and tenant id {} in nsl_transaction. Message: {}",
                    transactionId, tenantId, e.getMessage(), e);
            throw e;
        } catch (DataAccessException e) {
            log.error("DataAccessException while fetching the data for transaction id {} and tenant id {} in nsl_transaction: {}",
                    transactionId, tenantId, e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected exception while fetching the data for transaction id {} and tenant id {} in nsl_transaction: {}",
                    transactionId, tenantId, e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Fetches txn data from the 'nsl_txn_data' table.
     *
     * @param transactionId the ID of the transaction.
     * @param tenantId      the ID of the tenant.
     * @return the TxnResult consisting of transactionId, tenantId, and data.
     * @throws DataNotFoundException if no data found for the specified transactionId and tenantId.
     * @throws DriverException       if an error occurs with the ScyllaDB driver.
     * @throws DataAccessException  if an error occurs accessing data.
     */
    @Override
    public TxnResult fetchTxnData(final String transactionId, final String tenantId) throws DriverException, DataAccessException,DataNotFoundException {
        try {
            BoundStatement boundStatement = fetchTxnDataStmt.bind(transactionId, tenantId);
            ResultSet resultSet = cqlSession.execute(boundStatement);
            Row row = resultSet.one();
            if (row != null) {
                String data = row.getString("data");
                JsonNode jsonNode = objectMapper.readTree(data);
                return new TxnResult(tenantId, transactionId, jsonNode);
            } else {
                log.warn("No data found for transaction id {} and tenant id {} in nsl_txn_data", transactionId, tenantId);
                throw new DataNotFoundException("No data found for transaction id " + transactionId + " and tenant id " + tenantId + " in nsl_txn_data");
            }
        } catch (DataNotFoundException e){
            throw e;
        } catch (DriverException e) {
            log.error("DriverException while fetching the data for transaction id {} and tenant id {} in nsl_txn_data. Message: {}",
                    transactionId, tenantId, e.getMessage(), e);
            throw e;
        } catch (DataAccessException e) {
            log.error("DataAccessException while fetching the data for transaction id {} and tenant id {} in nsl_txn_data: {}",
                    transactionId, tenantId, e.getMessage(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected exception while fetching the data for transaction id {} and tenant id {} in nsl_txn_data: {}",
                    transactionId, tenantId, e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Fetches bulk txn data payloads from the 'nsl_txn_data' table .
     *
     * @param transactionIds the list of transaction IDs.
     * @param tenantId       the ID of the tenant.
     * @return a map containing found transactions, not found transactions, and their respective TxnResult.
     * @throws DriverException       if an error occurs with the ScyllaDB driver.
     * @throws DataAccessException  if an error occurs accessing data.
     * @throws DataNotFoundException if no data found for any of the transactionIds.
     */
    @Override
    public Map<String, Object> fetchBulkTxnData(final List<String> transactionIds, final String tenantId) throws DriverException, DataAccessException, DataNotFoundException {
        List<TxnResult> txnResults = new ArrayList<>();
        List<String> foundIds = new ArrayList<>();
        List<String> notFoundIds = new ArrayList<>();
        Set<String> uniqueTransactionIds = new HashSet<>(transactionIds);

        try {
            for (String transactionId : uniqueTransactionIds) {
                try {
                    TxnResult result = fetchTxnData(transactionId, tenantId);
                    txnResults.add(result);
                    foundIds.add(transactionId);
                } catch (DataNotFoundException e) {
                    notFoundIds.add(transactionId);
                } catch (DriverException | DataAccessException e) {
                    throw e;
                } catch (Exception e) {
                    throw new RuntimeException(e) ;
                }
            }

            if (txnResults.isEmpty()) {
                log.warn("No data found for all transaction IDs : {} in bulk fetch",notFoundIds);
                throw new DataNotFoundException("No data found for all transaction IDs in bulk fetch");
            }

            if (!notFoundIds.isEmpty()) {
                log.warn("Partial data found for transaction IDs: {}. Data not found for: {}", foundIds, notFoundIds);
            }

            Map<String, Object> response = new HashMap<>();
            response.put("txnResults", txnResults);
            response.put("foundIds", foundIds);
            response.put("notFoundIds", notFoundIds);
            return response;
        } catch (DataNotFoundException | DriverException | DataAccessException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e) ;
        }
    }


    /**
     * Fetches bulk transaction data from the 'nsl_transaction' table .
     *
     * @param transactionIds the list of transaction IDs.
     * @param tenantId       the ID of the tenant.
     * @return a map containing found transactions, not found transactions, and their respective TxnResult.
     * @throws DataNotFoundException if no data found for any of the transactionIds.
     * @throws DriverException       if an error occurs with the ScyllaDB driver.
     * @throws DataAccessException  if an error occurs accessing data.
     */
    @Override
    public Map<String, Object> fetchBulkTransactionData(final List<String> transactionIds, final String tenantId) throws DriverException, DataAccessException, DataNotFoundException {
        List<TxnResult> txnResults = new ArrayList<>();
        List<String> foundIds = new ArrayList<>();
        List<String> notFoundIds = new ArrayList<>();
        Set<String> uniqueTransactionIds = new HashSet<>(transactionIds);

        try {
            for (String transactionId : uniqueTransactionIds) {
                try {
                    TxnResult result = fetchTransactionData(transactionId, tenantId);
                    txnResults.add(result);
                    foundIds.add(transactionId);
                } catch (DataNotFoundException e) {
                    notFoundIds.add(transactionId);
                } catch (DriverException | DataAccessException e) {
                    throw e;
                } catch (Exception e) {
                    throw new RuntimeException(e) ;
                }
            }

            if (txnResults.isEmpty()) {
                log.warn("No data found for all transaction IDs : {} in bulk fetch",notFoundIds);
                throw new DataNotFoundException("No data found for all transaction IDs in bulk fetch");
            }

            if (!notFoundIds.isEmpty()) {
                log.warn("Partial data found for transaction IDs: {}. Data not found for: {}", foundIds, notFoundIds);
            }

            Map<String, Object> response = new HashMap<>();
            response.put("txnResults", txnResults);
            response.put("foundIds", foundIds);
            response.put("notFoundIds", notFoundIds);
            return response;
        } catch (DataNotFoundException | DriverException | DataAccessException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException(e) ;
        }
    }
}

