package com.nsl.novus.txnstore.health;

import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.metadata.EndPoint;
import com.datastax.oss.driver.api.core.metadata.Metadata;
import com.datastax.oss.driver.api.core.metadata.Node;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

import java.net.InetSocketAddress;

/**
 * Custom HealthIndicator implementation to check the health of the ScyllaDB connection.
 */
@Component
public class ScyllaDBHealthIndicator implements HealthIndicator {

    @Autowired
    private CqlSession cqlSession;

    /**
     * Checks the health of the ScyllaDB connection by performing a simple query and extracting metadata.
     *
     * @return a Health object representing the status of the ScyllaDB connection.
     */
    @Override
    public Health health() {
        try {
            // Perform a simple query to check the connection
            cqlSession.execute("SELECT now() FROM system.local");

            // Get metadata from the session
            Metadata metadata = cqlSession.getMetadata();
            Node node = metadata.getNodes().values().iterator().next();

            // Extract details
            EndPoint endPoint = node.getEndPoint();
            InetSocketAddress socketAddress = (InetSocketAddress) endPoint.resolve();
            String host = socketAddress.getHostString();
            int port = socketAddress.getPort();
            String datacenter = node.getDatacenter();
            String rack = node.getRack();

            return Health.up()
                    .withDetail("ScyllaDB", "Available")
                    .withDetail("Host", host)
                    .withDetail("Port", port)
                    .withDetail("Datacenter", datacenter)
                    .withDetail("Rack", rack)
                    .build();
        } catch (Exception e) {
            // If an exception occurs, mark the ScyllaDB as down and provide details about the exception.
            return Health.down().withDetail("ScyllaDB", "Not Available").withException(e).build();
        }
    }
}
