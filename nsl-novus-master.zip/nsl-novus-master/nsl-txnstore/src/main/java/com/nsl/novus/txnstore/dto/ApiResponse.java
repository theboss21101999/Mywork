package com.nsl.novus.txnstore.dto;

/**
 * DTO class representing the API response structure.
 * This class encapsulates the HTTP status, a message, and the result data.
 */
public class ApiResponse {

    // HTTP status code of the response.
    private int status;

    // Message accompanying the response, used for errors or status description.
    private String message;

    // The actual result or data being fetched from scylladb.
    private Object result;

    public ApiResponse() {}

    public ApiResponse(Integer status, String message, Object result) {
        super();
        this.status = status;
        this.message = message;
        this.result = result;
    }

    public ApiResponse(Integer status, String message) {
        this.status = status;
        this.message = message;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

    @Override
    public String toString() {
        return "ApiResponse [statusCode=" + status + ", message=" + message + "]";
    }

}
