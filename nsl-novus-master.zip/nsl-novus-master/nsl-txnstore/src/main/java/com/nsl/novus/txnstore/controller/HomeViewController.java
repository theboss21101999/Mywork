package com.nsl.novus.txnstore.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeViewController {

    @Operation(summary = "Home Page", description = "Displays the home page.")
    @GetMapping("/home")
    public String home() {
        return "home";
    }

    @Operation(summary = "Fetch Transaction Data Page", description = "Displays the page for fetching transaction data for a single Transaction ID and Tenant ID.")
    @GetMapping("/ui/fetch/transactionData")
    public String fetchTransactionData() {
        return "fetchTransactionData";
    }

    @Operation(summary = "Fetch Txn Data Page", description = "Displays the page for fetching txn data payload for a single Transaction ID and Tenant ID.")
    @GetMapping("/ui/fetch/txnData")
    public String fetchTxnData() {
        return "fetchTxnData";
    }

    @Operation(summary = "Fetch Bulk Txn Data Page", description = "Displays the page for fetching bulk txn data payloads for multiple Transaction IDs and specific Tenant ID.")
    @GetMapping("/ui/fetch/bulk/txnData")
    public String fetchBulkTxnData() {
        return "fetchBulkTxnData";
    }

    @Operation(summary = "Fetch Bulk Transaction Data Page", description = "Displays the page for fetching bulk transaction data for multiple Transaction IDs and specific Tenant ID.")
    @GetMapping("/ui/fetch/bulk/transactionData")
    public String fetchBulkTransactionData() {
        return "fetchBulkTransactionData";
    }

    @Operation(summary = "redoc Page", description = "Displays the redoc API documentation.")
    @GetMapping("/redoc")
    public String redoc() {
        return "redoc";
    }
}
