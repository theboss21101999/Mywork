package com.nsl.novus.txnstore.dto;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * DTO Represents the result of the data payload retrieved along with respective transactionId, tenantId.
 */
public class TxnResult {
    private String tenantId;
    private String transactionId;
    private JsonNode data;

    public TxnResult(){
    }

    public TxnResult(String tenantId, String transactionId, JsonNode data) {
        this.tenantId = tenantId;
        this.transactionId = transactionId;
        this.data = data;
    }

    public String getTenantId() {
        return tenantId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public JsonNode getData() {
        return data;
    }
}
