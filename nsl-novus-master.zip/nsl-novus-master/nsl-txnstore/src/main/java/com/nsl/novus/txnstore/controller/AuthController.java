package com.nsl.novus.txnstore.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AuthController {

    @Operation(summary = "Login Page", description = "Displays the login page.")
    @GetMapping("/login")
    public String getLoginPage(){
        return "login";
    }

    @GetMapping("/")
    public String loginPage() {
        return "login";
    }
}
