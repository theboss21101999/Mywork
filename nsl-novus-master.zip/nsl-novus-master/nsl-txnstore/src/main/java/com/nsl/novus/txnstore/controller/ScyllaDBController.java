package com.nsl.novus.txnstore.controller;

import com.datastax.oss.driver.api.core.DriverException;
import com.nsl.novus.txnstore.dto.ApiResponse;
import com.nsl.novus.txnstore.dto.TxnResult;
import com.nsl.novus.txnstore.exceptions.DataNotFoundException;
import com.nsl.novus.txnstore.service.ScyllaDBService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * REST controller for handling ScyllaDB related requests.
 */
@RestController
@RequestMapping("/api")
public class ScyllaDBController {


    @Autowired
    private ScyllaDBService scyllaDBService;

    /**
     * Retrieves transaction data payload from the 'nsl_transaction' table .
     *
     * @param transactionId the ID of the transaction.
     * @param tenantId the ID of the tenant.
     * @return a ResponseEntity containing ApiResponse with the transaction data or error information.
     */
    @Operation(summary = "Retrieve transaction data", description = "Retrieves transaction data payload from the 'nsl_transaction' table for a single Transaction ID and Tenant ID in scylladb.")
    @GetMapping("/fetch/transactionData")
    public ResponseEntity<ApiResponse> getTransactionData(@RequestParam String transactionId, @RequestParam String tenantId) {
        try {
                // Fetch transaction data using the service.
                TxnResult result = scyllaDBService.getTransactionData(transactionId, tenantId);
                ApiResponse response = new ApiResponse(HttpStatus.OK.value(), "Transaction data fetched successfully", result);
                return new ResponseEntity<>(response, HttpStatus.OK);
        }catch (DataNotFoundException e) {
                // Handle case where data is not found .
                ApiResponse response = new ApiResponse(HttpStatus.NOT_FOUND.value(), e.getMessage());
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (DriverException | DataAccessException e) {
            ApiResponse response = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Error fetching transaction data", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            ApiResponse response = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Unexpected error", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Retrieves txn data payload from the 'nsl_txn_data' table .
     *
     * @param transactionId the ID of the transaction.
     * @param tenantId the ID of the tenant.
     * @return a ResponseEntity containing ApiResponse with the transaction data or error information.
     */
    @Operation(summary = "Retrieve txn data", description = "Retrieves txn data payload from the 'nsl_txn_data' table for a single Transaction ID and Tenant ID in scylladb.")
    @GetMapping("/fetch/txnData")
    public ResponseEntity<ApiResponse> getTxnData(@RequestParam String transactionId, @RequestParam String tenantId) {
        try {
                // Fetch txn data using the service.
                TxnResult result = scyllaDBService.getTxnData(transactionId, tenantId);
                ApiResponse response = new ApiResponse(HttpStatus.OK.value(), "Txn data fetched successfully", result);
                return new ResponseEntity<>(response, HttpStatus.OK);
        }catch (DataNotFoundException e) {
                // Handle case where data is not found .
                ApiResponse response = new ApiResponse(HttpStatus.NOT_FOUND.value(), e.getMessage());
                return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch (DriverException | DataAccessException e) {
            ApiResponse response = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Error fetching txn data", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            ApiResponse response = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "Unexpected error", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Retrieves bulk txn data payloads from the 'nsl_txn_data' table.
     *
     * @param transactionIds the list of transaction IDs.
     * @param tenantId the ID of the tenant.
     * @return a ResponseEntity containing ApiResponse with the bulk txn data or error information.
     */
    @Operation(summary = "Retrieve bulk txn datas", description = "Retrieves bulk txn data payloads from the 'nsl_txn_data' table for multiple Transaction IDs and specific Tenant ID in scylladb.")
    @GetMapping("/fetch/bulk/txnData")
    public ResponseEntity<ApiResponse> getBulkTxnData(@RequestParam List<String> transactionIds, @RequestParam String tenantId) {
        List<TxnResult> results = new ArrayList<>();
        List<String> foundIds = new ArrayList<>();
        List<String> notFoundIds = new ArrayList<>();

        try {
            Map<String, Object> bulkTxnData = scyllaDBService.getBulkTxnData(transactionIds, tenantId);

            @SuppressWarnings("unchecked")
            List<TxnResult> txnResults = (List<TxnResult>) bulkTxnData.get("txnResults");
            @SuppressWarnings("unchecked")
            List<String> found = (List<String>) bulkTxnData.get("foundIds");
            @SuppressWarnings("unchecked")
            List<String> notFound = (List<String>) bulkTxnData.get("notFoundIds");

            if (txnResults != null) {
                results.addAll(txnResults);
            }
            if (found != null) {
                foundIds.addAll(found);
            }
            if (notFound != null) {
                notFoundIds.addAll(notFound);
            }

            // Construct response message based on found and not found IDs.
            String message = "Partial success. Data not found for transaction IDs: " + String.join(", ", notFoundIds);
            if (!notFoundIds.isEmpty()) {
                message += ". Data found for transaction IDs: " + String.join(", ", foundIds);
                return new ResponseEntity<>(new ApiResponse(HttpStatus.PARTIAL_CONTENT.value(), message, results), HttpStatus.PARTIAL_CONTENT);
            }

            message = "Bulk txn datas fetched successfully for all transactionIds";
            return new ResponseEntity<>(new ApiResponse(HttpStatus.OK.value(), message, results), HttpStatus.OK);
        } catch (DataNotFoundException e) {
            String message = "Data not found for all transaction IDs: " + String.join(", ", transactionIds);
            return new ResponseEntity<>(new ApiResponse(HttpStatus.NOT_FOUND.value(), message), HttpStatus.NOT_FOUND);
        } catch (DataAccessException e) {
            ApiResponse response = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "DataAccessException occurred while fetching bulk txn datas");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (DriverException e) {
            ApiResponse response = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "DriverException  occurred while fetching bulk txn datas");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            ApiResponse response = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "An unexpected exception occurred while fetching bulk txn datas");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    /**
     * Retrieves bulk transaction data payloads from the 'nsl_transaction' table.
     *
     * @param transactionIds the list of transaction IDs.
     * @param tenantId the ID of the tenant.
     * @return a ResponseEntity containing ApiResponse with the bulk transaction data or error information.
     */
    @Operation(summary = "Retrieve bulk transaction datas", description = "Retrieves bulk transaction data payloads from the 'nsl_transaction' table for multiple Transaction IDs and specific Tenant ID in scylladb.")
    @GetMapping("/fetch/bulk/transactionData")
    public ResponseEntity<ApiResponse> getBulkTransactionData(@RequestParam List<String> transactionIds, @RequestParam String tenantId) {
        List<TxnResult> results = new ArrayList<>();
        List<String> foundIds = new ArrayList<>();
        List<String> notFoundIds = new ArrayList<>();

        try {
            Map<String, Object> bulkTransactionData = scyllaDBService.getBulkTransactionData(transactionIds, tenantId);

            @SuppressWarnings("unchecked")
            List<TxnResult> txnResults = (List<TxnResult>) bulkTransactionData.get("txnResults");
            @SuppressWarnings("unchecked")
            List<String> found = (List<String>) bulkTransactionData.get("foundIds");
            @SuppressWarnings("unchecked")
            List<String> notFound = (List<String>) bulkTransactionData.get("notFoundIds");

            if (txnResults != null) {
                results.addAll(txnResults);
            }
            if (found != null) {
                foundIds.addAll(found);
            }
            if (notFound != null) {
                notFoundIds.addAll(notFound);
            }

            // Construct response message based on found and not found IDs.
            String message = "Partial success. Data not found for transaction IDs: " + String.join(", ", notFoundIds);
            if (!notFoundIds.isEmpty()) {
                message += ". Data found for transaction IDs: " + String.join(", ", foundIds);
                return new ResponseEntity<>(new ApiResponse(HttpStatus.PARTIAL_CONTENT.value(), message, results), HttpStatus.PARTIAL_CONTENT);
            }

            message = "Bulk transaction datas fetched successfully for all transactionIds";
            return new ResponseEntity<>(new ApiResponse(HttpStatus.OK.value(), message, results), HttpStatus.OK);
        } catch (DataNotFoundException e) {
            String message = "Data not found for all transaction IDs: " + String.join(", ", transactionIds);
            return new ResponseEntity<>(new ApiResponse(HttpStatus.NOT_FOUND.value(), message), HttpStatus.NOT_FOUND);
        } catch (DataAccessException e) {
            ApiResponse response = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "DataAccessException occurred while fetching bulk transaction datas");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (DriverException e) {
            ApiResponse response = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "DriverException  occurred while fetching bulk transaction datas");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            ApiResponse response = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), "An unexpected exception occurred while fetching bulk transaction datas");
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


}
