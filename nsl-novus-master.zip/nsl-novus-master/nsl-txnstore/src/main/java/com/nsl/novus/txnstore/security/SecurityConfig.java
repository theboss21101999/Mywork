package com.nsl.novus.txnstore.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

/**
 * Security configuration class for setting up Spring Security.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Value(value = "${app.username}")
    private String name;

    @Value(value = "${app.password}")
    private String pwd;

    @Value(value = "${app.security.enabled}")
    private boolean securityEnabled;

    /**
     * In-memory user details manager.
     * Creates an in-memory user with the provided username, password, and role.
     *
     * @return an instance of InMemoryUserDetailsManager.
     */
    @Bean
    public InMemoryUserDetailsManager userDetailsService() {
        UserDetails user = User.builder()
                .username(name)
                .password(encoder().encode(pwd))
                .roles("ADMIN")
                .build();
        return new InMemoryUserDetailsManager(user);
    }

    /**
     * Password encoder.
     * Uses BCrypt algorithm for encoding passwords.
     *
     * @return an instance of BCryptPasswordEncoder.
     */
    @Bean
    public PasswordEncoder encoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Configures the security filter chain.
     *
     * @param http the HttpSecurity instance to configure.
     * @return the configured SecurityFilterChain instance.
     * @throws Exception if any error occurs during configuration.
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        if (securityEnabled) {
            // Permit access to these endpoints without authentication
            http.authorizeHttpRequests(auth -> auth
                            .requestMatchers("/login", "/redoc", "/v3/api-docs/**", "/swagger-ui/index.html", "/swagger-ui/**","/actuator/**").permitAll()
                            .requestMatchers("/resources/**", "/static/**").permitAll()
                            .requestMatchers("/css/**").permitAll()
                            .requestMatchers("/images/**").permitAll()
                            // Require authentication for any other request
                            .anyRequest().authenticated()
                    )
                    // Disable CSRF protection for simplicity
                    .csrf(AbstractHttpConfigurer::disable)
                    // Configure form login
                    .formLogin(form -> form.loginPage("/login")
                            .loginProcessingUrl("/authUser")
                            .defaultSuccessUrl("/home", true)
                            .permitAll()
                    )
                    // Configure logout
                    .logout(logout -> logout.logoutUrl("/logout")
                            .logoutSuccessUrl("/login?logout")
                            .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                            .permitAll()
                    );
            return http.build();
        } else {
            http.httpBasic(Customizer.withDefaults())
                    // Permit all requests when security is disabled
                    .authorizeHttpRequests(authorize ->
                            authorize.requestMatchers("/**").permitAll()
                                    .anyRequest().authenticated()
                    )
                    // Disable CSRF protection for simplicity
                    .csrf(AbstractHttpConfigurer::disable);
            return http.build();
        }
    }

}
