package com.nsl.novus.txnstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NslTxnstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
