package com.nsl.novus.history.service;

import com.mongodb.MongoClient;
import org.bson.Document;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class HistoryServiceTest {
    @Mock
    private MongoClient mongoClient;

    @Mock
    private MongoTemplate mongoTemplate;

    @Mock
    private EntityStoreService esService;

    @InjectMocks
    private HistoryService historyService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetSnapshotsByID() {
        String tenant = "Tenant1";
        String entity = "Entity1";
        String id = "1";
        int pageNumber=1;
        int limit=10;
        List<Document> expectedSnapshots = List.of(new Document("key", "value"));

        when(historyService.getSnapshotsByID(tenant,entity,id,pageNumber,limit)).thenReturn(expectedSnapshots);
        List<Document> actualSnapshots = historyService.getSnapshotsByID(tenant, entity, id, pageNumber, limit);

        Assertions.assertEquals(expectedSnapshots, actualSnapshots);
        verify(mongoTemplate, times(1)).find(any(Query.class), eq(Document.class), eq("jv_snapshots"));
    }

    @Test
    void testGetSnapshotsByType() {
        String tenant = "Tenant1";
        String entity = "Entity1";
        String type = "deleted";
        int pageNumber=1;
        int limit=10;
        List<Document> expectedSnapshots = List.of(new Document("key", "value"));

        when(historyService.getSnapshotsByType(tenant,entity,type, pageNumber, limit)).thenReturn(expectedSnapshots);
        List<Document> actualSnapshots = historyService.getSnapshotsByType(tenant, entity, type, pageNumber, limit);

        Assertions.assertEquals(expectedSnapshots, actualSnapshots);
        verify(mongoTemplate, times(1)).find(any(Query.class), eq(Document.class), eq("jv_snapshots"));
    }

    @Test
    void testGetSnapshotsByDate() {
        String tenant = "Tenant1";
        String entity = "Entity1";
        String date = "2023-03-04";
        int pageNumber=1;
        int limit=10;
        List<Document> expectedSnapshots = List.of(new Document("key", "value"));

        when(historyService.getSnapshotsByDate(tenant,entity,date, pageNumber, limit)).thenReturn(expectedSnapshots);
        List<Document> actualSnapshots = historyService.getSnapshotsByDate(tenant, entity, date, pageNumber, limit);

        Assertions.assertEquals(expectedSnapshots, actualSnapshots);
        verify(mongoTemplate, times(1)).find(any(Query.class), eq(Document.class), eq("jv_snapshots"));
    }

    @Test
    void testGetSnapshotsByVersion() {
        String tenant = "Tenant1";
        String entity = "Entity1";
        String id = "1";
        Long version = 1L;
        int pageNumber=1;
        int limit=10;
        List<Document> expectedSnapshots = List.of(new Document("key", "value"));

        when(historyService.getSnapshotsByVersion(tenant, entity,id,version, pageNumber, limit)).thenReturn(expectedSnapshots);
        List<Document> actualSnapshots = historyService.getSnapshotsByVersion(tenant, entity, id, version, pageNumber, limit);

        Assertions.assertEquals(expectedSnapshots, actualSnapshots);
        verify(mongoTemplate, times(1)).find(any(Query.class), eq(Document.class), eq("jv_snapshots"));
    }

    @Test
    public void testGetSnapshotsByDateRange() {
        String tenant = "Tenant1";
        String entity = "Entity1";
        String startDate = "2023-03-04";
        String endDate = "2023-03-05";
        int pageNumber=1;
        int limit=10;
        List<Document> expectedSnapshots = List.of(new Document("key", "value"));

        when(historyService.getSnapshotsByDateRange(tenant,entity,startDate,endDate, pageNumber, limit)).thenReturn(expectedSnapshots);
        List<Document> actualSnapshots = historyService.getSnapshotsByDateRange(tenant, entity, startDate, endDate, pageNumber, limit);

        Assertions.assertEquals(expectedSnapshots, actualSnapshots);
        verify(mongoTemplate, times(1)).find(any(Query.class), eq(Document.class), eq("jv_snapshots"));
    }

    @Test
    public void testGetSnapshotsCount(){
        String tenant = "Tenant1";
        String entity = "Entity1";
        String type1 = "INITIAL";
        String type2 = "UPDATE";
        String type3 = "TERMINAL";

        Document initialSnapshot = new Document("type", type1);
        Document updateSnapshot = new Document("type", type2);
        Document terminalSnapshot = new Document("type", type3);

        List<Document> snapshots = new ArrayList<>();
        snapshots.add(initialSnapshot);
        snapshots.add(updateSnapshot);
        snapshots.add(terminalSnapshot);

        when(mongoTemplate.find(any(Query.class), eq(Document.class), eq("jv_snapshots"))).thenReturn(snapshots);
        Map<String, Long> countsByType = historyService.getSnapshotsCount(tenant, entity);

        verify(mongoTemplate, times(1)).find(any(Query.class), eq(Document.class), eq("jv_snapshots"));
        verifyNoMoreInteractions(mongoTemplate);

        Assertions.assertEquals(1L, countsByType.get("CREATED"));
        Assertions.assertEquals(1L, countsByType.get("UPDATED"));
        Assertions.assertEquals(1L, countsByType.get("DELETED"));

    }

    @Test
    public void testGetSnapshotsCommitDate(){
        String tenant = "Tenant1";
        String entity = "Entity1";
        String commitDateString = "2024-03-07T06:10:32.492813";

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");
        LocalDateTime expectedCommitDate = LocalDateTime.parse(commitDateString, formatter);

        Document lastSnapshot = new Document("commitMetadata", new Document("commitDate", commitDateString));
        when(esService.getTables(tenant)).thenReturn(Arrays.asList(entity));
        when(mongoTemplate.findOne(any(Query.class), eq(Document.class), eq("jv_snapshots"))).thenReturn(lastSnapshot);

        LocalDateTime actualCommitDate = historyService.getSnapshotsCommitDate(tenant, entity);

        verify(esService, times(1)).getTables(tenant);
        verify(mongoTemplate, times(1)).findOne(any(Query.class), eq(Document.class), eq("jv_snapshots"));
        verifyNoMoreInteractions(esService, mongoTemplate);

        Assertions.assertEquals(expectedCommitDate, actualCommitDate);
    }



}
