package com.nsl.novus.history.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nsl.novus.ApiResponse;
import com.nsl.novus.history.service.EntityStoreService;
import com.nsl.novus.history.service.HistoryService;
import org.bson.Document;
import org.javers.core.metamodel.object.CdoSnapshot;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.*;

public class HistoryControllerTest {
    @Mock
    private HistoryService historyService;

    @Mock
    private EntityStoreService esService;

    @Mock
    private MongoTemplate mongoTemplate;

    @InjectMocks
    private HistoryController historyController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetSnapshots() throws ClassNotFoundException {
        String tenant = "Tenant1";
        String entity = "Entity1";
        String id = "1";
        List<CdoSnapshot> snapshots = new ArrayList<>();
        when(historyService.getSnapshots(tenant, entity, id)).thenReturn(snapshots);

        ApiResponse actualResponse = historyController.getSnapshots(tenant, entity, id);
        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success",
                historyController.createSnapshots(snapshots));

        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode expectedJson = objectMapper.valueToTree(expectedResponse.getResult());
        JsonNode actualJson = objectMapper.valueToTree(actualResponse.getResult());

        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedJson, actualJson);

        verify(historyService, times(1)).getSnapshots(tenant, entity, id);
    }


    @Test
    public void GetSnapshotsByIDTest() {
        List<CdoSnapshot> snapshots = new ArrayList<>();
        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success", snapshots);
        ApiResponse actualResponse = historyController.getSnapshotsByID("tenant", "entity", "newid", 1, 10);
        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedResponse.getResult(), actualResponse.getResult());
    }

    @Test
    void testGetSnapshotsByType() {
        List<CdoSnapshot> snapshots = new ArrayList<>();
        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success", snapshots);
        ApiResponse actualResponse = historyController.getSnapshotsByType("tenant", "entity", "Created", 1, 10);
        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedResponse.getResult(), actualResponse.getResult());
    }


    @Test
    public void testGetSnapshotsByDate() {
        List<CdoSnapshot> snapshots = new ArrayList<>();
        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success", snapshots);
        ApiResponse actualResponse = historyController.getSnapshotsByDate("tenant", "entity", "2024-32-02", 1, 10);
        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedResponse.getResult(), actualResponse.getResult());
    }


    @Test
    public void testGetSnapshotsByVersion() {
        List<CdoSnapshot> snapshots = new ArrayList<>();
        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success", snapshots);
        ApiResponse actualResponse = historyController.getSnapshotsByVersion("tenant", "entity", "newid", 1L, 1, 10);
        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedResponse.getResult(), actualResponse.getResult());
    }



    @Test
    public void getSnapshotsByDateRange(){
        List<CdoSnapshot> snapshots = new ArrayList<>();
        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success", snapshots);
        ApiResponse actualResponse = historyController.getSnapshotsByDateRange("tenant", "entity", "2024-32-02","2024-33-03", 1 , 10);
        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedResponse.getResult(), actualResponse.getResult());
    }

    @Test
    public void testGetSnapshotsCount(){
        Map<String, Long> snapshots = new HashMap<>();
        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success", snapshots);
        ApiResponse actualResponse = historyController.getSnapshotsCount("tenant", "entity");
        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedResponse.getResult(), actualResponse.getResult());
    }

    @Test
    public void testGetSnapshotsByCommitDate(){
        List<CdoSnapshot> snapshots = new ArrayList<>();
        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success", snapshots);
        ApiResponse actualResponse = historyController.getSnapshotsByCommitDate("tenant");
        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedResponse.getResult(), actualResponse.getResult());
    }



}
