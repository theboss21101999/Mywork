package com.nsl.novus.history.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class EntityStoreServiceTest {

    @Mock
    private DataSource dataSource;

    @InjectMocks
    private EntityStoreService entityStoreService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetSchemas() throws SQLException {

        Connection connection = mock(Connection.class);
        DatabaseMetaData metaData = mock(DatabaseMetaData.class);
        ResultSet resultSet = mock(ResultSet.class);

        when(dataSource.getConnection()).thenReturn(connection);
        when(connection.getMetaData()).thenReturn(metaData);
        when(metaData.getCatalogs()).thenReturn(resultSet);
        when(resultSet.next()).thenReturn(true).thenReturn(false);
        when(resultSet.getString("TABLE_CAT")).thenReturn("schema1");

        List<String> expected = Collections.singletonList("schema1");
        List<String> actual = entityStoreService.getSchemas();
        assertEquals(expected, actual);

        verify(connection).close();
        verify(resultSet).close();
    }

    @Test
    public void testGetTables() throws SQLException {
        //TO DO
//        Connection connection = mock(Connection.class);
//        DatabaseMetaData metaData = mock(DatabaseMetaData.class);
//        ResultSet resultSet = mock(ResultSet.class);
//
//        when(dataSource.getConnection()).thenReturn(connection);
//        when(connection.getMetaData()).thenReturn(metaData);
//        when(metaData.getTables(null, null, null, null)).thenReturn(resultSet);
//        when(resultSet.next()).thenReturn(true).thenReturn(false);
//        when(resultSet.getString("TABLE_NAME")).thenReturn("table1");
//
//        Assertions.assertNotNull(resultSet);
//        List<String> expected = Collections.singletonList("table1");
//        List<String> actual = entityStoreService.getTables("schema1");
//        assertEquals(expected, actual);
//
//        verify(connection).close();
//        verify(resultSet).close();
    }

    @Test
    public void testGetEntities() throws SQLException {

        Connection connection = mock(Connection.class);
        DatabaseMetaData metaData = mock(DatabaseMetaData.class);
        ResultSet resultSetPK = mock(ResultSet.class);
        ResultSet resultSetEntity = mock(ResultSet.class);
        Statement statement = mock(Statement.class);

        when(dataSource.getConnection()).thenReturn(connection);
        when(connection.getMetaData()).thenReturn(metaData);
        when(metaData.getPrimaryKeys(null, "schema1", "table1")).thenReturn(resultSetPK);
        when(resultSetPK.next()).thenReturn(true).thenReturn(false);
        when(resultSetPK.getString("COLUMN_NAME")).thenReturn("id");
        when(connection.createStatement()).thenReturn(statement);
        when(statement.executeQuery("SELECT id FROM schema1.table1 ORDER BY id")).thenReturn(resultSetEntity);
        when(resultSetEntity.next()).thenReturn(true).thenReturn(false);
        when(resultSetEntity.getString(1)).thenReturn("1");

        List<String> expected = Collections.singletonList("table1/1");
        List<String> actual = entityStoreService.getEntities("schema1", "table1");
        assertEquals(expected, actual);

        verify(connection).close();
        verify(resultSetPK).close();
        verify(resultSetEntity).close();
        verify(statement).close();
    }
}