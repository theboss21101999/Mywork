package com.nsl.novus.history.controller;


import com.nsl.novus.ApiResponse;
import com.nsl.novus.history.service.EntityStoreService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

public class EntityStoreControllerTest {
    @Mock
    private EntityStoreService entityStoreService;

    @InjectMocks
    private EntityStoreController entityStoreController;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetTenants() {
        List<String> tenants = new ArrayList<>();
        tenants.add("Tenant1");
        tenants.add("Tenant2");
        when(entityStoreService.getSchemas()).thenReturn(tenants);

        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success", tenants);
        ApiResponse actualResponse = entityStoreController.getTenants();

        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedResponse.getResult(), actualResponse.getResult());

        verify(entityStoreService, times(1)).getSchemas();
    }

    @Test
    public void testGetEntitiesByTenant() {
        String tenant = "Tenant1";
        List<String> entities = new ArrayList<>();
        entities.add("Entity1");
        entities.add("Entity2");
        when(entityStoreService.getTables(tenant)).thenReturn(entities);

        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success", entities);
        ApiResponse actualResponse = entityStoreController.getEntities(tenant);

        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedResponse.getResult(), actualResponse.getResult());

        verify(entityStoreService, times(1)).getTables(tenant);
    }

    @Test
    public void testGetEntitiesByEntity() {
        String tenant = "Tenant1";
        String entity = "Entity1";
        List<String> entities = new ArrayList<>();
        entities.add("Entity1");
        entities.add("Entity2");
        when(entityStoreService.getEntities(tenant, entity)).thenReturn(entities);

        ApiResponse expectedResponse = new ApiResponse(HttpStatus.OK, "Success", entities);
        ApiResponse actualResponse = entityStoreController.getEntities(tenant, entity);

        Assertions.assertEquals(expectedResponse.getStatus(), actualResponse.getStatus());
        Assertions.assertEquals(expectedResponse.getMessage(), actualResponse.getMessage());
        Assertions.assertEquals(expectedResponse.getResult(), actualResponse.getResult());

        verify(entityStoreService, times(1)).getEntities(tenant, entity);
    }


}
