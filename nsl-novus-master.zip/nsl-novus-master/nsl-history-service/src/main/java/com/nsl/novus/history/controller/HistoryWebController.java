package com.nsl.novus.history.controller;

import com.nsl.novus.history.model.Tenant;
import com.nsl.novus.history.service.EntityStoreService;
import com.nsl.novus.history.service.HistoryService;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import org.bson.Document;
import org.javers.core.metamodel.object.CdoSnapshot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import static org.codehaus.plexus.util.StringUtils.capitalizeFirstLetter;

@Controller
public class HistoryWebController {
  private static final Logger log = LoggerFactory.getLogger(HistoryWebController.class);

  @Autowired
  private EntityStoreService esService;
  @Autowired
  private HistoryService historyService;

  @Autowired
  private MongoTemplate mongoTemplate;

  @Autowired
  private HistoryController historyController;

  @Value("${generated.class.root.package}")
  private String rootPackage;

  @GetMapping("/")
  public String home() {
    log.info("In historyWebController for home");
    return "home/index";
  }

  @GetMapping("/audit")
  public String auditHome(Model model){
    var tenantList = new ArrayList<Tenant>();
    var tenants = esService.getSchemas();
    tenants.forEach(tenant -> {
      var geList = esService.getTables(tenant);
      tenantList.add(new Tenant(tenant, geList));
    });
    model.addAttribute("tenants", tenantList);

    return "history/index";
  }

  @GetMapping("/entities")
  public String getEntities(@RequestParam("tenant") final String tenant, final Model model, Authentication authentication) {
    boolean auth = authentication != null && authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority).anyMatch("ROLE_SUPER_ADMIN"::equals);
    log.info("In historyWebController for entities");
    var entities = esService.getTables(tenant);
    model.addAttribute("authentication",auth);
    model.addAttribute("tenant", new Tenant(tenant, entities));
    return "history/entities";
  }

  @GetMapping("/entities/{entity}")
  public String entityList(
          @RequestParam("tenant") final String tenant,
          @PathVariable final String entity,
          @RequestParam(value = "type", required = false) String type,
          @RequestParam(value = "date", required = false) String date,
          @RequestParam(value = "pageNumber", defaultValue = "1") int pageNumber,
          @RequestParam(value = "limit", defaultValue = "10") int limit,
          @RequestParam(value = "startDate", required = false) String startDateInput,
          @RequestParam(value = "endDate", required = false) String endDateInput, final Model model)
  {
    if(type!=null)
    {
      var entities = esService.getEntities(tenant, entity);
      String entity1 = capitalizeFirstLetter(entity);
      String globalId=rootPackage+'.'+tenant+'.'+entity1.replace(" ","_")+'/';
      Pattern regexPattern = Pattern.compile("^" + Pattern.quote(rootPackage + '.' + tenant + '.' + entity1.replace(" ","_") + '/') + ".*");
      if(Objects.equals(type, "created"))type="INITIAL";
      else if(Objects.equals(type, "updated"))type="UPDATE";
      else if(Objects.equals(type, "deleted"))type="TERMINAL";
      int offset=(pageNumber-1)*limit;
      List<Document> snapshots = mongoTemplate.find(
              Query.query(Criteria.where("globalId_key").regex(regexPattern).and("type").is(type)).with(Sort.by(Sort.Direction.DESC,"commitMetadata.commitDateInstant")).skip(offset).limit(limit),
              Document.class,
              "jv_snapshots"
      );

      model.addAttribute("globalId",globalId);
      model.addAttribute("tenant", tenant);
      model.addAttribute("entity", entity);
      model.addAttribute("entities", entities);
      model.addAttribute("snapshots",snapshots);
      }
      else if(date!=null){
        var entities = esService.getEntities(tenant, entity);
        String entity1 = capitalizeFirstLetter(entity);
        String globalId=rootPackage+'.'+tenant+'.'+entity1.replace(" ","_")+'/';
        Pattern regexPattern = Pattern.compile("^" + Pattern.quote(rootPackage + '.' + tenant + '.' + entity1.replace(" ","_") + '/') + ".*");
        Pattern pattern = Pattern.compile("^" + Pattern.quote(date) + "T" + ".*");
        int offset = (pageNumber-1)*limit;
        List<Document> snapshots = mongoTemplate.find(
              Query.query(Criteria.where("globalId_key").regex(regexPattern).and("commitMetadata.commitDate").regex(pattern)).with(Sort.by(Sort.Direction.DESC,"commitMetadata.commitDateInstant")).skip(offset).limit(limit),
              Document.class,
              "jv_snapshots"
        );
        model.addAttribute("globalId",globalId);
        model.addAttribute("tenant", tenant);
        model.addAttribute("entity", entity);
        model.addAttribute("entities", entities);
        model.addAttribute("snapshots",snapshots);

      }
      else if(startDateInput!=null && endDateInput!=null){
        var entities = esService.getEntities(tenant, entity);
        String entity1 = capitalizeFirstLetter(entity);
        String globalId=rootPackage+'.'+tenant+'.'+entity1.replace(" ","_")+'/';
        Pattern regexPattern = Pattern.compile("^" + Pattern.quote(rootPackage + '.' + tenant + '.' + entity1.replace(" ","_") + '/') + ".*");

        LocalDate startDate = LocalDate.parse(startDateInput);
        LocalDate endDate = LocalDate.parse(endDateInput);
        endDate = endDate.plusDays(1); //include the full day

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'00:00:00.000'Z'");
        String startDateStr = startDate.format(formatter);
        String endDateStr = endDate.format(formatter);
        Criteria criteria = new Criteria().andOperator(
                Criteria.where("commitMetadata.commitDate").gte(startDateStr).lte(endDateStr),
                Criteria.where("globalId_key").regex(regexPattern)
        );
        int offset = (pageNumber-1)*limit;
        List<Document> snapshots = mongoTemplate.find(
                Query.query(criteria).with(Sort.by(Sort.Direction.DESC,"commitMetadata.commitDateInstant")).skip(offset).limit(limit),
                Document.class,
                "jv_snapshots"
        );

        model.addAttribute("globalId",globalId);
        model.addAttribute("tenant", tenant);
        model.addAttribute("entity", entity);
        model.addAttribute("entities", entities);
        model.addAttribute("snapshots",snapshots);
        return "history/entity-records";
      }

      else {
        var entities = esService.getEntities(tenant, entity);
        String entity1 = capitalizeFirstLetter(entity);
        String globalId=rootPackage+'.'+tenant+'.'+entity1.replace(" ","_")+'/';
        Pattern regexPattern = Pattern.compile("^" + Pattern.quote(rootPackage + '.' + tenant + '.' + entity1.replace(" ","_") + '/') + ".*");
        int offset = (pageNumber-1)*limit;
        List<Document> snapshots = mongoTemplate.find(
                Query.query(Criteria.where("globalId_key").regex(regexPattern)).with(Sort.by(Sort.Direction.DESC,"commitMetadata.commitDateInstant")).skip(offset).limit(limit),
                Document.class,
                "jv_snapshots"
        );
        model.addAttribute("globalId",globalId);
        model.addAttribute("tenant", tenant);
        model.addAttribute("entity", entity);
        model.addAttribute("entities", entities);
        model.addAttribute("snapshots",snapshots);
      }
      return "history/entity-records";
  }

  @GetMapping("entities/{entity}/{id}")
  public String entityList(
          @RequestParam("tenant") final String tenant,
          @PathVariable final String entity,
          @PathVariable String id,
          @RequestParam(value = "pageNumber", defaultValue = "1") int pageNumber,
          @RequestParam(value="limit", defaultValue = "10") int limit, final Model model)
  {
      var entities = esService.getEntities(tenant, entity);
      String entity1 = capitalizeFirstLetter(entity);
      String globalId=rootPackage+'.'+tenant+'.'+entity1.replace(" ","_")+'/';
      String globalIdKey = rootPackage+'.'+tenant+'.'+entity1.replace(" ","_")+'/'+id;

      int offset = (pageNumber-1)*limit;
      List<Document> snapshots = mongoTemplate.find(
              Query.query(Criteria.where("globalId_key").is(globalIdKey)).with(Sort.by(Sort.Direction.DESC,"commitMetadata.commitDateInstant")).skip(offset).limit(limit),
              Document.class,
              "jv_snapshots"
      );

      model.addAttribute("globalId",globalId);
      model.addAttribute("tenant", tenant);
      model.addAttribute("entity", entity);
      model.addAttribute("entities", entities);
      model.addAttribute("snapshots",snapshots);

      return "history/entity-records";
  }


  @GetMapping("/entities1/{entity}")
  public String entityList1(@RequestParam final String tenant, @PathVariable final String entity,
      final Model model) {

    var entities = esService.getEntities(tenant, entity);
    model.addAttribute("tenant", tenant);
    model.addAttribute("entity", entity);
    model.addAttribute("entities", entities);

    return "history/entityRecords";
  }

  @GetMapping("/entities1/{entity}/{id}")
  public String listSnapshots(
          @RequestParam("tenant") final String tenant,
          @PathVariable final String entity,
          @PathVariable String id, final Model model
  ) throws ClassNotFoundException
  {
    List<CdoSnapshot> snapshots = historyService.getSnapshots(tenant, entity.replace(" ","_"), id);
    model.addAttribute("commits", snapshots);
    model.addAttribute("geEntityWithId", entity + "/" + id);

    var auditItems = historyService.getGEAuditItems(tenant, entity.replace(" ","_"), id);
    model.addAttribute("auditItems", auditItems);

    return "history/list";
  }
}
