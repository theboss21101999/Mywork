package com.nsl.novus.history.model;

import java.time.LocalDateTime;
import java.util.List;

public record GEHistoryItem(long version, LocalDateTime commitTime, Object entity, String commitBy,
                            List<String> values, List<String> completeValues) {


}
