package com.nsl.novus.history.service;

import com.nsl.novus.history.model.HecFormData;
import com.nsl.novus.history.model.RelatedTableData;
import com.nsl.novus.history.model.TableHierarchyConfigDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TableHierarchyConfigService {

    @Autowired
    MongoTemplate mongoTemplate;

    @Autowired
    EntityStoreService mySqlService;

    public void insertDocument(HecFormData formData) throws RuntimeException{
        //validate if the form has correct tables as input
        if(mySqlService.doesTableExist(formData.getDatabase(), formData.getMainTable())
                &&
                mySqlService.doesTableExist(formData.getDatabase(), formData.getRelatedTable())
        )
        {
            //check if the current table exists
            String mainTableId = String.join(".",formData.getDatabase(), formData.getMainTable());
            String relatedTableId = String.join(".",formData.getDatabase(), formData.getRelatedTable());

            Query query = new Query(Criteria.where("id").is(mainTableId));

            TableHierarchyConfigDTO tableDto = mongoTemplate.findOne(query,TableHierarchyConfigDTO.class);

            if(tableDto==null){
                mongoTemplate.save(createTableObject(formData));
            }
            else{
                HashSet<RelatedTableData> parentTables = tableDto.getParentTables();

                //check if the current relation already exists
                if(parentTables.stream().anyMatch(obj->obj.getForeignKeyColumn().equals(formData.getFkc()))){
                    throw new RuntimeException("Foreign Key is already in use");
                }
                else if(parentTables.stream().anyMatch(obj->obj.getId().equals(relatedTableId))){
                    throw new RuntimeException("Relation already exists");
                }
                else
                {
                    //creating a new parentTableData object
                    RelatedTableData newParentTable = new RelatedTableData();
                    newParentTable.setId(relatedTableId);
                    newParentTable.setName(formData.getRelatedTable());
                    newParentTable.setDatabase(formData.getDatabase());
                    newParentTable.setForeignKeyColumn(formData.getFkc());
                    parentTables.add(newParentTable);
                    //updating in the repository
                    Update updateStatement = new Update().set("parentTables",parentTables);
                    mongoTemplate.findAndModify(query,updateStatement, TableHierarchyConfigDTO.class);
                }
            }
        }
        else{
            throw new RuntimeException("The Table/Entity does not exist.");
        }
    }

    public List<TableHierarchyConfigDTO> getAllDocuments(){
        return mongoTemplate.findAll(TableHierarchyConfigDTO.class);
    }

    public void deleteAParent(String mainTable, String mainDatabase, String relatedTable, String relatedDatabase){
        String mainTableId = String.join(".",mainDatabase, mainTable);
        String relatedTableId = String.join(".",relatedDatabase, relatedTable);

        Query query = new Query(Criteria.where("id").is(mainTableId));

        TableHierarchyConfigDTO tableDto = mongoTemplate.findOne(query, TableHierarchyConfigDTO.class);
        if(tableDto!=null){
            HashSet<RelatedTableData> parentTables = tableDto.getParentTables()
                    .stream()
                    .filter(obj->!obj.getId().equals(relatedTableId))
                    .collect(Collectors.toCollection(HashSet::new));
            if(parentTables.isEmpty()){
                mongoTemplate.remove(query, TableHierarchyConfigDTO.class);
            }
            else{
                //updating in the repository
                Update updateStatement = new Update().set("parentTables",parentTables);
                mongoTemplate.findAndModify(query,updateStatement, TableHierarchyConfigDTO.class);
            }
        }
    }

    //method to convert FormData to TableMetaData object to store in mongo
    public TableHierarchyConfigDTO createTableObject(HecFormData formData){
        TableHierarchyConfigDTO mainTable = new TableHierarchyConfigDTO();
        RelatedTableData parentTableData = new RelatedTableData();
        HashSet<RelatedTableData> hs = new HashSet<>();

        //setting parent table data
        parentTableData.setId(String.join(".",formData.getDatabase(), formData.getRelatedTable()));
        parentTableData.setName(formData.getRelatedTable());
        parentTableData.setDatabase(formData.getDatabase());
        parentTableData.setForeignKeyColumn(formData.getFkc());
        hs.add(parentTableData);

        //setting main table data
        mainTable.setName(formData.getMainTable());
        mainTable.setDatabase(formData.getDatabase());
        mainTable.setPrimaryKeyColumn(formData.getPkc());
        mainTable.setId(String.join(".", formData.getDatabase(), formData.getMainTable()));

        //no parent exists for the fresh instance
        mainTable.setParentTables(hs);

        return mainTable;
    }

    public HecFormData getFormData(String tableName){
        Query query = new Query(Criteria.where("name").is(tableName));
        TableHierarchyConfigDTO tableDto = mongoTemplate.findOne(query,TableHierarchyConfigDTO.class);

        //if tableDto is null there is an error
        HecFormData fd = new HecFormData();

        if(tableDto!=null) {

            fd.setDatabase(tableDto.getDatabase());
            fd.setMainTable(tableDto.getName());
            fd.setPkc(tableDto.getPrimaryKeyColumn());
        }

        return fd;
    }
}
