package com.nsl.novus.history.controller;

import com.nsl.novus.ApiResponse;
import com.nsl.novus.history.model.SummaryReport;
import com.nsl.novus.history.model.TableMetrics;
import com.nsl.novus.history.service.EntityStoreService;
import io.swagger.v3.oas.annotations.Hidden;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.List;

@RestController
@RequestMapping("/entity-store/")
public class EntityStoreController {

  @Autowired
  private EntityStoreService entityStoreService;

  @GetMapping("tenants")
  public ApiResponse getTenants() {

    var tenants = entityStoreService.getSchemas();
    return new ApiResponse(HttpStatus.OK, "Success", tenants);

  }

  @GetMapping("entities")
  public ApiResponse getEntities(@RequestParam String tenant) {

    var tenants = entityStoreService.getTables(tenant);
    return new ApiResponse(HttpStatus.OK, "Success", tenants);

  }

  @GetMapping("entities/{entity}")
  public ApiResponse getEntities(@RequestParam String tenant, @PathVariable String entity) {

    var entities = entityStoreService.getEntities(tenant, entity);
    return new ApiResponse(HttpStatus.OK, "Success", entities);

  }

  @GetMapping("getFields")
  public List<String> getFieldsOfTable(
          @RequestParam("selectedSchema") String schema,
          @RequestParam("selectedTable") String table
  )
  {
    return entityStoreService.getFieldsOfTable(schema, table);
  }

  @GetMapping("tableExist")
  public boolean doesTableExist(
          @RequestParam("selectedSchema") String schema,
          @RequestParam("selectedTable") String table
  )
  {
    return entityStoreService.doesTableExist(schema, table);
  }

  @Hidden
  @PostMapping("truncate")
  @ResponseBody
  public ResponseEntity<Object> truncateEntity(
          @RequestParam("tenant") String tenant,
          @RequestParam("entity") String entity) {
    try{
      int rows = entityStoreService.truncate(tenant, entity);
      return ResponseEntity.ok("Deleted "+ rows +" rows successfully.");
    }
    catch(Exception e){
      return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }
  }

  @GetMapping("downloadCsv")
  @ResponseBody
  public ResponseEntity<StreamingResponseBody> downloadCsv(
          @RequestParam("tenant") String tenant,
          @RequestParam("entity") String entity) {

    String csvName = String.join("_",tenant,entity)+".csv";
    try{
      StreamingResponseBody stream = outputStream -> {
        entityStoreService.downloadCsv(tenant, entity,outputStream);
      };
      return ResponseEntity.ok()
              .contentType(MediaType.parseMediaType("text/csv; charset=UTF-8"))
              .header(HttpHeaders.CONTENT_DISPOSITION, String.format("attachment; filename=%s",csvName))
              .header(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION)
              .body(stream);
    } catch (RuntimeException e) {
      throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @GetMapping("{tenant}/table/_stats")
  public ApiResponse getTableMetrics(@PathVariable("tenant") String database){
    List<TableMetrics> tableMetricsList = entityStoreService.getTableMetrics(database);
    return new ApiResponse(HttpStatus.OK,"success",tableMetricsList);
  }

  @GetMapping("{tenant}/_stats")
  public ApiResponse getTenantMetrics(@PathVariable("tenant") String database){
    SummaryReport dbReport = entityStoreService.getTenantSummary(database);
    return new ApiResponse(HttpStatus.OK,"success",dbReport);
  }
}
