package com.nsl.novus.history.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Value(value = "${app.username}")
    private String name;

    @Value(value = "${app.password}")
    private String pwd;

    @Value(value = "${app.security.enabled:false}")
    private boolean securityEnabled;

    @Bean
    public InMemoryUserDetailsManager userDetailsService() {
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();

        UserDetails user = User.builder()
                .username(name)
                .password(encoder().encode(pwd))
                .roles("ADMIN")
                .build();
        UserDetails superAdmin = User.builder()
                .username("novus_admin")
                .password(encoder().encode("N0vu$!"))
                .roles("SUPER_ADMIN")
                .build();
        manager.createUser(user);
        manager.createUser(superAdmin);
        return manager;
    }

    @Bean
    public PasswordEncoder encoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        if(securityEnabled){
            http.authorizeHttpRequests
                            (auth -> auth
                                    .requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html").permitAll()
                                    .requestMatchers("/entity-store/truncate").hasRole("SUPER_ADMIN")
                                    .requestMatchers("/login").permitAll()
                                    .requestMatchers("/resources/**, /static/**").permitAll()
                                    .requestMatchers("/css/**").permitAll()
                                    .requestMatchers("/images/**").permitAll()
                                    .anyRequest()
                                    .authenticated()
                            )
                    .csrf(AbstractHttpConfigurer::disable)
                    .httpBasic(withDefaults())
                    .formLogin
                            (form -> form.loginPage("/login")
                                        .loginProcessingUrl("/authUser")
                                        .permitAll()
                            )
                    .logout(logout->logout.logoutUrl("/logout")
                            .logoutSuccessUrl("/login?logout")
                            .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                            .permitAll()
                    );
            return http.build();
        }
        else {
            http.httpBasic(withDefaults())
                    .authorizeHttpRequests(authorize ->
                            authorize.requestMatchers("/**").permitAll()
                                    .anyRequest()
                                    .authenticated()
                    )
                    .csrf(AbstractHttpConfigurer::disable)
            ;
            return http.build();
        }
    }
}
