package com.nsl.novus.history.model;

public class HecFormData {
    private String mainTable;
    private String relatedTable;
    private String database;
    private String fkc;
    private String pkc;

    public HecFormData(){

        this.database = "_default";
        this.fkc = "_default";
    }
    public String getMainTable() {
        return mainTable;
    }

    public void setMainTable(String mainTable) {
        this.mainTable = mainTable;
    }

    public String getRelatedTable() {
        return relatedTable;
    }

    public void setRelatedTable(String relatedTable) {
        this.relatedTable = relatedTable;
    }


    public String getDatabase() {
        return database;
    }

    public void setDatabase(String database) {
        this.database = database;
    }

    public String getFkc() {
        return fkc;
    }

    public void setFkc(String fkc) {
        this.fkc = fkc;
    }

    public String getPkc() {
        return pkc;
    }

    public void setPkc(String pkc) {
        this.pkc = pkc;
    }

    @Override
    public String toString() {
        return "FormData{" +
                "mainTable='" + mainTable + '\'' +
                ", relatedTable='" + relatedTable + '\'' +
                ", database='" + database + '\'' +
                ", fkc='" + fkc + '\'' +
                ", pkc='" + pkc + '\'' +
                '}';
    }
}
