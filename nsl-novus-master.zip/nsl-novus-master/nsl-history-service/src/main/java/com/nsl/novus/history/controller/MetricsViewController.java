package com.nsl.novus.history.controller;

import com.nsl.novus.history.model.SummaryReport;
import com.nsl.novus.history.model.TableMetrics;
import com.nsl.novus.history.service.EntityStoreService;
import com.nsl.novus.history.service.EntityStoreServiceTidb;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class MetricsViewController {
    @Autowired
    EntityStoreService entityStoreService;

    @Autowired
    EntityStoreServiceTidb tidbEntityStoreService;

    @GetMapping("/{tenant}/view/_stats")
    public String getTableMetrics(@PathVariable("tenant") String database, Model model){
        SummaryReport summaryReport = entityStoreService.getTenantSummary(database);
        List<TableMetrics> tableMetricsList = entityStoreService.getTableMetrics(database);

        model.addAttribute("tenant",database);
        model.addAttribute("type","replicaDB");
        model.addAttribute("totalRows",abbreviateNumber(summaryReport.getTotalRows()));
        model.addAttribute("totalTables",abbreviateNumber(summaryReport.getTotalTables()));
        model.addAttribute("summaryReport",summaryReport);
        model.addAttribute("tableMetricsList",tableMetricsList);
        return "metrics";
    }

    @GetMapping("/{tenant}/view/_stats/tidb")
    public String getTableMetricsForTidb(@PathVariable("tenant") String database, Model model){
        SummaryReport summaryReport = tidbEntityStoreService.getTenantSummary(database);
        List<TableMetrics> tableMetricsList = tidbEntityStoreService.getTableMetrics(database);

        model.addAttribute("tenant",database);
        model.addAttribute("type","tiDB");
        model.addAttribute("totalRows",abbreviateNumber(summaryReport.getTotalRows()));
        model.addAttribute("totalTables",abbreviateNumber(summaryReport.getTotalTables()));
        model.addAttribute("summaryReport",summaryReport);
        model.addAttribute("tableMetricsList",tableMetricsList);
        return "metrics";
    }

    public static String abbreviateNumber(long number) {
        if (number < 1000) return Long.toString(number);
        int exp = (int) (Math.log(number) / Math.log(1000));
        char prefix = "kMBTPE".charAt(exp - 1);
        return String.format("%.2f%c", number / Math.pow(1000, exp), prefix);
    }
}
