package com.nsl.novus.history.model;

public record TableMetrics(
        String tableName,
        long rowCount,
        double reservedSizeMB,
        double dataSizeMB,
        double indexSizeMB,
        double unusedSizeMB
) {}
