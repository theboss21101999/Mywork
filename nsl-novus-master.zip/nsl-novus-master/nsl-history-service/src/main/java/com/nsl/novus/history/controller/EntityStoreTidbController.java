package com.nsl.novus.history.controller;

import com.nsl.novus.ApiResponse;
import com.nsl.novus.history.model.SummaryReport;
import com.nsl.novus.history.model.TableMetrics;
import com.nsl.novus.history.service.EntityStoreServiceTidb;
import io.swagger.v3.oas.annotations.Hidden;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/entity-store/")
public class EntityStoreTidbController {

    @Autowired
    EntityStoreServiceTidb service;

    @Hidden
    @PostMapping("tidb/truncate")
    @ResponseBody
    public ResponseEntity<Object> truncateEntity(
            @RequestParam("tenant") String tenant,
            @RequestParam("entity") String entity) {

        try{
            int rows = service.truncate(tenant, entity);
            return ResponseEntity.ok("Deleted "+ rows +" rows successfully.");
        }
        catch(Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
    @GetMapping("{tenant}/table/_stats/tidb")
    public ApiResponse getTableMetrics(@PathVariable("tenant") String database){
        List<TableMetrics> tableMetricsList = service.getTableMetrics(database);
        return new ApiResponse(HttpStatus.OK,"success",tableMetricsList);
    }

    @GetMapping("{tenant}/_stats/tidb")
    public ApiResponse getTenantMetrics(@PathVariable("tenant") String database){
        SummaryReport dbReport = service.getTenantSummary(database);
        return new ApiResponse(HttpStatus.OK,"success",dbReport);
    }
}
