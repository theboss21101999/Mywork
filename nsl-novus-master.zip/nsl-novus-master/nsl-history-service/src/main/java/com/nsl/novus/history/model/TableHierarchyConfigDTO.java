package com.nsl.novus.history.model;

import jakarta.persistence.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.HashSet;

@Document("hierarchy_entity_config")
public class TableHierarchyConfigDTO {

    @Id
    private String id;
    private String name;
    private String primaryKeyColumn;
    private String database;
    private HashSet<RelatedTableData> parentTables = new HashSet<>();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String childTable) {
        this.name = childTable;
    }
    public HashSet<RelatedTableData> getParentTables() {
        return parentTables;
    }
    public void setParentTables(HashSet<RelatedTableData> parentTables) {
        this.parentTables = parentTables;
    }

    public String getPrimaryKeyColumn() {
        return primaryKeyColumn;
    }

    public void setPrimaryKeyColumn(String primaryKeyColumn) {
        this.primaryKeyColumn = primaryKeyColumn;
    }

    public String getDatabase() {
        return database;
    }

    public void setDatabase(String database) {
        this.database = database;
    }

    @Override
    public String toString() {
        return "TableMetaDataDto{" +
                "id='" + id + '\'' +
                "name='" + name + '\'' +
                ", primaryKeyColumn='" + primaryKeyColumn + '\'' +
                ", database='" + database + '\'' +
                ", parentTables=" + parentTables +
                '}';
    }
}
