package com.nsl.novus.history.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.nsl.novus.ApiResponse;
import com.nsl.novus.history.model.EntitySnapshot;
import com.nsl.novus.history.service.EntityStoreService;
import com.nsl.novus.history.service.HistoryService;

import java.time.LocalDateTime;
import java.util.*;
import javax.annotation.PostConstruct;

import org.bson.Document;
import org.javers.core.metamodel.object.CdoSnapshot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HistoryController {

  @Autowired
  private HistoryService historyService;
  @Autowired
  private MongoTemplate mongoTemplate;
  @Value("${generated.class.root.package}")
  private String rootPackage;

  //TODO check if it is thread-safe

  @Autowired
  private EntityStoreService esService;

  private static final Logger LOGGER = LoggerFactory.getLogger(HistoryController.class);

  private final ObjectMapper objectMapper = new ObjectMapper();

  @PostConstruct
  void init() {
    objectMapper.registerModule(new JavaTimeModule());
  }

  @GetMapping("/{entity}/{id}/1")
  public ApiResponse getSnapshots(
          @RequestParam final String tenant,
          @PathVariable final String entity,
          @PathVariable String id) throws ClassNotFoundException
  {
    var snapshots = historyService.getSnapshots(tenant, entity, id);
    return new ApiResponse(HttpStatus.OK, "Success", objectMapper.valueToTree(createSnapshots(snapshots)));

  }


  @GetMapping("/getSnapshotsByID/{tenant}/{entity}/{id}")
  public ApiResponse getSnapshotsByID(
          @RequestParam final String tenant,
          @RequestParam final String entity,
          @RequestParam final String id,
          @RequestParam(defaultValue = "1") final int pageNumber,
          @RequestParam(defaultValue = "10") final int limit)
  {
    List<Document> snapshots = historyService.getSnapshotsByID(tenant, entity, id, pageNumber, limit);
    return new ApiResponse(HttpStatus.OK,"Success", snapshots);
  }


  @GetMapping("/getSnapshotsByType/{tenant}/{entity}/{type}")
  public ApiResponse getSnapshotsByType(
          @RequestParam final String tenant,
          @RequestParam final String entity,
          @RequestParam String type,
          @RequestParam(defaultValue = "1") final int pageNumber,
          @RequestParam(defaultValue = "10") final int limit)
  {
    List<Document> snapshots = historyService.getSnapshotsByType(tenant, entity, type, pageNumber, limit);
    return new ApiResponse(HttpStatus.OK,"Success", snapshots);
  }



  @GetMapping("/getSnapshotsByDate/{tenant}/{entity}/{date}")
  public ApiResponse getSnapshotsByDate(
          @RequestParam final String tenant,
          @RequestParam final String entity,
          @RequestParam final String date,
          @RequestParam(defaultValue = "1") final int pageNumber,
          @RequestParam(defaultValue = "10") final int limit)
  {
    List<Document> snapshots = historyService.getSnapshotsByDate(tenant, entity, date,pageNumber, limit);
    return new ApiResponse(HttpStatus.OK,"Success", snapshots);
  }

  @GetMapping("/getSnapshotsByVersion/{tenant}/{entity}/{id}/{version}")
  public ApiResponse getSnapshotsByVersion(
          @RequestParam final String tenant,
          @RequestParam final String entity,
          @RequestParam final String id,
          @RequestParam final Long version,
          @RequestParam(defaultValue = "1") final int pageNumber,
          @RequestParam(defaultValue = "10") final int limit)
  {
    List<Document> snapshots = historyService.getSnapshotsByVersion(tenant, entity, id, version, pageNumber, limit);
    return new ApiResponse(HttpStatus.OK, "Success", snapshots);
  }


  @GetMapping("/getSnapshotsByDate/{tenant}/{entity}/{startDate}/{endDate}")
  public ApiResponse getSnapshotsByDateRange(
          @RequestParam final String tenant,
          @RequestParam final String entity,
          @RequestParam final String startDateInput,
          @RequestParam final String endDateInput,
          @RequestParam(defaultValue = "1") final int pageNumber,
          @RequestParam(defaultValue = "10") final int limit)
  {
    List<Document> snapshots = historyService.getSnapshotsByDateRange(tenant, entity, startDateInput, endDateInput, pageNumber, limit);
    return new ApiResponse(HttpStatus.OK,"Success", snapshots);
  }

  @GetMapping("/history/getChanges/{tenant}/{entity}")
  public ApiResponse getSnapshotsCount(@RequestParam final String tenant, @RequestParam final String entity){
    LOGGER.info("Received getSnapshots Count for each type request");
    Map<String, Long> count = historyService.getSnapshotsCount(tenant, entity);
    return new ApiResponse(HttpStatus.OK,"Success", count);
  }
  @GetMapping("/history/getEntities/{tenant}")
  public ApiResponse getSnapshotsByCommitDate(@RequestParam final String tenant){
    LOGGER.info("Received getSnapshots sorted by commitDate request");
    var entities = esService.getTables(tenant);
    entities.sort(Comparator.comparing(entity -> {
      LocalDateTime commitDate = historyService.getSnapshotsCommitDate(tenant, entity);
      return commitDate != null ? commitDate : LocalDateTime.MIN;
    }, Comparator.nullsLast(Comparator.reverseOrder())));
    //entities.sort(Comparator.comparing(entity -> historyService.getSnapshotsCommitDate(tenant, entity), Comparator.reverseOrder()));
    return new ApiResponse(HttpStatus.OK,"Success", entities);
  }


  public List<EntitySnapshot> createSnapshots(List<CdoSnapshot> snapshots) {

    var entitySnapshots = new ArrayList<EntitySnapshot>(snapshots.size());
    snapshots.forEach(snapshot -> {
      entitySnapshots.add(createSnapshot(snapshot));
    });

    return entitySnapshots;
  }

  private EntitySnapshot createSnapshot(CdoSnapshot snapshot) {

    var stateMap = new HashMap<String, Object>();
    for (String propertyName : snapshot.getState().getPropertyNames()) {
      stateMap.put(propertyName, snapshot.getPropertyValue(propertyName));
    }
    return new EntitySnapshot(snapshot.getCommitMetadata(), stateMap, snapshot.getType(),
        snapshot.getChanged(), snapshot.getVersion());

  }


}
