package com.nsl.novus.history.model;

public class SummaryReport {
    long totalTables;
    long totalRows;
    double totalReservedSizeMB;
    double totalDataSizeMB;
    double totalIndexedSizeMB;
    double totalUnusedSizeMB;

    public long getTotalTables() {
        return totalTables;
    }

    public void setTotalTables(long totalTables) {
        this.totalTables = totalTables;
    }

    public long getTotalRows() {
        return totalRows;
    }

    public void setTotalRows(long totalRows) {
        this.totalRows = totalRows;
    }

    public double getTotalReservedSizeMB() {
        return totalReservedSizeMB;
    }

    public void setTotalReservedSizeMB(double totalReservedSizeMB) {
        this.totalReservedSizeMB = totalReservedSizeMB;
    }

    public double getTotalDataSizeMB() {
        return totalDataSizeMB;
    }

    public void setTotalDataSizeMB(double totalDataSizeMB) {
        this.totalDataSizeMB = totalDataSizeMB;
    }

    public double getTotalIndexedSizeMB() {
        return totalIndexedSizeMB;
    }

    public void setTotalIndexedSizeMB(double totalIndexedSizeMB) {
        this.totalIndexedSizeMB = totalIndexedSizeMB;
    }

    public double getTotalUnusedSizeMB() {
        return totalUnusedSizeMB;
    }

    public void setTotalUnusedSizeMB(double totalUnusedSizeMB) {
        this.totalUnusedSizeMB = totalUnusedSizeMB;
    }

}
