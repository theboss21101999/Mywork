package com.nsl.novus.history.model;

import java.util.List;
import java.util.Map;
import org.javers.core.commit.CommitMetadata;
import org.javers.core.metamodel.object.SnapshotType;

public record EntitySnapshot(CommitMetadata commitMetadata, Map<String, Object> state,
                             SnapshotType type,
                             List<String> changed, Long version) {

}
