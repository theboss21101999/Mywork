package com.nsl.novus.history.service;

import com.mysql.cj.jdbc.MysqlDataSource;
import com.nsl.novus.history.model.SummaryReport;
import com.nsl.novus.history.model.TableMetrics;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Service
public class EntityStoreServiceTidb {

    @Value("${tidb.datasource.url}")
    private String url;

    @Value("${tidb.datasource.username}")
    private String user;

    @Value("${tidb.datasource.password}")
    private String pwd;


    private final MysqlDataSource  dataSource = new MysqlDataSource();

    @PostConstruct
    public void initDB(){
        dataSource.setURL(url);
        dataSource.setUser(user);
        dataSource.setPassword(pwd);
    }

    public int truncate(String tenant, String entity){
        int rows=0;
        try(Connection conn = dataSource.getConnection();
            Statement stmt = conn.createStatement()){
            var tName = entity;
            if (entity.contains(" ")) {
                tName = "`"+entity+"`";
            }
            String sql = "SELECT COUNT(*) AS row_count FROM " + tenant + "." + tName;

            //if the amount of rows is too large throw RunTime Error
            ResultSet rs = stmt.executeQuery(sql);

            if (rs.next()) {
                rows = rs.getInt("row_count");
            }

            String query = "TRUNCATE TABLE " + tenant +"."+tName ;

            stmt.executeUpdate(query);

            return rows;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public List<TableMetrics> getTableMetrics(String database){
        List<TableMetrics> tableMetricsList = new ArrayList<>();
        try(Connection conn = dataSource.getConnection();
            Statement stmt = conn.createStatement()){
            String query = "SELECT TABLE_NAME, TABLE_ROWS, DATA_LENGTH, INDEX_LENGTH, DATA_FREE "
                    + "FROM information_schema.TABLES "
                    + "WHERE TABLE_SCHEMA = " + "'"+database+"';";

            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                String tableName = rs.getString("TABLE_NAME");
                long rowCount = rs.getLong("TABLE_ROWS");
                long reservedSize = rs.getLong("DATA_LENGTH") + rs.getLong("INDEX_LENGTH");
                long dataSize = rs.getLong("DATA_LENGTH");
                long indexSize = rs.getLong("INDEX_LENGTH");
                long unusedSize = rs.getLong("DATA_FREE");

                double reservedSizeMB = reservedSize / 1024.0 / 1024.0;
                double dataSizeMB = dataSize / 1024.0 / 1024.0;
                double indexSizeMB = indexSize / 1024.0 / 1024.0;
                double unusedSizeMB = unusedSize / 1024.0 / 1024.0;

                tableMetricsList.add(new TableMetrics(
                        tableName,
                        rowCount,
                        reservedSizeMB,
                        dataSizeMB,
                        indexSizeMB,
                        unusedSizeMB
                ));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return tableMetricsList;
    }

    public SummaryReport getTenantSummary(String database){
        SummaryReport report = new SummaryReport();
        try(Connection conn = dataSource.getConnection();
            Statement stmt = conn.createStatement()){
            String totalQuery = "SELECT COUNT(TABLE_NAME) AS TOTAL_TABLES,SUM(TABLE_ROWS) AS TOTAL_ROWS, SUM(DATA_LENGTH) AS TOTAL_DATA_LENGTH, SUM(INDEX_LENGTH) AS TOTAL_INDEX_LENGTH, SUM(DATA_FREE) AS TOTAL_DATA_FREE "
                    + "FROM information_schema.TABLES "
                    + "WHERE TABLE_SCHEMA = " + "'"+database+"';";

            ResultSet resultSet = stmt.executeQuery(totalQuery);

            while(resultSet.next()){
                long totalTables = resultSet.getLong("TOTAL_TABLES");
                long totalRowCount = resultSet.getLong("TOTAL_ROWS");
                long totalReservedSize = resultSet.getLong("TOTAL_DATA_LENGTH") + resultSet.getLong("TOTAL_INDEX_LENGTH");
                long totalDataSize = resultSet.getLong("TOTAL_DATA_LENGTH");
                long totalIndexSize = resultSet.getLong("TOTAL_INDEX_LENGTH");
                long totalUnusedSize = resultSet.getLong("TOTAL_DATA_FREE");

                double totalReservedSizeMB = totalReservedSize / 1024.0 / 1024.0;
                double totalDataSizeMB = totalDataSize / 1024.0 / 1024.0;
                double totalIndexSizeMB = totalIndexSize / 1024.0 / 1024.0;
                double totalUnusedSizeMB = totalUnusedSize / 1024.0 / 1024.0;

                report.setTotalTables(totalTables);
                report.setTotalRows(totalRowCount);
                report.setTotalReservedSizeMB(Math.round(totalReservedSizeMB * 100.0) / 100.0);
                report.setTotalDataSizeMB(Math.round(totalDataSizeMB * 100.0) / 100.0);
                report.setTotalIndexedSizeMB(Math.round(totalIndexSizeMB * 100.0) / 100.0);
                report.setTotalUnusedSizeMB(Math.round(totalUnusedSizeMB * 100.0) / 100.0);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return report;
    }
}
