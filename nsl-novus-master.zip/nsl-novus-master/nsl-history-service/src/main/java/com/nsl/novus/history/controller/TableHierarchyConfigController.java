package com.nsl.novus.history.controller;

import com.nsl.novus.history.model.HecFormData;
import com.nsl.novus.history.model.TableHierarchyConfigDTO;
import com.nsl.novus.history.service.EntityStoreService;
import com.nsl.novus.history.service.TableHierarchyConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/hec")
public class TableHierarchyConfigController {
    @Autowired
    TableHierarchyConfigService service;

    @Autowired
    EntityStoreService msqlService;

    @GetMapping("/register")
    public String getHomePage(Model model){
        HecFormData formData = new HecFormData();
        model.addAttribute("formData",formData);
        model.addAttribute("schemaList",msqlService.getSchemas());
        return "hec/index";
    }

    @GetMapping("/home")
    public String getAllCollections(Model model) {
        List<TableHierarchyConfigDTO> rows = service.getAllDocuments();
        model.addAttribute("rows",rows);
        return "hec/home";
    }

    @PostMapping("/submit")
    public String getFormData(HecFormData formData, Model model) {
        try {
            model.addAttribute("success","success");
            model.addAttribute("error",null);
            service.insertDocument(formData);
            return "hec/response";
        }catch(Exception e){
            model.addAttribute("success",null);
            model.addAttribute("error",e.getMessage());
            return "hec/response";
        }
    }

    @GetMapping("/update/{id}/{db}")
    public String updateRelations(@PathVariable("id") String id, @PathVariable("db") String db, Model model){

        model.addAttribute("formData",service.getFormData(id));
        model.addAttribute("schemaList",msqlService.getSchemas());
        model.addAttribute("fieldsList",msqlService.getFieldsOfTable(db,id));

        return "hec/index";
    }

    @PostMapping("/delete")
    @ResponseBody
    public ResponseEntity<String> deleteAParent(
            @RequestParam("mainTable") String mainTable,
            @RequestParam("mainDatabase") String mainDatabase,
            @RequestParam("relatedTable") String relatedTable,
            @RequestParam("relatedDatabase") String relatedDatabase

    ){
        service.deleteAParent(mainTable,mainDatabase, relatedTable,relatedDatabase);
        return ResponseEntity.ok("Deleted");
    }
}
