package com.nsl.novus.history.model;

import java.util.List;

public record Tenant(String name, List<String> generalEntities) {

}
