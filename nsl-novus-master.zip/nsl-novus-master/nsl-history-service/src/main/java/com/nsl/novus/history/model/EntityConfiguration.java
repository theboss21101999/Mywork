package com.nsl.novus.history.model;

import org.javers.core.metamodel.annotation.Id;

public class EntityConfiguration {

  private long masterId;
  private boolean auditEnabled;

  public EntityConfiguration(boolean auditEnabled) {
    this.auditEnabled = true;
  }

  public boolean isAuditEnabled() {
    return auditEnabled;
  }
}
