package com.nsl.novus.history.service;

import com.mongodb.client.MongoClient;
import com.nsl.novus.NslClassLoader;
import com.nsl.novus.history.model.GEHistoryItem;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;

import org.bson.Document;
import org.javers.core.Javers;
import org.javers.core.JaversBuilder;
import org.javers.core.diff.Diff;
import org.javers.core.metamodel.object.CdoSnapshot;
import org.javers.repository.jql.QueryBuilder;
import org.javers.repository.mongo.MongoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import static org.codehaus.plexus.util.StringUtils.capitalizeFirstLetter;

@Service
public class HistoryService {

  @Autowired
  private EntityStoreService esService;


  @Value("${generated.entity.classes.directory}")
  private String entityClassesDirectory;

  @Value("${generated.class.root.package}")
  private String rootPackage;

  private String packagePrefix;

  private NslClassLoader nslClassLoader;

  @Autowired
  private MongoClient mongoClient;

  @Autowired
  private MongoTemplate mongoTemplate;

  @Value("${mongodb.name}")
  private String mongodbName;

  private Javers javers;
  private static final Logger log = LoggerFactory.getLogger(HistoryService.class);


  @PostConstruct
  void init() {
    packagePrefix = rootPackage+".";
    var mongoDb = mongoClient.getDatabase(Objects.requireNonNull(mongodbName));
    var mongoRepository = new MongoRepository(mongoDb);
    javers = JaversBuilder.javers().registerJaversRepository(mongoRepository).build();
    nslClassLoader = new NslClassLoader(Path.of(entityClassesDirectory),
        this.getClass().getClassLoader());

  }

  public List<CdoSnapshot> getSnapshots(final String tenant, final String entityName, Object id)
      throws ClassNotFoundException {
    log.info("In getSnapshots for entityName : {} and id: {} ", entityName, id);

    var entityClass = toEntityClass(tenant, entityName);
    var query = QueryBuilder.byInstanceId(id, entityClass).build();
    return javers.findSnapshots(query);

  }

  public List<GEHistoryItem> getGEAuditItems(final String tenant, final String entityName, Object id)
      throws ClassNotFoundException {
    log.info("In getGEAuditItems for entityName : {} and id: {} ", entityName, id);

    var entityClass = toEntityClass(tenant, entityName);
    var query = QueryBuilder.byInstanceId(id, entityClass).build();
    var snapshots = javers.findSnapshots(query);
    var auditItems = new ArrayList<GEHistoryItem>(snapshots.size());

    GEHistoryItem prevAuditItem = null;

    for (int i = snapshots.size() - 1; i >= 0; i--) {
      var auditItem = toEntityInstance(entityClass, snapshots.get(i), prevAuditItem);
      auditItems.add(auditItem);
      prevAuditItem = auditItem;
    }

    return auditItems;
  }


  public Optional<CdoSnapshot> getSnapshot(final Class<?> entityClass, final Object id) {
    return javers.getLatestSnapshot(id, entityClass);
  }

  public Object getSnapshot(final String tenant, final String entityName,
      final Object id, final long version) {
    log.info("In getSnapshot for entityName : {} and id: {}  and version: {}", entityName, id, version);

    var entityClass = toEntityClass(tenant, entityName);
    var query = QueryBuilder.byInstanceId(id, entityClass).withVersion(version).build();
    var snapshots = javers.findSnapshots(query);
    if (CollectionUtils.isEmpty(snapshots)) {
      throw new IllegalArgumentException(
          String.format("No snapshot found for '%s' with id '%s' and version '%s'",
              entityClass.getName(), id, version));
    }
    return snapshots.get(8).getState().toString();
  }

  public void commitShallowDelete(final String author, final Object entity) {
    javers.commitShallowDelete(author, entity);
  }

  public void commit(final String author, final Object entity) {
    javers.commit(author, entity);
  }

  public void enableAudit(long entityMasterId, boolean auditEnabled) {

  }

  private Class<?> toEntityClass(final String tenant, String entity) {
    log.info("toEntityClass");

    var entityClassName = packagePrefix + tenant + "." + toTitleCase(entity);
    try {
      return nslClassLoader.loadClass(entityClassName);
    } catch (ClassNotFoundException e) {
      throw new RuntimeException(e);
    }

  }

  //TODO remove
  private String toTitleCase(String input) {
    if (input.contains(" ")) {
      input = input.replace(" ", "_");
    }
    StringBuilder titleCase = new StringBuilder(input.length());
    boolean nextTitleCase = true;

    for (char c : input.toCharArray()) {
      if (nextTitleCase) {
        c = Character.toTitleCase(c);
        nextTitleCase = false;
      }
      titleCase.append(c);
    }
    return titleCase.toString();
  }


  private GEHistoryItem toEntityInstance(Class<?> entityClass, CdoSnapshot snapshot,
      GEHistoryItem preAuditItem) {
    log.info("In toEntityInstance" );

    try {
      var method = entityClass.getMethod("create", new Class[] {CdoSnapshot.class});
      var entity = method.invoke(null, new Object[] {snapshot});

      Object prevEntity = null;
      if (preAuditItem != null) {
        prevEntity = preAuditItem.entity();
      }

      var metadata = snapshot.getCommitMetadata();
      var valueList = new ArrayList<String>();
      var completeValueList = new ArrayList<String>();
      var values = snapshot.getState();

      var typeBuilder = new StringBuilder();
      switch (snapshot.getType()) {
        case INITIAL -> {
          typeBuilder.append("Created by ");

          values.getPropertyNames().forEach(attribute -> {
            valueList.add(attribute + ": " + values.getPropertyValue(attribute));
          });
        }
        case UPDATE -> {
          typeBuilder.append("Updated by ");
          Diff diff = javers.compare(prevEntity, entity);

          diff.groupByObject().forEach(changes -> {

            changes.getPropertyChanges().forEach(change -> {
              String strBuilder = change.getPropertyName() + " : "
                  + change.getLeft() + " -> " + change.getRight()
                  + System.lineSeparator();
              valueList.add(strBuilder);
            });

          });

          values.getPropertyNames().forEach(attribute -> {
            completeValueList.add(attribute + ": " + values.getPropertyValue(attribute));
          });
        }
        case TERMINAL -> {
          typeBuilder.append("Deleted by ");

          values.getPropertyNames().forEach(attribute -> {
            valueList.add(attribute + ": " + values.getPropertyValue(attribute));
          });
        }
      }

      typeBuilder.append(metadata.getAuthor());

      return new GEHistoryItem(snapshot.getVersion(), metadata.getCommitDate(),
          entity, typeBuilder.toString(), valueList, completeValueList);
    } catch (Exception e) {
      throw new RuntimeException(e);

    }

  }

  public List<Document> getSnapshotsByID(String tenant, String entity, String id, int pageNumber, int limit){
    log.info("In getSnapshotsByID for tenant : {} and entity: {} ", tenant, entity);

    String entity1=capitalizeFirstLetter(entity);
    String globalIdKey = rootPackage+'.'+tenant+'.'+entity1+'/'+id;
//    List<Document> snapshots = mongoTemplate.find(
//            Query.query(Criteria.where("globalId_key").is(globalIdKey)),
//            Document.class,
//            "jv_snapshots"
//    );
    int offset=(pageNumber-1)*limit;
    List<Document> snapshots = mongoTemplate.find(
            Query.query(Criteria.where("globalId_key").is(globalIdKey)).with(Sort.by(Sort.Direction.DESC,"commitMetadata.commitDateInstant")).skip(offset).limit(limit),
            Document.class,
            "jv_snapshots"
    );
    return snapshots;
  }

  public List<Document> getSnapshotsByType(String tenant, String entity, String type,int pageNumber, int limit){
    log.info("In getSnapshotsByType for tenant : {} and entity: {} and type : {}", tenant, entity, type);

    String entity1 = capitalizeFirstLetter(entity);
    String globalId=rootPackage+'.'+tenant+'.'+entity1+'/';
    Pattern regexPattern = Pattern.compile("^" + Pattern.quote(rootPackage + '.' + tenant + '.' + entity1 + '/') + ".*");
    if(Objects.equals(type, "created"))type="INITIAL";
    else if(Objects.equals(type, "updated"))type="UPDATE";
    else if(Objects.equals(type, "deleted"))type="TERMINAL";
    int offset=(pageNumber-1)*limit;
    List<Document> snapshots = mongoTemplate.find(
            Query.query(Criteria.where("globalId_key").regex(regexPattern).and("type").is(type)).with(Sort.by(Sort.Direction.DESC,"commitMetadata.commitDateInstant")).skip(offset).limit(limit),
            Document.class,
            "jv_snapshots"
    );
    return snapshots;
  }

  public List<Document> getSnapshotsByDate(String tenant, String entity,String date, int pageNumber, int limit){
    log.info("In getSnapshotsByID for tenant : {} and entity: {} and date : {}", tenant, entity, date);

    String entity1 = capitalizeFirstLetter(entity);
    String globalId=rootPackage+'.'+tenant+'.'+entity1+'/';
    Pattern regexPattern = Pattern.compile("^" + Pattern.quote(rootPackage + '.' + tenant + '.' + entity1 + '/') + ".*");
    Pattern pattern = Pattern.compile("^" + Pattern.quote(date) + "T" + ".*");
    int offset=(pageNumber-1)*limit;
    List<Document> snapshots = mongoTemplate.find(
            Query.query(Criteria.where("globalId_key").regex(regexPattern).and("commitMetadata.commitDate").regex(pattern)).with(Sort.by(Sort.Direction.DESC,"commitMetadata.commitDateInstant")).skip(offset).limit(limit),
            Document.class,
            "jv_snapshots"
    );
    return snapshots;
  }

  public List<Document> getSnapshotsByVersion(String tenant, String entity, String id, Long version, int pageNumber, int limit){
    log.info("In getSnapshotsByVersion for tenant : {} and entity: {} and id : {} and version : {}", tenant, entity, id, version);

    String entity1=capitalizeFirstLetter(entity);
    String globalIdKey = rootPackage+'.'+tenant+'.'+entity1+'/'+id;
    int offset=(pageNumber-1)*limit;
    List<Document> snapshots = mongoTemplate.find(
            Query.query(Criteria.where("globalId_key").is(globalIdKey).and("version").is(version)).with(Sort.by(Sort.Direction.DESC,"commitMetadata.commitDateInstant")).skip(offset).limit(limit),
            Document.class,
            "jv_snapshots"
    );
    return snapshots;
  }

  public List<Document> getSnapshotsByDateRange(String tenant, String entity, String startDateInput, String endDateInput, int pageNumber, int limit){
    log.info("In getSnapshotsByDateRange for tenant : {} and entity: {} and startDate : {} and endDate : {}", tenant, entity, startDateInput, endDateInput);

    String entity1 = capitalizeFirstLetter(entity);
    String globalId=rootPackage+'.'+tenant+'.'+entity1+'/';
    Pattern regexPattern = Pattern.compile("^" + Pattern.quote(rootPackage + '.' + tenant + '.' + entity1 + '/') + ".*");

    LocalDate startDate = LocalDate.parse(startDateInput);
    LocalDate endDate = LocalDate.parse(endDateInput);

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'00:00:00.000'Z'");
    String startDateStr = startDate.format(formatter);
    String endDateStr = endDate.format(formatter);
    Criteria criteria = new Criteria().andOperator(
            Criteria.where("commitMetadata.commitDate").gte(startDateStr).lte(endDateStr),
            Criteria.where("globalId_key").regex(regexPattern)
    );

    int offset=(pageNumber-1)*limit;
    List<Document> snapshots = mongoTemplate.find(
            Query.query(criteria).with(Sort.by(Sort.Direction.DESC,"commitMetadata.commitDateInstant")).skip(offset).limit(limit),
            Document.class,
            "jv_snapshots"
    );
    return snapshots;
  }

  public Map<String, Long> getSnapshotsCount(String tenant, String entity){
    log.info("In getSnapshotsByCount for tenant : {} and entity: {} ", tenant, entity);
    var entities = esService.getTables(tenant);
    String entity1 = capitalizeFirstLetter(entity);
    String globalId=rootPackage+'.'+tenant+'.'+entity1+'/';
    Pattern regexPattern = Pattern.compile("^" + Pattern.quote(rootPackage + '.' + tenant + '.' + entity1 + '/') + ".*");

    List<Document> snapshots = mongoTemplate.find(
            Query.query(Criteria.where("globalId_key").regex(regexPattern)),
            Document.class,
            "jv_snapshots"
    );

    Map<String, Long> countsByType = new HashMap<>();
    for (Document snapshot : snapshots) {
      String type = snapshot.getString("type");
      String updatedType = type;
      switch (type) {
        case "INITIAL":
          updatedType = "CREATED";
          break;
        case "UPDATE":
          updatedType = "UPDATED";
          break;
        case "TERMINAL":
          updatedType = "DELETED";
          break;
      }
      countsByType.put(updatedType, countsByType.getOrDefault(updatedType, 0L) + 1);
    }
    return countsByType;
  }

  public LocalDateTime getSnapshotsCommitDate(String tenant, String entity){
    log.info("In getSnapshotsByCommitDate for tenant : {} and entity: {} ", tenant, entity);
    var entities = esService.getTables(tenant);
    String entity1 = capitalizeFirstLetter(entity);
    String globalId=rootPackage+'.'+tenant+'.'+entity1+'/';
    Pattern regexPattern = Pattern.compile("^" + Pattern.quote(rootPackage + '.' + tenant + '.' + entity1 + '/') + ".*");

    Query query = Query.query(Criteria.where("globalId_key").regex(regexPattern))
            .with(Sort.by(Sort.Order.desc("commitMetadata.commitDate")))
            ;
    Document lastSnapshot = mongoTemplate.findOne(query, Document.class, "jv_snapshots");

    LocalDateTime commitDate = null;
    if (lastSnapshot != null) {
      Document commitMetadata = (Document) lastSnapshot.get("commitMetadata");
      String commitDateString = commitMetadata.getString("commitDate");
      commitDate = LocalDateTime.parse(commitDateString, DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    }
    return commitDate;

  }
}