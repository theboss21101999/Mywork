
/**
 * Register an event at the document for the specified selector,
 * so events are still catched after DOM changes.
 */
function addEvent(eventType, selector, handler) {
    document.addEventListener(eventType, function(event) {
        if (event.target.matches(selector + ', ' + selector + ' *')) {
            handler.apply(event.target.closest(selector), arguments);
        }
    });
}

addEvent('click', '.js-dropdown', function(event) {
    document.querySelectorAll('.js-dropdown').forEach(($dropdown) => {
        if (this === $dropdown ||
                ($dropdown.getAttribute('data-dropdown-single') !== 'true' && $dropdown.ariaExpanded === 'true')) {
            $dropdown.ariaExpanded = $dropdown.ariaExpanded !== 'true';
            $dropdown.nextElementSibling.classList.toggle('hidden');
        }
    });
    return false;
});

function checkInputValue(valueToCheck) {
    let newStr = valueToCheck.split(" ").join("_");
    const inputField = document.getElementById(newStr+'-table-name');
    const submitButton = document.getElementById(newStr+'-submitBtn');

    if (inputField.value === valueToCheck) {
       submitButton.disabled = false;
    } else {
       submitButton.disabled = true;
    }
 }

//Methods to call truncate service on btn click
function truncate(selectedSchema,selectedTable){
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
    $.ajax({
        url: '/history/entity-store/tidb/truncate',
        type: 'POST',
        data: {tenant: selectedSchema,entity:selectedTable},
        success: function(response){
           console.log(response);
           toastr.success(response);
        },
        error: function(xhr, status, error){
            toastr.error(xhr.responseText);
            console.error(xhr.responseText);
        }
    })
}

function downloadCsv(selectedSchema,selectedTable){
    $.ajax({
        url: '/history/entity-store/downloadCsv',
        type: 'GET',
        data: {tenant: selectedSchema,entity:selectedTable},
        xhrFields: {
            responseType: 'blob'
        },
        success: function(response){
            var blob = new Blob([response], { type: 'text/csv' });

                    // Create a blob URL using FileReader
                    var reader = new FileReader();
                    reader.onload = function(event) {
                        // Create a link element
                        var link = document.createElement('a');
                        link.href = event.target.result;
                        link.download = selectedSchema+'_'+selectedTable+'.csv';

                        // Append the link to the body
                        document.body.appendChild(link);

                        // Programmatically click the link to trigger the download
                        link.click();

                        // Remove the link from the document
                        $(link).remove();
                    };
                    reader.readAsDataURL(blob);
        },
        error: function(xhr, status, error){
            console.error(xhr.responseText);
        }
    })
}

// Methods which manipulate data in table hierarchy config pages

// This method calls the mysql service to check if the inputted table exists or not
function doesTableExist(databaseId,tableId,field1Id="_default",field2Id="_default"){

    //Getting the values inside the element tags
    var selectedSchema = $(databaseId).val();
    var selectedTable = $(tableId).val();

    //identifying the input field's related error element tag to show error mssg/disable
    var errorTag = "";
    if(tableId==="#cdt"){
        errorTag="cErrorHelp";
    }
    else if(tableId==="#pdt"){
        errorTag="pErrorHelp";
    }

    //AJAX call to the controller
    $.ajax({
             url: '/history/entity-store/tableExist',
             type: 'GET',
             data: {selectedSchema: selectedSchema,selectedTable:selectedTable},
             success: function(response){
                console.log(response)
                if(response==true){
                    document.getElementById(errorTag).classList.remove("enableError");
                    document.getElementById(errorTag).classList.add("disableError");
                    if(field1Id!=="_default"){
                        getFields(selectedSchema,selectedTable,field1Id,field2Id)
                    }
                }
                else{

                    document.getElementById(errorTag).classList.remove("disableError");
                    document.getElementById(errorTag).classList.add("enableError");

                    /* *this field will be different for main table
                       *as for main table we have primary key and foreign keys
                    */
                    if(field1Id!=="_default"){
                        $(field1Id).empty();
                        $(field2Id).empty();
                    }
                }
             },
             error: function(xhr, status, error){
                 console.error(xhr.responseText);
             }
         })
 }

 //Function call to get all the columns of the selected table
function getFields(selectedSchema,selectedTable,field1Id,field2Id){

     $.ajax({
         url: '/history/entity-store/getFields',
         type: 'GET',
         data: {selectedSchema: selectedSchema,selectedTable:selectedTable},
         success: function(response){
            addPrimaryKeyOptions(field1Id,response);
            addForeignKeyOptions(field2Id,response);
         },
         error: function(xhr, status, error){
             console.error(xhr.responseText);
         }
     })
}

//Function call to delete a relation between the child and parent onClick Delete btn
function deleteParent(mainTable, mainDatabase, relatedTable, relatedDatabase){
    console.log(mainTable);
    console.log(relatedTable)
     $.ajax({
         url: '/history/hec/delete',
         type: 'POST',
         data:
         {
             mainTable: mainTable,
             mainDatabase:mainDatabase,
             relatedTable:relatedTable,
             relatedDatabase:relatedDatabase
         },
         success: function(response){
            console.log(response);
            window.location.reload();
         },
         error: function(xhr, status, error){
             console.error(xhr.responseText);
         }
     })
}

function addPrimaryKeyOptions(tagId,dataList){
    $(tagId).empty();
    var defaultOption = document.createElement("option");
    defaultOption.value = "default";
    defaultOption.text = "PK of current table"
    defaultOption.disabled = true;
    defaultOption.selected = true;

    $(tagId).append(defaultOption);
    addOptions(tagId,dataList);
}

function addForeignKeyOptions(tagId, dataList){
    $(tagId).empty();
    var defaultOption = document.createElement("option");
    defaultOption.value = "default";
    defaultOption.text = "FK column of current to related table"
    defaultOption.disabled = true;
    defaultOption.selected = true;

    $(tagId).append(defaultOption);
    addOptions(tagId,dataList);
}

function addOptions(fieldTag,list){

    $.each(list, function(index, option){
         var optionTag = document.createElement("option");
         optionTag.value = option;
         optionTag.text = option;
         $(fieldTag).append(optionTag);
    });
}

