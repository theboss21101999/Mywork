package com.nsl.novus.utils;

import java.io.*;
import java.net.JarURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Objects;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Stream;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import com.nsl.novus.enums.HttpMethod;
import com.nsl.novus.model.ApiRequest;
import com.nsl.novus.model.ApiResponse;
import com.nsl.novus.model.ConnectorListResponse;
import com.nsl.novus.model.ConnectorRegisterResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConnectorsUtils {
	
	private Gson gson = new Gson();
	private GetProperties properties = new GetProperties();
	private static final String GET_CONNECTORS = "/connectors";
	private static final String GET_CONNECTORS_CONFIG_BYNAME = "/connectors/{name}/config";
	private static final String GET_CONNECTORS_STATUS_BYNAME = "/connectors/{name}/status";
	private static final String PAUSE_CONNECTORS_BYNAME = "/connectors/{name}/pause";
	private static final String RESUME_CONNECTORS_BYNAME = "/connectors/{name}/resume";
	private static final String RESTART_CONNECTORS_BYNAME = "/connectors/{name}/restart";
	private static final String GET_TASKS_OF_CONNECTORS_BYNAME = "/connectors/{name}/tasks";
	private static final String GET_TOPIC_OF_CONNECTORS_BYNAME = "/connectors/{name}/topics";

	private static final Logger logger = LoggerFactory.getLogger(ConnectorsUtils.class);
	
	public List<String> getAllConnectorsName(String host){
		try {
			String apiUrl = host + GET_CONNECTORS;
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                List<String> connectors = gson.fromJson(responseBody,
          	          new TypeToken<ArrayList<String>>() {}.getType());
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list of ConnectorsName failed ", e);
		}
		return null;
	}
	
	public Object getAllConnectorsStatus(){
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS + "?expand=status";
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list of ConnectorsStatus failed ", e);
		}
		return null;
	}
	
	public Object getAllConnectorsInfo() {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS + "?expand=info";
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list of ConnectorsInfo failed ", e);
		}
		return null;
	}
	
	public Object getAllConnectorsStatusInfo() {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS +"?expand=status&expand=info";
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list of ConnectorsStatusAndInfo failed ", e);
		}
		return null;
	}
	
	public Object getConnectorByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS + name;
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get Connector ByName failed ", e);
		}
		return null;
	}
	
	public Object getConnectorConfigByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS_CONFIG_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get Connector Config ByName failed ", e);
		}
		return null;
	}
	
	public Object getConnectorStatusByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS_STATUS_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get Connector Status ByName failed ", e);
		}
		return null;
	}


	public ConnectorListResponse createConnectorsEnv(String host, String directoryPath) throws IOException {

		ConnectorListResponse connectorListResponse = new ConnectorListResponse();
		List<Object> connectorInfo = new ArrayList<>();
		String resourcePath = "connectorconfig/" + directoryPath;

		Enumeration<URL> resources = getClass().getClassLoader().getResources(resourcePath);
		if (!resources.hasMoreElements()) {
			throw new RuntimeException("Resource not found: " + resourcePath);
		}
		while (resources.hasMoreElements()) {
			URL url = resources.nextElement();
			if (url.getProtocol().equals("jar")) {
				JarURLConnection connection = (JarURLConnection) url.openConnection();
				JarFile jarFile = connection.getJarFile();
				Enumeration<JarEntry> entries = jarFile.entries();
				while (entries.hasMoreElements()) {
					JarEntry jarEntry = entries.nextElement();
					String entryName = jarEntry.getName();
					if (entryName.startsWith(resourcePath + "/") && !jarEntry.isDirectory()) {
						try {
							InputStream inputStream = jarFile.getInputStream(jarEntry);
							BufferedReader fileReader = new BufferedReader(new InputStreamReader(inputStream));
							StringBuilder jsonStringBuilder = new StringBuilder();
							String line;
							while ((line = fileReader.readLine()) != null) {
								jsonStringBuilder.append(line);
							}
							String jsonString = jsonStringBuilder.toString();
							ConnectorRegisterResponse connectorRegisterResponse = createConnector(host, jsonString);
							connectorInfo.add(connectorRegisterResponse);
							connectorListResponse.setObjects(connectorInfo);
							if (connectorRegisterResponse.getStatus() == 201) {
								connectorListResponse.incrementSuccessCount();
							} else if (connectorRegisterResponse.getStatus() == 409) {
								connectorListResponse.incrementAlreadyRegistered();
							} else {
								connectorListResponse.incrementFailureCount();
							}
						} catch (Exception e) {
							logger.error("Error processing jar entry: " + entryName, e);
							throw new RuntimeException(e);
						}
					}
				}
			}
		}
		return connectorListResponse;
	}

	public ConnectorRegisterResponse createConnector(String host, String connector) {
		try {
			String apiUrl = host + GET_CONNECTORS;
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.POST, apiUrl, connector));
			String responseBody = response.getResult();
			Object connectors = gson.fromJson(responseBody, Object.class);

			ConnectorRegisterResponse connectorRegisterResponse = new ConnectorRegisterResponse();
			connectorRegisterResponse.setObject(connectors);
			connectorRegisterResponse.setStatus(response.getStatus());

			return connectorRegisterResponse;
		} catch (Exception e) {
			throw e;
		}
	}

	public List<String> deleteAllConnectors(String host){
		try{
			List<String> responseBody = new ArrayList<>();
			List<String> connectorsList = getAllConnectorsName(host);
			for(String connectorName: connectorsList){
				String response = deleteConnectorByName(host, connectorName);
				responseBody.add(response);
			}
			return responseBody;
		}catch (Exception e){
			throw new RuntimeException("delete connector failed :" + e.getMessage());
		}
	}

	public String deleteConnectorByName(String host, String connectorName) {
		try {
			String apiUrl = host + GET_CONNECTORS + "/" + connectorName;
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.DELETE, apiUrl));
			if(response.getStatus()==204){
				String responseBody = "Successfully deleted connector : "+connectorName;
				return responseBody;
			}
			else {
				return response.getResult();
			}
		}catch (Exception e){
			throw new RuntimeException("delete connector failed", e);
		}
	}


	
	//not tested
	public Object UpdateConnectorConfigByName(Object connector, String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_CONNECTORS_CONFIG_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.PUT, apiUrl, gson.toJson(connector)));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Update Connector Config ByName failed ", e);
		}
		return null;
	}
	
	public String pauseConnectorByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + PAUSE_CONNECTORS_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.PUT, apiUrl));
            if (response.getStatus() == 202) { 
                return "Successful Pause Connector "+ name;
            }
		} catch (Exception e) {
			throw new RuntimeException("Pause Connector failed ", e);
		}
		return null;
	}
	
	public String resumeConnectorByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + RESUME_CONNECTORS_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.PUT, apiUrl));
            if (response.getStatus() == 202) { 
                return "Successful Resume Connector " + name;
            }
		} catch (Exception e) {
			throw new RuntimeException("Resume Connector failed ", e);
		}
		return null;
	}
	
	public String restartConnectorInstanceByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + RESTART_CONNECTORS_BYNAME.replace("{name}", name) + "?includeTasks=false&onlyFailed=false";
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.POST, apiUrl));
            if (response.getStatus() == 202) { 
                return "Successful Restart Connector " + name;
            }
		} catch (Exception e) {
			throw new RuntimeException("Restart Connector failed ", e);
		}
		return null;
	}
	
	public Object restartConnectorInstanceAndTaskInstanceByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + RESTART_CONNECTORS_BYNAME.replace("{name}", name) + "?includeTasks=true&onlyFailed=true";
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.POST, apiUrl));
            if (response.getStatus() == 202) { 
            	String responseBody = response.getResult();
                Object connectors = gson.fromJson(responseBody, Object.class);
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Restart Connector failed ", e);
		}
		return null;
	}
	
	public List<Object> getAllTaskConnectorsByName(String name){
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_TASKS_OF_CONNECTORS_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                List<Object> connectors = gson.fromJson(responseBody,
          	          new TypeToken<ArrayList<Object>>() {}.getType());
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list Task assign to Connectors failed ", e);
		}
		return null;
	}
	
	public Object getAllTopicOfConnectorsByName(String name) {
		try {
			String apiUrl = properties.getConnectorsServiceHost() + GET_TOPIC_OF_CONNECTORS_BYNAME.replace("{name}", name);
			APIUtils apiUtils = new APIUtils();
			ApiResponse response = apiUtils.send(new ApiRequest(HttpMethod.GET, apiUrl));
            if (response.getStatus() == 200) {
                String responseBody = response.getResult();
                List<Object> connectors = gson.fromJson(responseBody,
          	          new TypeToken<ArrayList<Object>>() {}.getType());
                return connectors;
            }
		} catch (Exception e) {
			throw new RuntimeException("Get list Topic assign to Connectors failed ", e);
		}
		return null;
	}

}
