package com.nsl.novus.utils;

import java.util.Collections;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.ListTopicsOptions;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.errors.TopicExistsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AdminClientUtils {
	
	private static final Logger logger = LoggerFactory.getLogger(AdminClientUtils.class);
	
	public Set<String> listKafkaTopics(Properties properties) throws ExecutionException, InterruptedException {
        try (AdminClient adminClient = AdminClient.create(properties)) {
            ListTopicsOptions options = new ListTopicsOptions().timeoutMs(5000);
            ListTopicsResult topicsResult = adminClient.listTopics(options);
            Set<String>  allTopics = topicsResult.names().get();
            String internalTopicRegex = "_.*";
            return allTopics.stream()
            		.filter(topic -> !topic.matches(internalTopicRegex))
            		.collect(Collectors.toSet());
        } catch (InterruptedException | ExecutionException e) {
        	logger.error("Getting error while accessing ListKafkaTopics", e.getLocalizedMessage());
        	throw new RuntimeException("Getting error while accessing ListKafkaTopics",e);
        }
    }
	
	public String createKafkaTopic(String topicName, Properties properties, int numPartitions, short replicationFactor) {
		try (AdminClient adminClient = AdminClient.create(properties)) {
			if (!topicExists(adminClient, topicName)) {
				NewTopic newTopic = new NewTopic(topicName, numPartitions, replicationFactor);
				adminClient.createTopics(Collections.singletonList(newTopic)).all()
						.whenComplete((createdTopics, throwable) -> {
							if (throwable == null) {
								logger.info("Topic {} created successfully.", topicName);
								return;
							} else {
								handleTopicCreationFailure(throwable, topicName);
							}
						}).get();
				return "Topic created successfully";

			} else {
				logger.warn("Topic {} already exists.",topicName);
				return "Topic already exists";
			}

		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getLocalizedMessage());
			throw new RuntimeException("Failed to create topic", e);
		}
	}
	
	private static boolean topicExists(AdminClient adminClient, String topicName)
			throws InterruptedException, ExecutionException {
		return adminClient.listTopics().names().get().contains(topicName);
	}

	private static void handleTopicCreationFailure(Throwable throwable, String topicName) {
		if (throwable instanceof TopicExistsException) {
			logger.warn("Topic {} already exists.", topicName);
			throw new RuntimeException("Topic already exists", throwable);
		} else {
			logger.error("Failed to create topic {}: {}", topicName, throwable.getMessage());
			throw new RuntimeException("Failed to create topic", throwable);
		}
	}
}
