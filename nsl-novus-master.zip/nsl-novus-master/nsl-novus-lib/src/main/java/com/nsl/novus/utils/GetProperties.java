package com.nsl.novus.utils;

import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GetProperties {
	
	private static final Logger logger = LoggerFactory.getLogger(GetProperties.class);
	
	private String bootstrapServers;
	private int numPartitions;
	private short replicationFactor;
	private String connectorsServiceHost;
	
	public GetProperties() {
		Properties properties = new Properties();
		try (InputStream input = NovusAdminUtils.class.getClassLoader().getResourceAsStream("nsl-novus-lib-config.properties")) {
			if (input == null) {
				logger.warn("unable to find config.properties file");
				return;
			}
			properties.load(input);

			this.bootstrapServers = properties.getProperty("bootstrapServers");
			this.numPartitions = Integer.parseInt(properties.getProperty("numPartitions"));
			this.replicationFactor = Short.parseShort(properties.getProperty("replicationFactor"));
			this.connectorsServiceHost = properties.getProperty("connectorsServiceHost");

		} catch (Exception e) {
			throw new RuntimeException("Getting error on accessing nsl-novus-lib-config.properties file", e);
		}
	}

	public String getBootstrapServers() {
		return bootstrapServers;
	}

	public void setBootstrapServers(String bootstrapServers) {
		this.bootstrapServers = bootstrapServers;
	}

	public int getNumPartitions() {
		return numPartitions;
	}

	public void setNumPartitions(int numPartitions) {
		this.numPartitions = numPartitions;
	}

	public short getReplicationFactor() {
		return replicationFactor;
	}

	public void setReplicationFactor(short replicationFactor) {
		this.replicationFactor = replicationFactor;
	}

	public String getConnectorsServiceHost() {
		return connectorsServiceHost;
	}

	public void setConnectorsServiceHost(String connectorsServiceHost) {
		this.connectorsServiceHost = connectorsServiceHost;
	}

}
