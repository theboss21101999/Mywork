package com.nsl.novus.enums;

public enum HttpMethod {
	GET, POST, PUT, DELETE
}
