package com.nsl.novus.model;

import java.util.List;

public class ConnectorListResponse {
    private int successCount=0;
    private int failureCount=0;
    private int alreadyRegistered=0;

    public int getAlreadyRegistered() {
        return alreadyRegistered;
    }

    public void setAlreadyRegistered(int alreadyRegistered) {
        this.alreadyRegistered = alreadyRegistered;
    }

    private List<Object> objects;
    public List<Object> getObjects() {
        return objects;
    }

    public void setObjects(List<Object> objects) {
        this.objects = objects;
    }

    public int getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(int successCount) {
        this.successCount = successCount;
    }

    public int getFailureCount() {
        return failureCount;
    }

    public void setFailureCount(int failureCount) {
        this.failureCount = failureCount;
    }

    public void incrementSuccessCount(){
        this.successCount++;
    }

    public void incrementFailureCount(){
        this.failureCount++;
    }

    public void incrementAlreadyRegistered(){
        this.alreadyRegistered++;
    }
}
