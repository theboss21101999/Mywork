package com.nsl.novus;

import com.google.gson.Gson;
import com.nsl.novus.utils.ConnectorsUtils;
import com.nsl.novus.utils.NovusAdminUtils;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class LibraryMain {
    public static void main(String[] args) throws ExecutionException, InterruptedException, IOException, URISyntaxException {
//        System.out.println("Hello");
//
//        Gson gson = new Gson();
//
//        NovusAdminUtils utils = new NovusAdminUtils();
//        utils.getListKafkaTopics();
//
//        ConnectorsUtils connectorsUtils = new ConnectorsUtils();

//        InputStream connectorConfig = NovusAdiminUtils.class.getClassLoader().getResourceAsStream("qa3/mysql-debezium-connector.json");
//        String jsonConfig = new String(connectorConfig.readAllBytes(), StandardCharsets.UTF_8);
//        Object object = connectorsUtils.createConnector(jsonConfig);
//        System.out.println("Connector is successfully registered");
//
//        System.out.println("The details of connector is" + gson.toJson(object));

//        List<Object> connectorConfigs = connectorsUtils.createConnectorsEnv("qa3");
//        System.out.println("Connectors are successfully registered");
//        for (Object connectorConfig : connectorConfigs){
//            System.out.println(gson.toJson(connectorConfig));
//        }
//        String response = connectorsUtils.deleteConnectorByName("http://localhost:8083", "CodeGenSinkConnectorConnector_0");
//        System.out.println(response);

//        List<String> response = connectorsUtils.deleteAllConnectors("http://localhost:8083");
//        System.out.println(response);
    }
}
