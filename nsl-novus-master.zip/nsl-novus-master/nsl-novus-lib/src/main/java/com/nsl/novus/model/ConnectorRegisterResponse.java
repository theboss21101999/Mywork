package com.nsl.novus.model;

import java.util.ArrayList;

public class ConnectorRegisterResponse {
    int status;
    Object object;
    public ConnectorRegisterResponse() {
    }
    public ConnectorRegisterResponse(Object object) {
        this.object = object;
    }

    public Object getObject() {
        return object;
    }

    public void setObject(Object object) {
        this.object = object;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
