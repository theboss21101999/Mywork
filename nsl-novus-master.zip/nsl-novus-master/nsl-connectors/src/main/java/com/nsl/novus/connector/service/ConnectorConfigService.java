package com.nsl.novus.connector.service;

import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ConnectorConfigService {

  private static final String CONFIG_DIR = "config/";

  @Value("${confluent.connector.url}")
  private String connectorUrl;

  public JsonNode createConnectorConfig(String connectorType, Map<String, String> configValues) {

    var connectorConfig = getConnectorConfig(connectorType, configValues);
    return postConnectorConfig(connectorConfig);

  }

  private String getConnectorConfig(String connectorType, Map<String, String> configValues) {

    try (var inputStream = getClass().getClassLoader().getResourceAsStream(CONFIG_DIR + connectorType + ".json")) {

      var configJson = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
      var strSubstitutor = new StringSubstitutor(configValues);
      return strSubstitutor.replace(configJson);

    } catch (IOException e) {
      throw new RuntimeException(e);
    }

  }

  private JsonNode postConnectorConfig(String connectorConfig) {

    var restTemplate = new RestTemplate();
    var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);

    HttpEntity<String> request = new HttpEntity<String>(connectorConfig, headers);

    ResponseEntity<JsonNode> response = restTemplate.postForEntity(connectorUrl, request, JsonNode.class);
    return response.getBody();

  }

}
