package com.nsl.novus.connector.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.nsl.novus.connector.service.ConnectorConfigService;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/config")
public class ConnectorConfigController {

  @Autowired
  private ConnectorConfigService configService;

  @PostMapping(path = "/{connectorType}", consumes = MediaType.APPLICATION_JSON_VALUE,
    produces = MediaType.APPLICATION_JSON_VALUE)
  public JsonNode createConnectorConfig(@PathVariable String connectorType,
                                        @RequestBody Map<String, String> configValues) {

    return configService.createConnectorConfig(connectorType, configValues);

  }


}
