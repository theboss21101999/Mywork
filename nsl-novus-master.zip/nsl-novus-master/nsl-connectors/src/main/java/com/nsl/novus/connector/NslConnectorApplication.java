package com.nsl.novus.connector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NslConnectorApplication {
  //private static final Logger LOG = LoggerFactory.getLogger(Kafdrop.class);

  public static void main(String[] args) {
    SpringApplication.run(NslConnectorApplication.class, args);
  }

}

