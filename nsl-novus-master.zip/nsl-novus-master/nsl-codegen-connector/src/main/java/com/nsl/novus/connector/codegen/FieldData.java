package com.nsl.novus.connector.codegen;

public class FieldData{
    String originalName;
    String modifiedName;
    String avroName;
    Boolean isModified = false;

    FieldData(){}

    FieldData(String originalName){
        this.originalName = originalName;
        this.modifiedName = originalName;
        this.avroName = originalName;
    }

    public String getModifiedName() {
        return modifiedName;
    }

    public void setModifiedName(String modifiedName) {
        this.modifiedName = modifiedName;
    }

    public String getOriginalName() {
        return originalName;
    }

    public void setOriginalName(String originalName) {
        this.originalName = originalName;
    }

    public Boolean getModified() {
        return isModified;
    }

    public void setModified(Boolean modified) {
        isModified = modified;
    }

    public String getAvroName() {
        return avroName;
    }

    public void setAvroName(String avroName) {
        this.avroName = avroName;
    }
}
