package com.nsl.novus.connector.codegen;

import java.io.File;
import java.util.*;

import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.KafkaFuture;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.connect.data.Struct;
import org.apache.kafka.connect.sink.SinkRecord;
import org.apache.kafka.connect.sink.SinkTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * Task class for Javapoet Connector.
 */
public class CodeGenSinkTask extends SinkTask {

  private static final Logger log = LoggerFactory.getLogger(CodeGenSinkTask.class);

  private CodeGenSinkConnectorConfig config;
  private Map<TopicPartition, OffsetAndMetadata> topicOffsets;
  private JavapoetClassGenerator javapoetClassGenerator ;

  private String destinationPath;
  private String jarsPath;
  private String kafkaBrokers;

  @Override
  public void start(Map<String, String> settings) {
    this.config = new CodeGenSinkConnectorConfig(settings);
    topicOffsets = new HashMap<>();
    this.kafkaBrokers = context.configs().get("kafka.advertised.listener");
    this.jarsPath = context.configs().get("plugin.path");
    this.destinationPath = jarsPath+ File.separator+"src";
    File directory = new File(destinationPath);
    directory.mkdir();

    javapoetClassGenerator = new JavapoetClassGenerator();
  }


  @Override
  public void put(Collection<SinkRecord> records) {
    log.info("Received messages {}",records.size());
    for (SinkRecord record : records) {

      log.info("message {} '{}'",record.value().getClass(),record.value());

      // Commit offset in the case of successful processing of sink record
      topicOffsets.put(new TopicPartition(record.topic(), record.kafkaPartition()),
              new OffsetAndMetadata(record.kafkaOffset() + 1));

      Object value = record.value();

      if (value instanceof Struct) {
        Struct valueStruct = (Struct) value;

        // Access the "tableChanges" field
        Object tableChanges = valueStruct.get("tableChanges");
        log.info("Object details: {}", tableChanges);

        if (tableChanges instanceof List) {
          List<?> tableChangesList = (List<?>) tableChanges;

          // Assuming there's only one table change in the list
          if (!tableChangesList.isEmpty()) {
            Object firstTableChange = tableChangesList.get(0);

            if (firstTableChange instanceof Struct) {
              Struct tableChangeStruct = (Struct) firstTableChange;

              // Access the "table" field
              Object tableField = tableChangeStruct.get("table");
              String tableId = tableChangeStruct.getString("id");
              Object[] tableIdParts = Arrays.stream(tableId.split("\\.\"")).map(str->str.replace("\"","")).toArray();
              String tableHeading = "";
              String dataBaseName = "";
              if(tableIdParts.length>1) {
                dataBaseName = tableIdParts[0].toString();
                tableHeading = tableIdParts[tableIdParts.length-1].toString();
                log.info("The table heading is `{}`",tableHeading);
              }
              else {
                // the id field of the table is not having correct format
                log.error("Invalid table ID");
              }

              if (tableField instanceof Struct) {
                Struct tableStruct = (Struct) tableField;

                // Access the "columns" field
                Object columnsField = tableStruct.get("columns");
                // Access "primary keys"
                List<?> primaryKeysList = (List<?>) tableStruct.get("primaryKeyColumnNames");

                if (columnsField instanceof List) {
                  log.info("the destination path is `{}`",destinationPath);
                  log.info("the jars path is `{}`",jarsPath);
                  List<?> columnsList = (List<?>) columnsField;
                  String packageName = record.topic()+"."+dataBaseName;
                  boolean compileStatus = javapoetClassGenerator.init(columnsList,tableHeading,packageName,primaryKeysList,destinationPath,jarsPath);

//                  if(compileStatus){
//                    createKafkaTopic(record.topic()+"."+dataBaseName+"."+tableHeading);
//                  }
                }
              }
            }
          }
        }
      }
    }
  }

  public void createKafkaTopic(String topicName){
    topicName = topicName.replace(" ","_");
    Properties properties = new Properties();
    properties.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, this.kafkaBrokers);

    // Create AdminClient
    try (AdminClient adminClient = AdminClient.create(properties)) {
      // Define new topic
      int numPartitions = 3;
      short replicationFactor = 1;

      NewTopic newTopic = new NewTopic(topicName, numPartitions, replicationFactor);

      // Create the topic
      if(!doesTopicExist(adminClient,topicName)) {
        adminClient.createTopics(Collections.singletonList(newTopic)).all().get();
        log.info("Topic created successfully.");
      }
    } catch (Exception e) {
      // wrong kafka broker address
      log.error("",e);
    }
  }

  public boolean doesTopicExist(AdminClient adminClient, String topicName) {
    DescribeTopicsResult describeTopicsResult = adminClient.describeTopics(Collections.singletonList(topicName));

    try {
      KafkaFuture<TopicDescription> topicDescriptionFuture = describeTopicsResult.values().get(topicName);
      TopicDescription topicDescription = topicDescriptionFuture.get();
      return topicDescription != null;
    } catch (Exception e) {
      return false;
    }
  }

  @Override
  public Map<TopicPartition, OffsetAndMetadata> preCommit(
          Map<TopicPartition, OffsetAndMetadata> currentOffsets
  ) {
    return currentOffsets;
  }

  @Override
  public void stop() {
    close();
  }

  void close() {
  }

  @Override
  public String version() {
    return CodeGenSinkConnectorConfig.VERSION;
  }
}