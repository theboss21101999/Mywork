package com.nsl.novus.connector.codegen;

import java.util.Arrays;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.kafka.common.config.AbstractConfig;
import org.apache.kafka.common.config.ConfigDef;

public class CodeGenSinkConnectorConfig extends AbstractConfig {

  public static String VERSION = "1.0";

  private static final String CONFIG_CONNECTION_GROUP = "Path Specification";

  public static final String CONFIG_NAME_JARS_PATH = "plugin.path";
  private static final String CONFIG_DOCUMENTATION_JARS_PATH = "The absolute path to get the jar files.";
  private static final String CONFIG_DISPLAY_JARS_PATH = "plugin path";

  public static final String CONFIG_NAME_BOOTSTRAP_SERVER = "kafka.advertised.listener";
  private static final String CONFIG_DOCUMENTATION_BOOTSTRAP_SERVER = "The advertised bootstrap server";
  private static final String CONFIG_DISPLAY_BOOTSTRAP_SERVER = "Bootstrap Server";

  private static final Pattern TOPIC_KS_TABLE_SETTING_PATTERN =
          Pattern.compile("topic\\.([a-zA-Z0-9._-]+)\\.([^.]+|\"[\"]+\")\\.([^.]+|\"[\"]+\")\\.(mapping|consistencyLevel|ttlSeconds|deletesEnabled)$");

  public CodeGenSinkConnectorConfig(Map<?, ?> originals) {
    super(config(), originals);
  }

  public static ConfigDef config() {
    ConfigDef config = new ConfigDef();

    config.define(CONFIG_NAME_JARS_PATH,
            ConfigDef.Type.STRING,
            ConfigDef.NO_DEFAULT_VALUE,
            ConfigDef.Importance.HIGH,
            CONFIG_DOCUMENTATION_JARS_PATH,
            CONFIG_CONNECTION_GROUP,
            1,
            ConfigDef.Width.LONG,
            CONFIG_DISPLAY_JARS_PATH);
//    config.define(CONFIG_NAME_BOOTSTRAP_SERVER,
//            ConfigDef.Type.STRING,
//            ConfigDef.NO_DEFAULT_VALUE,
//            ConfigDef.Importance.HIGH,
//            CONFIG_DOCUMENTATION_BOOTSTRAP_SERVER,
//            "Kafka Broker",
//            1,
//            ConfigDef.Width.LONG,
//            CONFIG_DISPLAY_BOOTSTRAP_SERVER);

    return config;
  }

  private String tryMatchTopicName(final String name) {
    final Matcher m = CodeGenSinkConnectorConfig.TOPIC_KS_TABLE_SETTING_PATTERN.matcher(name);
    if (m.matches()) {
      return m.group(1);
    }
    throw new IllegalArgumentException("The setting: " + name + " does not match topic.keyspace.table nor topic.codec regular expression pattern");
  }

  private static String[] toStringArray(Object[] arr){
    return Arrays.stream(arr).map(Object::toString).toArray(String[]::new);
  }

  /**
   * Enums for behavior on error.
   */
  public enum BehaviorOnError {
    IGNORE,
    LOG,
    FAIL
  }

}
