package com.nsl.novus.connector.codegen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.kafka.common.config.Config;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.connect.connector.Task;
import org.apache.kafka.connect.sink.SinkConnector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CodeGenSinkConnector extends SinkConnector {

  private static final Logger log = LoggerFactory.getLogger(CodeGenSinkConnector.class);

  CodeGenSinkConnectorConfig config;
  
  @Override
  public void start(Map<String, String> settings) {
    config = new CodeGenSinkConnectorConfig(settings);
  }

  @Override
  public List<Map<String, String>> taskConfigs(int maxTasks) {
    List<Map<String, String>> configs = new ArrayList<>();
    Map<String, String> taskProps = new HashMap<>();
    taskProps.putAll(config.originalsStrings());
    for (int i = 0; i < maxTasks; i++) {
      configs.add(taskProps);
    }
    return configs;
  }

  @Override
  public void stop() {
    log.info("Stopping CodeGen Connector.");
  }

  @Override
  public ConfigDef config() {
    return CodeGenSinkConnectorConfig.config();
  }

  @Override
  public Class<? extends Task> taskClass() {
    return CodeGenSinkTask.class;
  }

  @Override
  public String version() {
    return CodeGenSinkConnectorConfig.VERSION;
  }

  @Override
  public Config validate(Map<String, String> connectorConfigs){

    Config result = super.validate(connectorConfigs);
    return result;
  }

}
