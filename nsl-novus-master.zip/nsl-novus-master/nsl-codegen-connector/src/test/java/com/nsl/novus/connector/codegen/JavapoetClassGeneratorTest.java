package com.nsl.novus.connector.codegen;

import org.junit.Test;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.Assert.*;

public class JavapoetClassGeneratorTest {
    JavapoetClassGenerator javapoetClassGenerator = new JavapoetClassGenerator();
    @Test
    public void shouldCapitaliseTheFirstLetterOnly(){
        assertEquals("Same",javapoetClassGenerator.toTitleCase("same"));
        assertEquals("Nsl_users",javapoetClassGenerator.toTitleCase("Nsl_users"));
        assertEquals("Nsl users",javapoetClassGenerator.toTitleCase("Nsl users"));
    }

    @Test
    public void shouldValidateTopicName(){
        assertTrue(javapoetClassGenerator.isValidTopicName("alphaOmega"));
        assertFalse(javapoetClassGenerator.isValidTopicName("alpha Omega"));
        assertTrue(javapoetClassGenerator.isValidTopicName("alpha-Omega"));
        assertTrue(javapoetClassGenerator.isValidTopicName("alpha_Omega"));
        assertTrue(javapoetClassGenerator.isValidTopicName("alpha.Omega"));
        assertTrue(javapoetClassGenerator.isValidTopicName("alpha...Omega"));
    }

    @Test
    public void shouldCreateAValidFieldName(){
        assertEquals("myDOTName",javapoetClassGenerator.convertToValidJavaVariableName("my.name"));
        assertEquals("myDOTName",javapoetClassGenerator.convertToValidJavaVariableName("My.name"));
        assertEquals("myDOTName",javapoetClassGenerator.convertToValidJavaVariableName("My.Name"));
        assertEquals("myName",javapoetClassGenerator.convertToValidJavaVariableName("MyName"));
        assertEquals("my_Name",javapoetClassGenerator.convertToValidJavaVariableName("My___Name"));
        assertEquals("my_Name_is",javapoetClassGenerator.convertToValidJavaVariableName("My____Name____is"));
        assertEquals("_1Ans",javapoetClassGenerator.convertToValidJavaVariableName("1Ans"));
    }

    @Test
    public void shouldSplitStringProperly(){

        String x = "\"part1\".\"part2...part3\"";
        Object[] parts = Arrays.stream(x.split("\\.\"")).map(str->str.replace("\"","")).toArray();
        System.out.println(parts[1].toString());
        assertEquals(2, parts.length);
    }
}
